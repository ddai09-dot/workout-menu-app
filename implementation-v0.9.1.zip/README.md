# 筋トレメニュー提案アプリ 実装基盤 v0.9.1

タスク12〜19の開発スナップショットに、タスク19.5-B2〜B4のDB・Migration・検証基盤是正、C1〜C4のローカル実装、C3の週間生成トレース、C4の通知設定SQLite Repository接続、C4後のタスク19.5-D「MVP外部機能の通常UI除外」とタスク20-A「端末内データ初期化・Flutter統合事前確認」と、タスク20-Bの再現可能なFlutter／iOS実行レーンを反映したFlutterプロジェクトです。

この成果物は**配布可能な完成アプリではありません**。初期登録、週間計画、トレーニング実施、記録・進行提案にはローカル実装がありますが、Flutter・iOS統合検証は未完了です。現環境ではSDK／Xcode不足によりBLOCKEDであり、実行レーンと証跡収集だけを準備済みです。MVPは端末内で完結する主要機能へ固定し、アカウント同期、AI相談、ネイティブ通知は通常UIとルートから除外しました。Schemaと接続境界は将来再開用として保持しています。

## 現在の基準

- アプリ版：`0.9.1+19`
- ローカルDB：Schema v9／75テーブル
- 種目：72
- 器具：48
- フォーム画像メタデータ：144
- 進行プロフィール：216
- 通知設定の運用正本：`notification_preference`
- 旧通知設定の保全先：`notification_setting_legacy_archive`
- Migration：v1→v9の連続経路を検証済み

## 主要なローカル実装

- Feature-first MVVM、Riverpod 3、go_routerによる4タブ
- 初期登録13画面、質問単位の直列化自動保存、途中復帰
- 固定式／可変式ダンベル、バーベル、曜日別場所の詳細登録
- 月曜始まりの週間メニュー作成、休養週、再生成、履歴保持
- 経験、器具、時間、痛み、優先部位を使うルールベース生成
- 開始前調整、8記録方式、セット自動保存、休憩、訂正、代替、スキップ
- アプリ再起動・中断・日付またぎからのセッション復帰用データ構造
- 終了後評価と完了／一部完了判定
- 記録ダッシュボード、履歴、種目別比較系列、自己ベスト
- 体重・体脂肪率の追記型記録と訂正履歴
- 結果分類、進歩・停滞判定、安全条件付きの次回提案
- 提案の採用、維持、保留、拒否、再提示抑制
- 72種目のフォーム説明文言表示、トレーニング中・記録詳細からの導線
- 画像1・画像2のスロット単位フォールバック、状態・URI・SHA-256・AssetBundle実在確認
- 同梱画像の成功キャッシュと、失敗時に再試行できる読込境界
- マイページから目的、経験、環境・器具、通常予定、分け方、優先部位、痛み・制限を個別編集
- 項目別の差分保存、未保存変更の破棄確認、保存失敗時の入力保持
- 器具削減・制限強化時だけ今週の確認を案内し、作成済みメニューと記録は自動変更しない
- 週間生成アルゴリズム仕様v1.1の13工程トレースを生成結果へ保存・再読込
- 通知設定4種類を`notification_preference`へ永続化し、時刻・事前通知を編集
- 通知設定変更時に同種の旧予約を取消し、`notification_schedule`へ状態反映
- MVP通常UIからアカウント同期、AI相談、通知設定を除外し、ローカル用語・FAQだけを残す
- `/my-page/account`、`/ai-coach`、`/my-page/notifications`の通常ルートを削除
- マイページから端末内データを二段階確認後に完全削除し、新しい匿名IDで初期登録へ戻す

## MVP外部機能の扱い

- アカウント同期：MVPから一時的に除外・後回し。通常UIとルートは削除。Schema、Repository、Outbox、競合処理試作は将来境界として保持
- AI相談：MVPから一時的に除外・後回し。通常UIとルートは削除。AI Schema、Edge Function境界、安全語判定は将来境界として保持
- ネイティブ通知：MVPから一時的に除外・後回し。通知設定の通常UIとルートは削除。SQLite設定Repository、予約取消境界、Gateway Stubは保持
- 用語・FAQ：外部サービスを使わないローカル機能として通常UIに残す
- 休憩タイマー：アプリ内タイマーは残す。バックグラウンドOS通知はMVP要件に含めない
- フォーム説明：72種目の文言表示、2画像スロットの可用性判定、画像なしフォールバックをローカル実装済み。実画像144枚は未同梱
- マイページ通常設定編集：7カテゴリのローカル編集を実装済み。Flutter／iOS統合検証前

## Schema・Migrationの是正

### v6→v7

欠落していたSQL Migrationを追加し、AppDatabase内のMigrationと正本SQLの一致を検証しています。

### v8→v9

- 運用上の唯一の通知設定正本：`notification_preference`
- 旧行の全12列：`notification_setting_legacy_archive`へ原文保持
- 旧運用テーブル：削除
- 未知の曜日コード：推測せず`REVIEW_REQUIRED_WEEKDAY`

### v1→v9

- 8本のMigrationを順番に適用
- 各Schema段階のテーブル数と外部キーを確認
- v1時点の代表的なユーザー・週間計画・実績行を保持
- Seed内容を保持
- 最終構造を新規Schema v9と一致させる
- AppDatabaseに埋め込まれたMigration SQLも正本SQLと一致確認

新規Schema v2〜v9のスナップショットは、連続Migration後の物理列順・索引・Triggerを正として再生成しています。

## 検証

```bash
make verify
```

主な検証内容：

- v1→v9連続Migration
- AppDatabase MigrationとSQL正本の一致
- Schema v9 SeedとJSON資産の整合
- Seedの再適用冪等性
- 12 Repositoryファイル、262 SQL呼出、263 SQL分岐のSQLiteコンパイル
- 動的テーブル・列識別子の実在確認
- 初期登録、週間計画、実施、記録・進行、フォーム説明、通常設定編集、通知設定SQLite Repository、MVP外部機能非表示、端末内データ初期化の契約テスト
- 通知設定統合Migration
- ローカルimportと区切り文字の静的確認
- README、Version Matrix、Roadmap、CI、Makefileの版整合性
- Task20-BのFlutter／iOS実行スクリプト、公式SDK installer、Action SHA固定、ログ保存、GitHub Actions実行レーンの静的契約

## Flutter・iOS統合検証

Flutter側の正規実行入口：

```bash
./tools/run_task20_b_flutter_checks.sh
```

macOS／Xcode側の正規実行入口：

```bash
./tools/run_task20_b_ios_simulator.sh
```

前者は依存解決、コード生成、`make verify`、静的解析、custom_lint、Flutter Testがすべて成功した場合だけPASSを記録します。後者は同じ検証に加えてiOS Simulator debug buildが成功した場合だけPASSを記録します。ログと機械可読な`result.json`は`build/task20_b_logs/`へ出力します。

初回のプラットフォーム雛形生成だけを行う場合：

```bash
./tools/bootstrap_flutter_project.sh
```

Windowsではシェルスクリプトの内容をPowerShellまたはGit Bashで実行してください。

## 未実施

この作成環境にはFlutter SDKとXcodeがないため、以下は未実施です。

- `flutter pub get`
- `pubspec.lock`生成・固定
- Driftコード生成
- `flutter analyze`
- `custom_lint`
- `flutter test`（フォーム、通常設定編集、通知Repository、端末内データ初期化の追加テストを含む）
- Widget Test／Golden Test
- iOS Simulator／iPhone実機ビルド
- Apple認証、Supabase RLS・同期関数、OpenAI実API、iOS実通知

`pubspec.lock`はFlutter環境で依存解決後に生成し、アプリプロジェクトの正本としてGit管理します。現時点で存在しないlockファイルを作成済みとは扱いません。

- タスク19.5-C3：週間生成アルゴリズム仕様v1.1の13工程トレースを保存し、部分対応を明示。
- タスク19.5-C4：通知設定SQLite Repository接続。ネイティブiOS通知はStub。
- タスク19.5-D：アカウント同期、AI相談、ネイティブ通知をMVP通常UIとルートから除外。用語・FAQとアプリ内休憩タイマーは維持。

- タスク20-A：端末内データ初期化をローカル実装し、53ユーザー所有テーブルの削除範囲、他ユーザー・マスタ保持、外部キーをSQLiteで検証。Flutter／iOS実行は未実施。
- 一時的に除外した機能は `docs/PARKING_LOT.md`、採用・削除理由は `docs/DECISION_LOG.md` で管理。


## タスク20-B2のCI強化

- 採用：Google公式release metadataからFlutter 3.44.6を導入し、release ref `ee80f08`とSHA-256を検証
- 採用理由：SDKの版だけでなく由来と完全性を固定し、CI結果を再検証可能にするため
- 完全削除：`subosito/flutter-action`。公式archive方式へ一本化したため後回しではない
- 一時的に除外・後回し：cross-run cache。初回Flutter／iOS PASS後にPL-004の条件で再検討
- GitHub Actions：全`uses:`を完全長commit SHAへ固定し、`contents: read`、checkout credential非保持
- 証跡：工程別`steps.ndjson`、`result.json`、`pubspec.lock`、生成`.g.dart`、Simulator `.app`

## タスク20-Bの現在地

- 判定：`BLOCKED／未完了`
- 採用：Ubuntu系Flutter検証とmacOS iOS Simulator検証を分離した再現可能な実行レーン
- 採用理由：Flutter共通不具合とiOS固有不具合を分け、失敗工程と証跡を残せるため
- 削除：なし
- 現環境で未実施：`flutter pub get`、`pubspec.lock`、Drift生成、analyze、custom_lint、Flutter Test、iOS build
- 完了判定：GitHub Actionsまたは同等のFlutter 3.44.6／macOS Xcode環境で実結果がPASSになった時点
