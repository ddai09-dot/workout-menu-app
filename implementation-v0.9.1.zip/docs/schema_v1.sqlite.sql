-- Workout Menu App / Drift schema v1
-- Dates and timestamps are ISO-8601 TEXT. UUID/ULID and enums are TEXT.
-- Do not reuse stable codes, even after logical deletion.

CREATE TABLE body_part_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  parent_body_part_id TEXT REFERENCES body_part_master(id) ON DELETE RESTRICT,
  split_group_code TEXT,
  display_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE movement_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  movement_group_code TEXT NOT NULL
);

CREATE TABLE equipment_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  equipment_category_code TEXT NOT NULL,
  supports_weight_options INTEGER NOT NULL DEFAULT 0,
  supports_quantity INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE joint_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE fatigue_tag_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fatigue_group_code TEXT NOT NULL
);

CREATE TABLE exercise_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  series_code TEXT,
  technical_difficulty_code TEXT NOT NULL,
  role_code TEXT NOT NULL,
  exercise_class_code TEXT NOT NULL,
  execution_mode_code TEXT NOT NULL,
  recording_method_code TEXT NOT NULL,
  beginner_availability TEXT NOT NULL,
  intermediate_availability TEXT NOT NULL,
  advanced_availability TEXT NOT NULL,
  default_priority_code TEXT NOT NULL DEFAULT 'STANDARD',
  image_angle_code TEXT
);

CREATE TABLE exercise_body_part (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  body_part_id TEXT NOT NULL REFERENCES body_part_master(id) ON DELETE RESTRICT,
  relation_type TEXT NOT NULL
);

CREATE TABLE exercise_movement (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  movement_id TEXT NOT NULL REFERENCES movement_master(id) ON DELETE RESTRICT,
  relation_type TEXT NOT NULL
);

CREATE TABLE exercise_equipment_option (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  option_code TEXT NOT NULL,
  display_order INTEGER NOT NULL DEFAULT 1,
  is_active INTEGER NOT NULL DEFAULT 1,
  source_text TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE exercise_equipment (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  equipment_option_id TEXT NOT NULL REFERENCES exercise_equipment_option(id) ON DELETE RESTRICT,
  equipment_id TEXT NOT NULL REFERENCES equipment_master(id) ON DELETE RESTRICT,
  requirement_type TEXT NOT NULL,
  minimum_quantity INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE exercise_joint (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  joint_id TEXT NOT NULL REFERENCES joint_master(id) ON DELETE RESTRICT,
  risk_level TEXT NOT NULL DEFAULT 'NORMAL'
);

CREATE TABLE exercise_fatigue_tag (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  fatigue_tag_id TEXT NOT NULL REFERENCES fatigue_tag_master(id) ON DELETE RESTRICT,
  fatigue_weight REAL NOT NULL DEFAULT 1.0
);

CREATE TABLE exercise_alternative (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  alternative_exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  reason_code TEXT NOT NULL,
  priority INTEGER NOT NULL DEFAULT 100,
  CONSTRAINT ck_no_self CHECK (exercise_id <> alternative_exercise_id)
);

CREATE TABLE exercise_progression_profile (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  goal_code TEXT NOT NULL,
  experience_level_code TEXT NOT NULL,
  progression_group_code TEXT NOT NULL,
  target_mode_code TEXT NOT NULL,
  rep_lower INTEGER,
  rep_upper INTEGER,
  duration_lower_sec INTEGER,
  duration_upper_sec INTEGER,
  set_lower INTEGER NOT NULL,
  set_upper INTEGER NOT NULL,
  rest_sec INTEGER NOT NULL,
  CONSTRAINT ck_rep_range CHECK (rep_lower IS NULL OR rep_upper IS NULL OR rep_lower <= rep_upper),
  CONSTRAINT ck_duration_range CHECK (duration_lower_sec IS NULL OR duration_upper_sec IS NULL OR duration_lower_sec <= duration_upper_sec),
  CONSTRAINT ck_set_range CHECK (set_lower <= set_upper)
);

CREATE TABLE exercise_form_copy (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  image_1_label TEXT NOT NULL,
  image_2_label TEXT NOT NULL,
  movement_tip TEXT NOT NULL,
  caution_text TEXT NOT NULL
);

CREATE TABLE exercise_form_asset (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  asset_position INTEGER NOT NULL,
  asset_uri TEXT NOT NULL,
  checksum TEXT NOT NULL,
  asset_status TEXT NOT NULL DEFAULT 'NOT_STARTED',
  CONSTRAINT ck_asset_position CHECK (asset_position IN (1,2))
);

CREATE TABLE user_account (
  id TEXT PRIMARY KEY NOT NULL,
  auth_provider TEXT NOT NULL DEFAULT 'ANONYMOUS',
  auth_subject TEXT UNIQUE,
  account_status TEXT NOT NULL DEFAULT 'ACTIVE',
  locale TEXT NOT NULL DEFAULT 'ja-JP',
  timezone TEXT NOT NULL DEFAULT 'Asia/Tokyo',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT
);

CREATE TABLE user_profile (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  nickname TEXT NOT NULL,
  age_years INTEGER NOT NULL,
  age_updated_on TEXT NOT NULL,
  sex_code TEXT,
  height_cm REAL,
  onboarding_completed_at TEXT
);

CREATE TABLE user_training_setting (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  desired_days_per_week INTEGER NOT NULL,
  usual_duration_min INTEGER NOT NULL,
  location_mode_code TEXT NOT NULL,
  both_usage_mode_code TEXT,
  split_preference_code TEXT NOT NULL DEFAULT 'APP',
  ab_goal_code TEXT NOT NULL DEFAULT 'NONE',
  change_applies_from TEXT NOT NULL DEFAULT 'NEXT_MENU'
);

CREATE TABLE user_experience_profile (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  cumulative_experience_code TEXT NOT NULL,
  continuity_code TEXT NOT NULL,
  hiatus_code TEXT,
  current_frequency INTEGER NOT NULL,
  adjusts_by_history INTEGER NOT NULL DEFAULT 0,
  logs_sets INTEGER NOT NULL DEFAULT 0,
  calculated_level_code TEXT NOT NULL,
  returning_mode INTEGER NOT NULL DEFAULT 0,
  start_volume_factor REAL NOT NULL DEFAULT 1.0,
  calculated_by_rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT
);

CREATE TABLE training_location (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  location_type_code TEXT NOT NULL,
  display_name TEXT NOT NULL,
  gym_profile_code TEXT,
  is_primary INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE location_equipment (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  training_location_id TEXT NOT NULL REFERENCES training_location(id) ON DELETE RESTRICT,
  equipment_id TEXT NOT NULL REFERENCES equipment_master(id) ON DELETE RESTRICT,
  quantity INTEGER NOT NULL DEFAULT 1,
  min_weight REAL,
  max_weight REAL,
  increment_weight REAL,
  has_rack INTEGER NOT NULL DEFAULT 0,
  has_safety INTEGER NOT NULL DEFAULT 0,
  is_available INTEGER NOT NULL DEFAULT 1,
  CONSTRAINT ck_weight_range CHECK ((min_weight IS NULL OR max_weight IS NULL OR min_weight <= max_weight))
);

CREATE TABLE equipment_weight_option (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  location_equipment_id TEXT NOT NULL REFERENCES location_equipment(id) ON DELETE RESTRICT,
  weight_value REAL NOT NULL,
  unit_code TEXT NOT NULL DEFAULT 'KG',
  quantity INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE standard_schedule_day (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  weekday_code TEXT NOT NULL,
  is_available INTEGER NOT NULL DEFAULT 0,
  duration_min INTEGER,
  training_location_id TEXT REFERENCES training_location(id) ON DELETE RESTRICT
);

CREATE TABLE user_goal (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  goal_code TEXT NOT NULL,
  goal_type TEXT NOT NULL,
  display_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE user_priority_part (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  context_code TEXT NOT NULL,
  priority_type TEXT NOT NULL,
  body_part_id TEXT REFERENCES body_part_master(id) ON DELETE RESTRICT,
  appearance_code TEXT,
  CONSTRAINT ck_priority_target CHECK (((body_part_id IS NULL) <> (appearance_code IS NULL)))
);

CREATE TABLE user_restriction (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  restriction_type_code TEXT NOT NULL,
  body_part_id TEXT REFERENCES body_part_master(id) ON DELETE RESTRICT,
  movement_id TEXT REFERENCES movement_master(id) ON DELETE RESTRICT,
  exercise_id TEXT REFERENCES exercise_master(id) ON DELETE RESTRICT,
  default_action_code TEXT NOT NULL,
  effective_from TEXT NOT NULL,
  effective_to TEXT,
  source_code TEXT NOT NULL DEFAULT 'USER'
);

CREATE TABLE notification_setting (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  notification_type_code TEXT NOT NULL,
  is_enabled INTEGER NOT NULL DEFAULT 1,
  time_local TEXT,
  weekday_code TEXT
);

CREATE TABLE app_preference (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  weight_unit_code TEXT NOT NULL DEFAULT 'KG',
  height_unit_code TEXT NOT NULL DEFAULT 'CM',
  appearance_code TEXT NOT NULL DEFAULT 'SYSTEM',
  sound_enabled INTEGER NOT NULL DEFAULT 1,
  rest_timer_default_sec INTEGER NOT NULL DEFAULT 90
);

CREATE TABLE device_registration (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  platform_code TEXT NOT NULL DEFAULT 'IOS',
  app_version TEXT NOT NULL,
  push_token TEXT UNIQUE,
  last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE training_week (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  week_start_date TEXT NOT NULL,
  week_end_date TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'PLANNING',
  CONSTRAINT ck_week_dates CHECK (week_end_date = date(week_start_date, '+6 day')),
  CONSTRAINT ck_week_monday CHECK (strftime('%w', week_start_date) = '1')
);

CREATE TABLE weekly_input (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  same_as_last_week INTEGER NOT NULL DEFAULT 0,
  sleep_score INTEGER NOT NULL,
  motivation_score INTEGER NOT NULL,
  previous_load_score INTEGER,
  goal_rep_achievement_rate REAL,
  weekly_load_direction_code TEXT NOT NULL DEFAULT 'APP',
  increase_method_code TEXT,
  split_override_code TEXT,
  rest_week INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT ck_sleep_score CHECK (sleep_score BETWEEN 1 AND 5),
  CONSTRAINT ck_motivation_score CHECK (motivation_score BETWEEN 1 AND 5),
  CONSTRAINT ck_previous_load_score CHECK (previous_load_score IS NULL OR previous_load_score BETWEEN 1 AND 5),
  CONSTRAINT ck_achievement_rate CHECK (goal_rep_achievement_rate IS NULL OR goal_rep_achievement_rate BETWEEN 0 AND 1)
);

CREATE TABLE weekly_available_day (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  weekday_code TEXT NOT NULL,
  plan_date TEXT NOT NULL,
  is_available INTEGER NOT NULL DEFAULT 0,
  duration_min INTEGER,
  training_location_id TEXT REFERENCES training_location(id) ON DELETE RESTRICT
);

CREATE TABLE weekly_priority_part (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  body_part_id TEXT NOT NULL REFERENCES body_part_master(id) ON DELETE RESTRICT,
  priority_type TEXT NOT NULL
);

CREATE TABLE weekly_pain_entry (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  body_part_id TEXT NOT NULL REFERENCES body_part_master(id) ON DELETE RESTRICT,
  action_code TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'NOTICEABLE_CONTINUE'
);

CREATE TABLE weekly_stalled_exercise (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  detected_by_code TEXT NOT NULL,
  adjustment_code TEXT NOT NULL,
  recommended_adjustment_code TEXT
);

CREATE TABLE weekly_menu (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  menu_version INTEGER NOT NULL DEFAULT 1,
  status_code TEXT NOT NULL DEFAULT 'DRAFT',
  split_code TEXT,
  generated_at TEXT NOT NULL,
  finalized_at TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  generation_input_snapshot_json TEXT NOT NULL
);

CREATE TABLE workout_day_plan (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  weekly_menu_id TEXT NOT NULL REFERENCES weekly_menu(id) ON DELETE RESTRICT,
  plan_date TEXT NOT NULL,
  weekday_code TEXT NOT NULL,
  training_location_id TEXT REFERENCES training_location(id) ON DELETE RESTRICT,
  duration_min INTEGER NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'PLANNED',
  session_focus_snapshot TEXT NOT NULL,
  reason_text_snapshot TEXT NOT NULL
);

CREATE TABLE planned_exercise (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  workout_day_plan_id TEXT NOT NULL REFERENCES workout_day_plan(id) ON DELETE RESTRICT,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  order_index INTEGER NOT NULL,
  exercise_name_snapshot TEXT NOT NULL,
  role_code_snapshot TEXT NOT NULL,
  recording_method_snapshot TEXT NOT NULL,
  target_part_snapshot TEXT NOT NULL,
  reason_text_snapshot TEXT NOT NULL,
  progression_profile_snapshot_json TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'PLANNED'
);

CREATE TABLE planned_set (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  planned_exercise_id TEXT NOT NULL REFERENCES planned_exercise(id) ON DELETE RESTRICT,
  set_number INTEGER NOT NULL,
  is_warmup INTEGER NOT NULL DEFAULT 0,
  target_weight_kg REAL,
  input_weight_value REAL,
  input_weight_unit_code TEXT,
  target_reps_lower INTEGER,
  target_reps_upper INTEGER,
  target_duration_sec INTEGER,
  target_assistance_value REAL,
  rest_sec INTEGER NOT NULL,
  CONSTRAINT ck_target_range CHECK (target_reps_lower IS NULL OR target_reps_upper IS NULL OR target_reps_lower <= target_reps_upper)
);

CREATE TABLE workout_session (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  workout_day_plan_id TEXT REFERENCES workout_day_plan(id) ON DELETE RESTRICT,
  attempt_number INTEGER NOT NULL DEFAULT 1,
  status_code TEXT NOT NULL DEFAULT 'IN_PROGRESS',
  started_at TEXT NOT NULL,
  ended_at TEXT,
  record_date TEXT NOT NULL,
  training_location_id TEXT REFERENCES training_location(id) ON DELETE RESTRICT,
  current_session_exercise_id TEXT,
  current_set_number INTEGER,
  rest_started_at TEXT,
  rest_duration_sec INTEGER,
  last_local_saved_at TEXT NOT NULL,
  day_adjustment_snapshot_json TEXT
);

CREATE TABLE session_exercise (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
  planned_exercise_id TEXT REFERENCES planned_exercise(id) ON DELETE RESTRICT,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  order_index INTEGER NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'IN_PROGRESS',
  exercise_name_snapshot TEXT NOT NULL,
  recording_method_snapshot TEXT NOT NULL,
  performance_series_key TEXT NOT NULL,
  substitution_reason_code TEXT
);

CREATE TABLE post_workout_assessment (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
  overall_difficulty_score INTEGER NOT NULL,
  had_pain INTEGER NOT NULL DEFAULT 0,
  incomplete_reason_code TEXT,
  completed_exercise_count INTEGER NOT NULL DEFAULT 0,
  completed_work_set_count INTEGER NOT NULL DEFAULT 0,
  actual_duration_sec INTEGER NOT NULL DEFAULT 0,
  next_proposal_response_code TEXT,
  CONSTRAINT ck_difficulty CHECK (overall_difficulty_score BETWEEN 1 AND 5)
);

CREATE TABLE progression_proposal (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  exercise_id TEXT REFERENCES exercise_master(id) ON DELETE RESTRICT,
  performance_series_key TEXT,
  source_workout_session_id TEXT REFERENCES workout_session(id) ON DELETE RESTRICT,
  proposal_type_code TEXT NOT NULL,
  current_value_json TEXT,
  proposed_value_json TEXT NOT NULL,
  reason_text_snapshot TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'PENDING',
  cooldown_remaining_sessions INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE work_set_record (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  voided_at TEXT,
  supersedes_id TEXT,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  session_exercise_id TEXT NOT NULL REFERENCES session_exercise(id) ON DELETE RESTRICT,
  planned_set_id TEXT REFERENCES planned_set(id) ON DELETE RESTRICT,
  set_number INTEGER NOT NULL,
  side_code TEXT NOT NULL DEFAULT 'BOTH',
  is_warmup INTEGER NOT NULL DEFAULT 0,
  actual_weight_kg REAL,
  input_weight_value REAL,
  input_weight_unit_code TEXT,
  actual_reps INTEGER,
  actual_duration_sec INTEGER,
  assistance_value REAL,
  variation_code TEXT,
  equipment_mode_code TEXT,
  machine_instance_key TEXT,
  body_weight_snapshot_kg REAL,
  completed_at TEXT NOT NULL,
  CONSTRAINT ck_actual_nonnegative CHECK ((actual_weight_kg IS NULL OR actual_weight_kg >= 0) AND (actual_reps IS NULL OR actual_reps >= 0) AND (actual_duration_sec IS NULL OR actual_duration_sec >= 0) AND (assistance_value IS NULL OR assistance_value >= 0))
);

CREATE TABLE session_pain_entry (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  voided_at TEXT,
  supersedes_id TEXT,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
  session_exercise_id TEXT REFERENCES session_exercise(id) ON DELETE RESTRICT,
  body_part_id TEXT NOT NULL REFERENCES body_part_master(id) ON DELETE RESTRICT,
  action_code TEXT NOT NULL,
  timing_code TEXT NOT NULL,
  worsened INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE body_measurement (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  voided_at TEXT,
  supersedes_id TEXT,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  measured_at TEXT NOT NULL,
  weight_kg REAL,
  body_fat_percent REAL,
  source_code TEXT NOT NULL DEFAULT 'MANUAL'
);

CREATE TABLE rule_version (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  rule_type_code TEXT NOT NULL,
  version_label TEXT NOT NULL,
  released_at TEXT NOT NULL,
  checksum TEXT NOT NULL
);

CREATE TABLE reason_template (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  template_type_code TEXT NOT NULL,
  template_text TEXT NOT NULL,
  placeholder_schema_json TEXT
);

CREATE TABLE sync_outbox (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  operation_code TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  idempotency_key TEXT NOT NULL UNIQUE,
  status_code TEXT NOT NULL DEFAULT 'PENDING',
  retry_count INTEGER NOT NULL DEFAULT 0,
  next_retry_at TEXT
);

CREATE UNIQUE INDEX uq_user_auth ON user_account(auth_provider, auth_subject) WHERE auth_subject IS NOT NULL;

CREATE UNIQUE INDEX uq_exercise_code ON exercise_master(code);

CREATE UNIQUE INDEX uq_exercise_body_part ON exercise_body_part(exercise_id, body_part_id, relation_type);

CREATE UNIQUE INDEX uq_exercise_movement ON exercise_movement(exercise_id, movement_id, relation_type);

CREATE UNIQUE INDEX uq_exercise_equipment_option ON exercise_equipment_option(exercise_id, option_code);

CREATE UNIQUE INDEX uq_exercise_equipment ON exercise_equipment(equipment_option_id, equipment_id);

CREATE UNIQUE INDEX uq_location_equipment ON location_equipment(training_location_id, equipment_id);

CREATE UNIQUE INDEX uq_equipment_weight ON equipment_weight_option(location_equipment_id, weight_value, unit_code);

CREATE UNIQUE INDEX uq_standard_day ON standard_schedule_day(user_id, weekday_code);

CREATE UNIQUE INDEX uq_user_week ON training_week(user_id, week_start_date);

CREATE UNIQUE INDEX uq_weekly_input ON weekly_input(training_week_id);

CREATE UNIQUE INDEX uq_weekly_priority ON weekly_priority_part(training_week_id, priority_type);

CREATE UNIQUE INDEX uq_weekly_day ON weekly_available_day(training_week_id, weekday_code);

CREATE UNIQUE INDEX uq_menu_version ON weekly_menu(training_week_id, menu_version);

CREATE UNIQUE INDEX uq_active_menu ON weekly_menu(training_week_id) WHERE is_active = 1 AND deleted_at IS NULL;

CREATE INDEX ix_active_menu ON weekly_menu(training_week_id, is_active, status_code);

CREATE UNIQUE INDEX uq_plan_date ON workout_day_plan(weekly_menu_id, plan_date);

CREATE UNIQUE INDEX uq_planned_order ON planned_exercise(workout_day_plan_id, order_index);

CREATE UNIQUE INDEX uq_planned_set ON planned_set(planned_exercise_id, set_number);

CREATE INDEX ix_open_session ON workout_session(user_id, status_code, last_local_saved_at);

CREATE UNIQUE INDEX uq_session_order ON session_exercise(workout_session_id, order_index);

CREATE INDEX ix_measurement_time ON body_measurement(user_id, measured_at);

CREATE INDEX ix_pending_proposal ON progression_proposal(user_id, status_code, exercise_id);

CREATE INDEX ix_outbox_retry ON sync_outbox(status_code, next_retry_at);

CREATE UNIQUE INDEX uq_form_asset_position ON exercise_form_asset(exercise_id, asset_position, content_version);
