# タスク16 記録・進行提案機能 実装レポート

- 作成日：2026-07-17
- プロジェクト版：0.5.0+5
- DB Schema：v5
- 正式対象：iPhone

## 1. 完了範囲

トレーニング履歴、実施日詳細、種目別比較系列、推移グラフ、自己ベスト、体重・体脂肪率、結果分類、進歩・停滞判定、次回調整提案、提案の採否と次回メニュー反映を実装しました。

## 2. 追加した主要コンポーネント

- `RecordsRepository` / `LocalRecordsRepository`
- `ProgressionRepository` / `LocalProgressionRepository`
- `ResultClassifier`
- `ProgressionEngine`
- Records／Progression用Riverpod Provider・Notifier
- 記録ダッシュボード、履歴、詳細、種目推移、身体測定、提案画面
- 外部グラフライブラリに依存しない軽量折れ線グラフ

## 3. Schema v5

新規テーブル：

- `exercise_performance_series`
- `session_exercise_evaluation`
- `progression_proposal_decision`
- `accepted_progression_adjustment`

`progression_proposal`へ追加：

- `source_evaluation_id`
- `proposal_key`
- `priority`
- `expires_at`
- `applied_at`

テーブル総数は60です。

SQLiteの既存テーブルへ外部キー付き列を単純追加できないため、`source_evaluation_id`は挿入・更新トリガーで有効な評価レコードを検証します。新規作成とv4→v5移行後で同じ整合性を保証します。

## 4. 安全上の固定

- 痛みありでは増量しない
- 睡眠1〜2またはきつさ4〜5では増量しない
- モチベーション単独では増量しない
- 実績がない重量を推測しない
- 時間・器具による未完了を性能低下へ数えない
- RIR／RPEの追加入力を要求しない
- AIを結果分類・増減判断の決定者にしない

## 5. データ保全

- セッション評価は入力・結果・理由をスナップショット保存
- 身体測定の訂正は追記型
- 提案の回答は履歴テーブルへ保存
- 採用した数値調整は未来予定または次回生成へ1回だけ適用
- 手動選択が必要な提案は自動変更しない
- トレーニング完了と進行評価を分離し、評価失敗で完了記録を失わない

## 6. 検証結果

- Schema v5新規作成：合格
- Schema v4→v5移行：合格
- 60テーブル、72種目、144画像メタデータ、216進行プロフィール
- 外部キー違反：0
- 同一セッション種目の評価重複拒否：合格
- 同一アクティブ提案キーの重複拒否：合格
- 提案元評価の整合性トリガー：合格
- Repository SQL：106引数定義、201 SQL文をSQLiteでコンパイル
- Records／Progression契約検証：合格
- ローカルimport・区切り文字検証：合格
- Dart tree-sitter構文走査：84ファイル、エラー0
- ZIP：152ファイル、CRC検証合格
- Manifest：151対象ファイルのサイズ・SHA-256整合性合格
- ZIP展開後の全検証再実行：合格

## 7. 未実施

作成環境にFlutter SDKがないため、以下は未実施です。

- `flutter pub get`
- Driftコード生成
- `flutter analyze`
- `custom_lint`
- `flutter test`
- iOS Simulator／実機ビルド

CIへSchema v5とタスク16の検証を追加済みです。Flutter SDKがある環境では、コード生成後に上記を必ず実行します。
