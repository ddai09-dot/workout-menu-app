# 採用・削除の意思決定ログ

## D-001 外部3領域をMVP通常UIから除外

- 日付：2026-07-22
- 区分：一時的な除外・後回し
- 対象：アカウント同期、AI相談、ネイティブ通知
- 理由：実サービス・安全・実機検証が未完成であり、利用できない機能を通常UIへ表示しないため
- 完全削除：していない
- 保持範囲：Schema、Migration、Repository／Gateway境界
- 再検討先：`docs/PARKING_LOT.md`

## D-002 端末内データ初期化をMVPへ採用

- 日付：2026-07-22
- 区分：採用
- 理由：ローカルMVPでユーザーが自分の登録内容と記録を消去できる手段が必須なため
- 期待効果：初期状態への復帰、プライバシー管理、受入試験の再実行
- 採用しなかった案：再インストール案、論理削除のみ、Schema全消去
- 影響範囲：Account Repository／Notifier、マイページ、専用削除画面、Provider破棄、初期登録復帰
- データ削除区分：ユーザーの二段階確認後に限る実行時の完全削除。プロジェクト機能の削除ではない

## D-003 Flutter共通検証とiOS検証を分離した実行レーンを採用

- 日付：2026-07-22
- 区分：採用
- 対象：タスク20-BのFlutter／iOS統合検証方法
- 採用理由：Flutter共通工程とiOS固有工程を分離し、依存解決、コード生成、解析、テスト、iOS buildの失敗箇所を工程別ログで特定できるため
- 期待効果：環境差による誤判定防止、再現性、失敗時証跡、CIとローカル実行の同一化
- 採用しなかった案：静的検証だけで完了扱い、Flutter固定版の解除、iOS検証の省略
- 影響範囲：実行スクリプト、GitHub Actions、証跡JSON、README、Roadmap、Version Matrix
- 削除：なし
- 完了条件：Flutter 3.44.6 RunnerとmacOS／Xcode Runnerの実結果がPASSになること

## D-004 Flutter SDKを公式リリースメタデータから導入する方式を採用

- 日付：2026-07-22
- 区分：採用
- 対象：GitHub Actions上のFlutter SDK準備
- 採用理由：Flutter 3.44.6、release ref `ee80f08`、公式メタデータのSHA-256を同時検証し、CIの再現性と供給網の追跡性を高めるため
- 期待効果：誤バージョン、異なるrelease ref、破損・差替えarchiveをRunner開始前に拒否できる
- 採用しなかった案：最新版追従、バージョン番号だけの確認、checksum未検証download
- 影響範囲：`tools/install_pinned_flutter_sdk.py`、Flutter／iOS workflow、静的Verifier
- 削除：アプリ機能の削除はない

## D-005 `subosito/flutter-action`を完全削除

- 日付：2026-07-22
- 区分：完全削除
- 対象：GitHub Actionsの第三者Flutter setup action
- 完全削除の理由：タグ参照と推移的なAction依存を避け、Google公式archiveとSHA-256検証へ一本化するため
- 代替手段：`tools/install_pinned_flutter_sdk.py`による公式release metadata、release ref、SHA-256検証
- 影響範囲：`.github/workflows/ci.yml`、`.github/workflows/ios-build.yml`
- 後回しではない：同Actionを再採用する予定はない

## D-006 CIのcross-run cacheを一時的に除外

- 日付：2026-07-22
- 区分：一時的な除外・後回し
- 対象：Flutter SDK／Pub cacheのGitHub Actions cross-run cache
- 理由：初回PASS前は速度よりも、公式archiveから毎回検証して得た証跡と供給網の単純性を優先するため
- 完全削除：していない
- 影響：初回CIのdownload時間が増える
- 再検討先：`docs/PARKING_LOT.md`のPL-004
