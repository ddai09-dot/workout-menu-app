# 将来検討タスク（Parking Lot）

ここには、完全削除ではなく一時的に除外・後回しにした機能を記録する。再開時は、採用理由、再公開条件、影響範囲を改めて確認する。

## PL-001 アカウント・クラウド同期

- 状態：一時的に除外・後回し
- 完全削除：していない
- 後回しの理由：Apple認証、Supabase RLS、push／pull、Outbox、競合、退会削除、複数端末・通信断の実環境検証が必要で、ローカルMVPの中核完成を遅らせるため
- 保持物：Schema、Migration、LocalAccountRepository、Supabase境界、Outbox、checkpoint、競合処理試作
- 再開条件：認証・RLS・同期・競合・再ログイン・退会削除を実環境と複数端末で検証できる体制が整ったとき

## PL-002 AI相談

- 状態：一時的に除外・後回し
- 完全削除：していない
- 後回しの理由：Edge Function、秘密管理、レート制限、安全分類、応答Schema、会話保存・削除、タイムアウト・不適切応答試験が必要なため
- 保持物：AI Schema、Gateway、Edge Function境界、安全語判定、キャッシュ境界
- MVPで残すもの：外部APIを使わない用語・FAQ、ルールベース説明、フォーム文言
- 再開条件：API接続・安全・保存削除・異常系を実環境で検証し、AIにメニューや進行の決定権を持たせない境界を保証できるとき

## PL-003 ネイティブ通知

- 状態：一時的に除外・後回し
- 完全削除：していない
- 後回しの理由：iOS権限、予約生成、取消・再予約、タイムゾーン、再起動、通知タップ、実機配信の検証が必要なため
- 保持物：`notification_preference`、`notification_schedule`、SQLite Repository、取消境界、Gateway Stub
- MVPで残すもの：アプリ内休憩タイマー
- 再開条件：source-specific schedulerを実装し、SimulatorとiPhone実機で権限・予約・取消・再予約・タップ・復帰を確認できるとき

## 運用ルール

- 「一時的な除外」を完全削除と表現しない。
- 再開条件を満たす前に通常UIへ戻さない。
- 完全削除へ変更する場合は、理由、データ・Migration互換性、代替手段、影響範囲を説明し、ユーザーの判断を確認する。

## PL-004 GitHub ActionsのFlutter SDK／Pub cache

- 状態：一時的に除外・後回し
- 完全削除：していない
- 後回しの理由：タスク20-Bの初回PASS取得前は、cache hitによる状態差を排除し、公式archive・release ref・SHA-256検証を毎回通すことを優先するため
- 現在の代替：Google公式release metadataからFlutter 3.44.6を導入し、工程別ログとSDK解決結果をArtifact保存
- 再開条件：Flutter共通検証とiOS Simulator buildが各1回以上PASSし、使用するcache Actionを完全長commit SHAへ固定し、cache keyへOS・architecture・Flutter version・release ref・pubspec lock hashを含められるとき
