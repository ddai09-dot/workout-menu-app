# 実装順序・現在地

「Schemaまたは接続境界がある」ことと「実機で機能する」ことを分離して判定します。

## 0. 開発基盤【雛形・静的検証済み／Flutter統合前】

- Feature-first MVVM
- Riverpod、go_router、Drift構成
- Seed・Migration・Repository SQL検証
- CI定義

未完了：正式なFlutter/iOSプロジェクト生成、`pubspec.lock`、コード生成、実ビルド。

## 1. 初期登録【ローカル実装済み／統合未検証】

- 13画面
- 質問単位の自動保存
- 中断復帰
- 器具詳細
- 正規化保存

未完了：Flutter実行、Widget/Integration Test。マイページ通常設定編集はC2でローカル実装済み。

## 2. 今日の行動と週間計画【部分実装】

- 月曜開始の週
- 週次下書き
- 休養週
- ルールベース生成
- 再生成・版管理
- 完了／一部実施／実施中の日を固定

未完了：Excelアルゴリズム全項目との完全トレーサビリティ、全テストケース、実画面検証。

## 3. トレーニング実施【ローカル実装済み／統合未検証】

- 開始前調整
- 8記録方式
- セット確定・訂正
- 休憩状態
- 代替・後回し・スキップ
- 痛み・途中終了
- 中断復帰用データ構造

未完了：バックグラウンド、iOS通知、強制終了、実機日付またぎ検証。

## 4. 記録と進行提案【ローカル実装済み／統合未検証】

- 履歴・比較系列
- 体重・体脂肪率
- 結果分類・停滞判定
- 提案の採用・維持・保留・拒否
- 未来予定への一回適用

未完了：Flutterグラフ描画、Repository統合テスト、全進行ケースの受入確認。

## 5. アカウントと同期【MVP除外／接続境界保持】

実装済み：

- 匿名アカウント境界
- Outbox・checkpoint・競合Schema
- ConflictResolver試作
- 退会申請キュー

通常UI：非表示。`/my-page/account`ルートを削除。

再公開まで未完了：

- Apple認証
- Supabase Migration・RLS
- sync-push／sync-pull
- 既存RepositoryからOutboxへの接続
- ログアウト・再ログイン・競合確認UI
- サーバー退会削除

## 6. AI相談【MVP除外／接続境界保持】

実装済み：

- AI Schema
- Edge Function境界
- 安全語判定
- キャッシュ・FAQ・辞書Repository

通常UI：AI相談は非表示。`/ai-coach`ルートを削除。用語・FAQはローカル機能として維持。

再公開まで未完了：

- 画面とRepository/APIの接続
- 会話保存
- FAQ・辞書Seed運用
- フォーム説明文言との接続
- 実API、レート制限、応答Schema検証

## 7. 通知【MVP除外／SQLite境界保持】

実装済み：

- `notification_preference`を唯一の正本へ統合
- 旧設定の読取専用archive
- 設定画面
- `notification_preference`へのSQLite Repository接続
- 4種類の既定値、時刻、事前通知の永続化
- 設定変更時の旧予約取消とDB状態反映
- Gateway境界

通常UI：通知設定は非表示。`/my-page/notifications`ルートを削除。アプリ内休憩タイマーは維持。

再公開まで未完了：

- iOS権限
- ローカル通知の実予約・取消・再予約
- タイムゾーン・端末再起動対応
- 休憩タイマー連携

## 8. タスク19.5-B DB・Migration・検証是正【B1〜B4完了】

- DB設計をSchema v9へ統合
- v6→v7 Migration追加
- 通知設定正本統合
- v1→v9連続Migration検証
- AppDatabase MigrationとSQL正本の一致検証
- 最新Seed・JSON資産の検証
- 全Repository SQLのSchema v9コンパイル
- CI・Makefile・README・Version Matrix・Roadmap更新

## 9. タスク19.5-C1 フォーム説明【ローカル実装済み／統合未検証】

実装済み：

- `exercise_form_copy`と2件の`exercise_form_asset`を一括取得
- トレーニング中と記録の種目詳細から「フォームを確認」へ遷移
- 位置ラベル、動作ポイント、注意点を画像状態にかかわらず表示
- 画像1・画像2を独立判定し、片方の欠落で成功側を消さない
- `READY`／`PUBLISHED`、同梱Asset URI、SHA-256、AssetBundle実在を確認
- 未制作・未承認・checksum未確定・不一致・読込失敗時の説明付きプレースホルダー
- 成功画像のメモリキャッシュ。失敗結果は固定キャッシュせず再試行可能
- EX003ダンベルフロアプレスのダンベル方向を文言・Seed・JSONで固定

未完了・未検証：

- Flutterコンパイル、Widget Test、Golden Test
- iOS Simulator／iPhone実機の表示・復帰・アクセシビリティ確認
- 実画像144枚の制作、安全性レビュー、checksum登録、公開状態への移行
- 将来のStorage/CDN画像とディスクキャッシュ


## 10. タスク19.5-C2 マイページ通常設定編集【ローカル実装済み／統合未検証】

実装済み：

- 目的、経験、環境・器具、通常予定、分け方、優先部位、痛み・制限の7カテゴリ
- 初期登録と同じ選択肢・入力Widgetの再利用
- 正規化済み設定のRepository読込と項目別保存
- 変更なし時の保存ボタン無効化、未保存変更の破棄確認
- 器具・場所削減、痛み・制限追加時の今週確認導線
- 作成済みメニュー・実施記録を自動更新しない保存境界
- 避ける動作8グループと物理Movement行の一意な往復

未完了・未検証：

- Flutterコンパイル、Widget／Repository統合テスト
- iOS Simulator／実機の入力、戻る操作、キーボード、アクセシビリティ確認
- 同期中の競合と複数端末での設定変更


## 11. タスク19.5-C3 週間生成アルゴリズム・トレーサビリティ【トレース完成／本体は部分対応】

実装済み：

- 自動生成アルゴリズム仕様v1.1の13工程を構造化トレースへ紐づけ
- 生成入力、採用分割、曜日配置、種目選定、理由、検証結果を`generation_trace_json`へ保存・再読込
- 休養週は工程2で終了した事実を保存
- 分割と種目の同点判定を安定コード順で固定
- 仕様、実装箇所、DB入力、出力、保存証跡、検証をトレーサビリティ台帳へ整理

部分対応：

- 工程6：疲労区分・補助筋重複・場所適合の全配置候補採点
- 工程7：目的・経験別の部位別週間セット目標
- 工程11：ProgressionEngineとの統合実行
- 工程12：独立PlanValidatorと重大違反部分だけの局所再生成

未検証：Flutter Test、Repository統合、Widget、iOS Simulator／実機。

## 12. タスク19.5-C4 通知設定SQLite Repository【ローカル実装済み／ネイティブ未実装】

実装済み：

- `notification_preference`を設定画面の唯一のローカル正本として接続
- 通知4種類の不足行を初回読込時に作成し、既存行は保持
- 有効／無効、通知時刻、事前通知をSQLiteへ保存
- 曜日マスク、音、振動、タイムゾーンを読込・保持
- 設定変更時に同種の旧予約を取消し、`notification_schedule`を`CANCELLED`へ更新
- Providerを`appDatabaseProvider`へ接続し、インメモリMapを廃止
- Repository単体テストを作成

未完了・未検証：

- ネイティブiOS通知アダプター、権限、実予約、配信、通知タップ
- 週間予定、未記録、休憩タイマーからの予約行生成
- タイムゾーン変更・端末再起動時の実再予約
- Flutter Test、Widget Test、iOS Simulator／実機

## 13. タスク19.5-D MVP外部機能判断【判断・通常UI除外完了】

- アカウント同期をMVPから除外し、マイページ項目とルートを削除
- AI相談をMVPから除外し、マイページ項目とルートを削除
- ネイティブ通知をMVPから除外し、通知設定項目とルートを削除
- 用語・FAQはローカル機能として維持
- アプリ内休憩タイマーは維持し、OS通知はMVP受入条件から除外
- Schema v9と将来接続境界は削除せず保持

未検証：Flutterコンパイル、Widget Test、Router実行、iOS Simulator／実機。

## 14. タスク20-A ローカルMVPの端末内データ初期化・統合事前確認【ローカル実装・SQLite検証済み／Flutter未実行】

採用済み：

- マイページ「端末内データ」
- 二段階確認後の実行時完全削除
- 現在ユーザーに属する53テーブルと旧匿名アカウントの物理削除
- 新しい匿名IDの作成と初期登録への復帰
- マスタ、フォーム説明、FAQ、他ユーザー行の保持
- Secure Storage切替、DB transaction、失敗時の旧ID復元
- 全削除対象のSchema自動照合と子→親順序検証
- Flutter統合実行スクリプトとBLOCKED事前確認レポート

判断：端末内データ初期化はMVPへ採用。理由はローカル保存だけで運用するMVPでも、ユーザー自身が登録内容と記録を消去できる必要があるため。再インストール依存、論理削除のみ、Schema全消去は採用しない。

未完了・未検証：

- Flutter 3.44.6の導入
- `flutter pub get`、`pubspec.lock`
- Driftコード生成
- `flutter analyze`、custom_lint、Flutter Test
- Widget／Repository統合／Golden Test
- iOS Simulator／iPhone実機の削除・復帰・アクセシビリティ確認

## 将来検討タスク

アカウント同期、AI相談、ネイティブ通知は完全削除ではなく、一時的な除外・後回しである。理由、保持物、再開条件は`docs/PARKING_LOT.md`で管理する。

## 15. タスク20-B Flutter・iOS統合実行検証【実行レーン準備済み／BLOCKED】

採用済み：

- Flutter 3.44.6を固定したLinux／一般Flutter環境向け一括検証
- macOS／Xcode向けiOS Simulator一括検証
- 工程別ログと機械可読`result.json`
- GitHub Actions Artifactによる失敗時を含む証跡保存
- 実行レーンの静的契約Verifier

採用理由：Flutter共通工程とiOS固有工程を分離し、依存解決、生成、解析、テスト、iOS buildのどこで失敗したかを再現可能に確認するため。

削除：なし。

現在の阻害要因：

- 作成環境にFlutter／Dartがない
- `pubspec.lock`とDrift生成コードがない
- Linux環境のためXcode／iOS Simulatorを実行できない

未完了・未検証：

- Flutter依存解決とlockファイル確定
- Driftコード生成
- Flutter analyze、custom_lint、全Flutter Test
- iOS Simulator debug build
- Simulator上の主要導線操作
- iPhone実機とアクセシビリティ確認

静的Verifierの合格をFlutter・iOS実行成功とは扱わない。タスク20-B全体は未完了であり、現在の判定はBLOCKED。

## 16. タスク20-B2 CI供給網・証跡強化【実装・静的検証済み／実行BLOCKED】

採用済み：

- Google公式release metadataからFlutter SDKを解決・download・SHA-256検証
- Flutter 3.44.6とrelease ref `ee80f08`の固定
- GitHub Actionsの全Actionを完全長commit SHAへ固定
- `contents: read`、checkout credential非保持、重複実行取消
- 工程別`steps.ndjson`、最終`result.json`、lock・生成コード・Simulator appのArtifact回収

完全削除：`subosito/flutter-action`。公式archive installerへ置換したため後回しではない。

一時的に除外：cross-run cache。初回Flutter PASSとiOS Simulator PASS後にPL-004の条件で再検討する。

未完了：Flutter依存解決、生成、解析、テスト、iOS buildの実結果取得。

## 次工程

Flutter 3.44.6を利用できるRunnerで`./tools/run_task20_b_flutter_checks.sh`を実行し、続いてmacOS／Xcode Runnerで`./tools/run_task20_b_ios_simulator.sh`を実行する。失敗した場合はログに基づき実装修正へ戻る。
