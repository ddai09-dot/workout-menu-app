-- Schema v2 -> v3: weekly planner draft and generation metadata.
CREATE TABLE IF NOT EXISTS weekly_planner_draft (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  week_start_date TEXT NOT NULL,
  current_step_code TEXT NOT NULL DEFAULT 'START',
  draft_json TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'IN_PROGRESS',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_active_weekly_planner_draft
  ON weekly_planner_draft(user_id, week_start_date)
  WHERE status_code = 'IN_PROGRESS' AND deleted_at IS NULL;
ALTER TABLE weekly_input ADD COLUMN priority_mode_code TEXT NOT NULL DEFAULT 'DEFAULT';
ALTER TABLE weekly_menu ADD COLUMN generation_trace_json TEXT NOT NULL DEFAULT '{}';
ALTER TABLE weekly_menu ADD COLUMN estimated_total_min INTEGER NOT NULL DEFAULT 0;
ALTER TABLE workout_day_plan ADD COLUMN estimated_duration_min INTEGER NOT NULL DEFAULT 0;
ALTER TABLE planned_exercise ADD COLUMN selection_score INTEGER NOT NULL DEFAULT 0;
ALTER TABLE planned_exercise ADD COLUMN selection_reason_ids_json TEXT NOT NULL DEFAULT '[]';

DROP INDEX IF EXISTS uq_weekly_priority;
DROP INDEX IF EXISTS uq_weekly_priority_part;
DROP INDEX IF EXISTS uq_weekly_main_priority;
CREATE UNIQUE INDEX uq_weekly_priority_part ON weekly_priority_part(training_week_id, priority_type, body_part_id) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX uq_weekly_main_priority ON weekly_priority_part(training_week_id) WHERE priority_type = 'MAIN' AND deleted_at IS NULL;
DROP INDEX IF EXISTS uq_weekly_day;
CREATE UNIQUE INDEX uq_weekly_day ON weekly_available_day(training_week_id, weekday_code) WHERE deleted_at IS NULL;
