-- Schema migration v1 -> v2
ALTER TABLE user_experience_profile ADD COLUMN adjustment_habit_code TEXT NOT NULL DEFAULT 'NONE';
ALTER TABLE user_experience_profile ADD COLUMN logging_habit_code TEXT NOT NULL DEFAULT 'NONE';
ALTER TABLE user_restriction ADD COLUMN joint_id TEXT REFERENCES joint_master(id) ON DELETE RESTRICT;
DROP INDEX IF EXISTS uq_location_equipment;
CREATE INDEX IF NOT EXISTS ix_location_equipment ON location_equipment(training_location_id, equipment_id);
CREATE TABLE IF NOT EXISTS location_dumbbell_detail (
  id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT, row_version INTEGER NOT NULL DEFAULT 1, sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  location_equipment_id TEXT NOT NULL REFERENCES location_equipment(id) ON DELETE RESTRICT,
  setup_type_code TEXT NOT NULL, unit_count INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS location_barbell_detail (
  id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT, row_version INTEGER NOT NULL DEFAULT 1, sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  location_equipment_id TEXT NOT NULL REFERENCES location_equipment(id) ON DELETE RESTRICT,
  shaft_weight_kg REAL NOT NULL, max_total_weight_kg REAL NOT NULL, min_increment_kg REAL NOT NULL,
  has_rack INTEGER NOT NULL DEFAULT 0, has_safety INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS onboarding_draft (
  id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  current_step_code TEXT NOT NULL DEFAULT 'INTRO', draft_json TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'IN_PROGRESS', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT, row_version INTEGER NOT NULL DEFAULT 1
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_active_onboarding_draft ON onboarding_draft(user_id) WHERE status_code = 'IN_PROGRESS' AND deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_dumbbell_detail ON location_dumbbell_detail(location_equipment_id) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_barbell_detail ON location_barbell_detail(location_equipment_id) WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uq_active_user_profile ON user_profile(user_id) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_active_training_setting ON user_training_setting(user_id) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_active_experience_profile ON user_experience_profile(user_id) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX IF NOT EXISTS uq_active_app_preference ON app_preference(user_id) WHERE deleted_at IS NULL;
