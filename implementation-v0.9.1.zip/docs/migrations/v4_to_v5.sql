ALTER TABLE progression_proposal ADD COLUMN source_evaluation_id TEXT;
ALTER TABLE progression_proposal ADD COLUMN proposal_key TEXT NOT NULL DEFAULT '';
ALTER TABLE progression_proposal ADD COLUMN priority INTEGER NOT NULL DEFAULT 100;
ALTER TABLE progression_proposal ADD COLUMN expires_at TEXT;
ALTER TABLE progression_proposal ADD COLUMN applied_at TEXT;

CREATE TABLE exercise_performance_series (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  series_key TEXT NOT NULL,
  display_name_snapshot TEXT NOT NULL,
  progression_group_code TEXT NOT NULL,
  target_mode_code TEXT NOT NULL,
  first_recorded_at TEXT NOT NULL,
  last_recorded_at TEXT NOT NULL,
  latest_session_exercise_id TEXT REFERENCES session_exercise(id) ON DELETE RESTRICT,
  valid_session_count INTEGER NOT NULL DEFAULT 0,
  stall_count INTEGER NOT NULL DEFAULT 0,
  pain_count INTEGER NOT NULL DEFAULT 0,
  last_result_class_code TEXT,
  baseline_set_count INTEGER,
  baseline_metric_value REAL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE session_exercise_evaluation (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  session_exercise_id TEXT NOT NULL REFERENCES session_exercise(id) ON DELETE RESTRICT,
  workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
  performance_series_id TEXT NOT NULL REFERENCES exercise_performance_series(id) ON DELETE RESTRICT,
  evaluated_at TEXT NOT NULL,
  result_class_code TEXT NOT NULL,
  valid_for_performance INTEGER NOT NULL DEFAULT 0,
  work_set_count INTEGER NOT NULL DEFAULT 0,
  representative_weight_kg REAL,
  representative_assistance_value REAL,
  total_reps INTEGER NOT NULL DEFAULT 0,
  minimum_reps INTEGER,
  maximum_reps INTEGER,
  total_duration_sec INTEGER NOT NULL DEFAULT 0,
  progression_metric_value REAL,
  comparison_delta REAL,
  progress_detected INTEGER NOT NULL DEFAULT 0,
  stall_count_after INTEGER NOT NULL DEFAULT 0,
  pain_detected INTEGER NOT NULL DEFAULT 0,
  incomplete_reason_code TEXT,
  reason_text_snapshot TEXT NOT NULL,
  input_snapshot_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE progression_proposal_decision (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  progression_proposal_id TEXT NOT NULL REFERENCES progression_proposal(id) ON DELETE RESTRICT,
  decision_code TEXT NOT NULL,
  applies_to_code TEXT NOT NULL DEFAULT 'NEXT_MATCHING_SESSION',
  decision_reason_code TEXT,
  decided_at TEXT NOT NULL,
  application_result_code TEXT,
  target_planned_exercise_id TEXT REFERENCES planned_exercise(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE accepted_progression_adjustment (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  progression_proposal_id TEXT NOT NULL REFERENCES progression_proposal(id) ON DELETE RESTRICT,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  performance_series_key TEXT,
  adjustment_type_code TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'QUEUED',
  target_planned_exercise_id TEXT REFERENCES planned_exercise(id) ON DELETE RESTRICT,
  queued_at TEXT NOT NULL,
  applied_at TEXT,
  consumed_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE UNIQUE INDEX uq_active_performance_series ON exercise_performance_series(user_id, series_key) WHERE deleted_at IS NULL;
CREATE INDEX ix_performance_series_exercise ON exercise_performance_series(user_id, exercise_id, last_recorded_at);
CREATE UNIQUE INDEX uq_session_exercise_evaluation ON session_exercise_evaluation(session_exercise_id) WHERE deleted_at IS NULL;
CREATE INDEX ix_evaluation_series ON session_exercise_evaluation(performance_series_id, evaluated_at);
CREATE UNIQUE INDEX uq_active_proposal_key ON progression_proposal(user_id, proposal_key) WHERE proposal_key <> '' AND status_code IN ('PENDING', 'DEFERRED') AND deleted_at IS NULL;
CREATE INDEX ix_proposal_source_evaluation ON progression_proposal(source_evaluation_id);
CREATE INDEX ix_proposal_decision ON progression_proposal_decision(progression_proposal_id, decided_at);
CREATE UNIQUE INDEX uq_active_progression_adjustment ON accepted_progression_adjustment(progression_proposal_id) WHERE status_code IN ('QUEUED', 'APPLIED') AND deleted_at IS NULL;
CREATE INDEX ix_queued_adjustment_exercise ON accepted_progression_adjustment(user_id, exercise_id, status_code, queued_at);


CREATE TRIGGER ck_progression_proposal_source_insert
BEFORE INSERT ON progression_proposal
WHEN NEW.source_evaluation_id IS NOT NULL
 AND NOT EXISTS (
   SELECT 1 FROM session_exercise_evaluation
   WHERE id = NEW.source_evaluation_id AND deleted_at IS NULL
 )
BEGIN
  SELECT RAISE(ABORT, 'invalid progression proposal source evaluation');
END;

CREATE TRIGGER ck_progression_proposal_source_update
BEFORE UPDATE OF source_evaluation_id ON progression_proposal
WHEN NEW.source_evaluation_id IS NOT NULL
 AND NOT EXISTS (
   SELECT 1 FROM session_exercise_evaluation
   WHERE id = NEW.source_evaluation_id AND deleted_at IS NULL
 )
BEGIN
  SELECT RAISE(ABORT, 'invalid progression proposal source evaluation');
END;
