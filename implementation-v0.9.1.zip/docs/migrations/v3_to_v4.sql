ALTER TABLE workout_session ADD COLUMN current_input_draft_json TEXT NOT NULL DEFAULT '{}';
ALTER TABLE workout_session ADD COLUMN last_interaction_at TEXT NOT NULL DEFAULT '';
UPDATE workout_session
SET last_interaction_at = COALESCE(last_local_saved_at, updated_at, created_at, '1970-01-01T00:00:00Z')
WHERE last_interaction_at = '';
ALTER TABLE workout_session ADD COLUMN completion_reason_code TEXT;

ALTER TABLE session_exercise ADD COLUMN skip_reason_code TEXT;
ALTER TABLE session_exercise ADD COLUMN started_at TEXT;
ALTER TABLE session_exercise ADD COLUMN ended_at TEXT;
ALTER TABLE session_exercise ADD COLUMN original_order_index INTEGER NOT NULL DEFAULT 1;
ALTER TABLE session_exercise ADD COLUMN original_set_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE session_exercise ADD COLUMN target_set_count INTEGER NOT NULL DEFAULT 0;

ALTER TABLE work_set_record ADD COLUMN rest_duration_sec INTEGER;
ALTER TABLE work_set_record ADD COLUMN correction_reason_code TEXT;

CREATE TABLE session_set_target (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  session_exercise_id TEXT NOT NULL REFERENCES session_exercise(id) ON DELETE RESTRICT,
  planned_set_id TEXT REFERENCES planned_set(id) ON DELETE RESTRICT,
  set_number INTEGER NOT NULL,
  is_warmup INTEGER NOT NULL DEFAULT 0,
  target_weight_kg REAL,
  input_weight_value REAL,
  input_weight_unit_code TEXT,
  target_reps_lower INTEGER,
  target_reps_upper INTEGER,
  target_duration_sec INTEGER,
  target_assistance_value REAL,
  rest_sec INTEGER NOT NULL,
  source_code TEXT NOT NULL DEFAULT 'PLANNED',
  CONSTRAINT ck_session_target_range CHECK (target_reps_lower IS NULL OR target_reps_upper IS NULL OR target_reps_lower <= target_reps_upper)
);

CREATE TABLE workout_session_event (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
  session_exercise_id TEXT REFERENCES session_exercise(id) ON DELETE RESTRICT,
  event_type_code TEXT NOT NULL,
  payload_json TEXT NOT NULL DEFAULT '{}',
  occurred_at TEXT NOT NULL,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT
);

CREATE UNIQUE INDEX uq_session_set_target
ON session_set_target(session_exercise_id, set_number)
WHERE deleted_at IS NULL;
CREATE INDEX ix_session_events
ON workout_session_event(workout_session_id, occurred_at);
CREATE UNIQUE INDEX uq_post_workout_assessment
ON post_workout_assessment(workout_session_id)
WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_open_workout_session
ON workout_session(user_id)
WHERE status_code IN ('IN_PROGRESS', 'AWAITING_ASSESSMENT')
  AND deleted_at IS NULL;

CREATE UNIQUE INDEX uq_active_work_set
ON work_set_record(session_exercise_id, set_number, side_code)
WHERE voided_at IS NULL;
