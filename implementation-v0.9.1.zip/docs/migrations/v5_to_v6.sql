-- Task 17: account and synchronization lifecycle.
CREATE TABLE account_link_history (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  event_code TEXT NOT NULL,
  provider_code TEXT NOT NULL,
  provider_subject_hash TEXT,
  occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE sync_checkpoint (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  device_id TEXT NOT NULL REFERENCES device_registration(id) ON DELETE RESTRICT,
  scope_code TEXT NOT NULL DEFAULT 'USER_DATA',
  server_cursor TEXT,
  last_push_at TEXT,
  last_pull_at TEXT,
  last_success_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sync_run_history (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  device_id TEXT NOT NULL REFERENCES device_registration(id) ON DELETE RESTRICT,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  trigger_code TEXT NOT NULL,
  result_code TEXT NOT NULL DEFAULT 'RUNNING',
  pushed_count INTEGER NOT NULL DEFAULT 0,
  pulled_count INTEGER NOT NULL DEFAULT 0,
  conflict_count INTEGER NOT NULL DEFAULT 0,
  error_code TEXT,
  error_message_safe TEXT
);

CREATE TABLE sync_conflict_log (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  sync_run_id TEXT REFERENCES sync_run_history(id) ON DELETE RESTRICT,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  local_row_version INTEGER,
  remote_row_version INTEGER,
  resolution_code TEXT NOT NULL,
  local_payload_hash TEXT,
  remote_payload_hash TEXT,
  resolved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE account_deletion_request (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  requested_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status_code TEXT NOT NULL DEFAULT 'PENDING',
  remote_request_id TEXT,
  completed_at TEXT,
  last_error_code TEXT,
  retry_count INTEGER NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX uq_sync_checkpoint ON sync_checkpoint(user_id, device_id, scope_code);
CREATE INDEX ix_sync_run_user_time ON sync_run_history(user_id, started_at);
CREATE INDEX ix_sync_conflict_entity ON sync_conflict_log(user_id, entity_type, entity_id);
CREATE UNIQUE INDEX uq_pending_account_deletion ON account_deletion_request(user_id) WHERE status_code IN ('PENDING','PROCESSING');
CREATE INDEX ix_account_link_history ON account_link_history(user_id, occurred_at);
CREATE INDEX ix_outbox_pending_v6 ON sync_outbox(user_id, status_code, next_retry_at);
