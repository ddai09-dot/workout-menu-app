-- Task 19: local notification and reminder foundation.
CREATE TABLE notification_preference (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  notification_type_code TEXT NOT NULL,
  is_enabled INTEGER NOT NULL DEFAULT 1,
  local_time TEXT,
  weekday_mask INTEGER,
  advance_minutes INTEGER NOT NULL DEFAULT 0,
  sound_enabled INTEGER NOT NULL DEFAULT 1,
  vibration_enabled INTEGER NOT NULL DEFAULT 1,
  timezone TEXT NOT NULL DEFAULT 'Asia/Tokyo',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);
CREATE TABLE notification_schedule (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  notification_type_code TEXT NOT NULL,
  source_entity_type TEXT,
  source_entity_id TEXT,
  scheduled_at TEXT NOT NULL,
  timezone TEXT NOT NULL DEFAULT 'Asia/Tokyo',
  title_text TEXT NOT NULL,
  body_text TEXT NOT NULL,
  route_path TEXT,
  status_code TEXT NOT NULL DEFAULT 'SCHEDULED',
  platform_notification_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  delivered_at TEXT,
  cancelled_at TEXT,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);
CREATE TABLE notification_delivery_log (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  notification_schedule_id TEXT REFERENCES notification_schedule(id) ON DELETE RESTRICT,
  event_code TEXT NOT NULL,
  occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  platform_code TEXT NOT NULL DEFAULT 'IOS',
  app_state_code TEXT,
  error_code TEXT,
  error_message_safe TEXT
);
CREATE UNIQUE INDEX uq_notification_preference_active ON notification_preference(user_id, notification_type_code) WHERE deleted_at IS NULL;
CREATE UNIQUE INDEX uq_notification_platform_id ON notification_schedule(platform_notification_id) WHERE deleted_at IS NULL AND status_code = 'SCHEDULED';
CREATE UNIQUE INDEX uq_notification_source_schedule ON notification_schedule(user_id, notification_type_code, source_entity_type, source_entity_id, scheduled_at) WHERE deleted_at IS NULL AND status_code = 'SCHEDULED';
CREATE INDEX ix_notification_due ON notification_schedule(user_id, status_code, scheduled_at);
CREATE INDEX ix_notification_delivery_time ON notification_delivery_log(user_id, occurred_at);
