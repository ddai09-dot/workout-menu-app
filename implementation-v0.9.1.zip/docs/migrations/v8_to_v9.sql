-- Task 19.5-B3: consolidate legacy notification_setting into notification_preference.
-- Canonical source of truth after this migration: notification_preference.
-- The legacy rows are preserved verbatim in notification_setting_legacy_archive.
-- weekday_mask bit convention: MON=1, TUE=2, WED=4, THU=8, FRI=16, SAT=32, SUN=64.

ALTER TABLE notification_preference
ADD COLUMN source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT;

CREATE TEMP TABLE _notification_existing_preference AS
SELECT user_id, notification_type_code, id AS preference_id
FROM notification_preference
WHERE deleted_at IS NULL;

CREATE TEMP TABLE _notification_source_group AS
SELECT
  ns.user_id,
  ns.notification_type_code,
  'np_migrated_' || lower(hex(randomblob(16))) AS generated_preference_id,
  (
    SELECT n2.is_enabled
    FROM notification_setting n2
    WHERE n2.user_id = ns.user_id
      AND n2.notification_type_code = ns.notification_type_code
      AND n2.deleted_at IS NULL
    ORDER BY n2.updated_at DESC, n2.row_version DESC, n2.id DESC
    LIMIT 1
  ) AS is_enabled,
  (
    SELECT n2.time_local
    FROM notification_setting n2
    WHERE n2.user_id = ns.user_id
      AND n2.notification_type_code = ns.notification_type_code
      AND n2.deleted_at IS NULL
      AND n2.time_local IS NOT NULL
      AND trim(n2.time_local) <> ''
    ORDER BY n2.updated_at DESC, n2.row_version DESC, n2.id DESC
    LIMIT 1
  ) AS local_time,
  CASE
    WHEN MAX(
      CASE
        WHEN ns.weekday_code IS NULL
          OR trim(ns.weekday_code) = ''
          OR upper(trim(ns.weekday_code)) IN ('ALL', 'DAILY', 'EVERYDAY', 'ANY')
        THEN 1 ELSE 0
      END
    ) = 1 THEN NULL
    WHEN MAX(
      CASE
        WHEN upper(trim(ns.weekday_code)) IN (
          'MON', 'MONDAY', '1', '月', '月曜', '月曜日',
          'TUE', 'TUESDAY', '2', '火', '火曜', '火曜日',
          'WED', 'WEDNESDAY', '3', '水', '水曜', '水曜日',
          'THU', 'THURSDAY', '4', '木', '木曜', '木曜日',
          'FRI', 'FRIDAY', '5', '金', '金曜', '金曜日',
          'SAT', 'SATURDAY', '6', '土', '土曜', '土曜日',
          'SUN', 'SUNDAY', '7', '0', '日', '日曜', '日曜日'
        ) THEN 0 ELSE 1
      END
    ) = 1 THEN NULL
    ELSE SUM(DISTINCT CASE upper(trim(ns.weekday_code))
      WHEN 'MON' THEN 1 WHEN 'MONDAY' THEN 1 WHEN '1' THEN 1
      WHEN '月' THEN 1 WHEN '月曜' THEN 1 WHEN '月曜日' THEN 1
      WHEN 'TUE' THEN 2 WHEN 'TUESDAY' THEN 2 WHEN '2' THEN 2
      WHEN '火' THEN 2 WHEN '火曜' THEN 2 WHEN '火曜日' THEN 2
      WHEN 'WED' THEN 4 WHEN 'WEDNESDAY' THEN 4 WHEN '3' THEN 4
      WHEN '水' THEN 4 WHEN '水曜' THEN 4 WHEN '水曜日' THEN 4
      WHEN 'THU' THEN 8 WHEN 'THURSDAY' THEN 8 WHEN '4' THEN 8
      WHEN '木' THEN 8 WHEN '木曜' THEN 8 WHEN '木曜日' THEN 8
      WHEN 'FRI' THEN 16 WHEN 'FRIDAY' THEN 16 WHEN '5' THEN 16
      WHEN '金' THEN 16 WHEN '金曜' THEN 16 WHEN '金曜日' THEN 16
      WHEN 'SAT' THEN 32 WHEN 'SATURDAY' THEN 32 WHEN '6' THEN 32
      WHEN '土' THEN 32 WHEN '土曜' THEN 32 WHEN '土曜日' THEN 32
      WHEN 'SUN' THEN 64 WHEN 'SUNDAY' THEN 64 WHEN '7' THEN 64 WHEN '0' THEN 64
      WHEN '日' THEN 64 WHEN '日曜' THEN 64 WHEN '日曜日' THEN 64
    END)
  END AS weekday_mask,
  COALESCE((
    SELECT ap.sound_enabled
    FROM app_preference ap
    WHERE ap.user_id = ns.user_id AND ap.deleted_at IS NULL
    ORDER BY ap.updated_at DESC, ap.row_version DESC, ap.id DESC
    LIMIT 1
  ), 1) AS sound_enabled,
  COALESCE((SELECT ua.timezone FROM user_account ua WHERE ua.id = ns.user_id), 'Asia/Tokyo') AS timezone,
  MIN(ns.created_at) AS created_at,
  MAX(ns.updated_at) AS updated_at,
  MAX(ns.row_version) + 1 AS row_version,
  (
    SELECT n2.source_device_id
    FROM notification_setting n2
    WHERE n2.user_id = ns.user_id
      AND n2.notification_type_code = ns.notification_type_code
      AND n2.deleted_at IS NULL
    ORDER BY n2.updated_at DESC, n2.row_version DESC, n2.id DESC
    LIMIT 1
  ) AS source_device_id,
  COUNT(*) AS source_count,
  MAX(
    CASE
      WHEN ns.weekday_code IS NULL
        OR trim(ns.weekday_code) = ''
        OR upper(trim(ns.weekday_code)) IN (
          'ALL', 'DAILY', 'EVERYDAY', 'ANY',
          'MON', 'MONDAY', '1', '月', '月曜', '月曜日',
          'TUE', 'TUESDAY', '2', '火', '火曜', '火曜日',
          'WED', 'WEDNESDAY', '3', '水', '水曜', '水曜日',
          'THU', 'THURSDAY', '4', '木', '木曜', '木曜日',
          'FRI', 'FRIDAY', '5', '金', '金曜', '金曜日',
          'SAT', 'SATURDAY', '6', '土', '土曜', '土曜日',
          'SUN', 'SUNDAY', '7', '0', '日', '日曜', '日曜日'
        )
      THEN 0 ELSE 1
    END
  ) AS has_unknown_weekday
FROM notification_setting ns
WHERE ns.deleted_at IS NULL
GROUP BY ns.user_id, ns.notification_type_code;

INSERT INTO notification_preference (
  id, user_id, notification_type_code, is_enabled, local_time,
  weekday_mask, advance_minutes, sound_enabled, vibration_enabled,
  timezone, created_at, updated_at, deleted_at, row_version,
  sync_status, source_device_id
)
SELECT
  g.generated_preference_id,
  g.user_id,
  g.notification_type_code,
  g.is_enabled,
  g.local_time,
  g.weekday_mask,
  0,
  g.sound_enabled,
  1,
  g.timezone,
  g.created_at,
  g.updated_at,
  NULL,
  g.row_version,
  'LOCAL_ONLY',
  g.source_device_id
FROM _notification_source_group g
LEFT JOIN _notification_existing_preference e
  ON e.user_id = g.user_id
 AND e.notification_type_code = g.notification_type_code
WHERE e.preference_id IS NULL;

UPDATE notification_preference
SET source_device_id = (
  SELECT g.source_device_id
  FROM _notification_source_group g
  WHERE g.user_id = notification_preference.user_id
    AND g.notification_type_code = notification_preference.notification_type_code
)
WHERE source_device_id IS NULL
  AND deleted_at IS NULL
  AND EXISTS (
    SELECT 1
    FROM _notification_source_group g
    WHERE g.user_id = notification_preference.user_id
      AND g.notification_type_code = notification_preference.notification_type_code
      AND g.source_device_id IS NOT NULL
  );

CREATE TEMP TABLE _notification_preference_map AS
SELECT
  g.user_id,
  g.notification_type_code,
  COALESCE(e.preference_id, g.generated_preference_id) AS preference_id,
  CASE WHEN e.preference_id IS NULL THEN 0 ELSE 1 END AS used_existing
FROM _notification_source_group g
LEFT JOIN _notification_existing_preference e
  ON e.user_id = g.user_id
 AND e.notification_type_code = g.notification_type_code;

CREATE TABLE notification_setting_legacy_archive (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  row_version INTEGER NOT NULL,
  sync_status TEXT NOT NULL,
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  notification_type_code TEXT NOT NULL,
  is_enabled INTEGER NOT NULL,
  time_local TEXT,
  weekday_code TEXT,
  migrated_preference_id TEXT REFERENCES notification_preference(id) ON DELETE RESTRICT,
  archived_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  migration_status_code TEXT NOT NULL,
  CONSTRAINT ck_notification_legacy_migration_status CHECK (
    migration_status_code IN (
      'MIGRATED', 'CONSOLIDATED', 'MAPPED_TO_EXISTING',
      'REVIEW_REQUIRED_WEEKDAY', 'DELETED_SOURCE'
    )
  )
);

INSERT INTO notification_setting_legacy_archive (
  id, user_id, created_at, updated_at, deleted_at, row_version,
  sync_status, source_device_id, notification_type_code, is_enabled,
  time_local, weekday_code, migrated_preference_id, archived_at,
  migration_status_code
)
SELECT
  ns.id,
  ns.user_id,
  ns.created_at,
  ns.updated_at,
  ns.deleted_at,
  ns.row_version,
  ns.sync_status,
  ns.source_device_id,
  ns.notification_type_code,
  ns.is_enabled,
  ns.time_local,
  ns.weekday_code,
  pm.preference_id,
  CURRENT_TIMESTAMP,
  CASE
    WHEN ns.deleted_at IS NOT NULL THEN 'DELETED_SOURCE'
    WHEN g.has_unknown_weekday = 1 THEN 'REVIEW_REQUIRED_WEEKDAY'
    WHEN pm.used_existing = 1 THEN 'MAPPED_TO_EXISTING'
    WHEN g.source_count > 1 THEN 'CONSOLIDATED'
    ELSE 'MIGRATED'
  END
FROM notification_setting ns
LEFT JOIN _notification_source_group g
  ON g.user_id = ns.user_id
 AND g.notification_type_code = ns.notification_type_code
LEFT JOIN _notification_preference_map pm
  ON pm.user_id = ns.user_id
 AND pm.notification_type_code = ns.notification_type_code;

DROP TABLE notification_setting;

CREATE INDEX ix_notification_setting_legacy_user_type
ON notification_setting_legacy_archive(user_id, notification_type_code, archived_at);

DROP TABLE _notification_preference_map;
DROP TABLE _notification_source_group;
DROP TABLE _notification_existing_preference;
