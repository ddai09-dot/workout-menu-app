-- Task 18: AI consultation and form-advice support. AI is explanatory only.
CREATE TABLE ai_chat_session (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  title TEXT NOT NULL DEFAULT '',
  context_type_code TEXT NOT NULL DEFAULT 'GENERAL',
  context_entity_id TEXT,
  status_code TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE ai_chat_message (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  chat_session_id TEXT NOT NULL REFERENCES ai_chat_session(id) ON DELETE RESTRICT,
  role_code TEXT NOT NULL,
  content_text TEXT NOT NULL,
  safety_code TEXT NOT NULL DEFAULT 'OK',
  source_code TEXT NOT NULL DEFAULT 'MODEL',
  model_code TEXT,
  prompt_version TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE ai_prompt_template (
  id TEXT PRIMARY KEY NOT NULL,
  template_code TEXT NOT NULL,
  version_code TEXT NOT NULL,
  locale_code TEXT NOT NULL DEFAULT 'ja-JP',
  system_text TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  retired_at TEXT
);

CREATE TABLE ai_response_cache (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  request_hash TEXT NOT NULL,
  context_hash TEXT NOT NULL,
  response_text TEXT NOT NULL,
  safety_code TEXT NOT NULL DEFAULT 'OK',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TEXT NOT NULL
);

CREATE TABLE ai_feedback (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  message_id TEXT NOT NULL REFERENCES ai_chat_message(id) ON DELETE RESTRICT,
  rating_code TEXT NOT NULL,
  reason_code TEXT,
  comment_text TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ai_faq (
  id TEXT PRIMARY KEY NOT NULL,
  category_code TEXT NOT NULL,
  question_text TEXT NOT NULL,
  answer_text TEXT NOT NULL,
  locale_code TEXT NOT NULL DEFAULT 'ja-JP',
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ai_dictionary (
  id TEXT PRIMARY KEY NOT NULL,
  term_code TEXT NOT NULL,
  display_term TEXT NOT NULL,
  reading_text TEXT,
  definition_text TEXT NOT NULL,
  locale_code TEXT NOT NULL DEFAULT 'ja-JP',
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX uq_ai_prompt_version ON ai_prompt_template(template_code, version_code, locale_code);
CREATE UNIQUE INDEX uq_ai_active_prompt ON ai_prompt_template(template_code, locale_code) WHERE is_active = 1;
CREATE INDEX ix_ai_chat_session_user_time ON ai_chat_session(user_id, updated_at);
CREATE INDEX ix_ai_chat_message_session_time ON ai_chat_message(chat_session_id, created_at);
CREATE UNIQUE INDEX uq_ai_cache_request ON ai_response_cache(user_id, request_hash, context_hash);
CREATE INDEX ix_ai_cache_expiry ON ai_response_cache(expires_at);
CREATE UNIQUE INDEX uq_ai_feedback_message ON ai_feedback(user_id, message_id);
CREATE UNIQUE INDEX uq_ai_faq_content ON ai_faq(locale_code, question_text, content_version);
CREATE UNIQUE INDEX uq_ai_dictionary_term ON ai_dictionary(locale_code, term_code, content_version);
