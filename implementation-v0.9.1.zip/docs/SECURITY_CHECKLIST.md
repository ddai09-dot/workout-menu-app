# セキュリティ実装チェック

- Supabase Secret Keyをアプリへ埋め込まない
- モバイルにはPublishable Keyのみを設定
- ユーザーテーブルでRLSを有効化
- `user_id = auth.uid()`を基本条件にする
- 痛み、身体制限、身体測定をAnalyticsへ送らない
- トークン等の秘密値はKeychain経由のSecureStoreへ保存
- 通常ログへメール、JWT、痛み、体重を出さない
- Edge FunctionはJWT検証を有効化
- 退会時は未同期データを確認してから削除処理へ進む
- セッション評価の入力スナップショット、進行提案理由、身体測定をAnalytics・Crashlyticsのカスタム属性へ送らない
- 記録画面のエラー報告ではユーザーID、種目実績、痛み、体重をメッセージへ含めない

- [x] 認証情報はSecureStore（iOS Keychain）境界のみで扱う。
- [x] 競合ログには生の個人データではなくハッシュを保存する。
- [x] 退会のサーバー削除はEdge Function境界から実行する。
