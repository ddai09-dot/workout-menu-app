# タスク19.5-C2 マイページ通常設定編集

- 実装基盤：v0.8.5
- アプリ版：0.8.5+13
- Schema：v9／75テーブル（変更なし）
- 状態：ローカル実装・静的／SQLite契約検証済み、Flutter／iOS統合未検証

## 1. 対象

マイページから次の7項目を個別に開き、初期登録と同じ選択肢・入力部品で編集する。

1. トレーニング目的
2. 経験・継続状況
3. 環境・器具
4. 通常の予定
5. メニューの分け方
6. 優先部位
7. 痛み・身体上の制限

## 2. 保存契約

- 変更がない場合は「変更を保存する」を無効化する。
- 未保存の変更がある場合だけ、戻る操作で破棄確認を表示する。
- 保存失敗時は入力を画面へ残す。
- 目標、経験、通常予定、分け方、優先部位、環境・器具の追加は次回メニュー生成から反映する。
- 器具・場所の削除、利用可能重量の縮小、痛み・制限の追加または強化では、今週のメニュー確認を案内する。
- 本人の確認なしに、作成済み週間メニュー、日別計画、予定種目、予定セット、実施記録、進行履歴を変更しない。

## 3. アーキテクチャ

- `TrainingSettingsRepository`：正規化済み設定の読み書き境界。
- `LocalTrainingSettingsRepository`：11の設定関連テーブルを読み、`OnboardingDraft`へ復元する。
- `TrainingSettingsSection`：表示名、要約、検証対象、変更検知、影響判定を保持する。
- `TrainingSettingsEditPage`：初期登録Widgetを再利用し、7カテゴリを同じ保存フローで扱う。
- Riverpodは現行方針どおり手書きProviderを使用する。

## 4. 永続化

Schema追加は行わない。既存の以下を正本として使用する。

- `user_training_setting`
- `user_experience_profile`
- `training_location`
- `location_equipment`
- `location_dumbbell_detail`
- `location_barbell_detail`
- `equipment_weight_option`
- `standard_schedule_day`
- `user_goal`
- `user_priority_part`
- `user_restriction`

`user_training_setting.change_applies_from`は`NEXT_MENU`へ設定する。項目別保存では、対象外の列を一括更新せず、環境・通常予定・分割・腹筋目的を個別UPDATEする。

環境・器具変更時は、継続利用する自宅・ジムの`training_location` IDを維持し、通常予定を同じIDへ保持する。削除した場所と旧器具行だけを論理削除し、作成済みメニューや記録の参照を破壊しない。

曜日によって自宅とジムを使い分ける場合は、環境編集画面内で既存の実施曜日ごとの場所も確認・変更する。曜日数と時間そのものは「通常の予定」で編集する。

## 5. 避ける動作の復元

UIは8つの動作グループを保持するが、DBは`movement_master`単位で保存する。全256組合せを多重集合として検証し、保存済み行を一意にグループへ復元できることを確認した。完全一致しない既存データは推測せず未選択で表示し、警告する。

## 6. 検証

`tools/verify_training_settings_contract.py`で以下を検証する。

- 7カテゴリ・7ルート
- Schema v9の11設定テーブル
- `NEXT_MENU`適用境界
- C2保存入口が現在週・履歴テーブルを更新しないこと
- 器具削減・制限強化時の確認契約
- 未保存変更の破棄確認
- 動作グループ256組合せの一意復元
- Flutterテスト仕様の存在

Flutter SDKがないため、Widget Test、Repository統合テスト、`flutter analyze`、`flutter test`、iOS表示は未実行である。
