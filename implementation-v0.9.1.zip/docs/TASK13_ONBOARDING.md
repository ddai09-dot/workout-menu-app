# タスク13 初期登録機能

## 実装範囲

- 初回起動時の登録状態判定
- 未開始／途中／完了の3状態
- 途中回答がある場合の「登録の続きがあります」画面
- 初期登録中は下部4タブを非表示
- 13画面の登録フロー
- 質問単位の端末自動保存
- 自動保存の直列化による古い回答の後勝ち防止
- アプリ終了後の途中復帰
- 最初からやり直す場合だけ確認
- 必須回答と条件分岐の検証
- 最終確認から変更した場合は、修正後に最終確認へ戻る
- 登録完了時の正規化保存
- 登録完了後のホーム遷移
- ホーム主カードの登録状態反映

## 画面順

1. 説明
2. 基本情報
3. 主目的
4. 副目的
5. 累計経験・継続・休止
6. 現在頻度・調整・記録習慣
7. 利用場所・ジム設備
8. 自宅／限定ジムの器具
9. 通常日数・曜日・時間・曜日別場所
10. メニューの分け方
11. 優先部位・見た目・腹筋目的
12. 痛み・除外部位・動作・種目
13. 最終確認

## 器具詳細

### 固定式ダンベル

- 重量
- 個数
- 複数重量の追加・削除

### 可変式ダンベル

- 最小重量
- 最大重量
- 重量の刻み
- 個数
- 実際に使用できる重量一覧
- 最小〜最大からの自動生成
- 個別重量の追加・削除

### バーベル

- シャフト重量
- 所有プレートの重量と枚数
- 最大使用重量
- 最小増加単位
- ラック・セーフティの有無

`equipment_weight_option`は、ダンベルでは使用可能重量、バーベルでは所有プレートとして器具種別ごとに解釈します。

## 自宅とジムを曜日で使い分ける場合

`BOTH`＋`BY_WEEKDAY`では、通常実施しやすい各曜日について自宅またはジムを必須選択します。保存先は`standard_schedule_day.training_location_id`です。

## 保存方針

登録途中は`onboarding_draft.draft_json`へ保存します。これは一時状態に限定したJSON利用です。
登録完了時に、プロフィール、目的、経験、場所、器具、通常予定、優先部位、制限、身体測定へ正規化して保存し、下書きを論理削除します。

連続入力による保存順の逆転を防ぐため、端末保存はNotifier内で直列化します。画面状態は即時更新し、最後の保存だけが「保存中」表示とエラー表示を確定します。

## Schema v2で追加・修正したもの

- `onboarding_draft`
- `location_dumbbell_detail`
- `location_barbell_detail`
- `location_dumbbell_detail.unit_count`
- `user_experience_profile.adjustment_habit_code`
- `user_experience_profile.logging_habit_code`
- `user_restriction.joint_id`
- 一般的なジム器具カテゴリ7件
- 同一場所で固定式・可変式ダンベルを併存できる索引構成

## 設計理由

### 下書きテーブル

既存の正規化テーブルは必須列を持つため、未回答状態を無理に保存できません。一時的な回答だけを専用JSONへ保存し、完了時に正規化します。

### 経験回答コード

「調整していない／ときどき／前回結果で調整」と「記録していない／ときどき／毎回」は3段階です。従来のBOOLEANだけでは元回答を保持できないため、安定コード列を追加しました。BOOLEANは「何らかの調整・記録を行うか」という派生値として維持します。

### 器具詳細テーブル

固定式と可変式ダンベル、バーベル固有情報を1つのNULLの多いテーブルへ詰め込まず、器具別詳細へ分離しました。同じ場所で固定式と可変式の両方を登録できます。

### 関節制限

首、肘、手首、腰、股関節、膝、足首は部位マスタではなく関節マスタに存在するため、`user_restriction.joint_id`を追加しました。

## 検証

```bash
python3 tools/verify_seed.py
python3 tools/verify_onboarding_schema.py
python3 tools/verify_onboarding_contract.py
python3 tools/verify_repository_sql.py
python3 tools/verify_source.py
```

検証対象は、新規Schema v2、Schema v1からv2への移行、Seed件数、外部キー、器具コード・部位コード・関節コード・動作コード、ローカルimport、デリミタです。

## 未実施

この作成環境にはFlutter SDKがないため、次はCIまたはFlutter導入済み端末で実行します。

```bash
flutter pub get
dart run build_runner build --delete-conflicting-outputs
flutter analyze
dart run custom_lint
flutter test
flutter run --dart-define-from-file=config/dev.json
```
