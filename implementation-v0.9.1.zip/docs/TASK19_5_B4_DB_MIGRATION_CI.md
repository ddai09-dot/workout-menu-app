# 筋トレメニュー提案アプリ
## タスク19.5-B4 DB・Migration・CI横断是正レポート

- 実施日：2026-07-21
- 是正前実装基盤：v0.8.2／Schema v9
- 是正後実装基盤：v0.8.3／Schema v9
- 対象：v1→v9連続Migration、最新Seed、全Repository SQL、AppDatabase内Migration、CI、Makefile、README、VERSION_MATRIX、ROADMAP

---

## 1. 結論

タスク19.5-B4は完了した。

Schema v1へ既存Seedと代表的な業務データを投入した状態から、8本のMigrationを順番に適用し、Schema v9まで到達する連続経路を検証した。Migration後のSchema v9は、新規作成用Schema v9と完全一致した。

さらに、Schema v9 Seed、全Repository SQL、AppDatabase内に埋め込まれたMigration、CI・Makefile・bootstrap、README・VERSION_MATRIX・ROADMAPを同じ版基準へ統一した。

ただし、Flutter SDKとXcodeがないため、`flutter pub get`、`pubspec.lock`生成、Driftコード生成、`flutter analyze`、`flutter test`、iOSビルドは未実施である。

---

## 2. 連続Migrationの是正

### 2.1 検証経路

以下を順番に適用した。

1. Schema v1
2. `v1_to_v2.sql`
3. `v2_to_v3.sql`
4. `v3_to_v4.sql`
5. `v4_to_v5.sql`
6. `v5_to_v6.sql`
7. `v6_to_v7.sql`
8. `v7_to_v8.sql`
9. `v8_to_v9.sql`

### 2.2 各段階のテーブル数

- v1：50
- v2：53
- v3：54
- v4：56
- v5：60
- v6：65
- v7：72
- v8：75
- v9：75

### 2.3 検証結果

- 新規Schema v9と連続Migration後Schema：完全一致
- 比較したSchema object：146件
- Schema signature SHA-256：`b9c11deb4ffa8542122b6d843c8e761d6ba8a4d640381e261f1317c6e4fb81a0`
- 外部キー違反：0
- 既存Seed 18テーブル：全件保持
- 代表的なv1業務行：保持
- 旧通知設定行：archiveへ保持
- 通知曜日マスク：検証合格
- Schema v9へのSeed再適用：冪等

---

## 3. Schema snapshotの不一致是正

監査中、Schema v2〜v9の新規作成用snapshotと、連続Migration後の物理列順が一致していないことを確認した。

原因は、Migrationの`ALTER TABLE ADD COLUMN`では列が末尾へ追加される一方、従来の新規Schemaファイルでは列が論理的な位置へ挿入されていたためである。列名・型・制約が同じでも、物理Schemaの完全一致判定では差異となる。

### 是正内容

- Schema v1を起点にMigrationを適用してSchema v2〜v9 snapshotを再生成
- SQL snapshotとDrift snapshotを同一内容へ統一
- Schemaファイル先頭の古い版コメントを修正
- 新規作成とMigration後で、列順を含めた物理Schemaを一本化

### 検証結果

- Schema SQL／Drift snapshot一致：v2〜v9すべて合格
- 各Schemaのテーブル数：期待値と一致
- AppDatabaseのschemaVersion：9

---

## 4. Schema v9 Seed検証

### 件数

- テーブル：75
- 種目：72
- 器具：48
- フォーム説明文言：72
- フォーム画像メタデータ：144
- 進行プロフィール：216
- AI FAQ：2
- AI用語：2

### 整合性

- 種目ID：EX001〜EX072の連番
- EX071・EX072：名称一致
- 画像メタデータ：全種目2件
- JSON資産とSQL Seed：件数一致
- Seed二重適用：件数不変
- 外部キー違反：0
- Seed SHA-256：`20225548d5ab3ad7ba5afd210b7df5cff04131029afa277f9ec31347cd3bab70`

---

## 5. Repository SQL横断検証

従来の検証範囲をタスク16時点の一部Repositoryから、ローカルRepository・同期Repositoryの全SQLへ拡張した。

### 対象

- `local_sync_repository.dart`
- `local_account_repository.dart`
- `local_ai_coach_repository.dart`
- `local_today_action_repository.dart`
- `local_onboarding_repository.dart`
- `local_progression_repository.dart`
- `local_records_repository.dart`
- `local_weekly_planner_repository.dart`
- `local_workout_repository.dart`

### 検証結果

- SQLを含むRepository：9ファイル
- `customSelect`／`customStatement`呼出：229件
- コンパイルしたSQL分岐：230件
- 条件分岐SQL：2件
- 動的SQL分岐：7件
- 動的テーブル識別子：17件
- 動的列識別子：3件
- Schema v9に対するSQLiteコンパイル：全件合格

Migration SQLとSeedLoaderは、専用検証へ分離した。

---

## 6. AppDatabase内Migration検証

`app_database.dart`に埋め込まれたMigration SQLを静的に抽出し、`docs/migrations`のSQLファイルと段階ごとに比較した。

### 検証結果

- 対象：Schema v2〜v9
- 全8段階：合格
- AppDatabase内MigrationとSQLファイル：一致
- 代表的v1業務行：保持
- 通知archive：一致
- 外部キー違反：0

埋め込みstatement数：

- v2：15
- v3：15
- v4：19
- v5：20
- v6：11
- v7：16
- v8：8
- v9：13

---

## 7. CI・Makefile・bootstrap是正

### `make verify`

以下17検証を同じ入口から実行する構成へ統一した。

1. v1→v9連続Migration
2. AppDatabase内Migration
3. Schema v9 Seed
4. v6→v7 Migration
5. v8→v9通知設定Migration
6. 通知Schema
7. 初期登録Schema
8. 初期登録契約
9. 週間計画Schema
10. 週間計画契約
11. トレーニング実施Schema
12. トレーニング実施契約
13. 記録・進行Schema
14. 記録・進行契約
15. Repository SQL
16. Source smoke
17. プロジェクト整合性

### CI

- Flutter：3.44.6
- `flutter pub get`
- Drift／Riverpodコード生成
- `make verify`
- `flutter analyze`
- `custom_lint`
- `flutter test`

### iOS bootstrap

iOS Simulatorビルド前にも`make verify`を実行する。

### 現環境での実行結果

`make verify`：全検証合格

検証ログSHA-256：`e350f1b7768272d3653961f4a49cd5f93049105199023d9b2ed36c5854f4dda3`

---

## 8. 文書・版管理是正

### 更新した文書

- README：v0.8.3／Schema v9／未完成機能を正確に記載
- VERSION_MATRIX：v0.1.0〜v0.8.3を整形し、完成度を再分類
- IMPLEMENTATION_ROADMAP：タスク17〜19の完成表記を撤回し、次の是正順を明示
- SCHEMA_DEVIATIONS：重複していた節番号を修正
- 統合仕様書：v2.2へ更新
- DB設計：v2.3へ更新
- 成果物正本管理台帳：v1.4へ更新

### 版

- Flutterプロジェクト：`0.8.3+11`
- 実装基盤：v0.8.3
- Schema：v9
- DB設計：v2.3
- 統合仕様書：v2.2

---

## 9. プロジェクト整合性検証

- app version：0.8.3+11
- DB schemaVersion：9
- Migrationファイル：8
- Schema SQL／Drift snapshot一致：合格
- 必須検証スクリプト：17
- CIが`make verify`を使用：合格
- README・VERSION_MATRIX・ROADMAPの状態表現：合格
- `pubspec.lock`：Flutter SDK未導入のため未生成と明示

---

## 10. 未実施項目

作成環境にFlutter SDK、Xcode、Apple Developer、Supabase実環境がないため、以下は未実施である。

- `flutter pub get`
- `pubspec.lock`生成・固定
- Drift／Riverpodコード生成
- `flutter analyze`
- `custom_lint`
- `flutter test`
- iOS Simulatorビルド
- iPhone実機ビルド
- Apple認証
- Supabase Migration・RLS・Storage Policy
- sync-push／sync-pull
- OpenAI実API疎通
- iOS実通知

`pubspec.lock`を手作業で作成することは再現性を損なうため行っていない。Flutter環境で`flutter pub get`を実行して正式生成する。

---

## 11. 成果物検証

### 統合仕様書 v2.2

- ページ数：40
- 全40ページをレンダリングして視覚確認
- 文字切れ、重なり、表崩れ：なし
- アクセシビリティ監査：High 0／Medium 0／Low 0
- DOCX内部ZIP：19エントリ、CRC異常なし

### DB設計 v2.3

- シート：13
- 数式エラー検索：0件
- XLSX内部ZIP：48エントリ、CRC異常なし

### 実装基盤 v0.8.3

- ZIPエントリ：212
- Manifest対象：211ファイル
- ZIP内の全Manifestサイズ・SHA-256：一致
- 余剰・欠落エントリ：0
- CRC異常：なし

### 横断是正パッケージ

- ZIPエントリ：31
- Manifest対象：30ファイル
- サイズ・SHA-256：全件一致
- 余剰・欠落エントリ：0
- CRC異常：なし

---

## 12. 完了判定

**タスク19.5-B4「DB・Migration・Seed・Repository SQL・CIの横断是正」は完了。**

DB・Migration・静的SQL検証基盤は、Schema v9を正として同一基準へ統一された。

次はタスク19.5-Cとして、次の不足機能を一件ずつ是正する。

1. フォーム説明文言表示と画像なしフォールバック
2. マイページ通常設定編集
3. 週間生成仕様と実装のトレーサビリティ
4. 通知設定のSQLite Repository接続
