# アーキテクチャ

## 採用構成

```text
UI
  ↓
Notifier / AsyncNotifier
  ↓
Repository
  ↓
Drift / Supabase Gateway
```

複雑な業務判断だけをUseCaseへ分離します。単純なCRUDまで機械的にUseCase化しません。

## Feature-first

```text
lib/
├── app/
├── core/
│   ├── database/
│   ├── environment/
│   ├── sync/
│   └── theme/
└── features/
    ├── home/
    ├── onboarding/
    ├── weekly_planner/
    ├── workout/
    ├── menu/
    ├── records/
    ├── my_page/
    ├── progression/
    ├── subscription/
    └── ai_coach/
```

## 固定ルール

- UIからDriftやSupabaseを直接呼ばない。
- メニュー生成、停滞判定、進行判定をWidgetへ書かない。
- トレーニング実施中はローカルDBを正とする。
- 完了済み記録を同期競合で消さない。
- AIは説明・相談のみ。メニューや重量の決定者にしない。


## 週間メニュー生成の境界

```text
WeeklyPlanner UI
  ↓
WeeklyPlannerNotifier（画面状態・直列化自動保存）
  ↓
WeeklyPlannerRepository（下書き・正規化・版管理）
  ↓
RuleBasedWeeklyMenuGenerator（純粋な業務判断）
  ↓
Drift / SQLite
```

生成器はFlutter Widget、Drift、Supabaseへ依存しません。入力モデルと安定したルール版だけを受け取り、週間計画を返します。これにより、単体テスト、将来のサーバー再計算、AIなし動作を維持します。

## トレーニング実施の境界

```text
Workout UI
  ↓
WorkoutNotifier（現在入力・休憩表示・保存キュー）
  ↓
WorkoutRepository（開始、確定、訂正、復帰、終了をトランザクション化）
  ↓
Drift / SQLite
```

トレーニング中は端末ローカルDBを正とし、セット確定と現在位置を同じトランザクションで保存します。未確定入力だけを短命なJSONへ保存し、確定実績は正規化テーブルへ移します。

セット訂正は上書きせず、旧レコードを無効化して`supersedes_id`で新レコードへ関連付けます。また、部分一意索引により、1ユーザーの未終了セッションと同一セットの有効実績はそれぞれ1件に制限します。

休憩タイマーは残り秒を状態の正にせず、`rest_started_at`と`rest_duration_sec`から再構築します。これにより、画面再生成・アプリ再起動・日付またぎでも経過時間を失いません。


## 記録・進行提案の境界

```text
Workout completion
  ↓
ProgressionRepository
  ↓
ResultClassifier（純粋な結果分類）
  ↓
ProgressionEngine（純粋な提案判断）
  ↓
Evaluation / Proposal snapshot
  ↓
User decision
  ↓
Future planned_set または adjustment queue
```

トレーニング完了保存と進行評価は分離します。評価が失敗しても完了記録を取り消さず、記録タブまたは提案画面で未評価セッションを再処理します。

比較は`exercise_performance_series`の同一系列内だけで行います。痛み・睡眠・きつさ・未完了理由を安全ゲートとし、AIやWidgetへ判定を置きません。提案を採用するまでは未来予定を変更せず、採用後も数値調整だけを自動適用します。選択が必要な変更は`REVIEW_REQUIRED`として残します。

## フォーム説明（タスク19.5-C1）

フォーム説明は`exercise_form` Featureへ分離します。

- Domain：フォーム文言、2画像スロット、画像可用性、Repository／Resolver契約
- Data：SQLite RepositoryとAssetBundle Resolver
- UseCase：文言取得と2スロットの独立画像解決
- Presentation：手書きRiverpod Provider、画面、再試行、プレースホルダー

画像公開はfail-closedです。`READY`／`PUBLISHED`以外の状態、不正URI、未確定または不一致のSHA-256、Asset欠落は画像非表示とし、文言表示を継続します。成功した同梱Assetだけをメモリキャッシュし、失敗結果は再試行可能とします。将来のStorage/CDNは同じResolver境界の別実装とし、C1でHTTP・ディスクキャッシュを推測追加しません。


## Task 19.5-C4 notification persistence

- `notification_preference` is the only operational local source of truth.
- `LocalNotificationRepository` reads and writes preferences through `AppDatabase`; no in-memory preference map remains.
- The four MVP preference types are inserted only when missing. Existing canonical rows are preserved.
- Preference changes cancel stale rows in `notification_schedule` and persist `CANCELLED`; source-specific schedulers create replacement rows.
- `LocalNotificationGatewayStub` deliberately reports permission denied and performs no native scheduling until an iOS adapter is implemented and verified.
- SQLite persistence and native notification delivery are separate completion states.
