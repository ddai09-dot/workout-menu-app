# AI Coach Contract

- AI is optional and the app remains usable without it.
- AI explains rule-engine output; it does not mutate workout plans or progression data.
- Requests pass through Supabase Edge Functions. API keys never ship in the client.
- Free text is limited to 500 characters. Structured context excludes direct identifiers.
- Pain and emergency keywords trigger a deterministic safety response before model invocation.
- Responses are cached for 24 hours using request/context hashes.
