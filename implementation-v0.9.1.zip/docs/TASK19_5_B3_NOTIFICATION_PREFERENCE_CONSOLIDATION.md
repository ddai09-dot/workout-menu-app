# Task 19.5-B3: notification preference consolidation

## Scope

This correction removes the notification-setting source-of-truth conflict introduced by keeping both the legacy `notification_setting` and the newer `notification_preference` operational.

## Canonical policy

- Operational source of truth: `notification_preference`
- Historical preservation: `notification_setting_legacy_archive`
- Legacy operational table: removed in Schema v9
- Existing active `notification_preference` rows are never overwritten by legacy data.
- All legacy rows are copied verbatim to the archive before the old table is dropped.

## Weekday conversion

`weekday_mask` uses the following bits:

- MON: 1
- TUE: 2
- WED: 4
- THU: 8
- FRI: 16
- SAT: 32
- SUN: 64

`NULL`, blank, `ALL`, `DAILY`, `EVERYDAY`, and `ANY` mean no weekday restriction. Unknown codes are not guessed: the mask is left `NULL` and the archived row is marked `REVIEW_REQUIRED_WEEKDAY`.

## Migration behavior

- Multiple active legacy rows for the same user/type are consolidated.
- Latest `updated_at`, then `row_version`, then `id` determines enabled state and latest non-empty local time.
- Sound defaults from the active `app_preference`; timezone comes from `user_account`.
- Deleted-only legacy data does not create an active preference.
- `source_device_id` is added to the canonical table.
- Every original legacy column value is preserved in the archive.

## Added

- `docs/schema_v9.sqlite.sql`
- `lib/core/database/schema/schema_v9.drift`
- `docs/migrations/v8_to_v9.sql`
- `tools/verify_notification_preference_migration.py`
- `notification_setting_legacy_archive`

## Acceptance criteria

- Direct Schema v9 creation and v8→v9 migration are structurally equal.
- Schema v9 has 75 tables: 74 operational/content tables plus one read-only legacy archive.
- `notification_setting` no longer exists.
- Every legacy row is preserved verbatim.
- Existing canonical preferences retain their values.
- MON/WED/FRI becomes mask 21.
- Unknown weekday values are flagged for review.
- Foreign-key, unique-index and archive-status constraints reject invalid data.

## Deferred at B3 completion

- 通知設定画面とSQLiteの接続はTask 19.5-C4で実装した。
- Native iOS notification adapterは引き続き未実装である。
