# Task 19 — 通知・リマインダー

MVP対象はトレーニング予定、週間メニュー確認、任意の未記録リマインダー、インターバル終了。通知拒否でも主要機能は利用可能。WidgetKit、Live Activity、FCMは対象外。時刻・タイムゾーン変更時には予定を再計算する設計とする。

## 現在の状態

- Schema v9では`notification_preference`が唯一の運用設定正本。
- Task 19.5-C4で設定画面とSQLite Repositoryを接続済み。
- 有効／無効、時刻、事前通知をSQLiteへ保存し、既存予約の取消状態もDBへ反映する。
- ネイティブGatewayはStubであり、iOS権限・実予約・配信は未実装。
- 週間予定、未記録判定、休憩タイマーから`notification_schedule`を生成するsource-specific schedulerは未実装。

したがって、通知設定のローカル永続化は実装済みだが、通知機能全体は完成していない。
