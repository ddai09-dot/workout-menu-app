# タスク20-B：Flutter・iOS統合実行検証

## 判定

**BLOCKED／タスク20-B全体は未完了。**

この作成環境ではFlutter SDK、Dart、Xcode、xcrunが利用できないため、依存解決、コード生成、Flutter解析・テスト、iOS Simulatorビルドを実行できない。静的契約検証の合格をFlutterまたはiOSの実行成功とは扱わない。

## 今回実施したこと

- Flutter `3.44.6`を`.fvmrc`、CI、実行スクリプトで固定
- Linux／一般Flutter環境用の一括実行スクリプトを作成
- macOS／Xcode用のiOS Simulator一括実行スクリプトを作成
- GitHub ActionsでFlutter検証とiOS Simulatorビルドを分離
- Google公式release metadataからFlutter SDKを導入し、version、release ref、SHA-256を検証
- GitHub Actionsの全`uses:`を完全長commit SHAへ固定し、`contents: read`と`persist-credentials: false`を設定
- 工程ごとの`steps.ndjson`、最終`result.json`、lock・生成コード・Simulator appをArtifact回収対象へ追加
- 成否にかかわらず、各工程ログと`result.json`をArtifactへ保存する構成へ変更
- 現環境のコマンド、生成物、阻害要因をJSONで記録
- 実行レーン自体を静的に検査する専用Verifierを`make verify`へ追加

## 採用判断

### 採用：再現可能な2段階実行レーン

1. Ubuntu等で依存解決、Drift生成、静的解析、custom_lint、Flutter Testを実行する。
2. macOS／Xcodeで同じ検証に加えてiOS Simulatorビルドを実行する。

採用理由：Flutter側の不具合とiOS固有の不具合を分離でき、どの工程で失敗したかをログで追跡できるため。

採用しなかった案：

- 現環境の静的検証だけで統合完了とする案：コンパイル・実行を確認していないため不採用。
- Flutterの固定版を外して最新版で動けば合格とする案：依存解決結果と再現性が変わるため不採用。
- iOS検証を省略する案：iPhone向けMVPの受入判定として不十分なため不採用。

アプリ機能の削除はない。CI技術では`subosito/flutter-action`を完全削除し、公式archive検証へ置換した。cross-run cacheは完全削除ではなく、初回PASSまで一時的に除外・後回しとし、PL-004で管理する。

## 現環境の阻害要因

- `flutter`：未導入
- `dart`：未導入
- `pubspec.lock`：未生成
- Drift生成コード：未生成
- `ios/`：未生成
- ホストOS：Linux
- `xcodebuild`／`xcrun`：利用不可

## Flutter実行コマンド

```bash
./tools/run_task20_b_flutter_checks.sh
```

このスクリプトは、以下がすべて成功した場合だけ`PASS`を出力する。

1. Flutter版確認
2. `flutter pub get`
3. Drift／Riverpod生成
4. `make verify`
5. `flutter analyze`
6. `dart run custom_lint`
7. `flutter test --reporter expanded`

## iOS Simulator実行コマンド

macOS／Xcode環境で実行する。

```bash
./tools/run_task20_b_ios_simulator.sh
```

Flutter検証に加え、iOS雛形生成と`flutter build ios --simulator --debug`が成功した場合だけ`PASS`とする。

## 完了条件

タスク20-Bを完了とするには、少なくとも次が必要である。

- `pubspec.lock`を生成して正本へ追加
- Drift生成コードを生成
- `flutter analyze`合格
- `custom_lint`合格
- 全Flutter Test合格
- macOS上のiOS Simulator debug build合格
- 初期登録、週間生成、トレーニング実施、記録、通常設定編集、データ初期化の主要導線をSimulatorで確認

iPhone実機確認とアクセシビリティ確認は、Simulator build後の次段階として残る。


## タスク20-B2：CI供給網・証跡の強化

### 採用

- 公式Flutter release metadataを正本とするSDK installer
- Flutter `3.44.6`、release ref `ee80f08`、archive SHA-256の三重確認
- GitHub Actionsの完全長commit SHA固定、最小権限、checkout credential非保持
- 各工程の開始・終了・所要時間・exit codeを`steps.ndjson`へ記録
- `pubspec.lock`、`lib/**/*.g.dart`、iOS Simulator `.app`を実行証跡として回収

採用理由：CIが動いたという事実だけでなく、どのSDK・どの工程・どの生成物で合否が出たかを後から検証できるようにするため。

### 完全削除

- `subosito/flutter-action`：完全削除。公式archive installerへ一本化したため、後回しタスクにはしない。

### 一時的に除外・後回し

- cross-run cache：初回Flutter PASSとiOS Simulator PASSの取得まで一時的に除外。PL-004の再開条件を満たした後に再検討する。

### 現在の実行判定

この環境で更新後Runnerを再実行し、Flutter側は`preflight_flutter`、iOS側は`preflight_macos`で`BLOCKED`になった。これは期待した環境阻害判定であり、Flutter compile／test／iOS buildの成功ではない。
