# タスク18 AI相談・フォームアドバイス機能 実装レポート

## 完了範囲
- AI相談画面、用語・FAQ画面
- Edge Function経由のOpenAI接続境界
- 端末へAPIキーを置かない構成
- 個人情報除外用ContextBuilder
- 24時間キャッシュ
- 会話履歴、フィードバック、プロンプト版管理、FAQ、用語辞典のSchema v7
- 痛み等の安全エスカレーション

## 決定権の制限
AIは説明と一般的助言のみを行います。週間メニュー、重量、回数、セット数、進行提案、DB更新は既存ルールエンジンの責務です。

## Schema v7
追加7テーブル：ai_chat_session、ai_chat_message、ai_prompt_template、ai_response_cache、ai_feedback、ai_faq、ai_dictionary。合計72テーブル。

## 未実施
Flutter SDK、Apple/Supabase/OpenAI実環境がないため、flutter pub get、Drift生成、analyze、test、Simulator、Edge Function配備、実API疎通は未実施です。
