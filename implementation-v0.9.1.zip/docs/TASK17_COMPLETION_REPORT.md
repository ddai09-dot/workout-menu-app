# タスク17 アカウント・同期機能 実装レポート

## 実装版

- v0.6.0
- Schema v6

## 実装範囲

- 匿名利用を初期状態とするアカウント境界
- Apple連携用の認証アダプター境界とSupabaseサービス（認証設定前はボタン無効）
- Keychain経由の現在ユーザー保持
- Outboxへの同期操作登録
- 同期実行履歴、端末別チェックポイント、競合履歴
- アクティブなトレーニングと追記型セット記録を保護する競合解決
- 退会申請のローカルキューとサーバー削除関数の境界
- マイページの「アカウントと同期」導線

## Schema v6

既存の `user_account`、`device_registration`、`sync_outbox` を再利用し、重複テーブルは作成していません。追加は以下の5テーブルです。

- `account_link_history`
- `sync_checkpoint`
- `sync_run_history`
- `sync_conflict_log`
- `account_deletion_request`

合計テーブル数は65です。

## 競合ルール

- `work_set_record`／`workout_session_event`：追記マージ
- `IN_PROGRESS`の`workout_session`：ローカル優先
- その他：`row_version`、同値なら`updated_at`
- 解決不能：破棄せず保留・履歴化

## 検証

- Schema v6のSQLite新規作成
- 65テーブルを確認
- 外部キー違反0
- v5→v6 migration SQL適用
- 競合解決ルールの契約テスト追加
- Dartファイルのローカルimport参照・デリミタ静的検査
- ZIP Manifest、SHA-256、CRC検証

## 未実施

作成環境にFlutter SDKがないため、`flutter pub get`、Driftコード生成、`flutter analyze`、`custom_lint`、`flutter test`、iOS Simulator／実機ビルドは未実施です。

Apple Sign inの実認証には、Apple Developer設定、Supabase Auth設定、Associated Domains／Entitlements、およびアカウント削除Edge Functionの配備が必要です。
