# タスク10からの実装修正

未稼働のSchema v1なので、後方互換性を壊さずに以下を先に修正しました。

## 1. `weekly_priority_part`を追加

週次計画で「今週だけ優先部位を変える」仕様がある一方、最終DB設計書からテーブルが欠落していました。

**影響:** 追加しない場合、週次上書きをJSONへ逃がすか、通常設定を書き換える必要があり、過去再現性が失われます。

## 2. `exercise_equipment_option`を追加

元設計の平坦な`exercise_equipment`だけでは、
「ケーブル＋バー または ケーブル＋ロープ」のような代替器具セットを正確に表現できません。

**影響:** 追加しない場合、利用可能な種目を誤判定します。

`exercise_equipment_option`を成立可能な器具セットとし、`exercise_equipment`をセット内の必須器具として扱います。

## 3. 時間種目用の進行列を追加

`exercise_progression_profile`へ以下を追加しました。

- `target_mode_code`
- `duration_lower_sec`
- `duration_upper_sec`

**影響:** プランク等を回数列へ無理に格納せず、秒単位で判定できます。

## 4. 補助量の予定値を追加

`planned_set`へ`target_assistance_value`を追加しました。

**影響:** アシスト懸垂のように「補助量が減るほど進歩」の種目を予定値と実績値で比較できます。

## 変更していないもの

- 既存の種目ID `EX001`〜`EX072`
- 論理削除方針
- 過去スナップショット方針
- kg正規化＋入力単位保持
- AI非依存方針

# タスク13で追加したSchema v2修正

## 5. `onboarding_draft`

必須列を持つ正規化テーブルへ未回答値を入れず、登録途中だけ専用JSONへ保存します。完了後は正規化して下書きを論理削除します。

## 6. 経験回答の3段階コード

`adjustment_habit_code`と`logging_habit_code`を追加しました。従来BOOLEANだけでは「ときどき」を保持できないためです。

## 7. 器具別詳細

`location_dumbbell_detail`と`location_barbell_detail`を追加しました。同じ場所に固定式と可変式ダンベルを両方登録可能にし、器具固有情報を分離します。ダンベルの数量は`unit_count`、使用可能重量とバーベルの所有プレートは`equipment_weight_option`へ保存します。

## 8. 関節を対象とする身体制限

`user_restriction.joint_id`を追加しました。首・肘・手首・腰・股関節・膝・足首を正しく参照します。


# タスク14で追加したSchema v3修正

## 9. `weekly_planner_draft`

週次質問の未回答・入力途中状態を正規化テーブルへ無理に入れないため、一時下書き専用JSONを追加しました。生成時に正規化し、確定後は論理削除します。

## 10. 生成トレースと時間見積り

以下を追加しました。

- `weekly_menu.generation_trace_json`
- `weekly_menu.estimated_total_min`
- `workout_day_plan.estimated_duration_min`
- `planned_exercise.selection_score`
- `planned_exercise.selection_reason_ids_json`

これにより、採用理由、検証警告、分割名、推定時間をマスタ変更後も再現できます。

## 11. 週次優先部位の一意制約

主優先は週に1件、補助優先は部位ごとに複数件保存できるよう、単純な`(training_week_id, priority_type)`一意制約を以下へ分割しました。

- 主優先：`training_week_id`に対する部分一意索引
- 補助優先：`training_week_id + priority_type + body_part_id`

`SECONDARY:CHEST`のような動的コードは使用せず、安定コード`SECONDARY`を維持します。

## 12. 論理削除後の週次上書き

`weekly_available_day`と`weekly_priority_part`の一意索引を`deleted_at IS NULL`の部分一意索引へ変更しました。再生成時に旧回答を論理削除した後、同じ曜日・部位を新しい回答として保存できます。

# タスク15で追加したSchema v4修正

## 13. `session_set_target`

確定済みの`planned_set`を直接変更せず、当日のセット数変更、痛みによる負荷低減、代替種目の目標をセッション単位で保持します。

**影響:** 週間計画の履歴を壊さず、実施時の変更と元計画を比較できます。

## 14. `workout_session_event`

開始、セット完了、訂正、休憩変更、後回し、代替、スキップ、痛み、途中終了などの操作を追記型イベントとして保存します。

**影響:** 同期、障害調査、将来の進行提案で「最終状態だけでは分からない操作経緯」を確認できます。イベントを画面状態の唯一の正にはせず、正規化済み現行状態と併用します。

## 15. 実施中の復帰状態

`workout_session`へ以下を追加しました。

- `current_input_draft_json`
- `last_interaction_at`
- `completion_reason_code`

重量・回数等の未確定入力は短命なJSONへ自動保存し、確定セットは`work_set_record`へ正規化します。

## 16. 元計画と当日変更の分離

`session_exercise`へ以下を追加しました。

- `original_order_index`
- `original_set_count`
- `target_set_count`
- `skip_reason_code`
- `started_at` / `ended_at`

**影響:** 後回し、セット数変更、部分実施、スキップを元計画との差分として評価できます。

## 17. セット訂正と休憩実績

`work_set_record`へ以下を追加しました。

- `rest_duration_sec`
- `correction_reason_code`

修正は旧レコードを`voided_at`で無効化し、新レコードの`supersedes_id`から関連付けます。過去値を上書きしません。

## 18. 実施中の日を週間再生成から保護

週間メニュー再生成時の固定対象へ`IN_PROGRESS`を追加しました。

**影響:** 開いているセッションの元計画が再生成で差し替わり、進行位置やセット参照が壊れることを防ぎます。

## 19. 比較系列キーの補正

Seedの`series_code`には`exercise_id + variation_id + load_mode`のような設計式が含まれるため、その文字列自体を実績キーとして保存する方式を廃止しました。Schema v4時点では不変の`exercise_id`を基礎キーとし、実際の`variation_code`と`equipment_mode_code`をセット記録へ保存します。

**影響:** 異なる種目が同じ式文字列で混ざる誤集計を防ぎます。タスク16で、種目ID・バリエーション・器具モード・マシン個体キーを組み合わせた正式な比較系列を定義します。

## 20. 未終了セッションと有効セットの重複防止

以下の部分一意索引を追加しました。

- `uq_open_workout_session`：1ユーザーにつき`IN_PROGRESS`または`AWAITING_ASSESSMENT`は1件
- `uq_active_work_set`：同一実施種目・セット番号・左右区分につき、`voided_at IS NULL`の実績は1件

**影響:** 開始ボタンやセット完了ボタンの連打、通信再試行、画面再構築による二重登録をDB層でも防止します。セット訂正は旧行を先に無効化するため、追記型履歴と両立します。



## 21. 比較系列と評価履歴を追加

タスク10の`progression_proposal`だけでは、どの器具・マシン・バリエーション・左右条件の記録を比較したかを再現できません。Schema v5で以下を追加しました。

- `exercise_performance_series`
- `session_exercise_evaluation`

**影響:** 同名種目でも条件が異なる実績を混ぜず、判定入力・結果・理由を過去スナップショットとして保持できます。

## 22. 提案回答と適用キューを分離

提案本体へ最終状態だけを保存すると、「採用したが次の予定がまだない」「一度維持した」「拒否後の抑制期間」といった状態を追跡できません。以下を追加しました。

- `progression_proposal_decision`
- `accepted_progression_adjustment`

**影響:** 提案履歴とユーザー判断を分離し、採用した調整を未来予定または次回生成へ一度だけ適用できます。

## 23. 提案元評価の整合性

SQLiteは既存テーブルへ外部キー制約付き列を単純追加できないため、`progression_proposal.source_evaluation_id`は通常列として追加し、挿入・更新トリガーで有効な`session_exercise_evaluation`の存在を検証します。

**影響:** 新規Schema v5とv4→v5移行後で、同じ参照整合性を維持します。


## Schema v6
既存の user_account / device_registration / sync_outbox を再利用し、リンク監査、チェックポイント、同期実行、競合、退会申請の5テーブルのみ追加しました。


## Schema v7
AI data is separated from workout decision tables. AI messages cannot directly reference or update planned_set/progression tables. This enforces the advisory-only boundary.


## Schema v8→v9：通知設定の正本統合

Schema v8では旧`notification_setting`と新`notification_preference`が同時に存在し、通知設定の正本が二重でした。Schema v9では次の方針へ統一しました。

- 運用上の唯一の正本：`notification_preference`
- 旧行の保全：`notification_setting_legacy_archive`
- 旧運用テーブル`notification_setting`：削除
- 端末由来情報：`notification_preference.source_device_id`へ追加
- 曜日ビット：MON=1、TUE=2、WED=4、THU=8、FRI=16、SAT=32、SUN=64

既存の新`notification_preference`がある場合は上書きせず、その行を優先します。旧テーブルの曜日別複数行は1件へ集約し、未知の曜日コードは推測せず`weekday_mask=NULL`かつ`REVIEW_REQUIRED_WEEKDAY`としてアーカイブします。削除済み旧行だけの組合せから有効設定は生成しません。
