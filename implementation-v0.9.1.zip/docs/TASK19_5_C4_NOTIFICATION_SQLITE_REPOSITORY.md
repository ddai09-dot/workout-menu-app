# Task 19.5-C4: 通知設定SQLite Repository接続

## 範囲

`notification_preference`を通知設定画面の唯一のローカル正本として接続する。
ネイティブiOS通知の権限取得・予約・配信は本タスクに含めず、Gateway Stubのまま維持する。

## 実装

- `LocalNotificationRepository`をAppDatabaseへ接続。
- 通知設定4種類を初回読込時に不足分だけ作成。
- 設定画面から有効／無効、通知時刻、予定通知の事前時間を保存。
- `weekday_mask`、音、振動、タイムゾーンを読込・保持。
- 保存値はRepositoryの再生成後もSQLiteから復元。
- 設定変更時は同種の既存予約をGatewayで取消し、`notification_schedule.status_code`を`CANCELLED`へ更新。
- 全取消ではGateway取消後に対象ユーザーの予約状態をDBへ反映。
- 許可済みの場合だけ、DBに既に存在する有効な予約行をGatewayへ再登録できる境界を実装。
- Repository Providerを`appDatabaseProvider`へ接続し、インメモリMapを廃止。

## 既定値

| 種類 | 有効 | 時刻 | 曜日 | 事前通知 |
|---|---:|---|---|---:|
| WORKOUT_PLAN | 1 | 18:00 | 制限なし | 60分 |
| WEEKLY_PLANNING | 1 | 19:00 | 制限なし | 0分 |
| INACTIVITY | 0 | 19:00 | 制限なし | 0分 |
| REST_TIMER | 1 | なし | 制限なし | 0分 |

既存行は上書きせず、不足している種類だけを追加する。

## 安全契約

- `notification_preference`以外を運用設定の正本にしない。
- 保存時は`row_version`を加算し、`sync_status = LOCAL_ONLY`へ戻す。
- 時刻は`HH:mm`、曜日マスクは0〜127、事前通知は0〜1440分だけ受け付ける。
- 設定変更後の新規予約生成は、週間予定・休憩タイマー等のsource-specific schedulerの責務とする。
- 古い予約を新設定のまま残さないため、同種の既存予約は取消す。
- ネイティブ実装がない状態を通知完成と表現しない。

## 検証

- `verify_notification_repository_contract.py`で、ソース接続、4既定値、一意制約、SQLite永続化、予約取消状態、FK違反0を検証。
- Repository単体テストを作成したが、Flutter SDKがないため未実行。
- `make verify`へC4検証を追加。

## 未実施

- `flutter_local_notifications`等のネイティブアダプター導入
- iOS通知権限ダイアログ
- 週間メニュー・未記録・休憩タイマーからの予約行生成
- タイムゾーン変更・端末再起動時の実再予約
- 通知タップによる画面遷移の実機確認
- Flutter Test、Widget Test、iOS Simulator、iPhone実機確認
