-- Workout Menu App / Drift schema v8
-- Dates and timestamps are ISO-8601 TEXT. UUID/ULID and enums are TEXT.
-- Do not reuse stable codes, even after logical deletion.

CREATE TABLE body_part_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  parent_body_part_id TEXT REFERENCES body_part_master(id) ON DELETE RESTRICT,
  split_group_code TEXT,
  display_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE movement_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  movement_group_code TEXT NOT NULL
);

CREATE TABLE equipment_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  equipment_category_code TEXT NOT NULL,
  supports_weight_options INTEGER NOT NULL DEFAULT 0,
  supports_quantity INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE joint_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE fatigue_tag_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fatigue_group_code TEXT NOT NULL
);

CREATE TABLE exercise_master (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  series_code TEXT,
  technical_difficulty_code TEXT NOT NULL,
  role_code TEXT NOT NULL,
  exercise_class_code TEXT NOT NULL,
  execution_mode_code TEXT NOT NULL,
  recording_method_code TEXT NOT NULL,
  beginner_availability TEXT NOT NULL,
  intermediate_availability TEXT NOT NULL,
  advanced_availability TEXT NOT NULL,
  default_priority_code TEXT NOT NULL DEFAULT 'STANDARD',
  image_angle_code TEXT
);

CREATE TABLE exercise_body_part (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  body_part_id TEXT NOT NULL REFERENCES body_part_master(id) ON DELETE RESTRICT,
  relation_type TEXT NOT NULL
);

CREATE TABLE exercise_movement (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  movement_id TEXT NOT NULL REFERENCES movement_master(id) ON DELETE RESTRICT,
  relation_type TEXT NOT NULL
);

CREATE TABLE exercise_equipment_option (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  option_code TEXT NOT NULL,
  display_order INTEGER NOT NULL DEFAULT 1,
  is_active INTEGER NOT NULL DEFAULT 1,
  source_text TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE exercise_equipment (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  equipment_option_id TEXT NOT NULL REFERENCES exercise_equipment_option(id) ON DELETE RESTRICT,
  equipment_id TEXT NOT NULL REFERENCES equipment_master(id) ON DELETE RESTRICT,
  requirement_type TEXT NOT NULL,
  minimum_quantity INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE exercise_joint (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  joint_id TEXT NOT NULL REFERENCES joint_master(id) ON DELETE RESTRICT,
  risk_level TEXT NOT NULL DEFAULT 'NORMAL'
);

CREATE TABLE exercise_fatigue_tag (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  fatigue_tag_id TEXT NOT NULL REFERENCES fatigue_tag_master(id) ON DELETE RESTRICT,
  fatigue_weight REAL NOT NULL DEFAULT 1.0
);

CREATE TABLE exercise_alternative (
  id TEXT PRIMARY KEY NOT NULL,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  alternative_exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  reason_code TEXT NOT NULL,
  priority INTEGER NOT NULL DEFAULT 100,
  CONSTRAINT ck_no_self CHECK (exercise_id <> alternative_exercise_id)
);

CREATE TABLE exercise_progression_profile (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  goal_code TEXT NOT NULL,
  experience_level_code TEXT NOT NULL,
  progression_group_code TEXT NOT NULL,
  target_mode_code TEXT NOT NULL,
  rep_lower INTEGER,
  rep_upper INTEGER,
  duration_lower_sec INTEGER,
  duration_upper_sec INTEGER,
  set_lower INTEGER NOT NULL,
  set_upper INTEGER NOT NULL,
  rest_sec INTEGER NOT NULL,
  CONSTRAINT ck_rep_range CHECK (rep_lower IS NULL OR rep_upper IS NULL OR rep_lower <= rep_upper),
  CONSTRAINT ck_duration_range CHECK (duration_lower_sec IS NULL OR duration_upper_sec IS NULL OR duration_lower_sec <= duration_upper_sec),
  CONSTRAINT ck_set_range CHECK (set_lower <= set_upper)
);

CREATE TABLE exercise_form_copy (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  image_1_label TEXT NOT NULL,
  image_2_label TEXT NOT NULL,
  movement_tip TEXT NOT NULL,
  caution_text TEXT NOT NULL
);

CREATE TABLE exercise_form_asset (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  asset_position INTEGER NOT NULL,
  asset_uri TEXT NOT NULL,
  checksum TEXT NOT NULL,
  asset_status TEXT NOT NULL DEFAULT 'NOT_STARTED',
  CONSTRAINT ck_asset_position CHECK (asset_position IN (1,2))
);

CREATE TABLE user_account (
  id TEXT PRIMARY KEY NOT NULL,
  auth_provider TEXT NOT NULL DEFAULT 'ANONYMOUS',
  auth_subject TEXT UNIQUE,
  account_status TEXT NOT NULL DEFAULT 'ACTIVE',
  locale TEXT NOT NULL DEFAULT 'ja-JP',
  timezone TEXT NOT NULL DEFAULT 'Asia/Tokyo',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT
);

CREATE TABLE user_profile (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  nickname TEXT NOT NULL,
  age_years INTEGER NOT NULL,
  age_updated_on TEXT NOT NULL,
  sex_code TEXT,
  height_cm REAL,
  onboarding_completed_at TEXT
);

CREATE TABLE user_training_setting (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  desired_days_per_week INTEGER NOT NULL,
  usual_duration_min INTEGER NOT NULL,
  location_mode_code TEXT NOT NULL,
  both_usage_mode_code TEXT,
  split_preference_code TEXT NOT NULL DEFAULT 'APP',
  ab_goal_code TEXT NOT NULL DEFAULT 'NONE',
  change_applies_from TEXT NOT NULL DEFAULT 'NEXT_MENU'
);

CREATE TABLE user_experience_profile (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  cumulative_experience_code TEXT NOT NULL,
  continuity_code TEXT NOT NULL,
  hiatus_code TEXT,
  current_frequency INTEGER NOT NULL,
  adjusts_by_history INTEGER NOT NULL DEFAULT 0,
  logs_sets INTEGER NOT NULL DEFAULT 0,
  calculated_level_code TEXT NOT NULL,
  returning_mode INTEGER NOT NULL DEFAULT 0,
  start_volume_factor REAL NOT NULL DEFAULT 1.0,
  calculated_by_rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT
, adjustment_habit_code TEXT NOT NULL DEFAULT 'NONE', logging_habit_code TEXT NOT NULL DEFAULT 'NONE');

CREATE TABLE training_location (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  location_type_code TEXT NOT NULL,
  display_name TEXT NOT NULL,
  gym_profile_code TEXT,
  is_primary INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE location_equipment (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  training_location_id TEXT NOT NULL REFERENCES training_location(id) ON DELETE RESTRICT,
  equipment_id TEXT NOT NULL REFERENCES equipment_master(id) ON DELETE RESTRICT,
  quantity INTEGER NOT NULL DEFAULT 1,
  min_weight REAL,
  max_weight REAL,
  increment_weight REAL,
  has_rack INTEGER NOT NULL DEFAULT 0,
  has_safety INTEGER NOT NULL DEFAULT 0,
  is_available INTEGER NOT NULL DEFAULT 1,
  CONSTRAINT ck_weight_range CHECK ((min_weight IS NULL OR max_weight IS NULL OR min_weight <= max_weight))
);

CREATE TABLE equipment_weight_option (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  location_equipment_id TEXT NOT NULL REFERENCES location_equipment(id) ON DELETE RESTRICT,
  weight_value REAL NOT NULL,
  unit_code TEXT NOT NULL DEFAULT 'KG',
  quantity INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE standard_schedule_day (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  weekday_code TEXT NOT NULL,
  is_available INTEGER NOT NULL DEFAULT 0,
  duration_min INTEGER,
  training_location_id TEXT REFERENCES training_location(id) ON DELETE RESTRICT
);

CREATE TABLE user_goal (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  goal_code TEXT NOT NULL,
  goal_type TEXT NOT NULL,
  display_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE user_priority_part (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  context_code TEXT NOT NULL,
  priority_type TEXT NOT NULL,
  body_part_id TEXT REFERENCES body_part_master(id) ON DELETE RESTRICT,
  appearance_code TEXT,
  CONSTRAINT ck_priority_target CHECK (((body_part_id IS NULL) <> (appearance_code IS NULL)))
);

CREATE TABLE user_restriction (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  restriction_type_code TEXT NOT NULL,
  body_part_id TEXT REFERENCES body_part_master(id) ON DELETE RESTRICT,
  movement_id TEXT REFERENCES movement_master(id) ON DELETE RESTRICT,
  exercise_id TEXT REFERENCES exercise_master(id) ON DELETE RESTRICT,
  default_action_code TEXT NOT NULL,
  effective_from TEXT NOT NULL,
  effective_to TEXT,
  source_code TEXT NOT NULL DEFAULT 'USER'
, joint_id TEXT REFERENCES joint_master(id) ON DELETE RESTRICT);

CREATE TABLE notification_setting (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  notification_type_code TEXT NOT NULL,
  is_enabled INTEGER NOT NULL DEFAULT 1,
  time_local TEXT,
  weekday_code TEXT
);

CREATE TABLE app_preference (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  weight_unit_code TEXT NOT NULL DEFAULT 'KG',
  height_unit_code TEXT NOT NULL DEFAULT 'CM',
  appearance_code TEXT NOT NULL DEFAULT 'SYSTEM',
  sound_enabled INTEGER NOT NULL DEFAULT 1,
  rest_timer_default_sec INTEGER NOT NULL DEFAULT 90
);

CREATE TABLE device_registration (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  platform_code TEXT NOT NULL DEFAULT 'IOS',
  app_version TEXT NOT NULL,
  push_token TEXT UNIQUE,
  last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE training_week (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  week_start_date TEXT NOT NULL,
  week_end_date TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'PLANNING',
  CONSTRAINT ck_week_dates CHECK (week_end_date = date(week_start_date, '+6 day')),
  CONSTRAINT ck_week_monday CHECK (strftime('%w', week_start_date) = '1')
);

CREATE TABLE weekly_input (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  same_as_last_week INTEGER NOT NULL DEFAULT 0,
  sleep_score INTEGER NOT NULL,
  motivation_score INTEGER NOT NULL,
  previous_load_score INTEGER,
  goal_rep_achievement_rate REAL,
  weekly_load_direction_code TEXT NOT NULL DEFAULT 'APP',
  increase_method_code TEXT,
  split_override_code TEXT,
  rest_week INTEGER NOT NULL DEFAULT 0, priority_mode_code TEXT NOT NULL DEFAULT 'DEFAULT',
  CONSTRAINT ck_sleep_score CHECK (sleep_score BETWEEN 1 AND 5),
  CONSTRAINT ck_motivation_score CHECK (motivation_score BETWEEN 1 AND 5),
  CONSTRAINT ck_previous_load_score CHECK (previous_load_score IS NULL OR previous_load_score BETWEEN 1 AND 5),
  CONSTRAINT ck_achievement_rate CHECK (goal_rep_achievement_rate IS NULL OR goal_rep_achievement_rate BETWEEN 0 AND 1)
);

CREATE TABLE weekly_available_day (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  weekday_code TEXT NOT NULL,
  plan_date TEXT NOT NULL,
  is_available INTEGER NOT NULL DEFAULT 0,
  duration_min INTEGER,
  training_location_id TEXT REFERENCES training_location(id) ON DELETE RESTRICT
);

CREATE TABLE weekly_priority_part (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  body_part_id TEXT NOT NULL REFERENCES body_part_master(id) ON DELETE RESTRICT,
  priority_type TEXT NOT NULL
);

CREATE TABLE weekly_pain_entry (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  body_part_id TEXT NOT NULL REFERENCES body_part_master(id) ON DELETE RESTRICT,
  action_code TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'NOTICEABLE_CONTINUE'
);

CREATE TABLE weekly_stalled_exercise (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  detected_by_code TEXT NOT NULL,
  adjustment_code TEXT NOT NULL,
  recommended_adjustment_code TEXT
);

CREATE TABLE weekly_menu (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  training_week_id TEXT NOT NULL REFERENCES training_week(id) ON DELETE RESTRICT,
  menu_version INTEGER NOT NULL DEFAULT 1,
  status_code TEXT NOT NULL DEFAULT 'DRAFT',
  split_code TEXT,
  generated_at TEXT NOT NULL,
  finalized_at TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  generation_input_snapshot_json TEXT NOT NULL
, generation_trace_json TEXT NOT NULL DEFAULT '{}', estimated_total_min INTEGER NOT NULL DEFAULT 0);

CREATE TABLE workout_day_plan (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  weekly_menu_id TEXT NOT NULL REFERENCES weekly_menu(id) ON DELETE RESTRICT,
  plan_date TEXT NOT NULL,
  weekday_code TEXT NOT NULL,
  training_location_id TEXT REFERENCES training_location(id) ON DELETE RESTRICT,
  duration_min INTEGER NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'PLANNED',
  session_focus_snapshot TEXT NOT NULL,
  reason_text_snapshot TEXT NOT NULL
, estimated_duration_min INTEGER NOT NULL DEFAULT 0);

CREATE TABLE planned_exercise (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  workout_day_plan_id TEXT NOT NULL REFERENCES workout_day_plan(id) ON DELETE RESTRICT,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  order_index INTEGER NOT NULL,
  exercise_name_snapshot TEXT NOT NULL,
  role_code_snapshot TEXT NOT NULL,
  recording_method_snapshot TEXT NOT NULL,
  target_part_snapshot TEXT NOT NULL,
  reason_text_snapshot TEXT NOT NULL,
  progression_profile_snapshot_json TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'PLANNED'
, selection_score INTEGER NOT NULL DEFAULT 0, selection_reason_ids_json TEXT NOT NULL DEFAULT '[]');

CREATE TABLE planned_set (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  planned_exercise_id TEXT NOT NULL REFERENCES planned_exercise(id) ON DELETE RESTRICT,
  set_number INTEGER NOT NULL,
  is_warmup INTEGER NOT NULL DEFAULT 0,
  target_weight_kg REAL,
  input_weight_value REAL,
  input_weight_unit_code TEXT,
  target_reps_lower INTEGER,
  target_reps_upper INTEGER,
  target_duration_sec INTEGER,
  target_assistance_value REAL,
  rest_sec INTEGER NOT NULL,
  CONSTRAINT ck_target_range CHECK (target_reps_lower IS NULL OR target_reps_upper IS NULL OR target_reps_lower <= target_reps_upper)
);

CREATE TABLE workout_session (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  workout_day_plan_id TEXT REFERENCES workout_day_plan(id) ON DELETE RESTRICT,
  attempt_number INTEGER NOT NULL DEFAULT 1,
  status_code TEXT NOT NULL DEFAULT 'IN_PROGRESS',
  started_at TEXT NOT NULL,
  ended_at TEXT,
  record_date TEXT NOT NULL,
  training_location_id TEXT REFERENCES training_location(id) ON DELETE RESTRICT,
  current_session_exercise_id TEXT,
  current_set_number INTEGER,
  rest_started_at TEXT,
  rest_duration_sec INTEGER,
  last_local_saved_at TEXT NOT NULL,
  day_adjustment_snapshot_json TEXT
, current_input_draft_json TEXT NOT NULL DEFAULT '{}', last_interaction_at TEXT NOT NULL DEFAULT '', completion_reason_code TEXT);

CREATE TABLE session_exercise (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
  planned_exercise_id TEXT REFERENCES planned_exercise(id) ON DELETE RESTRICT,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  order_index INTEGER NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'IN_PROGRESS',
  exercise_name_snapshot TEXT NOT NULL,
  recording_method_snapshot TEXT NOT NULL,
  performance_series_key TEXT NOT NULL,
  substitution_reason_code TEXT
, skip_reason_code TEXT, started_at TEXT, ended_at TEXT, original_order_index INTEGER NOT NULL DEFAULT 1, original_set_count INTEGER NOT NULL DEFAULT 0, target_set_count INTEGER NOT NULL DEFAULT 0);

CREATE TABLE post_workout_assessment (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
  overall_difficulty_score INTEGER NOT NULL,
  had_pain INTEGER NOT NULL DEFAULT 0,
  incomplete_reason_code TEXT,
  completed_exercise_count INTEGER NOT NULL DEFAULT 0,
  completed_work_set_count INTEGER NOT NULL DEFAULT 0,
  actual_duration_sec INTEGER NOT NULL DEFAULT 0,
  next_proposal_response_code TEXT,
  CONSTRAINT ck_difficulty CHECK (overall_difficulty_score BETWEEN 1 AND 5)
);

CREATE TABLE progression_proposal (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  exercise_id TEXT REFERENCES exercise_master(id) ON DELETE RESTRICT,
  performance_series_key TEXT,
  source_workout_session_id TEXT REFERENCES workout_session(id) ON DELETE RESTRICT,
  proposal_type_code TEXT NOT NULL,
  current_value_json TEXT,
  proposed_value_json TEXT NOT NULL,
  reason_text_snapshot TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'PENDING',
  cooldown_remaining_sessions INTEGER NOT NULL DEFAULT 0
, source_evaluation_id TEXT, proposal_key TEXT NOT NULL DEFAULT '', priority INTEGER NOT NULL DEFAULT 100, expires_at TEXT, applied_at TEXT);

CREATE TABLE work_set_record (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  voided_at TEXT,
  supersedes_id TEXT,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  session_exercise_id TEXT NOT NULL REFERENCES session_exercise(id) ON DELETE RESTRICT,
  planned_set_id TEXT REFERENCES planned_set(id) ON DELETE RESTRICT,
  set_number INTEGER NOT NULL,
  side_code TEXT NOT NULL DEFAULT 'BOTH',
  is_warmup INTEGER NOT NULL DEFAULT 0,
  actual_weight_kg REAL,
  input_weight_value REAL,
  input_weight_unit_code TEXT,
  actual_reps INTEGER,
  actual_duration_sec INTEGER,
  assistance_value REAL,
  variation_code TEXT,
  equipment_mode_code TEXT,
  machine_instance_key TEXT,
  body_weight_snapshot_kg REAL,
  completed_at TEXT NOT NULL, rest_duration_sec INTEGER, correction_reason_code TEXT,
  CONSTRAINT ck_actual_nonnegative CHECK ((actual_weight_kg IS NULL OR actual_weight_kg >= 0) AND (actual_reps IS NULL OR actual_reps >= 0) AND (actual_duration_sec IS NULL OR actual_duration_sec >= 0) AND (assistance_value IS NULL OR assistance_value >= 0))
);

CREATE TABLE session_pain_entry (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  voided_at TEXT,
  supersedes_id TEXT,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
  session_exercise_id TEXT REFERENCES session_exercise(id) ON DELETE RESTRICT,
  body_part_id TEXT NOT NULL REFERENCES body_part_master(id) ON DELETE RESTRICT,
  action_code TEXT NOT NULL,
  timing_code TEXT NOT NULL,
  worsened INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE body_measurement (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  voided_at TEXT,
  supersedes_id TEXT,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  measured_at TEXT NOT NULL,
  weight_kg REAL,
  body_fat_percent REAL,
  source_code TEXT NOT NULL DEFAULT 'MANUAL'
);

CREATE TABLE rule_version (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  rule_type_code TEXT NOT NULL,
  version_label TEXT NOT NULL,
  released_at TEXT NOT NULL,
  checksum TEXT NOT NULL
);

CREATE TABLE reason_template (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  name_ja TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  template_type_code TEXT NOT NULL,
  template_text TEXT NOT NULL,
  placeholder_schema_json TEXT
);

CREATE TABLE sync_outbox (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  operation_code TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  idempotency_key TEXT NOT NULL UNIQUE,
  status_code TEXT NOT NULL DEFAULT 'PENDING',
  retry_count INTEGER NOT NULL DEFAULT 0,
  next_retry_at TEXT
);

CREATE TABLE location_dumbbell_detail (
  id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT, row_version INTEGER NOT NULL DEFAULT 1, sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  location_equipment_id TEXT NOT NULL REFERENCES location_equipment(id) ON DELETE RESTRICT,
  setup_type_code TEXT NOT NULL, unit_count INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE location_barbell_detail (
  id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT, row_version INTEGER NOT NULL DEFAULT 1, sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  location_equipment_id TEXT NOT NULL REFERENCES location_equipment(id) ON DELETE RESTRICT,
  shaft_weight_kg REAL NOT NULL, max_total_weight_kg REAL NOT NULL, min_increment_kg REAL NOT NULL,
  has_rack INTEGER NOT NULL DEFAULT 0, has_safety INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE onboarding_draft (
  id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  current_step_code TEXT NOT NULL DEFAULT 'INTRO', draft_json TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'IN_PROGRESS', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT, row_version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE weekly_planner_draft (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  week_start_date TEXT NOT NULL,
  current_step_code TEXT NOT NULL DEFAULT 'START',
  draft_json TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'IN_PROGRESS',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE session_set_target (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  session_exercise_id TEXT NOT NULL REFERENCES session_exercise(id) ON DELETE RESTRICT,
  planned_set_id TEXT REFERENCES planned_set(id) ON DELETE RESTRICT,
  set_number INTEGER NOT NULL,
  is_warmup INTEGER NOT NULL DEFAULT 0,
  target_weight_kg REAL,
  input_weight_value REAL,
  input_weight_unit_code TEXT,
  target_reps_lower INTEGER,
  target_reps_upper INTEGER,
  target_duration_sec INTEGER,
  target_assistance_value REAL,
  rest_sec INTEGER NOT NULL,
  source_code TEXT NOT NULL DEFAULT 'PLANNED',
  CONSTRAINT ck_session_target_range CHECK (target_reps_lower IS NULL OR target_reps_upper IS NULL OR target_reps_lower <= target_reps_upper)
);

CREATE TABLE workout_session_event (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
  session_exercise_id TEXT REFERENCES session_exercise(id) ON DELETE RESTRICT,
  event_type_code TEXT NOT NULL,
  payload_json TEXT NOT NULL DEFAULT '{}',
  occurred_at TEXT NOT NULL,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT
);

CREATE TABLE exercise_performance_series (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  series_key TEXT NOT NULL,
  display_name_snapshot TEXT NOT NULL,
  progression_group_code TEXT NOT NULL,
  target_mode_code TEXT NOT NULL,
  first_recorded_at TEXT NOT NULL,
  last_recorded_at TEXT NOT NULL,
  latest_session_exercise_id TEXT REFERENCES session_exercise(id) ON DELETE RESTRICT,
  valid_session_count INTEGER NOT NULL DEFAULT 0,
  stall_count INTEGER NOT NULL DEFAULT 0,
  pain_count INTEGER NOT NULL DEFAULT 0,
  last_result_class_code TEXT,
  baseline_set_count INTEGER,
  baseline_metric_value REAL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE session_exercise_evaluation (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
  session_exercise_id TEXT NOT NULL REFERENCES session_exercise(id) ON DELETE RESTRICT,
  workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
  performance_series_id TEXT NOT NULL REFERENCES exercise_performance_series(id) ON DELETE RESTRICT,
  evaluated_at TEXT NOT NULL,
  result_class_code TEXT NOT NULL,
  valid_for_performance INTEGER NOT NULL DEFAULT 0,
  work_set_count INTEGER NOT NULL DEFAULT 0,
  representative_weight_kg REAL,
  representative_assistance_value REAL,
  total_reps INTEGER NOT NULL DEFAULT 0,
  minimum_reps INTEGER,
  maximum_reps INTEGER,
  total_duration_sec INTEGER NOT NULL DEFAULT 0,
  progression_metric_value REAL,
  comparison_delta REAL,
  progress_detected INTEGER NOT NULL DEFAULT 0,
  stall_count_after INTEGER NOT NULL DEFAULT 0,
  pain_detected INTEGER NOT NULL DEFAULT 0,
  incomplete_reason_code TEXT,
  reason_text_snapshot TEXT NOT NULL,
  input_snapshot_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE progression_proposal_decision (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  progression_proposal_id TEXT NOT NULL REFERENCES progression_proposal(id) ON DELETE RESTRICT,
  decision_code TEXT NOT NULL,
  applies_to_code TEXT NOT NULL DEFAULT 'NEXT_MATCHING_SESSION',
  decision_reason_code TEXT,
  decided_at TEXT NOT NULL,
  application_result_code TEXT,
  target_planned_exercise_id TEXT REFERENCES planned_exercise(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE accepted_progression_adjustment (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  progression_proposal_id TEXT NOT NULL REFERENCES progression_proposal(id) ON DELETE RESTRICT,
  exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
  performance_series_key TEXT,
  adjustment_type_code TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  status_code TEXT NOT NULL DEFAULT 'QUEUED',
  target_planned_exercise_id TEXT REFERENCES planned_exercise(id) ON DELETE RESTRICT,
  queued_at TEXT NOT NULL,
  applied_at TEXT,
  consumed_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE account_link_history (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  event_code TEXT NOT NULL,
  provider_code TEXT NOT NULL,
  provider_subject_hash TEXT,
  occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE sync_checkpoint (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  device_id TEXT NOT NULL REFERENCES device_registration(id) ON DELETE RESTRICT,
  scope_code TEXT NOT NULL DEFAULT 'USER_DATA',
  server_cursor TEXT,
  last_push_at TEXT,
  last_pull_at TEXT,
  last_success_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sync_run_history (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  device_id TEXT NOT NULL REFERENCES device_registration(id) ON DELETE RESTRICT,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  trigger_code TEXT NOT NULL,
  result_code TEXT NOT NULL DEFAULT 'RUNNING',
  pushed_count INTEGER NOT NULL DEFAULT 0,
  pulled_count INTEGER NOT NULL DEFAULT 0,
  conflict_count INTEGER NOT NULL DEFAULT 0,
  error_code TEXT,
  error_message_safe TEXT
);

CREATE TABLE sync_conflict_log (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  sync_run_id TEXT REFERENCES sync_run_history(id) ON DELETE RESTRICT,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  local_row_version INTEGER,
  remote_row_version INTEGER,
  resolution_code TEXT NOT NULL,
  local_payload_hash TEXT,
  remote_payload_hash TEXT,
  resolved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE account_deletion_request (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  requested_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status_code TEXT NOT NULL DEFAULT 'PENDING',
  remote_request_id TEXT,
  completed_at TEXT,
  last_error_code TEXT,
  retry_count INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE ai_chat_session (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  title TEXT NOT NULL DEFAULT '',
  context_type_code TEXT NOT NULL DEFAULT 'GENERAL',
  context_entity_id TEXT,
  status_code TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE ai_chat_message (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  chat_session_id TEXT NOT NULL REFERENCES ai_chat_session(id) ON DELETE RESTRICT,
  role_code TEXT NOT NULL,
  content_text TEXT NOT NULL,
  safety_code TEXT NOT NULL DEFAULT 'OK',
  source_code TEXT NOT NULL DEFAULT 'MODEL',
  model_code TEXT,
  prompt_version TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE ai_prompt_template (
  id TEXT PRIMARY KEY NOT NULL,
  template_code TEXT NOT NULL,
  version_code TEXT NOT NULL,
  locale_code TEXT NOT NULL DEFAULT 'ja-JP',
  system_text TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  retired_at TEXT
);

CREATE TABLE ai_response_cache (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  request_hash TEXT NOT NULL,
  context_hash TEXT NOT NULL,
  response_text TEXT NOT NULL,
  safety_code TEXT NOT NULL DEFAULT 'OK',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TEXT NOT NULL
);

CREATE TABLE ai_feedback (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  message_id TEXT NOT NULL REFERENCES ai_chat_message(id) ON DELETE RESTRICT,
  rating_code TEXT NOT NULL,
  reason_code TEXT,
  comment_text TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ai_faq (
  id TEXT PRIMARY KEY NOT NULL,
  category_code TEXT NOT NULL,
  question_text TEXT NOT NULL,
  answer_text TEXT NOT NULL,
  locale_code TEXT NOT NULL DEFAULT 'ja-JP',
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE ai_dictionary (
  id TEXT PRIMARY KEY NOT NULL,
  term_code TEXT NOT NULL,
  display_term TEXT NOT NULL,
  reading_text TEXT,
  definition_text TEXT NOT NULL,
  locale_code TEXT NOT NULL DEFAULT 'ja-JP',
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  content_version TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notification_preference (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  notification_type_code TEXT NOT NULL,
  is_enabled INTEGER NOT NULL DEFAULT 1,
  local_time TEXT,
  weekday_mask INTEGER,
  advance_minutes INTEGER NOT NULL DEFAULT 0,
  sound_enabled INTEGER NOT NULL DEFAULT 1,
  vibration_enabled INTEGER NOT NULL DEFAULT 1,
  timezone TEXT NOT NULL DEFAULT 'Asia/Tokyo',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE notification_schedule (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  notification_type_code TEXT NOT NULL,
  source_entity_type TEXT,
  source_entity_id TEXT,
  scheduled_at TEXT NOT NULL,
  timezone TEXT NOT NULL DEFAULT 'Asia/Tokyo',
  title_text TEXT NOT NULL,
  body_text TEXT NOT NULL,
  route_path TEXT,
  status_code TEXT NOT NULL DEFAULT 'SCHEDULED',
  platform_notification_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  delivered_at TEXT,
  cancelled_at TEXT,
  deleted_at TEXT,
  row_version INTEGER NOT NULL DEFAULT 1,
  sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
);

CREATE TABLE notification_delivery_log (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  notification_schedule_id TEXT REFERENCES notification_schedule(id) ON DELETE RESTRICT,
  event_code TEXT NOT NULL,
  occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  platform_code TEXT NOT NULL DEFAULT 'IOS',
  app_state_code TEXT,
  error_code TEXT,
  error_message_safe TEXT
);

CREATE UNIQUE INDEX uq_user_auth ON user_account(auth_provider, auth_subject) WHERE auth_subject IS NOT NULL;

CREATE UNIQUE INDEX uq_exercise_code ON exercise_master(code);

CREATE UNIQUE INDEX uq_exercise_body_part ON exercise_body_part(exercise_id, body_part_id, relation_type);

CREATE UNIQUE INDEX uq_exercise_movement ON exercise_movement(exercise_id, movement_id, relation_type);

CREATE UNIQUE INDEX uq_exercise_equipment_option ON exercise_equipment_option(exercise_id, option_code);

CREATE UNIQUE INDEX uq_exercise_equipment ON exercise_equipment(equipment_option_id, equipment_id);

CREATE UNIQUE INDEX uq_equipment_weight ON equipment_weight_option(location_equipment_id, weight_value, unit_code);

CREATE UNIQUE INDEX uq_standard_day ON standard_schedule_day(user_id, weekday_code);

CREATE UNIQUE INDEX uq_user_week ON training_week(user_id, week_start_date);

CREATE UNIQUE INDEX uq_weekly_input ON weekly_input(training_week_id);

CREATE UNIQUE INDEX uq_menu_version ON weekly_menu(training_week_id, menu_version);

CREATE UNIQUE INDEX uq_active_menu ON weekly_menu(training_week_id) WHERE is_active = 1 AND deleted_at IS NULL;

CREATE INDEX ix_active_menu ON weekly_menu(training_week_id, is_active, status_code);

CREATE UNIQUE INDEX uq_plan_date ON workout_day_plan(weekly_menu_id, plan_date);

CREATE UNIQUE INDEX uq_planned_order ON planned_exercise(workout_day_plan_id, order_index);

CREATE UNIQUE INDEX uq_planned_set ON planned_set(planned_exercise_id, set_number);

CREATE INDEX ix_open_session ON workout_session(user_id, status_code, last_local_saved_at);

CREATE UNIQUE INDEX uq_session_order ON session_exercise(workout_session_id, order_index);

CREATE INDEX ix_measurement_time ON body_measurement(user_id, measured_at);

CREATE INDEX ix_pending_proposal ON progression_proposal(user_id, status_code, exercise_id);

CREATE INDEX ix_outbox_retry ON sync_outbox(status_code, next_retry_at);

CREATE UNIQUE INDEX uq_form_asset_position ON exercise_form_asset(exercise_id, asset_position, content_version);

CREATE INDEX ix_location_equipment ON location_equipment(training_location_id, equipment_id);

CREATE UNIQUE INDEX uq_active_onboarding_draft ON onboarding_draft(user_id) WHERE status_code = 'IN_PROGRESS' AND deleted_at IS NULL;

CREATE UNIQUE INDEX uq_dumbbell_detail ON location_dumbbell_detail(location_equipment_id) WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_barbell_detail ON location_barbell_detail(location_equipment_id) WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_active_user_profile ON user_profile(user_id) WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_active_training_setting ON user_training_setting(user_id) WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_active_experience_profile ON user_experience_profile(user_id) WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_active_app_preference ON app_preference(user_id) WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_active_weekly_planner_draft
  ON weekly_planner_draft(user_id, week_start_date)
  WHERE status_code = 'IN_PROGRESS' AND deleted_at IS NULL;

CREATE UNIQUE INDEX uq_weekly_priority_part ON weekly_priority_part(training_week_id, priority_type, body_part_id) WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_weekly_main_priority ON weekly_priority_part(training_week_id) WHERE priority_type = 'MAIN' AND deleted_at IS NULL;

CREATE UNIQUE INDEX uq_weekly_day ON weekly_available_day(training_week_id, weekday_code) WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_session_set_target
ON session_set_target(session_exercise_id, set_number)
WHERE deleted_at IS NULL;

CREATE INDEX ix_session_events
ON workout_session_event(workout_session_id, occurred_at);

CREATE UNIQUE INDEX uq_post_workout_assessment
ON post_workout_assessment(workout_session_id)
WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_open_workout_session
ON workout_session(user_id)
WHERE status_code IN ('IN_PROGRESS', 'AWAITING_ASSESSMENT')
  AND deleted_at IS NULL;

CREATE UNIQUE INDEX uq_active_work_set
ON work_set_record(session_exercise_id, set_number, side_code)
WHERE voided_at IS NULL;

CREATE UNIQUE INDEX uq_active_performance_series ON exercise_performance_series(user_id, series_key) WHERE deleted_at IS NULL;

CREATE INDEX ix_performance_series_exercise ON exercise_performance_series(user_id, exercise_id, last_recorded_at);

CREATE UNIQUE INDEX uq_session_exercise_evaluation ON session_exercise_evaluation(session_exercise_id) WHERE deleted_at IS NULL;

CREATE INDEX ix_evaluation_series ON session_exercise_evaluation(performance_series_id, evaluated_at);

CREATE UNIQUE INDEX uq_active_proposal_key ON progression_proposal(user_id, proposal_key) WHERE proposal_key <> '' AND status_code IN ('PENDING', 'DEFERRED') AND deleted_at IS NULL;

CREATE INDEX ix_proposal_source_evaluation ON progression_proposal(source_evaluation_id);

CREATE INDEX ix_proposal_decision ON progression_proposal_decision(progression_proposal_id, decided_at);

CREATE UNIQUE INDEX uq_active_progression_adjustment ON accepted_progression_adjustment(progression_proposal_id) WHERE status_code IN ('QUEUED', 'APPLIED') AND deleted_at IS NULL;

CREATE INDEX ix_queued_adjustment_exercise ON accepted_progression_adjustment(user_id, exercise_id, status_code, queued_at);

CREATE UNIQUE INDEX uq_sync_checkpoint ON sync_checkpoint(user_id, device_id, scope_code);

CREATE INDEX ix_sync_run_user_time ON sync_run_history(user_id, started_at);

CREATE INDEX ix_sync_conflict_entity ON sync_conflict_log(user_id, entity_type, entity_id);

CREATE UNIQUE INDEX uq_pending_account_deletion ON account_deletion_request(user_id) WHERE status_code IN ('PENDING','PROCESSING');

CREATE INDEX ix_account_link_history ON account_link_history(user_id, occurred_at);

CREATE INDEX ix_outbox_pending_v6 ON sync_outbox(user_id, status_code, next_retry_at);

CREATE UNIQUE INDEX uq_ai_prompt_version ON ai_prompt_template(template_code, version_code, locale_code);

CREATE UNIQUE INDEX uq_ai_active_prompt ON ai_prompt_template(template_code, locale_code) WHERE is_active = 1;

CREATE INDEX ix_ai_chat_session_user_time ON ai_chat_session(user_id, updated_at);

CREATE INDEX ix_ai_chat_message_session_time ON ai_chat_message(chat_session_id, created_at);

CREATE UNIQUE INDEX uq_ai_cache_request ON ai_response_cache(user_id, request_hash, context_hash);

CREATE INDEX ix_ai_cache_expiry ON ai_response_cache(expires_at);

CREATE UNIQUE INDEX uq_ai_feedback_message ON ai_feedback(user_id, message_id);

CREATE UNIQUE INDEX uq_ai_faq_content ON ai_faq(locale_code, question_text, content_version);

CREATE UNIQUE INDEX uq_ai_dictionary_term ON ai_dictionary(locale_code, term_code, content_version);

CREATE UNIQUE INDEX uq_notification_preference_active ON notification_preference(user_id, notification_type_code) WHERE deleted_at IS NULL;

CREATE UNIQUE INDEX uq_notification_platform_id ON notification_schedule(platform_notification_id) WHERE deleted_at IS NULL AND status_code = 'SCHEDULED';

CREATE UNIQUE INDEX uq_notification_source_schedule ON notification_schedule(user_id, notification_type_code, source_entity_type, source_entity_id, scheduled_at) WHERE deleted_at IS NULL AND status_code = 'SCHEDULED';

CREATE INDEX ix_notification_due ON notification_schedule(user_id, status_code, scheduled_at);

CREATE INDEX ix_notification_delivery_time ON notification_delivery_log(user_id, occurred_at);

CREATE TRIGGER ck_progression_proposal_source_insert
BEFORE INSERT ON progression_proposal
WHEN NEW.source_evaluation_id IS NOT NULL
 AND NOT EXISTS (
   SELECT 1 FROM session_exercise_evaluation
   WHERE id = NEW.source_evaluation_id AND deleted_at IS NULL
 )
BEGIN
  SELECT RAISE(ABORT, 'invalid progression proposal source evaluation');
END;

CREATE TRIGGER ck_progression_proposal_source_update
BEFORE UPDATE OF source_evaluation_id ON progression_proposal
WHEN NEW.source_evaluation_id IS NOT NULL
 AND NOT EXISTS (
   SELECT 1 FROM session_exercise_evaluation
   WHERE id = NEW.source_evaluation_id AND deleted_at IS NULL
 )
BEGIN
  SELECT RAISE(ABORT, 'invalid progression proposal source evaluation');
END;
