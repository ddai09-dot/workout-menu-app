# Seed運用方針

## 正本

- `exercises_v2_1.json`
- `progression_v1_1.json`
- `form_copy_v1_1.json`

元データは確定済みの72種目Excelです。JSONは実装で扱いやすい形へ無加工に近い状態で書き出しています。

## DB投入

`seed_v1.sql`をトランザクション内で実行します。
`rule_version.code = SEED_V1`が存在する場合は再投入しません。

## 数量契約

- exercise_master: 72
- exercise_form_copy: 72
- exercise_form_asset: 144
- exercise_progression_profile: 216
- EX071/EX072が存在
- 外部キー違反: 0

## 画像

初期画像本体は未制作なので、メタデータだけを投入しています。
画像が存在しない場合、UIはラベル・動作ポイント・注意点を表示し、破損画像を出しません。
