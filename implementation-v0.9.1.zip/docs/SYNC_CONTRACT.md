# 同期契約

同期はSupabase Realtimeへ直接依存せず、明示的なpush/pullで行います。

## ローカルを正とする範囲

`IN_PROGRESS`のトレーニングセッションは、そのセッションを実行している端末を正とします。セット確定、現在位置、休憩開始時刻、未確定入力を先にローカルトランザクションへ保存し、通信を待たずに次の操作へ進めます。

同一セッションを複数端末から同時編集する機能はMVPでは提供しません。別端末で開いた場合は閲覧または競合解決へ誘導します。

## push

クライアントは`sync_outbox`を作成順に送信します。

必須項目:

- `idempotency_key`
- `entity_type`
- `entity_id`
- `operation_code`
- `row_version`
- `payload`

サーバーは同じ`idempotency_key`を二重適用しません。

## pull

クライアントが保持する`server_cursor`以降の変更を取得します。

## 追記型データ

以下は原則としてID単位で追加し、最終更新日時による単純上書きを行いません。

- `work_set_record`
- `session_pain_entry`
- `workout_session_event`
- `body_measurement`

セット訂正は旧`work_set_record.voided_at`を設定し、新レコードの`supersedes_id`で訂正前を参照します。同じ訂正レコードIDの再送は冪等に無視します。

## 現行状態データ

以下は`row_version`で競合を検出します。

- `workout_session`
- `session_exercise`
- `session_set_target`
- ユーザー設定
- 週間計画

セッションの現行状態とイベント履歴は同じローカルトランザクションで更新します。イベントだけ、または現行状態だけが成功する書き込みは認めません。

## 競合

- セット実績などの追記データはID単位で統合
- 設定は`row_version`で検出
- 完了済み・一部完了・実施中セッションを自動削除しない
- 週間計画の競合は、実施開始済みの日を固定して未来日だけ再調整
- 痛み・身体制限は古い値で上書きしない
- 同一セッションの複数端末編集は自動マージせず、実行端末の完了後に解決

Supabase側のテーブル、RLS、Edge Functionsは実装ロードマップのフェーズ5で追加します。ローカル機能を先に完成させ、未検証のクラウド依存をMVPの主要動線へ入れません。

## 記録・進行提案

`session_exercise_evaluation`は確定済みセッションから再生成可能ですが、同期後の過去表示とルール版を固定するため通常データとして同期します。同じ`session_exercise_id`の有効評価を重複作成しません。

`progression_proposal_decision`は追記型です。採用・維持・保留・拒否の履歴を最終状態だけへ潰しません。

`accepted_progression_adjustment`は以下の状態を持ちます。

- `QUEUED`：次の一致する予定を待つ
- `APPLIED`：未来予定または新規メニューへ適用済み
- `REVIEW_REQUIRED`：ユーザー選択が必要で自動適用しない

同じ調整を複数端末で二重適用しないよう、提案IDと行バージョンを冪等キーへ含めます。
