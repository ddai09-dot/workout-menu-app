# バージョン固定表

- 現在のプロジェクト版：`0.9.1+19`
- 現在のDB：Schema v9
- 確認日：2026-07-22

## SDK・パッケージ

| 項目 | 固定値 |
|---|---:|
| Flutter | 3.44.6 |
| Dart | Flutter 3.44系に同梱される3.12系 |
| flutter_riverpod | 3.3.2 |
| go_router | 17.3.0 |
| drift | 2.34.2 |
| drift_flutter | 0.3.1 |
| drift_dev | 2.34.4 |
| supabase_flutter | 2.16.0 |
| flutter_secure_storage | 10.3.1 |
| uuid | 4.6.0 |
| crypto | 3.0.6 |
| build_runner | 2.15.2 |
| flutter_lints | 6.0.0 |
| riverpod_lint | 3.1.4 |
| custom_lint | 0.8.1 |

`pubspec.lock`はFlutter環境で`flutter pub get`を実行した後に生成し、Git管理します。現成果物にはFlutter SDKがないため、lockファイルはまだ存在しません。

## アプリ版とSchema

| アプリ版 | Schema | 工程 | 判定 |
|---|---:|---|---|
| 0.1.0 | 1 | タスク12：実装基盤 | 雛形 |
| 0.2.0 | 2 | タスク13：初期登録 | ローカル実装 |
| 0.3.0 | 3 | タスク14：週間メニュー | 部分実装 |
| 0.4.0 | 4 | タスク15：トレーニング実施 | ローカル実装 |
| 0.5.0 | 5 | タスク16：記録・進行提案 | ローカル実装 |
| 0.6.0 | 6 | タスク17：アカウント・同期 | 接続境界・試作 |
| 0.7.0 | 7 | タスク18：AI相談 | 接続境界・試作 |
| 0.8.0 | 8 | タスク19：通知基盤 | Schema・画面・Stub |
| 0.8.1 | 8 | タスク19.5-B2：v6→v7 Migration是正 | 検証基盤是正 |
| 0.8.2 | 9 | タスク19.5-B3：通知設定正本統合 | DB正本統合 |
| 0.8.3 | 9 | タスク19.5-B4：連続Migration・Seed・Repository SQL・CI横断是正 | 検証基盤統合 |
| 0.8.4 | 9 | タスク19.5-C1：フォーム説明文言表示・画像なしフォールバック | ローカル実装・Flutter/iOS統合前 |
| 0.8.5 | 9 | タスク19.5-C2：マイページ通常設定編集 | ローカル実装・Flutter/iOS統合前 |
| 0.8.6 | 9 | タスク19.5-C3：週間生成アルゴリズム・トレーサビリティ | 13工程トレース実装・不足差分明示 |
| 0.8.7 | 9 | タスク19.5-C4：通知設定SQLite Repository接続 | ローカル永続化実装・ネイティブiOS通知はStub |
| 0.8.8 | 9 | タスク19.5-D：MVP外部機能判断 | アカウント同期・AI相談・ネイティブ通知を通常UIとルートから一時的に除外 |
| 0.8.9 | 9 | タスク20-A：端末内データ初期化・統合事前確認 | ローカル実装・SQLite契約検証済み／Flutter・iOS実行前 |
| 0.9.0 | 9 | タスク20-B：Flutter・iOS統合実行レーン | 実行レーン準備済み／現環境BLOCKED |
| 0.9.1 | 9 | タスク20-B2：CI供給網・証跡強化 | 公式SDK検証・Action SHA固定済み／実行BLOCKED |

Schema番号はアプリ版とは独立して単調増加させます。

## 公式確認先

- https://docs.flutter.dev/release/release-notes
- https://pub.dev/packages/flutter_riverpod
- https://pub.dev/packages/go_router
- https://pub.dev/packages/drift
- https://pub.dev/packages/drift_flutter
- https://pub.dev/packages/drift_dev
- https://pub.dev/packages/supabase_flutter


## タスク20-B実行判定

- Flutter 3.44.6：固定済み、現作成環境には未導入
- `pubspec.lock`：未生成
- Drift生成コード：未生成
- Flutter analyze／test：未実行
- iOS Simulator build：未実行
- 実行スクリプト・CIログArtifact：準備済み

したがって、0.9.1も統合検証の成功版ではない。公式SDK検証、Action SHA固定、工程別証跡を追加した実行準備版であり、実結果は引き続きBLOCKEDである。
