# Task 19.5-B2: v6 to v7 Migration correction

## Scope

This correction adds the missing reproducible SQL migration from Schema v6 to Schema v7.
At the time of B2 this did not complete the full migration chain. B4 later regenerated canonical Schema snapshots from the continuous migration path and integrated this verifier into CI.

## Added

- `docs/migrations/v6_to_v7.sql`
- `tools/verify_v6_to_v7_migration.py`

## Acceptance criteria

- Applying the migration to a Schema v6 database produces the same SQLite schema objects as direct Schema v7 creation.
- All pre-existing Seed row counts remain unchanged.
- Schema v7 has 72 tables and the seven AI tables.
- `PRAGMA foreign_key_check` returns no rows.
- AI foreign-key and unique-index rejection are verified.

## Deferred

- notification setting table consolidation
- These items were completed by Task 19.5-B4.
- Flutter/Drift migration tests
