# Task 17 Account and Sync

## Scope

Anonymous-first account, optional Apple linking, offline-first outbox synchronization, conflict handling, and account deletion workflow.

## Fixed rules

- Workout execution remains available offline.
- Authentication is not required before initial use.
- Active workout sessions are not overwritten by generic last-write-wins.
- `work_set_record` and `workout_session_event` use append merge.
- Credentials are stored only through the Keychain-backed `SecureStore`.
- Remote deletion is performed by a server-side function. The client queues and displays its status.

## Conflict policy

1. Set records and session events: append merge.
2. Active workout session: local wins until completion.
3. Other versioned records: row version, then updated timestamp.
4. Unresolved conflict: hold and log without discarding either payload.
