import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('approved seed contains exactly 72 exercises', () async {
    final raw = await rootBundle.loadString(
      'assets/seed/exercises_v2_1.json',
    );
    final rows = jsonDecode(raw) as List<dynamic>;

    expect(rows, hasLength(72));
    final codes = rows
        .cast<Map<String, dynamic>>()
        .map((Map<String, dynamic> row) => row['ID'])
        .toSet();

    expect(codes, hasLength(72));
    expect(codes, containsAll(<String>['EX001', 'EX071', 'EX072']));
  });

  test('form and progression source rows match exercise count', () async {
    final formRows = jsonDecode(
      await rootBundle.loadString('assets/seed/form_copy_v1_1.json'),
    ) as List<dynamic>;
    final progressionRows = jsonDecode(
      await rootBundle.loadString('assets/seed/progression_v1_1.json'),
    ) as List<dynamic>;

    expect(formRows, hasLength(72));
    expect(progressionRows, hasLength(72));
  });
}
