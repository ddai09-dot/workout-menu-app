import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_step.dart';

void main() {
  test('下書きをJSON往復しても入力内容を保持する', () {
    final source = OnboardingDraft(
      id: 'draft-1',
      userId: 'user-1',
      currentStep: OnboardingStep.equipment,
      nickname: 'テスト',
      ageYears: 30,
      primaryGoalCode: 'HYPERTROPHY',
      secondaryGoalCodes: const <String>{'STRENGTH'},
      homeEquipmentCodes: const <String>{'FIXED_DUMBBELL'},
      fixedDumbbells: const DumbbellSetupDraft(
        setupTypeCode: 'FIXED',
        weightOptions: <WeightOptionDraft>[
          WeightOptionDraft(weightKg: 10, quantity: 2),
        ],
      ),
      adjustableDumbbells: const DumbbellSetupDraft(
        setupTypeCode: 'ADJUSTABLE',
        unitCount: 2,
        minWeightKg: 2,
        maxWeightKg: 24,
        incrementWeightKg: 2,
        weightOptions: <WeightOptionDraft>[
          WeightOptionDraft(weightKg: 2, quantity: 2),
          WeightOptionDraft(weightKg: 4, quantity: 2),
        ],
      ),
      barbellSetup: const BarbellSetupDraft(
        plateOptions: <WeightOptionDraft>[
          WeightOptionDraft(weightKg: 20, quantity: 2),
        ],
      ),
      scheduleLocationByWeekday: const <String, String>{
        'MON': 'HOME',
        'THU': 'GYM',
      },
    );

    final restored = OnboardingDraft.fromJson(source.toJson());

    expect(restored.currentStep, OnboardingStep.equipment);
    expect(restored.nickname, 'テスト');
    expect(restored.secondaryGoalCodes, contains('STRENGTH'));
    expect(restored.fixedDumbbells!.weightOptions.single.weightKg, 10);
    expect(restored.adjustableDumbbells!.unitCount, 2);
    expect(restored.adjustableDumbbells!.weightOptions.length, 2);
    expect(restored.barbellSetup!.plateOptions.single.quantity, 2);
    expect(restored.scheduleLocationByWeekday['THU'], 'GYM');
  });

  test('可変式ダンベルは実際に使用できる重量が必須', () {
    const draft = OnboardingDraft(
      id: 'draft-1',
      userId: 'user-1',
      locationModeCode: 'HOME',
      homeEquipmentCodes: <String>{'ADJUSTABLE_DUMBBELL'},
      adjustableDumbbells: DumbbellSetupDraft(
        setupTypeCode: 'ADJUSTABLE',
        unitCount: 2,
        minWeightKg: 2,
        maxWeightKg: 24,
        incrementWeightKg: 2,
      ),
    );

    expect(
      draft.validationMessage(OnboardingStep.equipment),
      '可変式ダンベルで実際に使用できる重量を登録してください。',
    );
  });

  test('曜日で自宅とジムを使い分ける場合は曜日ごとの場所が必須', () {
    const draft = OnboardingDraft(
      id: 'draft-1',
      userId: 'user-1',
      locationModeCode: 'BOTH',
      bothUsageModeCode: 'BY_WEEKDAY',
      desiredDaysPerWeek: 2,
      availableWeekdayCodes: <String>{'MON', 'THU'},
      usualDurationMin: 30,
      scheduleLocationByWeekday: <String, String>{'MON': 'HOME'},
    );

    expect(
      draft.validationMessage(OnboardingStep.schedule),
      '曜日ごとの利用場所を選択してください。',
    );
  });

  test('必須回答が揃うと未入力ステップがなくなる', () {
    final draft = OnboardingDraft(
      id: 'draft-1',
      userId: 'user-1',
      nickname: 'テスト',
      ageYears: 30,
      primaryGoalCode: 'HEALTH',
      cumulativeExperienceCode: 'NONE',
      continuityCode: 'LT_1M',
      currentFrequency: 0,
      adjustmentHabitCode: 'NONE',
      loggingHabitCode: 'NONE',
      locationModeCode: 'HOME',
      homeEquipmentCodes: const <String>{'NONE'},
      desiredDaysPerWeek: 2,
      availableWeekdayCodes: const <String>{'MON', 'THU'},
      usualDurationMin: 30,
      splitPreferenceCode: 'APP',
      primaryPriorityCode: 'BALANCED',
      abGoalCode: 'NONE',
    );

    expect(draft.firstInvalidStep, isNull);
  });
}
