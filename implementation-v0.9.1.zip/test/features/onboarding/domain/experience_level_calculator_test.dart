import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/features/onboarding/domain/experience_level_calculator.dart';

void main() {
  test('2年以上5年未満は中級者として判定する', () {
    final result = ExperienceLevelCalculator.calculate(
      cumulativeExperienceCode: 'Y2_5',
      continuityCode: 'Y1_2',
      hiatusCode: null,
    );

    expect(result.levelCode, 'INTERMEDIATE');
    expect(result.returningMode, isFalse);
    expect(result.startVolumeFactor, 1);
  });

  test('長期経験者でも2年以上休止中は復帰用50%から開始する', () {
    final result = ExperienceLevelCalculator.calculate(
      cumulativeExperienceCode: 'GTE_10Y',
      continuityCode: 'NOT_ACTIVE',
      hiatusCode: 'GTE_2Y',
    );

    expect(result.levelCode, 'ADVANCED');
    expect(result.returningMode, isTrue);
    expect(result.startVolumeFactor, 0.5);
  });

  test('未経験は初心者として判定する', () {
    final result = ExperienceLevelCalculator.calculate(
      cumulativeExperienceCode: 'NONE',
      continuityCode: 'LT_1M',
      hiatusCode: null,
    );

    expect(result.levelCode, 'BEGINNER');
    expect(result.returningMode, isFalse);
  });
}
