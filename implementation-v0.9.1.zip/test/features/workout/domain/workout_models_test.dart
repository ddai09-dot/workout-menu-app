import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/features/workout/domain/workout_models.dart';

void main() {
  test('rest timer is reconstructed from timestamps', () {
    final started = DateTime.utc(2026, 7, 17, 10);
    final rest = WorkoutRestState(
      startedAt: started,
      durationSec: 90,
      completedSetSummary: '20kg × 10回',
      isLastSetOfExercise: false,
      isLastExercise: false,
    );
    expect(rest.remainingSecondsAt(started.add(const Duration(seconds: 40))), 50);
    expect(rest.remainingSecondsAt(started.add(const Duration(seconds: 120))), 0);
  });

  test('set input round trips through json', () {
    const value = WorkoutSetInput(
      weightValue: 22.5,
      weightUnitCode: 'KG',
      reps: 10,
      durationSec: null,
      assistanceValue: 5,
      variationCode: 'KNEELING',
      equipmentModeCode: 'DUMBBELL',
    );
    final restored = WorkoutSetInput.fromJsonText(value.toJsonText());
    expect(restored.weightValue, 22.5);
    expect(restored.reps, 10);
    expect(restored.assistanceValue, 5);
    expect(restored.variationCode, 'KNEELING');
    expect(restored.equipmentModeCode, 'DUMBBELL');
  });

  test('recording methods expose only the inputs required by the exercise', () {
    final duration = _exercise('DURATION');
    expect(duration.recordsDuration, isTrue);
    expect(duration.recordsRepetitions, isFalse);
    expect(duration.supportsWeight, isFalse);

    final multiMode = _exercise('MULTI_MODE');
    expect(multiMode.recordsRepetitions, isTrue);
    expect(multiMode.supportsWeight, isTrue);
    expect(multiMode.requiresEquipmentMode, isTrue);

    final assistance = _exercise('ASSISTANCE_REVERSE');
    expect(assistance.requiresAssistance, isTrue);
    expect(assistance.supportsWeight, isFalse);
  });
}

WorkoutSessionExercise _exercise(String recordingMethodCode) {
  return WorkoutSessionExercise(
    sessionExerciseId: 'session-exercise',
    plannedExerciseId: 'planned-exercise',
    exerciseId: 'exercise',
    name: 'テスト種目',
    recordingMethodCode: recordingMethodCode,
    performanceSeriesKey: 'exercise',
    targetPart: '胸',
    orderIndex: 1,
    originalOrderIndex: 1,
    originalSetCount: 1,
    targetSetCount: 1,
    statusCode: 'IN_PROGRESS',
    targets: const <WorkoutSessionSetTarget>[],
    records: const <WorkoutCompletedSet>[],
    previousPerformanceText: '前回記録なし',
  );
}
