import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/notifications/data/local_notification_repository.dart';
import 'package:workout_menu_app/features/notifications/domain/notification_models.dart';
import 'package:workout_menu_app/features/notifications/domain/notification_repository.dart';

void main() {
  late AppDatabase database;
  late _FakeNotificationGateway gateway;
  late LocalNotificationRepository repository;

  setUp(() async {
    database = AppDatabase(NativeDatabase.memory());
    await database.customStatement(
      "INSERT INTO user_account(id, timezone) VALUES('notification-user', 'Asia/Tokyo')",
    );
    gateway = _FakeNotificationGateway();
    repository = LocalNotificationRepository(
      database,
      gateway,
      idGenerator: _SequenceIdGenerator(),
    );
  });

  tearDown(() => database.close());

  test('初回読込で4種類の既定値をSQLiteへ作成する', () async {
    final state = await repository.load();

    expect(state.preferences, hasLength(4));
    expect(
      state.preferences.map((ReminderPreference value) => value.type),
      ReminderType.values,
    );
    final count = await database.customSelect(
      'SELECT COUNT(*) AS count FROM notification_preference',
    ).getSingle();
    expect(count.read<int>('count'), 4);
  });

  test('保存値はRepositoryを作り直してもSQLiteから復元する', () async {
    final initial = await repository.load();
    final workout = initial.preferences.firstWhere(
      (ReminderPreference value) => value.type == ReminderType.workoutPlan,
    );
    await repository.save(
      workout.copyWith(localTime: '20:15', advanceMinutes: 30),
    );

    final reloaded = await LocalNotificationRepository(
      database,
      gateway,
      idGenerator: _SequenceIdGenerator(),
    ).load();
    final saved = reloaded.preferences.firstWhere(
      (ReminderPreference value) => value.type == ReminderType.workoutPlan,
    );
    expect(saved.localTime, '20:15');
    expect(saved.advanceMinutes, 30);
  });

  test('設定変更時は同種の旧予約を取消してDB状態も更新する', () async {
    final initial = await repository.load();
    await database.customStatement('''
      INSERT INTO notification_schedule(
        id, user_id, notification_type_code, scheduled_at, title_text,
        body_text, platform_notification_id
      ) VALUES(
        'schedule-1', 'notification-user', 'WORKOUT_PLAN',
        '2026-08-01T09:00:00Z', '予定', '本文', 101
      )
    ''');
    final workout = initial.preferences.firstWhere(
      (ReminderPreference value) => value.type == ReminderType.workoutPlan,
    );

    await repository.save(workout.copyWith(enabled: false));

    expect(gateway.cancelledIds, <int>[101]);
    final row = await database.customSelect(
      "SELECT status_code FROM notification_schedule WHERE id='schedule-1'",
    ).getSingle();
    expect(row.read<String>('status_code'), 'CANCELLED');
  });
}

final class _SequenceIdGenerator implements IdGenerator {
  int _value = 0;

  @override
  String next() => 'notification-id-${_value++}';
}

final class _FakeNotificationGateway implements LocalNotificationGateway {
  bool permissionGranted = false;
  final List<int> cancelledIds = <int>[];

  @override
  Future<bool> isPermissionGranted() async => permissionGranted;

  @override
  Future<bool> requestPermission() async {
    permissionGranted = true;
    return true;
  }

  @override
  Future<void> schedule({
    required int id,
    required DateTime scheduledAt,
    required String title,
    required String body,
    String? routePath,
  }) async {}

  @override
  Future<void> cancel(int id) async {
    cancelledIds.add(id);
  }

  @override
  Future<void> cancelAll() async {}
}
