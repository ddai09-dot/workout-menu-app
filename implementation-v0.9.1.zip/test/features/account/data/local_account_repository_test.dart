import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/core/security/secure_store.dart';
import 'package:workout_menu_app/features/account/data/local_account_repository.dart';

void main() {
  late AppDatabase database;
  late _MemorySecureStore secureStore;
  late LocalAccountRepository repository;

  setUp(() async {
    database = AppDatabase(NativeDatabase.memory());
    secureStore = _MemorySecureStore(<String, String>{
      'current_user_id': 'old-user',
    });
    repository = LocalAccountRepository(
      database: database,
      secureStore: secureStore,
      idGenerator: _SequenceIdGenerator(<String>['replacement-user']),
    );

    await database.customStatement("INSERT INTO user_account(id) VALUES('old-user')");
    await database.customStatement("INSERT INTO user_account(id) VALUES('other-user')");
    await database.customStatement('''
      INSERT INTO user_profile(id,user_id,nickname,age_years,age_updated_on)
      VALUES('profile-old','old-user','削除対象',30,'2026-07-22')
    ''');
    await database.customStatement('''
      INSERT INTO user_profile(id,user_id,nickname,age_years,age_updated_on)
      VALUES('profile-other','other-user','保持対象',31,'2026-07-22')
    ''');
    await database.customStatement(
      "INSERT INTO app_preference(id,user_id) VALUES('pref-old','old-user')",
    );
    await database.customStatement('''
      INSERT INTO ai_faq(id,category_code,question_text,answer_text,content_version)
      VALUES('faq-1','GENERAL','質問','回答','1')
    ''');
  });

  tearDown(() => database.close());

  test('current user data is deleted, master data and another user are preserved', () async {
    final snapshot = await repository.resetLocalData();

    expect(snapshot.userId, 'replacement-user');
    expect(await secureStore.read('current_user_id'), 'replacement-user');
    expect(await _count(database, 'user_account', "id='old-user'"), 0);
    expect(await _count(database, 'user_account', "id='replacement-user'"), 1);
    expect(await _count(database, 'user_account', "id='other-user'"), 1);
    expect(await _count(database, 'user_profile', "user_id='old-user'"), 0);
    expect(await _count(database, 'app_preference', "user_id='old-user'"), 0);
    expect(await _count(database, 'user_profile', "user_id='other-user'"), 1);
    expect(await _count(database, 'ai_faq'), 1);

    final violations = await database.customSelect('PRAGMA foreign_key_check').get();
    expect(violations, isEmpty);
  });

  test('secure-store write failure happens before destructive database commit', () async {
    secureStore.failNextWrite = true;

    await expectLater(repository.resetLocalData(), throwsStateError);

    expect(await secureStore.read('current_user_id'), 'old-user');
    expect(await _count(database, 'user_account', "id='old-user'"), 1);
    expect(await _count(database, 'user_profile', "user_id='old-user'"), 1);
    expect(await _count(database, 'app_preference', "user_id='old-user'"), 1);
  });

  test('stale secure-store user id is repaired with a new anonymous account', () async {
    await database.customStatement("DELETE FROM user_profile WHERE user_id='old-user'");
    await database.customStatement("DELETE FROM app_preference WHERE user_id='old-user'");
    await database.customStatement("DELETE FROM user_account WHERE id='old-user'");

    final snapshot = await repository.ensureAnonymousAccount();

    expect(snapshot.userId, 'replacement-user');
    expect(await secureStore.read('current_user_id'), 'replacement-user');
    expect(await _count(database, 'user_account', "id='replacement-user'"), 1);
  });
}

Future<int> _count(
  AppDatabase database,
  String table, [
  String where = '1=1',
]) async {
  final row = await database.customSelect(
    'SELECT COUNT(*) AS count FROM $table WHERE $where',
  ).getSingle();
  return row.read<int>('count');
}

final class _SequenceIdGenerator implements IdGenerator {
  _SequenceIdGenerator(this._ids);

  final List<String> _ids;
  int _index = 0;

  @override
  String next() {
    if (_index >= _ids.length) {
      throw StateError('No test ID remains');
    }
    return _ids[_index++];
  }
}

final class _MemorySecureStore implements SecureStore {
  _MemorySecureStore(this._values);

  final Map<String, String> _values;
  bool failNextWrite = false;

  @override
  Future<void> delete(String key) async {
    _values.remove(key);
  }

  @override
  Future<String?> read(String key) async => _values[key];

  @override
  Future<void> write({required String key, required String value}) async {
    if (failNextWrite) {
      failNextWrite = false;
      throw StateError('secure store write failed');
    }
    _values[key] = value;
  }
}
