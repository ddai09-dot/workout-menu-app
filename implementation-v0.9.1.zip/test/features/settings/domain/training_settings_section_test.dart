import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_section.dart';

void main() {
  group('TrainingSettingsSection fingerprint', () {
    test('set and map ordering does not create a false change', () {
      final first = _draft().copyWith(
        secondaryGoalCodes: const <String>{'STRENGTH', 'HEALTH'},
        availableWeekdayCodes: const <String>{'MON', 'THU'},
        scheduleLocationByWeekday: const <String, String>{
          'MON': 'HOME',
          'THU': 'GYM',
        },
      );
      final reordered = _draft().copyWith(
        secondaryGoalCodes: const <String>{'HEALTH', 'STRENGTH'},
        availableWeekdayCodes: const <String>{'THU', 'MON'},
        scheduleLocationByWeekday: const <String, String>{
          'THU': 'GYM',
          'MON': 'HOME',
        },
      );

      expect(
        TrainingSettingsSection.goals.fingerprint(first),
        TrainingSettingsSection.goals.fingerprint(reordered),
      );
      expect(
        TrainingSettingsSection.schedule.fingerprint(first),
        TrainingSettingsSection.schedule.fingerprint(reordered),
      );
    });
  });

  test('environment fingerprint includes weekday location assignments', () {
    final first = _draft().copyWith(
      locationModeCode: 'BOTH',
      bothUsageModeCode: 'BY_WEEKDAY',
      scheduleLocationByWeekday: const <String, String>{
        'MON': 'HOME',
        'THU': 'GYM',
      },
    );
    final changed = first.copyWith(
      scheduleLocationByWeekday: const <String, String>{
        'MON': 'GYM',
        'THU': 'GYM',
      },
    );

    expect(
      TrainingSettingsSection.environment.fingerprint(first),
      isNot(TrainingSettingsSection.environment.fingerprint(changed)),
    );
  });

  group('TrainingSettingsSection change impact', () {
    test('equipment removal recommends current-week review', () {
      final before = _draft().copyWith(
        homeEquipmentCodes: const <String>{
          'ADJUSTABLE_DUMBBELL',
          'ADJUSTABLE_BENCH',
        },
        adjustableDumbbells: const DumbbellSetupDraft(
          setupTypeCode: 'ADJUSTABLE',
          unitCount: 2,
          minWeightKg: 2,
          maxWeightKg: 24,
          incrementWeightKg: 2,
          weightOptions: <WeightOptionDraft>[
            WeightOptionDraft(weightKg: 2, quantity: 2),
            WeightOptionDraft(weightKg: 24, quantity: 2),
          ],
        ),
      );
      final after = before.copyWith(
        homeEquipmentCodes: const <String>{'ADJUSTABLE_BENCH'},
        adjustableDumbbells: null,
      );

      final impact = TrainingSettingsSection.environment.changeImpact(
        before,
        after,
      );

      expect(impact.currentWeekReviewRecommended, isTrue);
      expect(impact.message, contains('今週'));
    });

    test('equipment addition applies to future generation only', () {
      final before = _draft().copyWith(
        homeEquipmentCodes: const <String>{'FLAT_BENCH'},
      );
      final after = before.copyWith(
        homeEquipmentCodes: const <String>{'FLAT_BENCH', 'PULLUP_BAR'},
      );

      final impact = TrainingSettingsSection.environment.changeImpact(
        before,
        after,
      );

      expect(impact.currentWeekReviewRecommended, isFalse);
      expect(impact.message, contains('作成済み'));
    });

    test('new or stronger restriction recommends current-week review', () {
      final before = _draft();
      final after = before.copyWith(
        painActionsByArea: const <String, String>{
          'JOINT:JT001': 'REDUCE_LOAD',
        },
        avoidMovementGroupCodes: const <String>{'OVERHEAD_PRESS'},
      );

      final impact = TrainingSettingsSection.restrictions.changeImpact(
        before,
        after,
      );

      expect(impact.currentWeekReviewRecommended, isTrue);
    });

    test('restriction removal does not rewrite current week', () {
      final before = _draft().copyWith(
        painActionsByArea: const <String, String>{
          'JOINT:JT001': 'EXCLUDE',
        },
      );
      final after = before.copyWith(
        painActionsByArea: const <String, String>{},
      );

      final impact = TrainingSettingsSection.restrictions.changeImpact(
        before,
        after,
      );

      expect(impact.currentWeekReviewRecommended, isFalse);
    });
  });

  test('all seven sections have stable unique routes', () {
    final paths = TrainingSettingsSection.values
        .map((section) => section.pathSegment)
        .toSet();

    expect(TrainingSettingsSection.values, hasLength(7));
    expect(paths, hasLength(7));
    for (final section in TrainingSettingsSection.values) {
      expect(
        TrainingSettingsSectionDefinition.fromPath(section.pathSegment),
        section,
      );
    }
  });
}

OnboardingDraft _draft() {
  return const OnboardingDraft(
    id: 'settings-user-1',
    userId: 'user-1',
    nickname: 'テスト',
    ageYears: 30,
    primaryGoalCode: 'HEALTH',
    secondaryGoalCodes: <String>{'NONE'},
    cumulativeExperienceCode: 'Y2_5',
    continuityCode: 'Y1_2',
    currentFrequency: 3,
    adjustmentHabitCode: 'HISTORY_BASED',
    loggingHabitCode: 'ALWAYS',
    locationModeCode: 'HOME',
    homeEquipmentCodes: <String>{'NONE'},
    desiredDaysPerWeek: 2,
    availableWeekdayCodes: <String>{'MON', 'THU'},
    usualDurationMin: 45,
    splitPreferenceCode: 'APP',
    primaryPriorityCode: 'BALANCED',
    secondaryPriorityCodes: <String>{'NONE'},
    appearancePriorityCodes: <String>{'NONE'},
    abGoalCode: 'NONE',
  );
}
