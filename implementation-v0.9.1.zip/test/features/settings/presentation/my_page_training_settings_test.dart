import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/my_page/presentation/my_page.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_repository.dart';
import 'package:workout_menu_app/features/settings/presentation/training_settings_providers.dart';

void main() {
  testWidgets('My Page exposes all seven training setting categories', (
    WidgetTester tester,
  ) async {
    final router = GoRouter(
      initialLocation: '/my-page',
      routes: <RouteBase>[
        GoRoute(
          path: '/my-page',
          builder: (context, state) => const MyPage(),
          routes: <RouteBase>[
            GoRoute(
              path: 'settings/:section',
              builder: (context, state) => const Placeholder(),
            ),
          ],
        ),
      ],
    );
    await tester.pumpWidget(
      ProviderScope(
        overrides: [
          trainingSettingsSnapshotProvider.overrideWith(
            (ref) async => TrainingSettingsSnapshot(draft: _draft()),
          ),
        ],
        child: MaterialApp.router(routerConfig: router),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.textContaining('自動で書き換えません'), findsOneWidget);
    await tester.scrollUntilVisible(find.text('端末内データ'), 240);
    expect(find.text('端末内データ'), findsOneWidget);

    for (final label in <String>[
      'トレーニング目的',
      '経験・継続状況',
      '環境・器具',
      '通常の予定',
      'メニューの分け方',
      '優先部位',
      '痛み・身体上の制限',
    ]) {
      await tester.scrollUntilVisible(find.text(label), 240);
      expect(find.text(label), findsOneWidget);
    }
  });
}

OnboardingDraft _draft() {
  return const OnboardingDraft(
    id: 'settings-user-1',
    userId: 'user-1',
    nickname: 'テスト',
    ageYears: 30,
    primaryGoalCode: 'HEALTH',
    secondaryGoalCodes: <String>{'NONE'},
    cumulativeExperienceCode: 'Y2_5',
    continuityCode: 'Y1_2',
    currentFrequency: 3,
    adjustmentHabitCode: 'HISTORY_BASED',
    loggingHabitCode: 'ALWAYS',
    locationModeCode: 'HOME',
    homeEquipmentCodes: <String>{'NONE'},
    desiredDaysPerWeek: 2,
    availableWeekdayCodes: <String>{'MON', 'THU'},
    usualDurationMin: 45,
    splitPreferenceCode: 'APP',
    primaryPriorityCode: 'BALANCED',
    secondaryPriorityCodes: <String>{'NONE'},
    appearancePriorityCodes: <String>{'NONE'},
    abGoalCode: 'NONE',
  );
}
