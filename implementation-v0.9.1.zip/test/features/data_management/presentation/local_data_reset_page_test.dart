import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/account/domain/account_models.dart';
import 'package:workout_menu_app/features/account/domain/account_repository.dart';
import 'package:workout_menu_app/features/account/presentation/account_notifier.dart';
import 'package:workout_menu_app/features/data_management/presentation/local_data_reset_page.dart';

void main() {
  testWidgets('destructive action stays disabled until irreversible deletion is acknowledged', (
    WidgetTester tester,
  ) async {
    final repository = _FakeAccountRepository();
    final router = GoRouter(
      initialLocation: '/my-page/data',
      routes: <RouteBase>[
        GoRoute(
          path: '/my-page/data',
          builder: (context, state) => const LocalDataResetPage(),
        ),
        GoRoute(
          path: '/launch',
          builder: (context, state) => const Scaffold(body: Text('初期登録へ')),
        ),
      ],
    );

    await tester.pumpWidget(
      ProviderScope(
        overrides: [
          accountRepositoryProvider.overrideWithValue(repository),
        ],
        child: MaterialApp.router(routerConfig: router),
      ),
    );
    await tester.pumpAndSettle();

    final deleteButton = find.widgetWithText(FilledButton, '端末内データを削除');
    expect(tester.widget<FilledButton>(deleteButton).onPressed, isNull);
    expect(find.text('削除されるもの'), findsOneWidget);
    expect(find.text('削除されないもの'), findsOneWidget);

    await tester.tap(find.byType(CheckboxListTile));
    await tester.pump();
    expect(tester.widget<FilledButton>(deleteButton).onPressed, isNotNull);

    await tester.tap(deleteButton);
    await tester.pumpAndSettle();
    expect(find.text('すべて削除しますか？'), findsOneWidget);

    await tester.tap(find.widgetWithText(FilledButton, '削除する'));
    await tester.pumpAndSettle();

    expect(repository.resetCalls, 1);
    expect(find.text('初期登録へ'), findsOneWidget);
  });
}

final class _FakeAccountRepository implements AccountRepository {
  int resetCalls = 0;

  static const AccountSnapshot _snapshot = AccountSnapshot(
    userId: 'new-user',
    kind: AccountKind.anonymous,
    status: AccountStatus.active,
    lastSyncAt: null,
    pendingOutboxCount: 0,
  );

  @override
  Future<AccountSnapshot> ensureAnonymousAccount() async => _snapshot;

  @override
  Future<void> linkApple(AppleIdentityToken credential) async {}

  @override
  Future<void> requestDeletion() async {}

  @override
  Future<AccountSnapshot> resetLocalData() async {
    resetCalls += 1;
    return _snapshot;
  }

  @override
  Future<void> signOut() async {}

  @override
  Stream<AccountSnapshot> watchCurrent() => Stream<AccountSnapshot>.value(_snapshot);
}
