import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/rule_based_weekly_menu_generator.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_generation_models.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_draft.dart';

void main() {
  test('休養週では日別メニューを作らない', () {
    final generator = RuleBasedWeeklyMenuGenerator(
      idGenerator: _SequenceIdGenerator(),
    );
    final result = generator.generate(_input(restWeek: true));

    expect(result.isRestWeek, isTrue);
    expect(result.days, isEmpty);
    expect(result.estimatedTotalMin, 0);
  });

  test('離れた2日を選んだ初心者は全身A/Bを優先する', () {
    final generator = RuleBasedWeeklyMenuGenerator(
      idGenerator: _SequenceIdGenerator(),
    );
    final result = generator.generate(_input());

    expect(result.splitCode, 'FULL_BODY_AB');
    expect(result.days, hasLength(2));
    expect(result.days.first.exercises, isNotEmpty);
    expect(result.days.last.exercises, isNotEmpty);
  });

  test('連続する2日は上半身・下半身へ分ける', () {
    final generator = RuleBasedWeeklyMenuGenerator(
      idGenerator: _SequenceIdGenerator(),
    );
    final result = generator.generate(
      _input(dayCodes: const <String>['MON', 'TUE']),
    );

    expect(result.splitCode, 'UPPER_LOWER_2');
    expect(result.days.map((day) => day.focus), containsAll(<String>['上半身A', '下半身A']));
  });

  test('利用場所にない器具を必要とする種目は採用しない', () {
    final generator = RuleBasedWeeklyMenuGenerator(
      idGenerator: _SequenceIdGenerator(),
    );
    final exercises = <GenerationExercise>[
      _exercise(
        id: 'db-push',
        code: 'EX_DB',
        name: 'ダンベルプレス',
        parts: const <String>{'CHEST'},
        movements: const <String>{'PUSH'},
        equipment: const <EquipmentRequirementOption>[
          EquipmentRequirementOption(
            code: 'DB',
            requirements: <String, int>{'DUMBBELL': 2},
          ),
        ],
      ),
      ..._exercises(),
    ];
    final result = generator.generate(_input(exercises: exercises));
    final selectedCodes = result.days
        .expand((day) => day.exercises)
        .map((exercise) => exercise.exerciseCode)
        .toSet();

    expect(selectedCodes, isNot(contains('EX_DB')));
    expect(selectedCodes, contains('EX_PUSH'));
  });
}

WeeklyGenerationInput _input({
  bool restWeek = false,
  List<String> dayCodes = const <String>['MON', 'THU'],
  List<GenerationExercise>? exercises,
}) {
  final weekStart = DateTime(2026, 7, 13);
  final days = <WeeklyDayDraft>[];
  for (var index = 0; index < WeekdayCodes.ordered.length; index++) {
    final code = WeekdayCodes.ordered[index];
    final selected = dayCodes.contains(code);
    days.add(
      WeeklyDayDraft(
        weekdayCode: code,
        planDate: weekStart.add(Duration(days: index)),
        isAvailable: selected,
        durationMin: selected ? 45 : null,
        locationId: selected ? 'home-1' : null,
        locationName: selected ? '自宅' : null,
      ),
    );
  }
  final draft = WeeklyPlannerDraft(
    id: 'draft-1',
    userId: 'user-1',
    ruleVersionId: 'rule-1',
    weekStartDate: weekStart,
    days: days,
    restWeek: restWeek,
  );
  return WeeklyGenerationInput(
    draft: draft,
    primaryGoalCode: 'HEALTH',
    experienceLevelCode: 'BEGINNER',
    startVolumeFactor: 1,
    desiredDaysPerWeek: dayCodes.length,
    defaultSplitPreferenceCode: 'APP',
    abGoalCode: 'NONE',
    defaultPrimaryPriorityCode: null,
    defaultSecondaryPriorityCodes: const <String>{},
    locations: const <String, GenerationLocation>{
      'home-1': GenerationLocation(
        id: 'home-1',
        name: '自宅',
        typeCode: 'HOME',
        gymProfileCode: null,
        equipmentCodes: <String>{'NONE'},
      ),
    },
    restrictions: const GenerationRestrictions(),
    exercises: exercises ?? _exercises(),
    previousExerciseIds: const <String>{},
    lockedDays: const [],
  );
}

List<GenerationExercise> _exercises() => <GenerationExercise>[
      _exercise(
        id: 'push',
        code: 'EX_PUSH',
        name: 'プッシュアップ',
        parts: const <String>{'CHEST'},
        movements: const <String>{'PUSH'},
      ),
      _exercise(
        id: 'pull',
        code: 'EX_PULL',
        name: '自重ロー',
        parts: const <String>{'BACK'},
        movements: const <String>{'PULL'},
      ),
      _exercise(
        id: 'legs',
        code: 'EX_LEGS',
        name: 'スクワット',
        parts: const <String>{'LEGS'},
        movements: const <String>{'LEGS'},
      ),
      _exercise(
        id: 'shoulders',
        code: 'EX_SHOULDERS',
        name: 'パイクプッシュアップ',
        parts: const <String>{'SHOULDERS'},
        movements: const <String>{'PUSH'},
      ),
      _exercise(
        id: 'arms',
        code: 'EX_ARMS',
        name: 'ナロープッシュアップ',
        parts: const <String>{'ARMS'},
        movements: const <String>{'PUSH'},
      ),
      _exercise(
        id: 'glutes',
        code: 'EX_GLUTES',
        name: 'ヒップリフト',
        parts: const <String>{'GLUTES'},
        movements: const <String>{'LEGS'},
      ),
      _exercise(
        id: 'core',
        code: 'EX_CORE',
        name: 'プランク',
        parts: const <String>{'CORE'},
        movements: const <String>{'CORE'},
        targetMode: 'DURATION',
      ),
      _exercise(
        id: 'legs2',
        code: 'EX_LEGS_2',
        name: 'ランジ',
        parts: const <String>{'LEGS'},
        movements: const <String>{'LEGS'},
      ),
    ];

GenerationExercise _exercise({
  required String id,
  required String code,
  required String name,
  required Set<String> parts,
  required Set<String> movements,
  List<EquipmentRequirementOption> equipment = const <EquipmentRequirementOption>[],
  String targetMode = 'REPS',
}) {
  return GenerationExercise(
    id: id,
    code: code,
    name: name,
    roleCode: 'MAJOR',
    exerciseClassCode: 'COMPOUND',
    technicalDifficultyCode: 'LOW',
    recordingMethodCode: targetMode == 'DURATION' ? 'TIME' : 'REPS',
    availabilityByLevel: const <String, String>{
      'BEGINNER': 'AVAILABLE',
      'INTERMEDIATE': 'AVAILABLE',
      'ADVANCED': 'AVAILABLE',
    },
    defaultPriorityCode: 'STANDARD',
    primaryBodyPartCodes: parts,
    secondaryBodyPartCodes: const <String>{},
    movementGroupCodes: movements,
    jointCodes: const <String>{},
    equipmentOptions: equipment,
    progression: ExerciseProgression(
      targetModeCode: targetMode,
      repLower: targetMode == 'REPS' ? 8 : null,
      repUpper: targetMode == 'REPS' ? 12 : null,
      durationLowerSec: targetMode == 'DURATION' ? 20 : null,
      durationUpperSec: targetMode == 'DURATION' ? 30 : null,
      setLower: 2,
      setUpper: 4,
      restSec: 60,
    ),
  );
}

final class _SequenceIdGenerator implements IdGenerator {
  int _value = 0;

  @override
  String next() => 'id-${_value++}';
}
