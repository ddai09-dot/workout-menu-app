import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_draft.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_step.dart';

void main() {
  test('週間下書きをJSON往復しても回答と曜日別予定を保持する', () {
    final source = WeeklyPlannerDraft(
      id: 'draft-1',
      userId: 'user-1',
      ruleVersionId: 'rule-1',
      weekStartDate: DateTime(2026, 7, 13),
      currentStep: WeeklyPlannerStep.adjustment,
      days: <WeeklyDayDraft>[
        WeeklyDayDraft(
          weekdayCode: 'MON',
          planDate: DateTime(2026, 7, 13),
          isAvailable: true,
          durationMin: 45,
          locationId: 'home-1',
          locationName: '自宅',
        ),
      ],
      sleepScore: 2,
      motivationScore: 4,
      previousLoadScore: 4,
      achievementScore: 3,
      priorityModeCode: 'CUSTOM',
      primaryPriorityCode: 'CHEST',
      secondaryPriorityCodes: const <String>{'SHOULDERS'},
      painEntries: const <WeeklyPainDraft>[
        WeeklyPainDraft(
          bodyPartCode: 'LEGS',
          bodyPartName: '脚',
          actionCode: 'REDUCE_LOAD',
        ),
      ],
    );

    final restored = WeeklyPlannerDraft.fromJson(source.toJson());

    expect(restored.currentStep, WeeklyPlannerStep.adjustment);
    expect(restored.availableDays.single.durationMin, 45);
    expect(restored.availableDays.single.locationName, '自宅');
    expect(restored.sleepScore, 2);
    expect(restored.primaryPriorityCode, 'CHEST');
    expect(restored.secondaryPriorityCodes, contains('SHOULDERS'));
    expect(restored.painEntries.single.actionCode, 'REDUCE_LOAD');
  });

  test('利用可能日には時間と場所が必須', () {
    final draft = WeeklyPlannerDraft(
      id: 'draft-1',
      userId: 'user-1',
      ruleVersionId: 'rule-1',
      weekStartDate: DateTime(2026, 7, 13),
      days: <WeeklyDayDraft>[
        WeeklyDayDraft(
          weekdayCode: 'MON',
          planDate: DateTime(2026, 7, 13),
          isAvailable: true,
          durationMin: null,
          locationId: null,
          locationName: null,
        ),
      ],
    );

    expect(
      draft.validationMessage(WeeklyPlannerStep.schedule),
      '月曜日の時間を選択してください。',
    );
  });

  test('前週記録がない場合は振り返り回答を要求しない', () {
    final draft = WeeklyPlannerDraft(
      id: 'draft-1',
      userId: 'user-1',
      ruleVersionId: 'rule-1',
      weekStartDate: DateTime(2026, 7, 13),
      days: const <WeeklyDayDraft>[],
      hasPreviousWeek: false,
    );

    expect(
      draft.validationMessage(WeeklyPlannerStep.previousWeek),
      isNull,
    );
  });
}
