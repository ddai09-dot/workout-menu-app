import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/core/sync/conflict_resolver.dart';
import 'package:workout_menu_app/core/sync/sync_models.dart';

void main() {
  const resolver = ConflictResolver();

  VersionedEntity entity(
    String type,
    int version,
    DateTime time, [
    Map<String, Object?> payload = const <String, Object?>{},
  ]) {
    return VersionedEntity(
      entityType: type,
      entityId: 'id',
      rowVersion: version,
      updatedAt: time,
      payload: payload,
    );
  }

  test('set records use append merge', () {
    final now = DateTime.utc(2026, 7, 21);
    expect(
      resolver.resolve(
        local: entity('work_set_record', 1, now),
        remote: entity('work_set_record', 2, now),
      ),
      ConflictResolution.appendMerge,
    );
  });

  test('active session keeps local draft', () {
    final now = DateTime.utc(2026, 7, 21);
    expect(
      resolver.resolve(
        local: entity(
          'workout_session',
          1,
          now,
          <String, Object?>{'status_code': 'IN_PROGRESS'},
        ),
        remote: entity('workout_session', 9, now),
      ),
      ConflictResolution.localWins,
    );
  });

  test('higher row version wins for ordinary records', () {
    final now = DateTime.utc(2026, 7, 21);
    expect(
      resolver.resolve(
        local: entity('user_profile', 1, now),
        remote: entity('user_profile', 2, now),
      ),
      ConflictResolution.remoteWins,
    );
  });
}
