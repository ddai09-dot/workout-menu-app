import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_image_resolver.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_models.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_repository.dart';
import 'package:workout_menu_app/features/exercise_form/domain/load_exercise_form_use_case.dart';

void main() {
  test('画像スロットは片方の失敗で全体を失敗させない', () async {
    final useCase = LoadExerciseFormUseCase(
      _FakeRepository(),
      _FakeResolver(),
    );

    final result = await useCase('exercise-id');

    expect(result, isNotNull);
    expect(result!.images, hasLength(2));
    expect(result.images[0].canDisplayImage, isTrue);
    expect(result.images[1].canDisplayImage, isFalse);
    expect(result.movementTip, '動作のポイント');
    expect(result.cautionText, '注意点');
  });
}

final class _FakeRepository implements ExerciseFormRepository {
  @override
  Future<ExerciseFormContent?> loadByExerciseId(String exerciseId) async {
    return const ExerciseFormContent(
      exerciseId: 'exercise-id',
      exerciseName: 'テスト種目',
      movementTip: '動作のポイント',
      cautionText: '注意点',
      contentVersion: 1,
      images: <ExerciseFormImageMetadata>[
        ExerciseFormImageMetadata(
          position: 1,
          label: '位置1',
          assetUri: 'assets/images/exercises/EX001_01.png',
          checksum: 'checksum-1',
          assetStatus: 'READY',
          contentVersion: 1,
        ),
        ExerciseFormImageMetadata(
          position: 2,
          label: '位置2',
          assetUri: 'assets/images/exercises/EX001_02.png',
          checksum: 'checksum-2',
          assetStatus: 'READY',
          contentVersion: 1,
        ),
      ],
    );
  }
}

final class _FakeResolver implements ExerciseFormImageResolver {
  @override
  Future<ExerciseFormImageResolution> resolve(
    ExerciseFormImageMetadata metadata,
  ) async {
    if (metadata.position == 1) {
      return ExerciseFormImageResolution(
        availability: ExerciseFormImageAvailability.available,
        bytes: Uint8List.fromList(<int>[1, 2, 3]),
      );
    }
    return const ExerciseFormImageResolution(
      availability: ExerciseFormImageAvailability.missingAsset,
    );
  }

  @override
  void invalidate({String? assetUri}) {}
}
