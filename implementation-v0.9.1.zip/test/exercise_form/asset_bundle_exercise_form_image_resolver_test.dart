import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/features/exercise_form/data/asset_bundle_exercise_form_image_resolver.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_models.dart';

void main() {
  test('READYかつchecksum一致の同梱画像だけを利用可能にする', () async {
    final bytes = Uint8List.fromList(<int>[1, 2, 3, 4]);
    final resolver = AssetBundleExerciseFormImageResolver(
      _MemoryAssetBundle(<String, Uint8List>{
        'assets/images/exercises/EX001_01.png': bytes,
      }),
    );
    final result = await resolver.resolve(
      ExerciseFormImageMetadata(
        position: 1,
        label: '位置1',
        assetUri: 'assets/images/exercises/EX001_01.png',
        checksum: sha256.convert(bytes).toString(),
        assetStatus: 'READY',
        contentVersion: 1,
      ),
    );

    expect(result.availability, ExerciseFormImageAvailability.available);
    expect(result.bytes, orderedEquals(bytes));
  });

  test('NOT_STARTEDはAssetBundleを読まずに準備中と判定する', () async {
    final resolver = AssetBundleExerciseFormImageResolver(
      _MemoryAssetBundle(const <String, Uint8List>{}),
    );
    final result = await resolver.resolve(
      const ExerciseFormImageMetadata(
        position: 1,
        label: '位置1',
        assetUri: 'assets/images/exercises/EX001_01.png',
        checksum: 'PENDING',
        assetStatus: 'NOT_STARTED',
        contentVersion: 1,
      ),
    );

    expect(result.availability, ExerciseFormImageAvailability.notReady);
  });

  test('AssetBundleがFlutterError以外を返してもスロット失敗として扱う', () async {
    final resolver = AssetBundleExerciseFormImageResolver(
      _ThrowingAssetBundle(),
    );
    final result = await resolver.resolve(
      const ExerciseFormImageMetadata(
        position: 1,
        label: '位置1',
        assetUri: 'assets/images/exercises/EX001_01.png',
        checksum: 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
        assetStatus: 'READY',
        contentVersion: 1,
      ),
    );

    expect(result.availability, ExerciseFormImageAvailability.missingAsset);
  });

}

final class _MemoryAssetBundle extends CachingAssetBundle {
  _MemoryAssetBundle(this.assets);
  final Map<String, Uint8List> assets;

  @override
  Future<ByteData> load(String key) async {
    final bytes = assets[key];
    if (bytes == null) throw FlutterError('Missing asset: $key');
    return ByteData.sublistView(bytes);
  }
}


final class _ThrowingAssetBundle extends CachingAssetBundle {
  @override
  Future<ByteData> load(String key) async {
    throw StateError('unexpected asset failure');
  }
}
