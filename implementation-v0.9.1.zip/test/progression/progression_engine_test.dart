import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/features/progression/domain/progression_engine.dart';
import 'package:workout_menu_app/features/progression/domain/progression_models.dart';

void main() {
  const engine = ProgressionEngine();

  test('sleep score 2 blocks an otherwise valid load increase', () {
    final proposal = engine.propose(
      _context(input: _input(sleepScore: 2), nextWeight: 22),
    );
    expect(proposal, isNull);
  });

  test('all upper with a legal registered weight proposes that weight', () {
    final proposal = engine.propose(
      _context(input: _input(), nextWeight: 21),
    );
    expect(proposal?.typeCode, ProgressionProposalTypes.increaseWeight);
    expect(proposal?.proposedValue['weightKg'], 21);
  });

  test('three comparable stalls can add one set below profile cap', () {
    final context = _context(
      input: _input(),
      resultCode: ProgressionResultCodes.inRange,
      stallCount: 3,
      currentSetCount: 3,
      profileSetUpper: 4,
    );
    final proposal = engine.propose(context);
    expect(proposal?.typeCode, ProgressionProposalTypes.addSet);
    expect(proposal?.proposedValue['setCount'], 4);
  });
}

ProgressionExerciseInput _input({int sleepScore = 4}) {
  return ProgressionExerciseInput(
    userId: 'user',
    workoutSessionId: 'session',
    sessionExerciseId: 'session-exercise',
    exerciseId: 'exercise',
    exerciseName: 'テスト種目',
    roleCode: 'MAJOR',
    recordingMethodCode: 'WEIGHT_REPS',
    progressionGroupCode: 'PG01_WEIGHTED_MAJOR',
    targetModeCode: 'REPS',
    goalCode: 'HYPERTROPHY',
    difficultyScore: 3,
    sleepScore: sleepScore,
    statusCode: 'COMPLETED',
    hadPain: false,
    incompleteReasonCode: null,
    sets: List<ProgressionSetSample>.generate(
      3,
      (index) => ProgressionSetSample(
        setNumber: index + 1,
        sideCode: 'BOTH',
        isWarmup: false,
        actualWeightKg: 20,
        actualReps: 12,
        targetRepsLower: 8,
        targetRepsUpper: 12,
      ),
    ),
  );
}

ProgressionDecisionContext _context({
  required ProgressionExerciseInput input,
  String resultCode = ProgressionResultCodes.allUpper,
  int stallCount = 0,
  int currentSetCount = 3,
  int profileSetUpper = 4,
  double? nextWeight,
}) {
  return ProgressionDecisionContext(
    input: input,
    classification: ProgressionClassification(
      code: resultCode,
      validForPerformance: true,
      reasonText: 'test',
      workSetCount: currentSetCount,
      totalReps: 36,
      totalDurationSec: 0,
      minimumReps: 12,
      maximumReps: 12,
      representativeWeightKg: 20,
      metricValue: 200036,
      mixedLoad: false,
    ),
    stallCount: stallCount,
    consecutiveAllUpper: resultCode == ProgressionResultCodes.allUpper ? 1 : 0,
    consecutiveLow: 0,
    currentSetCount: currentSetCount,
    profileSetUpper: profileSetUpper,
    nextRegisteredWeightKg: nextWeight,
  );
}
