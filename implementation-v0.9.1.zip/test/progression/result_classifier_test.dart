import 'package:flutter_test/flutter_test.dart';
import 'package:workout_menu_app/features/progression/domain/progression_models.dart';
import 'package:workout_menu_app/features/progression/domain/result_classifier.dart';

void main() {
  const classifier = ResultClassifier();

  test('pain blocks performance evaluation', () {
    final result = classifier.classify(_input(hadPain: true));
    expect(result.code, ProgressionResultCodes.pain);
    expect(result.validForPerformance, isFalse);
  });

  test('all work sets at upper target are classified as all upper', () {
    final result = classifier.classify(_input());
    expect(result.code, ProgressionResultCodes.allUpper);
    expect(result.validForPerformance, isTrue);
    expect(result.workSetCount, 3);
    expect(result.totalReps, 36);
  });

  test('time shortage is not counted as performance decline', () {
    final result = classifier.classify(
      _input(statusCode: 'PARTIAL', incompleteReasonCode: 'TIME'),
    );
    expect(result.code, ProgressionResultCodes.contextIncomplete);
    expect(result.validForPerformance, isFalse);
  });
}

ProgressionExerciseInput _input({
  bool hadPain = false,
  String statusCode = 'COMPLETED',
  String? incompleteReasonCode,
}) {
  return ProgressionExerciseInput(
    userId: 'user',
    workoutSessionId: 'session',
    sessionExerciseId: 'session-exercise',
    exerciseId: 'exercise',
    exerciseName: 'テスト種目',
    roleCode: 'MAJOR',
    recordingMethodCode: 'WEIGHT_REPS',
    progressionGroupCode: 'PG01_WEIGHTED_MAJOR',
    targetModeCode: 'REPS',
    goalCode: 'HYPERTROPHY',
    difficultyScore: 3,
    sleepScore: 4,
    statusCode: statusCode,
    hadPain: hadPain,
    incompleteReasonCode: incompleteReasonCode,
    sets: List<ProgressionSetSample>.generate(
      3,
      (index) => ProgressionSetSample(
        setNumber: index + 1,
        sideCode: 'BOTH',
        isWarmup: false,
        actualWeightKg: 20,
        actualReps: 12,
        targetRepsLower: 8,
        targetRepsUpper: 12,
      ),
    ),
  );
}
