import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('MVP router and My Page do not expose unavailable external features', () {
    final router = File('lib/app/router/app_router.dart').readAsStringSync();
    final myPage = File(
      'lib/features/my_page/presentation/my_page.dart',
    ).readAsStringSync();

    for (final route in <String>[
      '/my-page/account',
      '/ai-coach',
      '/my-page/notifications',
    ]) {
      expect(router, isNot(contains(route)));
    }

    for (final label in <String>[
      'アカウントと同期',
      'AI相談',
      '通知・リマインダー',
    ]) {
      expect(myPage, isNot(contains(label)));
    }

    expect(router, contains('/ai-knowledge'));
    expect(myPage, contains('用語・FAQ'));
  });
}
