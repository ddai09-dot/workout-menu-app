INSERT OR IGNORE INTO body_part_master (id, code, name_ja, is_active, content_version, created_at, updated_at, parent_body_part_id, split_group_code, display_order) VALUES ('2cca493b-3f58-5100-a938-4c555dad4a18', 'CHEST', '胸', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', NULL, 'CHEST', 1);
-- statement
INSERT OR IGNORE INTO body_part_master (id, code, name_ja, is_active, content_version, created_at, updated_at, parent_body_part_id, split_group_code, display_order) VALUES ('1d825dfc-f561-555a-aa40-d544f3181341', 'BACK', '背中', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', NULL, 'BACK', 2);
-- statement
INSERT OR IGNORE INTO body_part_master (id, code, name_ja, is_active, content_version, created_at, updated_at, parent_body_part_id, split_group_code, display_order) VALUES ('3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'SHOULDERS', '肩', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', NULL, 'SHOULDERS', 3);
-- statement
INSERT OR IGNORE INTO body_part_master (id, code, name_ja, is_active, content_version, created_at, updated_at, parent_body_part_id, split_group_code, display_order) VALUES ('b8443d14-b195-556a-bef7-b810e2476377', 'ARMS', '腕', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', NULL, 'ARMS', 4);
-- statement
INSERT OR IGNORE INTO body_part_master (id, code, name_ja, is_active, content_version, created_at, updated_at, parent_body_part_id, split_group_code, display_order) VALUES ('fc177709-495f-5f69-a70a-20ee56bd0a66', 'GLUTES', 'お尻', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', NULL, 'GLUTES', 5);
-- statement
INSERT OR IGNORE INTO body_part_master (id, code, name_ja, is_active, content_version, created_at, updated_at, parent_body_part_id, split_group_code, display_order) VALUES ('daf26e81-268c-5cde-af17-102e8ac420ad', 'LEGS', '脚', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', NULL, 'LEGS', 6);
-- statement
INSERT OR IGNORE INTO body_part_master (id, code, name_ja, is_active, content_version, created_at, updated_at, parent_body_part_id, split_group_code, display_order) VALUES ('6779253e-e223-5b22-b0c1-180c9c7598f5', 'CORE', '腹筋・体幹', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', NULL, 'CORE', 7);
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('3ce804ac-eedf-5b8b-8280-2e888372ed9b', 'MV001', '水平プッシュ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PUSH');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('00c6bae4-492a-5ca2-931b-542a81222943', 'MV002', '斜め上方向プッシュ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PUSH');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('b11721fb-ef3c-5417-8d46-ce7c375b7ddd', 'MV003', '肩水平内転', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PUSH');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('55667833-727f-5f17-9a78-ffaed7e95719', 'MV004', '垂直プル', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PULL');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('61a06c0e-4b6a-5fbf-9ded-902a6a3abc3e', 'MV005', '水平プル', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PULL');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('04b24f98-95b2-5283-ade3-4d6201763da1', 'MV006', '肩伸展', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PULL');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('94f12711-6f68-5ab3-b010-f5f1f38025c4', 'MV007', '体幹伸展・股関節伸展', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PULL');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('8f5e9d68-8498-568d-80c6-7e34b2cf83b3', 'MV008', '垂直プッシュ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PUSH');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('625454c7-efcc-5cb1-a523-da01a7b3a143', 'MV009', '肩外転', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PUSH');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('3642b372-c5c2-5e1a-a2e1-c32a1617d4c0', 'MV010', '肩屈曲', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PUSH');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('95283fd3-86d9-54f4-9eb1-9e4984a563cb', 'MV011', '肩水平外転', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PULL');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('8ab974bf-455d-57b7-9f16-f6db59dead5c', 'MV012', '水平プル・肩外旋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PULL');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('ab10e639-72e2-51a6-82fe-ff721b208e70', 'MV013', '垂直プッシュ・肩回旋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PUSH');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('00d68707-bd4e-5d31-9c2e-be8530df2720', 'MV014', '肘屈曲', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PULL');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('c443643d-930f-50ca-9d14-bbb08d773d38', 'MV015', '肘伸展', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PUSH');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('89048f02-5230-5a32-bcdb-2a24944621a0', 'MV016', '水平プッシュ・肘伸展', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PUSH');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('17fa86f5-c377-53e3-b1a3-1ae6393ad185', 'MV017', '手首屈曲', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PULL');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('b63c3fa4-ddb5-5a81-acd0-c779467bd7d5', 'MV018', '股関節伸展', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('d08b8ce6-ec56-573b-8646-e862dca64d5c', 'MV019', 'ヒップヒンジ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('f2068657-53a1-58f0-82f1-c4c2adf847a2', 'MV020', '片脚スクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('adfa784b-a475-5e2b-b47e-75eff2b2ab4e', 'MV021', '股関節外転', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('d72fa645-84a7-5c91-9898-f2268bd4271f', 'MV022', '股関節外転・横移動', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('03965ec6-6d6b-5e39-9d6e-669dcbdf2168', 'MV023', 'スクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('477dd8ad-3780-5161-afdf-a91f4e13c4ba', 'MV024', '膝・股関節伸展', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('6132b346-08e6-54a8-a26f-122e6db12daa', 'MV025', '膝伸展', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('89079b75-f091-5d53-b5c0-728ca1d97b3a', 'MV026', '膝屈曲', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('3e0e1df8-d2ea-5b6f-bd9b-d71945f0e960', 'MV027', '片脚スクワット・歩行', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('c6762a7d-2d6e-51fd-a72e-22016f0fad6a', 'MV028', '足関節底屈', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'LEGS');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('362f4bbb-2513-53ec-aaf1-133e3a352784', 'MV029', '体幹屈曲', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('72962a81-d5d3-57d2-93ef-1710c2eb2187', 'MV030', '骨盤後傾', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('a8f5205a-66e0-5843-a322-4e5ce5654ff2', 'MV031', '股関節屈曲・骨盤後傾', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('15c5b087-7e7b-5d52-abf3-c059000bd211', 'MV032', '体幹伸展抑制', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('1d6b476a-6dc2-5ea0-8f01-72c7cf5b0755', 'MV033', '体幹側屈抑制', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('eda5a58f-670e-5202-8a76-7860bcfde860', 'MV034', '体幹回旋抑制・伸展抑制', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO movement_master (id, code, name_ja, is_active, content_version, created_at, updated_at, movement_group_code) VALUES ('d3486ade-ddb8-53c7-83aa-a77615a047c4', 'MV035', '体幹回旋抑制', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO joint_master (id, code, name_ja, is_active, content_version, created_at, updated_at) VALUES ('d9ff25cd-00a9-57cc-935b-500d30d0905e', 'JT001', '肩', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO joint_master (id, code, name_ja, is_active, content_version, created_at, updated_at) VALUES ('507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'JT002', '肘', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO joint_master (id, code, name_ja, is_active, content_version, created_at, updated_at) VALUES ('cafcde77-7fe1-581f-8224-b52d80500b7d', 'JT003', '手首', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO joint_master (id, code, name_ja, is_active, content_version, created_at, updated_at) VALUES ('d62a5656-fe76-5140-9198-7c3b742ef338', 'JT004', '腰', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO joint_master (id, code, name_ja, is_active, content_version, created_at, updated_at) VALUES ('187c487b-4f66-5b78-b6dd-5a5523ad179b', 'JT005', '股関節', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO joint_master (id, code, name_ja, is_active, content_version, created_at, updated_at) VALUES ('231afa62-ad43-545d-aa57-174553f36158', 'JT006', '膝', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO joint_master (id, code, name_ja, is_active, content_version, created_at, updated_at) VALUES ('9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'JT007', '足首', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO joint_master (id, code, name_ja, is_active, content_version, created_at, updated_at) VALUES ('a0e4cae0-77b6-5248-8d82-17bbd25899b8', 'JT008', '首', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('56b6b1c3-175a-5993-b27f-4e2f434634d9', 'FT001', '胸', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('f234d41b-664e-53bc-9589-6f1119cc4b07', 'FT002', '肩前部', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 'FT003', '上腕三頭筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('13792595-dcd6-5a35-961f-951a25310348', 'FT004', '肘', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'JOINT');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('eaff0d48-92a1-5199-843d-d230bec14362', 'FT005', '手首', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'JOINT');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('bd034c89-8fde-5539-b73c-feeea657d8b0', 'FT006', '体幹', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('31cb3393-17f8-51da-9aae-5a27b8302e1d', 'FT007', '胸上部', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('0fb9393b-988d-563d-8550-892e9af92b93', 'FT008', '上腕二頭筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('6f8f2aac-3c91-5244-b579-8918e7390b5e', 'FT009', '広背筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('e52b3685-8229-5955-a06a-c01d2c7c54ea', 'FT010', '前腕', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('9f1e0015-5378-5326-9639-4fc8556375b3', 'FT011', '肩後部', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('de57df8a-9b46-5c64-a036-de45ac8accd1', 'FT012', '僧帽筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('88287900-5ac0-5761-919d-84842dbbcdaa', 'FT013', '肩', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'JOINT');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('cb180d10-c29c-509c-b561-e9ee65e0a8b8', 'FT014', '腰', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'JOINT');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('83adbba0-4b1b-58d9-85c8-146b50e38786', 'FT015', '菱形筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('f2c100d6-5ea4-5fd0-a12d-1c350be3f2ea', 'FT016', '大円筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('e8e67542-58b2-5d96-aa1f-136ae73f9855', 'FT017', '上腕三頭筋長頭', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('00408f91-48f7-5a64-9f3e-00d889b5b9f0', 'FT018', '脊柱起立筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 'FT019', '臀部', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('2969b470-d7ec-520d-9bd3-763bc994afab', 'FT020', 'もも裏', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('a0e84e6c-eec6-536c-9b3c-0780eda119d1', 'FT021', '肩側部', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('810521fc-1bac-5fd0-8ead-0cd87d8f0ae4', 'FT022', '僧帽筋上部', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('a8e76a29-7c57-5875-8a30-1cf4d2770800', 'FT023', '僧帽筋中部', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('7e4d2a72-a147-59f4-aa6c-d7b0a248e40b', 'FT024', '上腕筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('8127307a-b647-5242-856f-33e845c480dc', 'FT025', '腕橈骨筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('8d5bdeeb-edd5-5eaf-b043-a2dbe14e0518', 'FT026', '前腕伸筋群', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('ac7c3d04-952d-5b39-a703-53446b3c512c', 'FT027', '前腕屈筋群', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('b029826b-6c01-5715-9175-e6ce17e0d2d3', 'FT028', '大腿四頭筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('eef589fe-ad5c-5eea-803b-6f4505dd2709', 'FT029', '膝', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'JOINT');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('c2d01fc1-b89f-55d7-bea6-4555436f8abd', 'FT030', '股関節', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'JOINT');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('d670e94d-96d4-5385-a70b-2b44aa9ccdbd', 'FT031', '臀部外側', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('005a7449-3a58-5f37-ae08-3ee76ba426d6', 'FT032', '腹筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('d7016ff3-6aa8-51bb-b4cc-44f8803a4873', 'FT033', 'ふくらはぎ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('ea99222f-ed2e-5fe8-9107-a44a9f0e3788', 'FT034', '足首', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'JOINT');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('7cc9fb64-5ee6-5b88-96a0-252c30b0d754', 'FT035', '足部', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('f0e78eed-f404-5d9b-a4f4-b123217e1e0f', 'FT036', '腹直筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('3ea569d1-a89b-5921-a998-ea62045ddddc', 'FT037', '首', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'JOINT');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('ae6d0bf5-a803-57dc-84de-b2be3df0fe9d', 'FT038', '下腹部', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('33996a24-8bb3-5165-afe1-d7768356dda5', 'FT039', '股関節屈筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('1c0574e5-b041-56ff-bb9b-ab2fe9a8321e', 'FT040', '腹斜筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('e7513330-a6af-529b-965e-434adb23ee1b', 'FT041', '背筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MUSCLE');
-- statement
INSERT OR IGNORE INTO fatigue_tag_master (id, code, name_ja, is_active, content_version, created_at, updated_at, fatigue_group_code) VALUES ('6afb5cd4-3892-5552-8fa4-bfd6c004fa17', 'FT042', '腹横筋', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'CORE');
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'NONE', '器具なし', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'NONE', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('73213a6e-2685-586a-992a-dac6783ead75', 'DUMBBELL', 'ダンベル', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'FREE_WEIGHT', 1, 1);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'BARBELL', 'バーベル', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'FREE_WEIGHT', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('170c3d51-3265-5cec-8432-9bcfc8c7c9a6', 'EZ_BAR', 'EZバー', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'FREE_WEIGHT', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('0e3f8f7d-46a7-52ec-a4cc-af1cf44fd0f4', 'KETTLEBELL', 'ケトルベル', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'FREE_WEIGHT', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('1d9b73ea-aca4-5ef8-b84c-ab997706e8a0', 'WEIGHT_PLATE', 'プレート', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'FREE_WEIGHT', 1, 1);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('6aa2bcdd-42e8-552e-9b49-38249d8a5f78', 'FLAT_BENCH', 'フラットベンチ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'BENCH', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('af7565b6-26dc-534e-b1f6-ae9b5a887fa5', 'ADJUSTABLE_BENCH', '角度調整ベンチ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'BENCH', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'BENCH', 'ベンチ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'BENCH', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('fc143718-6810-5509-bce4-8346c4db8715', 'STEP_PLATFORM', '安定した台', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'BENCH', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('b8f8a8dc-169e-5f97-82de-d1a015f697f0', 'RACK', 'パワーラック／ハーフラック', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'RACK', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('30f9cef2-8e64-58b8-9fc8-632dfd1bf3a3', 'SAFETY', 'セーフティ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'RACK', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('e325affa-7d33-5f9a-97b9-99776e87d26e', 'CABLE_MACHINE', 'ケーブルマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('676aec99-428e-5271-81ea-bd7ea0fc4c7a', 'CABLE_ROW_MACHINE', 'ケーブルロウマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('19e707a1-e4ac-5b94-af46-0344f44dadd8', 'LAT_PULLDOWN_MACHINE', 'ラットプルダウンマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('5fa043be-830c-5666-8b15-508c871bd9b8', 'CHEST_PRESS_MACHINE', 'チェストプレスマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('66df84ab-4761-5258-89d0-8f1b0f8f2e0a', 'SHOULDER_PRESS_MACHINE', 'ショルダープレスマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('b3adcfbb-0155-5887-b865-6e212116ec8e', 'PEC_DECK_MACHINE', 'ペックデックマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('a9ab118e-fd6c-515a-a0dd-e88ab2370c47', 'REVERSE_PEC_DECK_MACHINE', 'リバースペックデックマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('3df15c8f-f9a4-56d9-8d9b-886d57305df6', 'CHEST_SUPPORTED_ROW_MACHINE', '胸当て付きロウマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('b62790f5-7f49-5597-9eb2-11e3ff41a7ed', 'ASSIST_PULLUP_MACHINE', 'アシスト懸垂マシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('fcfdebc3-fe22-5351-9178-d41a78d8716d', 'LEG_PRESS_MACHINE', 'レッグプレスマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('e4645f85-d186-5bdb-8fd6-959832155402', 'LEG_EXTENSION_MACHINE', 'レッグエクステンションマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('8ba366f0-a3b5-5f13-91b9-8a71b3bb1149', 'LEG_CURL_MACHINE', 'レッグカールマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('b1c0559c-3032-52c4-81a6-f1990284bdc2', 'HIP_ABDUCTION_MACHINE', 'ヒップアブダクションマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('8424cd43-0751-5ad9-ad2b-26cb271ffd53', 'SEATED_CALF_MACHINE', 'シーテッドカーフマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('b662f884-4b5d-545c-ab04-ea8473c51598', 'CALF_MACHINE', 'カーフマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('e5d45659-a476-5264-ba03-b06726d9bf33', 'PREACHER_CURL_MACHINE', 'プリーチャーカールマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MACHINE', 1, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('9caa0abc-d5a3-5adc-a1e3-ccd95e3dde5d', 'BACK_EXTENSION_BENCH', 'バックエクステンション台', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'BENCH', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('4ce67979-7939-5157-96d1-07f06333b953', 'PULLUP_BAR', '懸垂器具', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'STATION', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('404aaddc-dfce-54bc-922e-54ccc919890d', 'LANDMINE_ATTACHMENT', 'ランドマインアタッチメント', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ATTACHMENT', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('c3909799-b948-5826-8736-f729d5ebd90e', 'LANDMINE_ANCHOR', '安全な固定設備', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ATTACHMENT', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('6173e25b-e304-597e-af87-231718b056b5', 'ROPE_ATTACHMENT', 'ロープアタッチメント', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ATTACHMENT', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('58800793-32bd-5935-bff9-05f8d476d9c6', 'STRAIGHT_BAR_ATTACHMENT', 'ケーブル用バー', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ATTACHMENT', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('8fd229c1-b772-511a-bb1f-36bfe2f746cf', 'ANKLE_STRAP', 'アンクルストラップ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ATTACHMENT', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('bd1363fe-7cb6-53c5-ba22-13c590a0ea3b', 'PREACHER_BENCH', 'プリーチャー台', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'BENCH', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('bb437913-c962-52fd-9c7c-fa4a674b01a0', 'BAND', 'トレーニングバンド', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'BAND', 0, 1);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('962c30f2-208d-57a6-b7d3-64aeee264b53', 'MAT', 'マット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ACCESSORY', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('f12c6115-5e32-58a3-9572-a658ed1a6155', 'AB_ROLLER', 'アブローラー', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ACCESSORY', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('d038c93b-126b-53f1-bcc7-707f3dcd9342', 'PUSHUP_BAR', 'プッシュアップバー', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ACCESSORY', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, is_active, content_version, created_at, updated_at, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('5e07b121-c2a0-5e03-b5b9-418f349df03e', 'PAD', 'パッド', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ACCESSORY', 0, 0);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('95819265-6d61-5cca-ad80-1609b3a02486', 'EX001', 'インクラインプッシュアップ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id', 'LOW', 'MAJOR_INTRO', 'COMPOUND', 'BILATERAL_ARMS', 'VARIATION_FIRST', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('66cb5620-69b9-5b12-985b-75fa436838ba', '95819265-6d61-5cca-ad80-1609b3a02486', '2cca493b-3f58-5100-a938-4c555dad4a18', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('9f825ae8-98d7-57fc-a484-8a3f78cc63b5', '95819265-6d61-5cca-ad80-1609b3a02486', '3ce804ac-eedf-5b8b-8280-2e888372ed9b', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('89274013-0fb5-56d8-ad03-7bec92b872fe', '95819265-6d61-5cca-ad80-1609b3a02486', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('0fa982ed-8ed6-5fb7-b0c6-53b33d1a9d90', '95819265-6d61-5cca-ad80-1609b3a02486', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('481b67ff-d02d-5596-b930-cd83ae9590aa', '95819265-6d61-5cca-ad80-1609b3a02486', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('9d81ad07-1acd-5e60-8b3a-c227bdefcfcc', '95819265-6d61-5cca-ad80-1609b3a02486', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('2616b8bd-73b7-50b3-8593-8cfa15431c74', '95819265-6d61-5cca-ad80-1609b3a02486', '56b6b1c3-175a-5993-b27f-4e2f434634d9', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ec342f1f-6290-542a-8254-a55d2d04e7b8', '95819265-6d61-5cca-ad80-1609b3a02486', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('480302b7-dc55-5083-945d-3195ce5eb2f5', '95819265-6d61-5cca-ad80-1609b3a02486', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f6d0fdce-ead7-501f-8203-c1838483794c', '95819265-6d61-5cca-ad80-1609b3a02486', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('27b016ad-1a68-59a1-9dd0-3fb77b16bc88', '95819265-6d61-5cca-ad80-1609b3a02486', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('1d971bf8-a0f7-5d20-8e88-808e0998d384', '95819265-6d61-5cca-ad80-1609b3a02486', 'bd034c89-8fde-5539-b73c-feeea657d8b0', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('97eb5e21-4886-5e17-89d0-52714ffab8e3', '95819265-6d61-5cca-ad80-1609b3a02486', 'OPT1', 1, 1, '安定した台またはベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('73653ad4-c472-53ba-91ec-dde28007455b', '95819265-6d61-5cca-ad80-1609b3a02486', '97eb5e21-4886-5e17-89d0-52714ffab8e3', 'fc143718-6810-5509-bce4-8346c4db8715', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('22f394d1-3f2d-5e88-9aa0-ca7e01b8eade', '95819265-6d61-5cca-ad80-1609b3a02486', 'OPT2', 2, 1, '安定した台またはベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('e2df5aa3-18d2-51a4-9cc7-87b8371aa4e1', '95819265-6d61-5cca-ad80-1609b3a02486', '22f394d1-3f2d-5e88-9aa0-ca7e01b8eade', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('05c70f4f-6814-55d7-a53b-feac833cfc7d', 'EX002', 'プッシュアップ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'MEDIUM', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'REPS_LOADABLE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('14499d79-16dc-5eee-bd63-4023ca84bde7', '05c70f4f-6814-55d7-a53b-feac833cfc7d', '2cca493b-3f58-5100-a938-4c555dad4a18', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('111dfc75-7bf1-5b31-b0f7-c8f5030666b4', '05c70f4f-6814-55d7-a53b-feac833cfc7d', '3ce804ac-eedf-5b8b-8280-2e888372ed9b', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('19573a9c-94dc-564d-bdd7-ed358e948f16', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('88a2d04f-66ce-52d8-bc82-7e6d346f9b76', '05c70f4f-6814-55d7-a53b-feac833cfc7d', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('353f26fd-1c33-5d8c-b7e8-4a30d2cde25f', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('2f85777b-380c-5666-88a6-538b16617d7a', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4e18c081-66f0-58e0-8801-b3a4e87bb8de', '05c70f4f-6814-55d7-a53b-feac833cfc7d', '56b6b1c3-175a-5993-b27f-4e2f434634d9', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4259d2be-1b5f-54d2-99b9-4ed86895e50a', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('d42c3800-b4ea-5968-8f4a-665613681c24', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('477cf4f0-8f6b-5075-b88c-d11ec071d9bf', '05c70f4f-6814-55d7-a53b-feac833cfc7d', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('001dca87-bf54-55f6-80fb-01dc80324d9a', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c72016bd-21a9-5e2e-949b-b854f36c7908', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'bd034c89-8fde-5539-b73c-feeea657d8b0', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('7e47ec04-2b5a-54a3-9b34-435f1c04b8a2', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'OPT1', 1, 1, '器具なし。任意でプッシュアップバー', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('8a6c5f48-44ab-568f-b51b-641f82782ec1', '05c70f4f-6814-55d7-a53b-feac833cfc7d', '7e47ec04-2b5a-54a3-9b34-435f1c04b8a2', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('728c22d5-86f9-58b2-b702-73ca968290c8', 'EX003', 'ダンベルフロアプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'LOW', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('5ff2df35-c013-52c7-8b2a-d47401979665', '728c22d5-86f9-58b2-b702-73ca968290c8', '2cca493b-3f58-5100-a938-4c555dad4a18', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('a710dddf-6c56-5e4a-aa66-2736adcf3414', '728c22d5-86f9-58b2-b702-73ca968290c8', '3ce804ac-eedf-5b8b-8280-2e888372ed9b', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('499de550-bddc-5fd7-8f4c-94776f9ab17e', '728c22d5-86f9-58b2-b702-73ca968290c8', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('4a3a0467-79ec-5b3d-9f01-2e64d4bf8ba8', '728c22d5-86f9-58b2-b702-73ca968290c8', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('b32d069b-2341-5bc4-a62e-e340bdfbabb5', '728c22d5-86f9-58b2-b702-73ca968290c8', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4b6b6df9-81a6-5991-a966-33a75d33b6d9', '728c22d5-86f9-58b2-b702-73ca968290c8', '56b6b1c3-175a-5993-b27f-4e2f434634d9', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('57386e02-9870-5f98-bbc6-dffa4ef032e3', '728c22d5-86f9-58b2-b702-73ca968290c8', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3003e452-4c0f-5966-a59e-97a96b3f7ff5', '728c22d5-86f9-58b2-b702-73ca968290c8', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('1bbd79a4-45e6-566d-86be-93a2117e5f6d', '728c22d5-86f9-58b2-b702-73ca968290c8', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('eb17f1a4-c6f0-52f1-8544-8e68ac792cdf', '728c22d5-86f9-58b2-b702-73ca968290c8', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('4620b5e6-bd0a-581a-b414-71e4e5197ceb', '728c22d5-86f9-58b2-b702-73ca968290c8', 'OPT1', 1, 1, 'ダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('976c45fb-b65e-5e2e-86ff-e1271e283333', '728c22d5-86f9-58b2-b702-73ca968290c8', '4620b5e6-bd0a-581a-b414-71e4e5197ceb', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('c3be154d-b150-5477-852d-553edd3155b7', 'EX004', 'ダンベルベンチプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('06879065-0822-528d-b0d0-cbb3db3da9fc', 'c3be154d-b150-5477-852d-553edd3155b7', '2cca493b-3f58-5100-a938-4c555dad4a18', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('d5bdd736-efd5-5a19-a035-58a6dad895e7', 'c3be154d-b150-5477-852d-553edd3155b7', '3ce804ac-eedf-5b8b-8280-2e888372ed9b', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('972f2f37-ac03-52db-95d0-3157b9cd19a1', 'c3be154d-b150-5477-852d-553edd3155b7', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('5602a450-bac0-5923-ac5f-ddcc7f2968b7', 'c3be154d-b150-5477-852d-553edd3155b7', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('a4231457-b7fa-5264-a37a-9bd5e136d31d', 'c3be154d-b150-5477-852d-553edd3155b7', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('a7a76372-d609-5a06-8428-2e9e5aa07de3', 'c3be154d-b150-5477-852d-553edd3155b7', '56b6b1c3-175a-5993-b27f-4e2f434634d9', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('97b83ccd-6e26-5e76-b733-7e37df738f9f', 'c3be154d-b150-5477-852d-553edd3155b7', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('27cec199-8b42-598b-86fb-80499b66f12c', 'c3be154d-b150-5477-852d-553edd3155b7', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('5c51741d-77c1-5abd-9151-433fda40d80a', 'c3be154d-b150-5477-852d-553edd3155b7', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('22fef9fe-6b9a-5757-9d29-2706783f4255', 'c3be154d-b150-5477-852d-553edd3155b7', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('b45d8dc5-5e39-51eb-b468-90d299e24f8b', 'c3be154d-b150-5477-852d-553edd3155b7', 'OPT1', 1, 1, 'ダンベル、フラットベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('8e3e227d-3745-5564-8467-c5861c55b272', 'c3be154d-b150-5477-852d-553edd3155b7', 'b45d8dc5-5e39-51eb-b468-90d299e24f8b', '6aa2bcdd-42e8-552e-9b49-38249d8a5f78', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('e1249c77-b4bf-5578-9720-d3abf69ab36e', 'c3be154d-b150-5477-852d-553edd3155b7', 'b45d8dc5-5e39-51eb-b468-90d299e24f8b', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('bf8c371e-abad-5b7e-a822-0e8717ea11eb', 'c3be154d-b150-5477-852d-553edd3155b7', 'b45d8dc5-5e39-51eb-b468-90d299e24f8b', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('c4e220e7-0ec4-503b-8200-468acd7628f5', 'EX005', 'インクラインダンベルプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('8c841b91-5c06-5462-8510-834267c5b1c9', 'c4e220e7-0ec4-503b-8200-468acd7628f5', '2cca493b-3f58-5100-a938-4c555dad4a18', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('b6c1f0b4-c71f-586f-b4d3-8b39c9b36c6f', 'c4e220e7-0ec4-503b-8200-468acd7628f5', '00c6bae4-492a-5ca2-931b-542a81222943', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f701bc30-6c36-5a29-93f6-1ab50f2fc380', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('94044cf0-4ca5-5869-aac6-d944a4e7a43e', 'c4e220e7-0ec4-503b-8200-468acd7628f5', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('23ef61c1-426d-5a2c-8349-c35fb22df40d', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('97e4f8f8-4d17-530a-9198-6807be12a769', 'c4e220e7-0ec4-503b-8200-468acd7628f5', '31cb3393-17f8-51da-9aae-5a27b8302e1d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('9683e844-4247-5732-819c-41ae5fc6c702', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('8090a0ed-8ecb-5cc2-852d-e196fb171b17', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('52a03da3-ae1e-589f-a1c6-01ced2849986', 'c4e220e7-0ec4-503b-8200-468acd7628f5', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e166f8f8-c837-5dde-bd37-702e667bee3f', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('29dcc268-7663-529b-84ee-60a7a0020046', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 'OPT1', 1, 1, 'ダンベル、角度調整ベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('656ff8f1-0e09-5c87-93c7-98787cea7167', 'c4e220e7-0ec4-503b-8200-468acd7628f5', '29dcc268-7663-529b-84ee-60a7a0020046', 'af7565b6-26dc-534e-b1f6-ae9b5a887fa5', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('704d8846-dc9f-5a9a-895c-43ef30c1fc2f', 'c4e220e7-0ec4-503b-8200-468acd7628f5', '29dcc268-7663-529b-84ee-60a7a0020046', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('4715f490-1f86-5bbb-9297-56d3dd16be56', 'c4e220e7-0ec4-503b-8200-468acd7628f5', '29dcc268-7663-529b-84ee-60a7a0020046', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'EX006', 'バーベルベンチプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'HIGH', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('1c14bbf2-03aa-59c6-aca3-065b094e21e0', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '2cca493b-3f58-5100-a938-4c555dad4a18', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('4b6e4471-60c8-5139-8abe-06c2b0c58ebd', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '3ce804ac-eedf-5b8b-8280-2e888372ed9b', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('af32ea03-2048-5955-819e-a39ebab55cd3', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('d9c0b20f-ca79-5894-af41-b085420c2b4c', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('035e3b69-0d9e-5dc9-981b-67b40e6502c1', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('78e88395-5ce2-5ec4-abb2-fa42de1ad3bb', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '56b6b1c3-175a-5993-b27f-4e2f434634d9', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c804c199-8448-5413-99ac-e80aabbcb7f1', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('5811f5f3-7a8e-59dd-bc61-cc3a01e9cdb5', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('b1fc608f-7e89-5a23-9c7d-df6a6a55abf0', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('70bfb2b3-629b-5d3d-a2da-0d5eed4ac4e5', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('4dfb3d2c-c1fa-5606-8374-7f26e1b990a7', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'OPT1', 1, 1, 'バーベル、フラットベンチ、ラック／セーフティ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('5f7af45d-f3cd-57d7-986b-925406f64c0b', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '4dfb3d2c-c1fa-5606-8374-7f26e1b990a7', '6aa2bcdd-42e8-552e-9b49-38249d8a5f78', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('6afed310-63d7-57be-bc06-7e69ec0fdde1', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '4dfb3d2c-c1fa-5606-8374-7f26e1b990a7', '30f9cef2-8e64-58b8-9fc8-632dfd1bf3a3', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('f6c0b645-dd2b-5414-b29c-3e2921c25384', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '4dfb3d2c-c1fa-5606-8374-7f26e1b990a7', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('1f2df77b-4a43-57a4-825c-c7b52feccb15', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '4dfb3d2c-c1fa-5606-8374-7f26e1b990a7', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'EX007', 'マシンチェストプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('65390d31-b5cf-5ce8-ae17-7a879579f694', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', '2cca493b-3f58-5100-a938-4c555dad4a18', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('f4bc5c2b-be5c-5d18-b9c0-5e569112dd7f', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', '3ce804ac-eedf-5b8b-8280-2e888372ed9b', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('64aef34b-d031-5ec8-9961-d5d9f1c0994a', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('ee724c47-72b0-5530-9953-9604936d12cd', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('4604f755-9ac2-565c-8266-df694053b634', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('1e2718ea-b90e-55d4-831c-8dcd69962304', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', '56b6b1c3-175a-5993-b27f-4e2f434634d9', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('766b6084-08c2-5f87-8383-8bfcc911b1ae', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('1d82f200-3c73-532f-83c9-7d4bd5711574', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0bb99cbe-9480-501b-a64c-2e2ae6df0193', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('40172f06-78aa-5f07-99e6-bee5cf32af89', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('33afbbc5-3b0b-5608-86c2-b5277c2611da', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'OPT1', 1, 1, 'チェストプレスマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('22470d01-58e0-5253-b118-57223cdbed42', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', '33afbbc5-3b0b-5608-86c2-b5277c2611da', '5fa043be-830c-5666-8b15-508c871bd9b8', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('16228203-ecfa-552d-b068-6a645dacc7ba', 'EX008', 'ダンベルフライ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('3e217b3b-d2b6-5cd8-97da-0840d42f009e', '16228203-ecfa-552d-b068-6a645dacc7ba', '2cca493b-3f58-5100-a938-4c555dad4a18', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('46c6951d-a38a-596c-a4d9-0b9fc9359924', '16228203-ecfa-552d-b068-6a645dacc7ba', 'b11721fb-ef3c-5417-8d46-ce7c375b7ddd', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('240bc868-d509-5a64-8458-3adb048e3530', '16228203-ecfa-552d-b068-6a645dacc7ba', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('e2dfddd9-466e-592b-9c27-4f838fa68d5d', '16228203-ecfa-552d-b068-6a645dacc7ba', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0014b9f4-69bd-5be3-a45c-f20507cd3b6e', '16228203-ecfa-552d-b068-6a645dacc7ba', '56b6b1c3-175a-5993-b27f-4e2f434634d9', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('28bd444e-2be6-58ae-b5b6-71623bc23268', '16228203-ecfa-552d-b068-6a645dacc7ba', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('88bd659b-fd28-5bb3-a479-1f0ff8f60ff4', '16228203-ecfa-552d-b068-6a645dacc7ba', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('d9f707ba-4a51-56d1-9984-844cb59fe072', '16228203-ecfa-552d-b068-6a645dacc7ba', 'OPT1', 1, 1, 'ダンベル、フラットベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('16f7a442-bbce-50e5-a170-3d93872ac0d3', '16228203-ecfa-552d-b068-6a645dacc7ba', 'd9f707ba-4a51-56d1-9984-844cb59fe072', '6aa2bcdd-42e8-552e-9b49-38249d8a5f78', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('222b7135-9f44-52a2-b7e8-09dbca14922d', '16228203-ecfa-552d-b068-6a645dacc7ba', 'd9f707ba-4a51-56d1-9984-844cb59fe072', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('802817d0-3495-5238-865a-fd5313bc5801', '16228203-ecfa-552d-b068-6a645dacc7ba', 'd9f707ba-4a51-56d1-9984-844cb59fe072', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('cc3f5a86-c002-56cd-a2e6-9327605675cd', 'EX009', 'ペックデックフライ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '正面斜め');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('2d476fea-822a-5128-86f8-0e845d975300', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', '2cca493b-3f58-5100-a938-4c555dad4a18', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('901597e7-82ab-5694-9094-96d0c89f9a59', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'b11721fb-ef3c-5417-8d46-ce7c375b7ddd', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('7e0754f2-a230-5aa7-a8c1-9ada1a4e4f43', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('02f13ee8-874e-5f57-9977-a63ee7a2f8c1', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('2014bc56-eea5-51a3-947e-e421ac11d059', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', '56b6b1c3-175a-5993-b27f-4e2f434634d9', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('9886c7d9-3b13-5a4a-8034-9274f43e4308', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('573486ea-c39b-5b55-94cd-833737748f56', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('3d48e3a8-14e2-5d09-8ace-4802bda54e9b', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'OPT1', 1, 1, 'ペックデックマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('512e9daa-f5e2-5d0c-b3eb-a5bf00111ec5', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', '3d48e3a8-14e2-5d09-8ace-4802bda54e9b', 'b3adcfbb-0155-5887-b865-6e212116ec8e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('87e7212a-24cb-5424-8c54-44c43d7abcdd', 'EX010', 'ケーブルフライ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'MEDIUM', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('649d7b9c-91ca-55e2-a162-0eda00595215', '87e7212a-24cb-5424-8c54-44c43d7abcdd', '2cca493b-3f58-5100-a938-4c555dad4a18', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('d151e553-fb50-5dce-93d0-bdb2a3556530', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'b11721fb-ef3c-5417-8d46-ce7c375b7ddd', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('ef3e7479-f6a6-5c0f-8c2a-3d9c79a24fb8', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('19ac5476-71d6-53f5-9b47-fbbdf8d218f5', '87e7212a-24cb-5424-8c54-44c43d7abcdd', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('77b72ea3-00df-5445-b790-9e77b8f94b0e', '87e7212a-24cb-5424-8c54-44c43d7abcdd', '56b6b1c3-175a-5993-b27f-4e2f434634d9', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0ff73afc-9559-55f6-b2d9-f12966fd790a', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('71ed1e92-7e0e-5331-9430-ad09b3c0b126', '87e7212a-24cb-5424-8c54-44c43d7abcdd', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('dc303435-2fb9-5f9e-a1b2-254242fac22e', '87e7212a-24cb-5424-8c54-44c43d7abcdd', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('8c80bfc2-9b7a-5e04-b61b-7bda2d93558a', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'OPT1', 1, 1, 'ケーブルマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('17ddaaaa-cf22-5ede-b81b-b719a24b33dd', '87e7212a-24cb-5424-8c54-44c43d7abcdd', '8c80bfc2-9b7a-5e04-b61b-7bda2d93558a', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('03040c5e-0485-5937-b86e-c7472ec6d488', 'EX011', 'ラットプルダウン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('9ca99d89-b328-5146-9f11-dcf662c8dba1', '03040c5e-0485-5937-b86e-c7472ec6d488', '1d825dfc-f561-555a-aa40-d544f3181341', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('3008a308-844e-5b7e-9ea5-9e11709af731', '03040c5e-0485-5937-b86e-c7472ec6d488', '55667833-727f-5f17-9a78-ffaed7e95719', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('c130da80-20f8-5782-be8c-c6c11308d0f8', '03040c5e-0485-5937-b86e-c7472ec6d488', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('2f9b67a2-5f09-5c68-aac4-7b60f0943cb5', '03040c5e-0485-5937-b86e-c7472ec6d488', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('81e6da5e-c616-551a-b356-548e5cf6673f', '03040c5e-0485-5937-b86e-c7472ec6d488', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3e4e85ae-48df-5623-b6c9-4d10635d3ade', '03040c5e-0485-5937-b86e-c7472ec6d488', '6f8f2aac-3c91-5244-b579-8918e7390b5e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e9b64888-b406-50e4-ba65-a8dcb99884a0', '03040c5e-0485-5937-b86e-c7472ec6d488', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ffb1a874-044b-5798-970a-dafeb6c2d6ff', '03040c5e-0485-5937-b86e-c7472ec6d488', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('21207ad0-388e-539e-a9e6-ff33ad82788a', '03040c5e-0485-5937-b86e-c7472ec6d488', '9f1e0015-5378-5326-9639-4fc8556375b3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('34934cdb-e2ac-52d4-a58c-09c5806c8836', '03040c5e-0485-5937-b86e-c7472ec6d488', 'de57df8a-9b46-5c64-a036-de45ac8accd1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('c38f1aa6-9861-599c-83e4-a87ec1a10039', '03040c5e-0485-5937-b86e-c7472ec6d488', 'OPT1', 1, 1, 'ラットプルダウンマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('c5da1438-3a47-5180-9a32-25663e0e1699', '03040c5e-0485-5937-b86e-c7472ec6d488', 'c38f1aa6-9861-599c-83e4-a87ec1a10039', '19e707a1-e4ac-5b94-af46-0344f44dadd8', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('69163398-4c97-5cd9-aa6b-f24bf952f178', 'EX012', '懸垂', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'HIGH', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'REPS_LOADABLE', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('0b8b8d95-263e-550b-867c-562777448adb', '69163398-4c97-5cd9-aa6b-f24bf952f178', '1d825dfc-f561-555a-aa40-d544f3181341', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('b445ac32-ce40-5ef9-b2a4-cd45689546fd', '69163398-4c97-5cd9-aa6b-f24bf952f178', '55667833-727f-5f17-9a78-ffaed7e95719', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('c31af0d5-f978-5210-8874-d022fc9efab6', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('232e0cf6-8678-5c2c-8eac-bfd15a2a8350', '69163398-4c97-5cd9-aa6b-f24bf952f178', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('981e4985-be6d-5ead-b9de-4a574c7da8ee', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('bd0eb6b3-de48-53d7-b46a-338a96946a17', '69163398-4c97-5cd9-aa6b-f24bf952f178', '6f8f2aac-3c91-5244-b579-8918e7390b5e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c5f83140-49cb-5816-8ce2-273bb065d1c9', '69163398-4c97-5cd9-aa6b-f24bf952f178', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0d45f0f4-f996-562e-9681-3f13ef5c15f7', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('7ca572ec-bc32-5a80-80b3-43df7ebeccc3', '69163398-4c97-5cd9-aa6b-f24bf952f178', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('342154b3-0f24-5101-b576-a099ddb645ca', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'de57df8a-9b46-5c64-a036-de45ac8accd1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('b23cdaea-0701-5c80-b7da-70aae847ec7b', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'OPT1', 1, 1, '懸垂器具', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('2b93f9bc-705a-5bd2-8887-1a59ec09d61c', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'b23cdaea-0701-5c80-b7da-70aae847ec7b', '4ce67979-7939-5157-96d1-07f06333b953', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('7a560855-9753-561d-84cb-f821ade60469', 'EX013', 'アシスト懸垂', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + assistance_mode + machine_id/band_id', 'MEDIUM', 'MAJOR_INTRO', 'COMPOUND', 'BILATERAL_ARMS', 'ASSISTANCE_REVERSE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('0b33b275-88aa-5934-adae-13b005636424', '7a560855-9753-561d-84cb-f821ade60469', '1d825dfc-f561-555a-aa40-d544f3181341', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('7aba1db5-fd39-5066-84e1-c4594753e66f', '7a560855-9753-561d-84cb-f821ade60469', '55667833-727f-5f17-9a78-ffaed7e95719', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('e393bff8-3c6c-57d2-b850-dc9e41b3e0a3', '7a560855-9753-561d-84cb-f821ade60469', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('2582de8b-07ad-5968-b4ef-8f4b67743dbd', '7a560855-9753-561d-84cb-f821ade60469', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f1f59a62-91c0-58ec-b596-3a42faed0d2d', '7a560855-9753-561d-84cb-f821ade60469', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('a8b50357-71bd-5d01-8a44-6809e5ac4775', '7a560855-9753-561d-84cb-f821ade60469', '6f8f2aac-3c91-5244-b579-8918e7390b5e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('5f48bb7b-e651-5739-8386-139b412b28ff', '7a560855-9753-561d-84cb-f821ade60469', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3a9d140b-01c0-55e5-90f7-3b5fb959c1a2', '7a560855-9753-561d-84cb-f821ade60469', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('02122e14-42e7-57b9-aee6-e4cad9dc0c36', '7a560855-9753-561d-84cb-f821ade60469', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('7f74c21b-077b-5c58-a6a3-5a38042c2a4a', '7a560855-9753-561d-84cb-f821ade60469', 'de57df8a-9b46-5c64-a036-de45ac8accd1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('6338421f-f842-5d54-8443-cccdd904fee3', '7a560855-9753-561d-84cb-f821ade60469', 'OPT1', 1, 1, 'アシスト懸垂マシンまたはバンド、懸垂器具', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('db0c088e-c6db-527f-a78c-46f7fb5e8740', '7a560855-9753-561d-84cb-f821ade60469', '6338421f-f842-5d54-8443-cccdd904fee3', 'b62790f5-7f49-5597-9eb2-11e3ff41a7ed', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('d6665fa6-b552-5a62-8c74-511cc8e57f81', '7a560855-9753-561d-84cb-f821ade60469', '6338421f-f842-5d54-8443-cccdd904fee3', '4ce67979-7939-5157-96d1-07f06333b953', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('cadbe3ce-49a8-5241-99d3-b2ab90abfd84', '7a560855-9753-561d-84cb-f821ade60469', 'OPT2', 2, 1, 'アシスト懸垂マシンまたはバンド、懸垂器具', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('66232ce1-1114-5076-81cf-a1c1c9cfd503', '7a560855-9753-561d-84cb-f821ade60469', 'cadbe3ce-49a8-5241-99d3-b2ab90abfd84', 'bb437913-c962-52fd-9c7c-fa4a674b01a0', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('3458ec74-64ca-5ff3-b233-85ce1efcadc9', '7a560855-9753-561d-84cb-f821ade60469', 'cadbe3ce-49a8-5241-99d3-b2ab90abfd84', '4ce67979-7939-5157-96d1-07f06333b953', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('d816e412-b368-5a89-b993-e2490b242817', 'EX014', 'ワンハンドダンベルロウ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'MAJOR', 'COMPOUND', 'UNILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('84fe5312-bd91-52ec-9285-db246110b32b', 'd816e412-b368-5a89-b993-e2490b242817', '1d825dfc-f561-555a-aa40-d544f3181341', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('33b39965-efe1-521d-a603-47f110e02e2b', 'd816e412-b368-5a89-b993-e2490b242817', '61a06c0e-4b6a-5fbf-9ded-902a6a3abc3e', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('a05237a9-870c-5116-b5b5-ae36ad8cce11', 'd816e412-b368-5a89-b993-e2490b242817', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('3eda8532-f14b-51c7-81e0-46d081c51150', 'd816e412-b368-5a89-b993-e2490b242817', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('aca17772-d879-5679-8cd0-1f09d402ea47', 'd816e412-b368-5a89-b993-e2490b242817', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('1bfca5a3-b3b1-564b-a4ee-263f5b1e89b9', 'd816e412-b368-5a89-b993-e2490b242817', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('099d7fae-5454-523f-8dd7-4fcabacd7ae3', 'd816e412-b368-5a89-b993-e2490b242817', '6f8f2aac-3c91-5244-b579-8918e7390b5e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('5bf101dc-8de3-5cce-922c-b6be2e207350', 'd816e412-b368-5a89-b993-e2490b242817', 'de57df8a-9b46-5c64-a036-de45ac8accd1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('8cc3397b-cdb1-563e-9f33-22db2afab5aa', 'd816e412-b368-5a89-b993-e2490b242817', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('84edf0b0-b5f3-5a30-a8b0-5397017006f8', 'd816e412-b368-5a89-b993-e2490b242817', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('8d0d809c-fd11-5d5a-8576-7cd4270e6f91', 'd816e412-b368-5a89-b993-e2490b242817', '9f1e0015-5378-5326-9639-4fc8556375b3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('faf39309-9bfa-5191-afef-3c2a73458d1d', 'd816e412-b368-5a89-b993-e2490b242817', 'bd034c89-8fde-5539-b73c-feeea657d8b0', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('00513f65-8e1e-5c6f-bfe5-d9a12f92af46', 'd816e412-b368-5a89-b993-e2490b242817', 'OPT1', 1, 1, 'ダンベル、ベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('84e60355-b0af-5a16-9efd-47f32fe97b65', 'd816e412-b368-5a89-b993-e2490b242817', '00513f65-8e1e-5c6f-bfe5-d9a12f92af46', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('4f49b5ec-6fd7-557e-9ee6-8cc5fe0bfd6a', 'd816e412-b368-5a89-b993-e2490b242817', '00513f65-8e1e-5c6f-bfe5-d9a12f92af46', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('1007e08b-3351-536d-afe4-0bcce09aa6ce', 'EX015', 'ベントオーバーダンベルロウ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('99d2ef5f-400a-5050-b6b2-f201dfd855f0', '1007e08b-3351-536d-afe4-0bcce09aa6ce', '1d825dfc-f561-555a-aa40-d544f3181341', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('08d60001-2ec2-5d26-bac7-57bd2ed50385', '1007e08b-3351-536d-afe4-0bcce09aa6ce', '61a06c0e-4b6a-5fbf-9ded-902a6a3abc3e', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('2509896c-1406-573e-b92e-126f3994bb7d', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('fe78336e-b658-5392-bc1d-8e95114370bd', '1007e08b-3351-536d-afe4-0bcce09aa6ce', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('6652a3be-7791-5cde-813f-b6998364659e', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('6e1e69fa-9f11-5e2b-b656-1f1b59ea45e6', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('6133d300-3b75-5da5-b877-41fa4aaf758a', '1007e08b-3351-536d-afe4-0bcce09aa6ce', '6f8f2aac-3c91-5244-b579-8918e7390b5e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('9b175d35-e3d9-531f-a50c-ea09db8d858c', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'de57df8a-9b46-5c64-a036-de45ac8accd1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4606dbb9-4846-5ae2-a2da-355d05857635', '1007e08b-3351-536d-afe4-0bcce09aa6ce', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4fd21691-2f90-511b-99d9-3e7c48cdab75', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('52651310-cd82-571a-875b-cd9e5c302771', '1007e08b-3351-536d-afe4-0bcce09aa6ce', '9f1e0015-5378-5326-9639-4fc8556375b3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('a437c201-b15b-5bfa-a87f-1b022e5d0c15', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('323eb8b5-b5fa-53ec-a294-e9ca6eeebe89', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'OPT1', 1, 1, 'ダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('b6d608a4-3ee6-5878-9a78-c1f7b517a5bb', '1007e08b-3351-536d-afe4-0bcce09aa6ce', '323eb8b5-b5fa-53ec-a294-e9ca6eeebe89', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('5c937e70-019c-5278-be21-8b2ceef7454b', 'EX016', 'バーベルロウ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'HIGH', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('48b49e40-7f74-5676-936c-7f87e51fc5a5', '5c937e70-019c-5278-be21-8b2ceef7454b', '1d825dfc-f561-555a-aa40-d544f3181341', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('18a50431-3925-5f7f-beac-b5da6c0f0f4a', '5c937e70-019c-5278-be21-8b2ceef7454b', '61a06c0e-4b6a-5fbf-9ded-902a6a3abc3e', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('015efa71-82ec-5920-b5d8-e348620c7bbd', '5c937e70-019c-5278-be21-8b2ceef7454b', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('2478402f-81e4-55b4-9ba0-a81854f6740b', '5c937e70-019c-5278-be21-8b2ceef7454b', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('b22da860-103b-5b94-b6a6-014c5cd9d93f', '5c937e70-019c-5278-be21-8b2ceef7454b', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('3d320f10-e81f-59aa-9b68-4111a18a42f2', '5c937e70-019c-5278-be21-8b2ceef7454b', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e9f77453-d2f9-5893-a012-ae543128bc34', '5c937e70-019c-5278-be21-8b2ceef7454b', '6f8f2aac-3c91-5244-b579-8918e7390b5e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('012bbde6-c443-5de3-9c9e-185ed0d2e78e', '5c937e70-019c-5278-be21-8b2ceef7454b', 'de57df8a-9b46-5c64-a036-de45ac8accd1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('dcf01c48-284e-5692-9157-83d3af308550', '5c937e70-019c-5278-be21-8b2ceef7454b', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('132d8529-fb62-5bcf-b1ad-67f4978aa015', '5c937e70-019c-5278-be21-8b2ceef7454b', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4dc7d6c4-7371-5609-a424-57967a51db81', '5c937e70-019c-5278-be21-8b2ceef7454b', '9f1e0015-5378-5326-9639-4fc8556375b3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('68870e58-c6c3-5067-9ac8-0ac4b4a96154', '5c937e70-019c-5278-be21-8b2ceef7454b', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('6974dfb9-d65d-5b8b-873e-0f1dfe5dfcf7', '5c937e70-019c-5278-be21-8b2ceef7454b', 'OPT1', 1, 1, 'バーベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('d696cefb-6442-5c66-aa4a-b77501741e07', '5c937e70-019c-5278-be21-8b2ceef7454b', '6974dfb9-d65d-5b8b-873e-0f1dfe5dfcf7', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('d35fe9d2-2062-5865-a64a-99a7a4dd9555', 'EX017', 'シーテッドケーブルロウ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('061f8c65-6d19-5a73-acff-fee41631b647', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '1d825dfc-f561-555a-aa40-d544f3181341', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('98e567c6-8d42-52a4-97fc-48aa26edffda', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '61a06c0e-4b6a-5fbf-9ded-902a6a3abc3e', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f4be0555-06b4-59de-b265-83f5fe8c4acf', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('8094f29e-31e0-5258-8dd7-7165f87b0a11', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('50286ca9-4f39-5c5c-bdbe-f77f8225c107', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('8c3e0ee5-4f9d-5221-b75d-fba6ea147b97', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('9534ce0e-85e6-5299-9f8a-4e2cf29865af', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '6f8f2aac-3c91-5244-b579-8918e7390b5e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e73f5c05-413f-5c4e-8619-1f7baa2d0d66', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'de57df8a-9b46-5c64-a036-de45ac8accd1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('51108a62-9e08-5919-b0d5-edb8301e8ea4', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '83adbba0-4b1b-58d9-85c8-146b50e38786', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c351cc59-1a5e-5b45-8502-d589bf756472', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('080fcef8-5cc9-5285-bbdf-5bb3e8408153', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('cb622624-3c7d-51c8-a10b-bb17b54d3e3c', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '9f1e0015-5378-5326-9639-4fc8556375b3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('16991bcc-13e3-5d53-a13f-f914b16ef5fc', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'OPT1', 1, 1, 'ケーブルロウマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('cf93b27c-80d5-5274-a9b0-237bef1a9a20', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '16991bcc-13e3-5d53-a13f-f914b16ef5fc', '676aec99-428e-5271-81ea-bd7ea0fc4c7a', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('0fef9047-fefc-58ed-a78e-bae3af9f179b', 'EX018', 'チェストサポートロウ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'LOW', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'MULTI_MODE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('c87e0dd2-bcbe-569c-a368-50d1fca77d0e', '0fef9047-fefc-58ed-a78e-bae3af9f179b', '1d825dfc-f561-555a-aa40-d544f3181341', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('d00cea3c-bfe7-531a-b592-11f66dfb5867', '0fef9047-fefc-58ed-a78e-bae3af9f179b', '61a06c0e-4b6a-5fbf-9ded-902a6a3abc3e', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('1d859ed5-fb97-5b83-96d1-4267bfce8bc4', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f719a95a-0eaa-5060-83d7-d9812bfc5b6d', '0fef9047-fefc-58ed-a78e-bae3af9f179b', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('5b61f660-07bb-5f54-a3e3-5a7c3b27b8cb', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4171e58c-04ab-5b18-b32a-53ab923dd152', '0fef9047-fefc-58ed-a78e-bae3af9f179b', '6f8f2aac-3c91-5244-b579-8918e7390b5e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ecfef499-53c4-5f7e-811e-14aa2a539d58', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'de57df8a-9b46-5c64-a036-de45ac8accd1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('491f6c84-adb8-505e-95d3-7aba42d84518', '0fef9047-fefc-58ed-a78e-bae3af9f179b', '83adbba0-4b1b-58d9-85c8-146b50e38786', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4b421be6-09a5-5c5e-a532-8652709f23b0', '0fef9047-fefc-58ed-a78e-bae3af9f179b', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f6b167ea-3664-5a63-add6-b19e48ea4880', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('99660877-177a-562e-9078-5b8c13333155', '0fef9047-fefc-58ed-a78e-bae3af9f179b', '9f1e0015-5378-5326-9639-4fc8556375b3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('8434a72e-ac2f-5033-9b2f-2a4c0d5da826', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'OPT1', 1, 1, '胸当て付きロウマシン、またはダンベル＋角度調整ベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('0f2ee108-613a-5048-b681-3b156c7a827d', '0fef9047-fefc-58ed-a78e-bae3af9f179b', '8434a72e-ac2f-5033-9b2f-2a4c0d5da826', '3df15c8f-f9a4-56d9-8d9b-886d57305df6', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('a311121a-fa93-5c70-89b5-1bff436c4c83', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'OPT2', 2, 1, '胸当て付きロウマシン、またはダンベル＋角度調整ベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('8bced77f-bd43-542a-ae33-f0a0b907e7f1', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'a311121a-fa93-5c70-89b5-1bff436c4c83', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('10cc5b8b-189f-5bbc-8a4c-7f4e3a746223', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'a311121a-fa93-5c70-89b5-1bff436c4c83', 'af7565b6-26dc-534e-b1f6-ae9b5a887fa5', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 'EX019', 'ストレートアームプルダウン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'MEDIUM', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('1ccf98df-6865-5189-9916-6e3c479cb3cf', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', '1d825dfc-f561-555a-aa40-d544f3181341', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('83bb19a3-d215-5601-906a-d17e5d3ae42a', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', '04b24f98-95b2-5283-ade3-4d6201763da1', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f8681af6-a626-5c9e-aebf-fe3fb44ddf1b', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('2a46630e-48ff-5895-8afb-eb0397762a23', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('2296e8f5-fd61-5f80-8eb6-63cab27dcc7a', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('9449a24b-5a13-5f79-b306-30f8b78ea00b', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', '6f8f2aac-3c91-5244-b579-8918e7390b5e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0a8bed66-63a0-5c9b-a14a-f6100b3edccc', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 'f2c100d6-5ea4-5fd0-a12d-1c350be3f2ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('85f75a25-d3b8-5791-a24b-b24dd6703f1d', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 'e8e67542-58b2-5d96-aa1f-136ae73f9855', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('43690c7f-005d-54be-a7ed-605fb730a830', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('1ae9a49a-e7c7-534a-9271-2eb04b1a7a02', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 'OPT1', 1, 1, 'ケーブルマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('8f759bd7-7ed7-5c3f-909b-eec755ec78e1', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', '1ae9a49a-e7c7-534a-9271-2eb04b1a7a02', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('f6a68de0-bee5-5265-84e4-dea9acafae28', 'EX020', 'バックエクステンション', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'MEDIUM', 'ACCESSORY', 'HIP_AND_TRUNK_EXTENSION', 'BILATERAL', 'REPS_LOADABLE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('4415ee98-52f0-5c88-8f61-18aa2d2e0ff0', 'f6a68de0-bee5-5265-84e4-dea9acafae28', '1d825dfc-f561-555a-aa40-d544f3181341', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('08ea7ffe-59e0-548a-834f-1124574e714f', 'f6a68de0-bee5-5265-84e4-dea9acafae28', '94f12711-6f68-5ab3-b010-f5f1f38025c4', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('58c8789c-bb4f-5de0-a7b8-eb5a57f19156', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('326cadce-de0f-5acc-8d46-721071e36642', 'f6a68de0-bee5-5265-84e4-dea9acafae28', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('57da1e90-10cb-5178-82b1-8d02a3a1bb52', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('073d3998-bff8-52f9-bdab-bc5d0e811632', 'f6a68de0-bee5-5265-84e4-dea9acafae28', '00408f91-48f7-5a64-9f3e-00d889b5b9f0', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('be96ea77-a2e1-55ff-a01b-058d38a96074', 'f6a68de0-bee5-5265-84e4-dea9acafae28', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('7f5328c9-8a2d-551c-a74f-905f0ff7e337', 'f6a68de0-bee5-5265-84e4-dea9acafae28', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('ec8f226a-a7a0-510c-98ba-1eedf5358a19', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 'OPT1', 1, 1, 'バックエクステンション台', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('2036c2b2-23c1-5da5-8cfe-04481bda9dce', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 'ec8f226a-a7a0-510c-98ba-1eedf5358a19', '9caa0abc-d5a3-5adc-a1e3-ccd95e3dde5d', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('76a14709-f432-5773-91fe-2ecd9bf0539e', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 'ec8f226a-a7a0-510c-98ba-1eedf5358a19', 'fc143718-6810-5509-bce4-8346c4db8715', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'EX021', 'ダンベルショルダープレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('4e933e5e-83a8-5ef3-bee2-70d75172e6dc', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('5c07cd22-3105-5764-8805-a01953232cd0', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', '8f5e9d68-8498-568d-80c6-7e34b2cf83b3', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('c7c3445d-92be-5981-ab69-51aa8fd43d92', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('9dc2388e-b193-5500-becb-b545b1e3d6ba', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('a2d597ee-6b82-5f51-8ac5-587010ec1d92', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('d62a12e4-cb72-538b-8ccb-00a3ca1a2e16', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('a0207131-0c90-5d9c-aecc-92ced3eec5a0', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4844b0ae-8fb1-58cd-a004-4f1ea9d0f8b2', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'a0e84e6c-eec6-536c-9b3c-0780eda119d1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('8dd8b026-13b6-5988-a759-32b2702300ed', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('595b9e19-9fd6-5097-95bc-775f2fbb6c98', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3b075b98-da80-5c23-ad5e-304d98b210b3', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('80d7b785-d851-5032-9be9-7f0b9c9b1e98', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'OPT1', 1, 1, 'ダンベル。任意で背もたれ付きベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('3dada0b8-869a-5f9a-a776-a89828740f0a', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', '80d7b785-d851-5032-9be9-7f0b9c9b1e98', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('cd42319a-c019-5368-9135-d14c0c904c32', 'EX022', 'マシンショルダープレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'MAJOR', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('23c72264-f49e-5f9c-87a5-aed51d7feb17', 'cd42319a-c019-5368-9135-d14c0c904c32', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('0764b253-be53-5f1a-b6d8-5f2971f33746', 'cd42319a-c019-5368-9135-d14c0c904c32', '8f5e9d68-8498-568d-80c6-7e34b2cf83b3', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('76f4296d-390f-58d7-83d3-4a77cc72ce56', 'cd42319a-c019-5368-9135-d14c0c904c32', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('a71ec241-2515-5680-8d9a-6b1ae235624f', 'cd42319a-c019-5368-9135-d14c0c904c32', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f7f4e7fa-81cf-5ad4-a2cd-ff09cd193994', 'cd42319a-c019-5368-9135-d14c0c904c32', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('69ee28b1-85df-5377-b1e4-1e5b8e2f2d6f', 'cd42319a-c019-5368-9135-d14c0c904c32', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0fd3cc14-92eb-5a6b-94a4-ef9511da4889', 'cd42319a-c019-5368-9135-d14c0c904c32', 'a0e84e6c-eec6-536c-9b3c-0780eda119d1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f07567a1-5484-5b12-b953-47632248d145', 'cd42319a-c019-5368-9135-d14c0c904c32', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('539cb55c-a294-5095-95c3-4c2e51f0ab29', 'cd42319a-c019-5368-9135-d14c0c904c32', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('a811951d-f9a6-5bde-95bc-6e9c25c09485', 'cd42319a-c019-5368-9135-d14c0c904c32', 'OPT1', 1, 1, 'ショルダープレスマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('4fa3e872-4358-5d0e-b407-bf807d2ba592', 'cd42319a-c019-5368-9135-d14c0c904c32', 'a811951d-f9a6-5bde-95bc-6e9c25c09485', '66df84ab-4761-5258-89d0-8f1b0f8f2e0a', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('8026feac-450b-5ab4-8641-8425d74be75f', 'EX023', 'ランドマインプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'MAJOR_ALTERNATIVE', 'COMPOUND', 'UNILATERAL_OR_BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('d12f466e-b151-5a66-9f31-a3b13bbe934a', '8026feac-450b-5ab4-8641-8425d74be75f', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('80e1fa7c-3ebe-5fac-9c8c-dec5cd7e1d90', '8026feac-450b-5ab4-8641-8425d74be75f', '00c6bae4-492a-5ca2-931b-542a81222943', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('c5707484-ecd4-5a33-8aaa-c3693364fe9d', '8026feac-450b-5ab4-8641-8425d74be75f', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('74f1b0cc-d576-5480-9f69-23c7f29fde7d', '8026feac-450b-5ab4-8641-8425d74be75f', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('eb04dc87-31d2-5f65-802a-52ef0e8fce10', '8026feac-450b-5ab4-8641-8425d74be75f', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('560c17ad-cd8c-527b-ac94-8e87c8557050', '8026feac-450b-5ab4-8641-8425d74be75f', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('54cced9c-d69c-5091-9ca3-78030eff79ff', '8026feac-450b-5ab4-8641-8425d74be75f', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('fb05def0-12ad-589a-8d0a-1cdf3dd466c7', '8026feac-450b-5ab4-8641-8425d74be75f', 'a0e84e6c-eec6-536c-9b3c-0780eda119d1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('80bf9b1c-d565-585d-ba0d-d194e1186c8d', '8026feac-450b-5ab4-8641-8425d74be75f', '31cb3393-17f8-51da-9aae-5a27b8302e1d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('a08a0f8a-34d8-53a6-8b98-69f6a3009ac9', '8026feac-450b-5ab4-8641-8425d74be75f', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('15d1d668-f7a5-5634-a66a-26318439ccc2', '8026feac-450b-5ab4-8641-8425d74be75f', 'bd034c89-8fde-5539-b73c-feeea657d8b0', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('27eee8fa-6b30-562b-b70c-a40ec7423f57', '8026feac-450b-5ab4-8641-8425d74be75f', 'OPT1', 1, 1, 'バーベル、ランドマインアタッチメントまたは安全な固定設備', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('d8040437-0b14-5798-ad6e-76f5283f7c01', '8026feac-450b-5ab4-8641-8425d74be75f', '27eee8fa-6b30-562b-b70c-a40ec7423f57', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('b1939d85-6584-5db1-b197-034cadb42018', '8026feac-450b-5ab4-8641-8425d74be75f', '27eee8fa-6b30-562b-b70c-a40ec7423f57', '404aaddc-dfce-54bc-922e-54ccc919890d', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('32dd508d-a1d2-5f63-b10d-238137722396', '8026feac-450b-5ab4-8641-8425d74be75f', 'OPT2', 2, 1, 'バーベル、ランドマインアタッチメントまたは安全な固定設備', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('455d66c4-6f8c-51cf-a3a1-c80234b0ed46', '8026feac-450b-5ab4-8641-8425d74be75f', '32dd508d-a1d2-5f63-b10d-238137722396', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('d0747be2-6105-500e-8c1e-b7d66606e72c', '8026feac-450b-5ab4-8641-8425d74be75f', '32dd508d-a1d2-5f63-b10d-238137722396', 'c3909799-b948-5826-8736-f729d5ebd90e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('ef47c102-303b-5969-b341-b4ab6cb5e7a6', 'EX024', 'ダンベルサイドレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('3a76449b-ca7a-5583-a7d1-d08683980a20', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('6ae30af3-d18f-5e08-bc72-aeb5fdefb471', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', '625454c7-efcc-5cb1-a523-da01a7b3a143', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('88e7ab00-48e3-5682-adf0-2402f04cc32e', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('aa46831b-7800-52fe-a1f6-ec021567eb51', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f2796980-3e5e-52b8-ba28-fe09fe11f9e3', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', 'a0e84e6c-eec6-536c-9b3c-0780eda119d1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('60bbb046-ac3e-5f3c-a372-f670e59e649d', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', '810521fc-1bac-5fd0-8ead-0cd87d8f0ae4', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('39d79068-6191-5e07-9e94-3f93d7c4b106', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('260072c2-488f-5ad8-ac04-0ae0bd4f5cf4', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', 'OPT1', 1, 1, 'ダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('372e4299-9f61-5408-810a-117264951910', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', '260072c2-488f-5ad8-ac04-0ae0bd4f5cf4', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('86ea1464-f372-502e-8bdd-f94953732cb4', 'EX025', 'ケーブルサイドレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'MEDIUM', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'UNILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('8fd73fb8-3512-5134-83cb-fe4e916d4eaa', '86ea1464-f372-502e-8bdd-f94953732cb4', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('490778d8-02ee-51dc-b1e0-93ab2e5a3900', '86ea1464-f372-502e-8bdd-f94953732cb4', '625454c7-efcc-5cb1-a523-da01a7b3a143', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('22f6726f-2112-5980-8f9b-f33a9ba60af8', '86ea1464-f372-502e-8bdd-f94953732cb4', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('0e09e672-af7b-5acd-bf1c-8568127bc88d', '86ea1464-f372-502e-8bdd-f94953732cb4', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('9d118960-fef8-5031-be2b-80bbfeb05cdc', '86ea1464-f372-502e-8bdd-f94953732cb4', 'a0e84e6c-eec6-536c-9b3c-0780eda119d1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('a918323f-7872-5637-a250-25060c600144', '86ea1464-f372-502e-8bdd-f94953732cb4', '810521fc-1bac-5fd0-8ead-0cd87d8f0ae4', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ebc8c3db-641a-5b0c-a7b9-1ef1076ba8e8', '86ea1464-f372-502e-8bdd-f94953732cb4', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('760c0f4e-13c1-5a26-8731-01b217961a27', '86ea1464-f372-502e-8bdd-f94953732cb4', 'OPT1', 1, 1, 'ケーブルマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('11b0259e-7f01-5a39-ae64-989c1f61a474', '86ea1464-f372-502e-8bdd-f94953732cb4', '760c0f4e-13c1-5a26-8731-01b217961a27', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('2346c3e0-d974-5556-a484-b3528dcde3ca', 'EX026', 'フロントレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'LOW', 'ACCESSORY', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_ARMS', 'MULTI_MODE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('2bb3f0a0-afc3-589c-a9b6-fd633da7d2f9', '2346c3e0-d974-5556-a484-b3528dcde3ca', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('45733399-2d13-5db5-a976-9869b31e381f', '2346c3e0-d974-5556-a484-b3528dcde3ca', '3642b372-c5c2-5e1a-a2e1-c32a1617d4c0', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('32634599-1461-50f2-b436-e64e58d332c4', '2346c3e0-d974-5556-a484-b3528dcde3ca', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('3c03e086-6a27-5e01-8d04-2764d2772dcb', '2346c3e0-d974-5556-a484-b3528dcde3ca', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('ac9ab114-2d84-5ed3-8fc7-774d2d36ff02', '2346c3e0-d974-5556-a484-b3528dcde3ca', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('33a2a29b-d2d1-5fe3-9717-ca6479162460', '2346c3e0-d974-5556-a484-b3528dcde3ca', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('5143562a-44f9-5c54-8270-5be9a28d4103', '2346c3e0-d974-5556-a484-b3528dcde3ca', '31cb3393-17f8-51da-9aae-5a27b8302e1d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('860eb680-8eed-54cf-a10a-a1417e146a7b', '2346c3e0-d974-5556-a484-b3528dcde3ca', '810521fc-1bac-5fd0-8ead-0cd87d8f0ae4', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('47ffb0b8-f8e6-592e-842e-b2884b061fff', '2346c3e0-d974-5556-a484-b3528dcde3ca', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('c5b79a16-ba0b-567b-9b03-abfd2f006485', '2346c3e0-d974-5556-a484-b3528dcde3ca', 'OPT1', 1, 1, 'ダンベルまたはプレート', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('3d534a30-c989-5812-9bac-89e11928ef7b', '2346c3e0-d974-5556-a484-b3528dcde3ca', 'c5b79a16-ba0b-567b-9b03-abfd2f006485', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('83f782c3-84e8-5c7e-aead-9b756d0c5e7f', '2346c3e0-d974-5556-a484-b3528dcde3ca', 'OPT2', 2, 1, 'ダンベルまたはプレート', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('40756bfe-75c7-5a57-9353-56c69de70e10', '2346c3e0-d974-5556-a484-b3528dcde3ca', '83f782c3-84e8-5c7e-aead-9b756d0c5e7f', '1d9b73ea-aca4-5ef8-b84c-ab997706e8a0', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'EX027', 'ベントオーバーリアレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め後ろ');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('d487bfe5-9c28-56e4-99ec-4b3f913dbce7', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('ca958c8d-272d-5cc0-beaa-ab654356d485', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', '95283fd3-86d9-54f4-9eb1-9e4984a563cb', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('5ad6187c-4251-5edf-b995-5aaa7f7009a5', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('ec603960-b444-5f72-ac20-6daf8f5185de', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('ab014677-f0a8-5e2d-accc-b4b2ac34f794', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3fce6824-0ab4-5e9d-88f9-0f73c5f3b379', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', '9f1e0015-5378-5326-9639-4fc8556375b3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('34c40248-7bad-5837-9561-d96d9a905439', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'a8e76a29-7c57-5875-8a30-1cf4d2770800', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f3797d3d-ec7d-513e-9745-af6c9a1cef8a', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', '83adbba0-4b1b-58d9-85c8-146b50e38786', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('318d8202-9a37-59c3-ac90-c1cab9736e0a', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('6aa2013b-53be-5ae2-bd1b-eed7183dd89e', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'OPT1', 1, 1, 'ダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('2856f953-c467-530a-9514-d322d6fa87b1', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', '6aa2013b-53be-5ae2-bd1b-eed7183dd89e', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('22fd1467-a582-5642-b51f-5a32ed150885', 'EX028', 'リバースペックデック', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め後ろ');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('f588b6bc-cc83-5a2c-9d87-c42b5c59fd46', '22fd1467-a582-5642-b51f-5a32ed150885', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('e880415e-2691-5389-82a9-da2f25104310', '22fd1467-a582-5642-b51f-5a32ed150885', '95283fd3-86d9-54f4-9eb1-9e4984a563cb', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('8e9a16b1-35bf-5d57-ae60-f037b272dfff', '22fd1467-a582-5642-b51f-5a32ed150885', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('16e82382-1b48-5358-9160-e62524716a3f', '22fd1467-a582-5642-b51f-5a32ed150885', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c49e0448-3ffd-5b9c-850f-a173a86ed80d', '22fd1467-a582-5642-b51f-5a32ed150885', '9f1e0015-5378-5326-9639-4fc8556375b3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4af3cc6d-6bc9-587d-be5e-6c1587c9fae3', '22fd1467-a582-5642-b51f-5a32ed150885', 'a8e76a29-7c57-5875-8a30-1cf4d2770800', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f4340933-74a5-53ea-92af-64e30ca665e6', '22fd1467-a582-5642-b51f-5a32ed150885', '83adbba0-4b1b-58d9-85c8-146b50e38786', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('82d868cc-89e4-5c07-a38c-dcf83e4c8cdd', '22fd1467-a582-5642-b51f-5a32ed150885', 'OPT1', 1, 1, 'リバースペックデックマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('cc23f789-8467-5531-af93-e534ea4a4ffe', '22fd1467-a582-5642-b51f-5a32ed150885', '82d868cc-89e4-5c07-a38c-dcf83e4c8cdd', 'a9ab118e-fd6c-515a-a0dd-e88ab2370c47', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('5a78703e-4ac7-5276-a608-dfbdb3cf04ab', '22fd1467-a582-5642-b51f-5a32ed150885', '82d868cc-89e4-5c07-a38c-dcf83e4c8cdd', 'b3adcfbb-0155-5887-b865-6e212116ec8e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'EX029', 'フェイスプル', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'MEDIUM', 'ACCESSORY_SHOULDER_STABILITY', 'SHOULDER_EXTERNAL_ROTATION_HORIZONTAL_ABDUCTION', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('c8642c05-18f9-5454-958c-ec4ac432adb6', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('3a636f65-ae80-57a9-a7d6-d015263cbe2c', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', '8ab974bf-455d-57b7-9f16-f6db59dead5c', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('4bf9df50-cf70-5a59-8eed-78cc17e8b5a1', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('a0123dc1-4b32-59df-8dbf-e1f468061edc', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('d57e800b-87f9-539e-85b8-ecfa7c9cb56c', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', '9f1e0015-5378-5326-9639-4fc8556375b3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('45e54a7a-634f-555e-9654-79b9db231c21', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'a8e76a29-7c57-5875-8a30-1cf4d2770800', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('19381a21-45be-53a7-b899-8c9f2c48934e', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', '83adbba0-4b1b-58d9-85c8-146b50e38786', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('cd7d2cbe-0bb3-53a7-853c-aace807a0bef', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('d0f618cd-fcbf-5a61-b7a4-e27f909af10d', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('cf63a574-9564-5e27-90f4-80ed49fd1317', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'OPT1', 1, 1, 'ケーブルマシン、ロープアタッチメント', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('cfb0c862-b7d9-594c-ba91-6f053acea7f0', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'cf63a574-9564-5e27-90f4-80ed49fd1317', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('6fc759b2-70fd-5508-b3d3-5a3ba112bc9e', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'cf63a574-9564-5e27-90f4-80ed49fd1317', '6173e25b-e304-597e-af87-231718b056b5', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'EX030', 'アーノルドプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'HIGH', 'MAJOR_OPTION', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('47b01aa4-d2db-5e5c-bb11-4ceead05cdcc', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('f58d19cb-8650-58db-a4b1-b9ef9f4807c1', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'ab10e639-72e2-51a6-82fe-ff721b208e70', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('6e632f04-d8a6-52f5-ae7c-802a9a2c1aaa', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('6893d2f7-2224-5152-8468-b2f716002db1', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('6748219c-02d7-55f9-843d-99cec5d321a9', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('a4317f50-2eaf-5610-ac56-5be3152caf61', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('fa06c74b-0e2a-539d-a7f6-8feca1e37bb0', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('705067cf-6a1f-5e80-9948-0a0853711060', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'a0e84e6c-eec6-536c-9b3c-0780eda119d1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('b7a1ceb3-4eac-51ac-8639-88f7672fa3b9', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('55f53126-511b-59c7-9862-89e5e4f6f9da', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('dfc21c32-5bbf-5552-87ec-cb2f5a548b4a', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('10a372d0-cd0e-594e-b90b-51a25a14e645', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'OPT1', 1, 1, 'ダンベル、任意で背もたれ付きベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('155b1b3e-e692-5f82-881c-99a72360e7bd', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', '10a372d0-cd0e-594e-b90b-51a25a14e645', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('da7d770b-d85e-5460-9068-c39bcc546503', 'EX031', 'ダンベルカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('dfa07806-fd38-5519-80a2-342a2d0eaf89', 'da7d770b-d85e-5460-9068-c39bcc546503', 'b8443d14-b195-556a-bef7-b810e2476377', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('f36a760e-060b-5a35-a751-310958a9a8d4', 'da7d770b-d85e-5460-9068-c39bcc546503', '00d68707-bd4e-5d31-9c2e-be8530df2720', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('d7e30996-63fa-50b5-b899-49f1317354e4', 'da7d770b-d85e-5460-9068-c39bcc546503', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('3fd692b2-81f2-533e-930b-422aff6b9d0e', 'da7d770b-d85e-5460-9068-c39bcc546503', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ed6ebea1-8c04-530c-a882-731114e1fcc9', 'da7d770b-d85e-5460-9068-c39bcc546503', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4604b86f-2513-5f31-892f-54a1ce4523bf', 'da7d770b-d85e-5460-9068-c39bcc546503', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('736e7c36-d469-55a0-8d10-c4fbc3511abf', 'da7d770b-d85e-5460-9068-c39bcc546503', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('cb56b27c-2a00-5b9a-942d-342c4a1d0954', 'da7d770b-d85e-5460-9068-c39bcc546503', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('1cee1ade-7c62-501b-b009-69ae167b23df', 'da7d770b-d85e-5460-9068-c39bcc546503', 'OPT1', 1, 1, 'ダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('adbdf682-9b22-5bd9-91f7-d69b638feb14', 'da7d770b-d85e-5460-9068-c39bcc546503', '1cee1ade-7c62-501b-b009-69ae167b23df', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('731ac79c-b789-5809-bd32-486d0f7c9c28', 'EX032', 'ハンマーカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('5e754c1a-597e-51b6-b8d2-214ac6019e8c', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'b8443d14-b195-556a-bef7-b810e2476377', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('196b49ba-cc0f-5819-92e8-43699db3f716', '731ac79c-b789-5809-bd32-486d0f7c9c28', '00d68707-bd4e-5d31-9c2e-be8530df2720', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('83c02589-b06f-5a6c-bb0d-886aa3772e3d', '731ac79c-b789-5809-bd32-486d0f7c9c28', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('10146512-ea53-5227-8d54-6f4b9a53469c', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ed29767a-5ac8-5f6d-92b8-c7d07e2fac74', '731ac79c-b789-5809-bd32-486d0f7c9c28', '7e4d2a72-a147-59f4-aa6c-d7b0a248e40b', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ad0654ef-aebd-5882-951f-7fbef90d12b0', '731ac79c-b789-5809-bd32-486d0f7c9c28', '8127307a-b647-5242-856f-33e845c480dc', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('cd1569f0-bf53-5b0e-82d1-32a482edd6bc', '731ac79c-b789-5809-bd32-486d0f7c9c28', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('392b35c6-b0d0-53d3-9803-756194aeda2a', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('91e26586-298b-5fa1-9f0d-b53b0882bef2', '731ac79c-b789-5809-bd32-486d0f7c9c28', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('537321b1-3ed5-5e94-8227-2c1ed87163fd', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'OPT1', 1, 1, 'ダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('55f49a34-86c4-58fb-b8bd-88af1fbe289e', '731ac79c-b789-5809-bd32-486d0f7c9c28', '537321b1-3ed5-5e94-8227-2c1ed87163fd', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 'EX033', 'インクラインダンベルカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'ACCESSORY', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_ARMS', 'WEIGHT_REPS', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('dc36b514-3e78-5d5d-8da2-783f783f4413', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 'b8443d14-b195-556a-bef7-b810e2476377', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('320eb6a1-a8e1-50f0-9ae5-07524adabe74', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', '00d68707-bd4e-5d31-9c2e-be8530df2720', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('6f6e6ab2-04f5-50c7-8cb3-d8917f1fabb0', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('a3908278-fc7e-53bb-bb56-237de8f4616f', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('1efc7816-1dd1-55a4-b1a7-5286eac83f4c', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('98f582f3-db5c-548d-8ecd-17e8c232d329', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ee779ef6-d0ac-5158-930a-60b1fca70e93', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('1e530574-c4b9-5770-955b-1f00695db210', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 'OPT1', 1, 1, 'ダンベル、角度調整ベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('032ad7d2-7399-5c0a-9222-c9e0d7d50522', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', '1e530574-c4b9-5770-955b-1f00695db210', 'af7565b6-26dc-534e-b1f6-ae9b5a887fa5', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('d523e797-0fe5-551f-93ad-5d001ce97745', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', '1e530574-c4b9-5770-955b-1f00695db210', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('bed2c0c1-a2e0-5a53-a5e2-35f96058648c', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', '1e530574-c4b9-5770-955b-1f00695db210', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('8ed32064-eb89-590b-ad11-85cdfbb15794', 'EX034', 'プリーチャーカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'MEDIUM', 'ACCESSORY', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_ARMS', 'MULTI_MODE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('26b5d892-07c7-52f5-b7e5-e552494d1392', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'b8443d14-b195-556a-bef7-b810e2476377', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('38d72a3d-3e2b-56a5-bc57-99ed98762391', '8ed32064-eb89-590b-ad11-85cdfbb15794', '00d68707-bd4e-5d31-9c2e-be8530df2720', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('bdc99deb-2664-593a-a141-bccc3fdfd6b0', '8ed32064-eb89-590b-ad11-85cdfbb15794', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('427c94e0-c231-509f-bb18-e8b03009a27e', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0d713329-92ca-579c-9170-6805e05db487', '8ed32064-eb89-590b-ad11-85cdfbb15794', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3793e1c6-ec34-51fc-a460-c46d55289f96', '8ed32064-eb89-590b-ad11-85cdfbb15794', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('552f4200-d558-5f1e-b301-b657a39d9bce', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('ceee7c95-331a-5323-8625-d097ad389cdb', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'OPT1', 1, 1, 'プリーチャー台、EZバーまたはダンベル／マシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('ef1aabfa-b9cc-50c3-a33c-5bb74a70bf0c', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'ceee7c95-331a-5323-8625-d097ad389cdb', 'bd1363fe-7cb6-53c5-ba22-13c590a0ea3b', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('0bc506aa-cf88-5cb6-9f7b-0342aa6f14e2', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'ceee7c95-331a-5323-8625-d097ad389cdb', '170c3d51-3265-5cec-8432-9bcfc8c7c9a6', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('f40873ca-3199-5fac-941d-32c6280c5675', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'OPT2', 2, 1, 'プリーチャー台、EZバーまたはダンベル／マシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('491b0ae6-28a5-5818-b0af-5bc3e5b6d628', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'f40873ca-3199-5fac-941d-32c6280c5675', 'bd1363fe-7cb6-53c5-ba22-13c590a0ea3b', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('df980424-db97-57c3-a8f8-8ba85b469e38', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'f40873ca-3199-5fac-941d-32c6280c5675', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('181a56dd-e6a4-5b2b-8216-75216cbb6a4d', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'OPT3', 3, 1, 'プリーチャー台、EZバーまたはダンベル／マシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('9291d1c2-3b0f-5936-865b-a280fef72cd5', '8ed32064-eb89-590b-ad11-85cdfbb15794', '181a56dd-e6a4-5b2b-8216-75216cbb6a4d', 'e5d45659-a476-5264-ba03-b06726d9bf33', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'EX035', 'リバースカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'MEDIUM', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'MULTI_MODE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('f22e2aaa-f057-528c-b628-11e2dd5f1b2a', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'b8443d14-b195-556a-bef7-b810e2476377', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('71057a49-9b02-5090-8a48-ea79a20f6b75', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', '00d68707-bd4e-5d31-9c2e-be8530df2720', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('98aec229-cde5-524b-9283-264b86a7c9d0', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('5ea14307-cbc5-5bc0-899f-9790b0442d74', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c3099572-17ea-5a35-8f1f-ca2ca7dae662', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', '8127307a-b647-5242-856f-33e845c480dc', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c3ab0470-747c-592d-b4a8-dd40e773eb96', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', '8d5bdeeb-edd5-5eaf-b043-a2dbe14e0518', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('77d99d1b-83f0-5346-acf2-8eb1d77e30c6', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', '0fb9393b-988d-563d-8550-892e9af92b93', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('01daaebc-1e8d-526f-9377-f242dddd0e5a', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f4d60635-4bbe-5a03-aab3-82cbc0838adb', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('bc3443e8-cb45-586e-9f7d-a615c20ccfdb', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'OPT1', 1, 1, 'EZバー、バーベルまたはダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('841a2bdb-4971-5130-b530-a0e5f37b3c20', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'bc3443e8-cb45-586e-9f7d-a615c20ccfdb', '170c3d51-3265-5cec-8432-9bcfc8c7c9a6', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('620e3d48-c258-5dc8-a5a1-252966af33df', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'OPT2', 2, 1, 'EZバー、バーベルまたはダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('bd8b6091-62db-5586-9549-4751d950f118', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', '620e3d48-c258-5dc8-a5a1-252966af33df', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('8cab0db3-2ace-54d1-ad8d-c37ebba67abf', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'OPT3', 3, 1, 'EZバー、バーベルまたはダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('9cefa02b-e71e-5773-933b-f15dacba59dd', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', '8cab0db3-2ace-54d1-ad8d-c37ebba67abf', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('792c2199-002e-5d63-b182-f3b6c645382d', 'EX036', 'ケーブルトライセプスプッシュダウン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('8a1ec3e4-ce39-5594-be92-8f373881114d', '792c2199-002e-5d63-b182-f3b6c645382d', 'b8443d14-b195-556a-bef7-b810e2476377', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('9302984e-4c9f-5804-bfae-5907c2bda8f7', '792c2199-002e-5d63-b182-f3b6c645382d', 'c443643d-930f-50ca-9d14-bbb08d773d38', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('373575a3-aa75-51c1-9df9-1ea4e693e8de', '792c2199-002e-5d63-b182-f3b6c645382d', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f25e4e1a-d4e1-5dc8-823a-3b5a382553a1', '792c2199-002e-5d63-b182-f3b6c645382d', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('535f9dd3-92a0-5660-af34-b668c10f0952', '792c2199-002e-5d63-b182-f3b6c645382d', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('47e3de4c-6d4b-53a7-8ae8-0b66489f26dd', '792c2199-002e-5d63-b182-f3b6c645382d', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0b0d38cc-de08-586d-8b36-184738c1e6c8', '792c2199-002e-5d63-b182-f3b6c645382d', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('be6fa279-115e-59a2-b9aa-56dc3ceb8db2', '792c2199-002e-5d63-b182-f3b6c645382d', 'OPT1', 1, 1, 'ケーブルマシン、バーまたはロープ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('303686f3-3a7b-5fa9-bd76-92d4fee79dca', '792c2199-002e-5d63-b182-f3b6c645382d', 'be6fa279-115e-59a2-b9aa-56dc3ceb8db2', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('92c5a351-bef7-519f-a6dc-19f181b99f6a', '792c2199-002e-5d63-b182-f3b6c645382d', 'be6fa279-115e-59a2-b9aa-56dc3ceb8db2', '58800793-32bd-5935-bff9-05f8d476d9c6', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('b0d8ca44-9a21-5ef0-a1fb-eceaead838b0', '792c2199-002e-5d63-b182-f3b6c645382d', 'OPT2', 2, 1, 'ケーブルマシン、バーまたはロープ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('273f8fd3-a763-5c20-85b2-303bcb45b563', '792c2199-002e-5d63-b182-f3b6c645382d', 'b0d8ca44-9a21-5ef0-a1fb-eceaead838b0', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('02329d15-54b3-5f26-890e-9c4192438cdc', '792c2199-002e-5d63-b182-f3b6c645382d', 'b0d8ca44-9a21-5ef0-a1fb-eceaead838b0', '6173e25b-e304-597e-af87-231718b056b5', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('6c86e230-f576-5e6e-a316-36ff2c7546bf', 'EX037', 'オーバーヘッドトライセプスエクステンション', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'MEDIUM', 'ACCESSORY', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_ARMS', 'MULTI_MODE', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('8c3d393d-e0ec-5385-aa84-8c65946bc287', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'b8443d14-b195-556a-bef7-b810e2476377', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('7c840d4f-9727-5303-97db-bccda218f7f3', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'c443643d-930f-50ca-9d14-bbb08d773d38', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('ec849633-232d-5eb0-9c92-b99a9cdc0014', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('332ee556-aa0f-5a69-a207-780495cc3efb', '6c86e230-f576-5e6e-a316-36ff2c7546bf', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('5f6f6ca2-9657-5477-a022-dce28b2e4fdd', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('4ba50669-9a5e-53b0-bf89-4e8085740906', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('672ebe0d-4afe-5885-bf7a-3fc9938b6091', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'e8e67542-58b2-5d96-aa1f-136ae73f9855', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('2cbd8abe-df11-56b6-9de8-23fc587a5b35', '6c86e230-f576-5e6e-a316-36ff2c7546bf', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e93b2207-3f6e-567a-9a74-5b5ccd003f29', '6c86e230-f576-5e6e-a316-36ff2c7546bf', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('c83faeb3-6aba-5ae9-a883-e4ff78ea642b', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'OPT1', 1, 1, 'ダンベルまたはケーブル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('7813f549-0006-53cd-bb27-9d4518a1fea9', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'c83faeb3-6aba-5ae9-a883-e4ff78ea642b', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('f8615f58-decc-54f6-9b56-70f2979f806e', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'OPT2', 2, 1, 'ダンベルまたはケーブル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('e75e7209-b780-5093-ad0e-d1f37812fc46', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'f8615f58-decc-54f6-9b56-70f2979f806e', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('f826ab1d-6750-5f56-b4be-938133f0222b', 'EX038', 'ライイングトライセプスエクステンション', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'HIGH', 'ACCESSORY', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'MULTI_MODE', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('aced8440-2cab-5f4c-96ee-fb6d73d4670f', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'b8443d14-b195-556a-bef7-b810e2476377', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('1c558acb-6c25-5e1b-bf8f-1e0e728e73f9', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'c443643d-930f-50ca-9d14-bbb08d773d38', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('7bdb0005-e737-50b2-b4c4-8a45e4957ce0', 'f826ab1d-6750-5f56-b4be-938133f0222b', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('15a1caa3-cb28-51b7-a349-331fa3812ff5', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('ccb31551-4606-5d0e-984c-febe3626696c', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('de152674-54f4-56b7-b10c-6aaf5d0440f8', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('8752d21c-7584-5069-a73c-1814462353ad', 'f826ab1d-6750-5f56-b4be-938133f0222b', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('a318b2be-e014-51d2-82b4-b2e6c91a9645', 'f826ab1d-6750-5f56-b4be-938133f0222b', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('3d3977a9-97ea-5ce3-bce8-ea3eb9557dae', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'OPT1', 1, 1, 'EZバーまたはダンベル、ベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('084c0897-9167-5696-9126-fa4b49e807fa', 'f826ab1d-6750-5f56-b4be-938133f0222b', '3d3977a9-97ea-5ce3-bce8-ea3eb9557dae', '170c3d51-3265-5cec-8432-9bcfc8c7c9a6', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('143f0ed4-80df-5608-97b9-ca47d39c7b85', 'f826ab1d-6750-5f56-b4be-938133f0222b', '3d3977a9-97ea-5ce3-bce8-ea3eb9557dae', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('ffe0ef46-2620-5475-b191-ae1b55eb880b', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'OPT2', 2, 1, 'EZバーまたはダンベル、ベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('b67e5962-90aa-5d04-959d-91c6247596a1', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'ffe0ef46-2620-5475-b191-ae1b55eb880b', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('4cf1592c-360a-549f-806c-13eebd951637', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'ffe0ef46-2620-5475-b191-ae1b55eb880b', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('62885afd-971e-53ef-89a0-c5799030d80c', 'EX039', 'クローズグリップベンチプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'HIGH', 'MAJOR_ACCESSORY', 'COMPOUND', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('837ed732-14c9-5c87-935a-b306ffdd4e16', '62885afd-971e-53ef-89a0-c5799030d80c', 'b8443d14-b195-556a-bef7-b810e2476377', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('294cb362-611f-568f-bd96-8ac6c50ad3f1', '62885afd-971e-53ef-89a0-c5799030d80c', '89048f02-5230-5a32-bcdb-2a24944621a0', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('4372a60a-f56b-563d-94af-89b15f37fa0d', '62885afd-971e-53ef-89a0-c5799030d80c', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('40fcf97a-a621-54a8-8bda-b11ca68ece27', '62885afd-971e-53ef-89a0-c5799030d80c', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('46772aba-71f8-5a65-ac4d-0b40ca841ddf', '62885afd-971e-53ef-89a0-c5799030d80c', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('1234666e-6fe6-54c6-a1c2-926cd9969764', '62885afd-971e-53ef-89a0-c5799030d80c', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3bc566c2-d06d-5ee4-b15e-4895d1a9bba3', '62885afd-971e-53ef-89a0-c5799030d80c', '56b6b1c3-175a-5993-b27f-4e2f434634d9', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('9dd79561-553d-5d76-8120-0a2efaa6636a', '62885afd-971e-53ef-89a0-c5799030d80c', 'f234d41b-664e-53bc-9589-6f1119cc4b07', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0eda9998-ee46-5bda-b815-893a556d52ba', '62885afd-971e-53ef-89a0-c5799030d80c', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('40a8d7b6-4165-5efd-9efc-0b0627478f3c', '62885afd-971e-53ef-89a0-c5799030d80c', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('6ec8d5c8-9934-5c67-9bb8-18e65856af7e', '62885afd-971e-53ef-89a0-c5799030d80c', 'OPT1', 1, 1, 'バーベル、ベンチ、ラック／セーフティ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('21e40b09-c1f6-588f-acb5-d2a84c5d8ee1', '62885afd-971e-53ef-89a0-c5799030d80c', '6ec8d5c8-9934-5c67-9bb8-18e65856af7e', '30f9cef2-8e64-58b8-9fc8-632dfd1bf3a3', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('17321272-7fc9-5c21-b48f-abd09e47668d', '62885afd-971e-53ef-89a0-c5799030d80c', '6ec8d5c8-9934-5c67-9bb8-18e65856af7e', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('5117b200-5718-5f7f-b51e-d10750dc10aa', '62885afd-971e-53ef-89a0-c5799030d80c', '6ec8d5c8-9934-5c67-9bb8-18e65856af7e', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'EX040', 'リストカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'LOW', 'FINISHER', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_ARMS', 'MULTI_MODE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('99dc0605-f0a9-53c6-83df-21518cefcb29', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'b8443d14-b195-556a-bef7-b810e2476377', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('679b5293-0cf4-5c52-831f-a67cfd9bcf4b', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', '17fa86f5-c377-53e3-b1a3-1ae6393ad185', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('8484c177-16de-5a3e-9a00-900cdab788dd', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('05fb5b97-0d60-5a6f-a534-dfd119bfeac8', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('d26ca6e5-e8d5-55fb-bdb7-c9cbfeb1998a', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'ac7c3d04-952d-5b39-a703-53446b3c512c', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e732516e-c59e-51b5-96e2-55e9494e3f9d', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('655c6089-32fc-5caa-808e-70c3f44aa94b', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('02b80d14-a39d-53d7-890d-81da3a4839a4', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'OPT1', 1, 1, 'ダンベルまたはバーベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('7e4d76c4-a09a-5065-87a2-9b330e388943', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', '02b80d14-a39d-53d7-890d-81da3a4839a4', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('b4816170-e4db-579d-ba48-8c66c1893be1', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'OPT2', 2, 1, 'ダンベルまたはバーベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('85a1b813-9889-5630-a3f6-815b161b6ccd', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'b4816170-e4db-579d-ba48-8c66c1893be1', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('35e88355-a311-5689-94d2-e04d60a4fdcf', 'EX041', 'グルートブリッジ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'LOW', 'INTRO_ACCESSORY', 'HIP_EXTENSION', 'BILATERAL_LEGS', 'REPS_LOADABLE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('d4fd78e8-bffe-5ed6-8900-abed177a2339', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'fc177709-495f-5f69-a70a-20ee56bd0a66', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('a96f4138-6a0c-5b27-88b7-b899789fabf9', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'b63c3fa4-ddb5-5a81-acd0-c779467bd7d5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('5b8cbb19-1757-5762-b854-761150ae5265', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('3fc6891a-05b7-528a-8815-48af6c77d4a4', '35e88355-a311-5689-94d2-e04d60a4fdcf', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('8634dec7-de26-5aa4-bef3-8fe2df667703', '35e88355-a311-5689-94d2-e04d60a4fdcf', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('b76af73e-fa87-54f4-a7fc-9f324846698b', '35e88355-a311-5689-94d2-e04d60a4fdcf', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('39c1b01c-35b9-57f0-b120-ee409e8ef705', '35e88355-a311-5689-94d2-e04d60a4fdcf', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('637c0d11-25fd-5187-9d65-ca622e7534cb', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('74fb922b-56d3-54d3-9c42-5525cf40cc93', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'OPT1', 1, 1, '器具なし。任意でバンドやダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('bbfe821f-d49c-5855-aee1-1ab697cf589e', '35e88355-a311-5689-94d2-e04d60a4fdcf', '74fb922b-56d3-54d3-9c42-5525cf40cc93', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'EX042', 'ヒップスラスト', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'MEDIUM', 'MAJOR', 'HIP_EXTENSION', 'BILATERAL_LEGS', 'MULTI_MODE', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('b9eb5ad1-515b-56f0-9660-337f1a2ad2e9', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'fc177709-495f-5f69-a70a-20ee56bd0a66', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('f3d55945-5405-54f5-a3e3-b8de6942477d', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'b63c3fa4-ddb5-5a81-acd0-c779467bd7d5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('d56f6815-5b89-5064-93b7-78ba673fb043', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('0d9a2f0c-724b-54eb-b83b-7451440b6b46', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('4dadfabd-b65d-5f39-9288-3eca32dca3a0', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('bc78ded9-2c8e-5540-b833-7453c740bf96', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('cf21f2ba-a483-5eec-8028-2e78dce0b130', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('d7c88d79-ebff-500c-98ce-5ae11a4a0ea9', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('1429feb9-e757-5796-b960-01f880c5a2d1', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'OPT1', 1, 1, 'ベンチ、バーベルまたはダンベル、パッド', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('248c680b-15e2-54ce-9918-19c8aa9c4a1d', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '1429feb9-e757-5796-b960-01f880c5a2d1', '5e07b121-c2a0-5e03-b5b9-418f349df03e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('e520528a-7aed-57b7-8f07-1dfbccdc21b6', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '1429feb9-e757-5796-b960-01f880c5a2d1', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('72243a85-e5a6-5b7d-84d4-90e3effb599f', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '1429feb9-e757-5796-b960-01f880c5a2d1', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('ae557a0c-c9f0-5bb4-a71a-0b6bd479059e', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '1429feb9-e757-5796-b960-01f880c5a2d1', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'EX043', 'ルーマニアンデッドリフト', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'HIGH', 'MAJOR', 'COMPOUND_HIP_EXTENSION', 'BILATERAL_LEGS', 'MULTI_MODE', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('490e4654-e09e-56e1-949a-f7dae813c2e2', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'fc177709-495f-5f69-a70a-20ee56bd0a66', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('c00fa928-9e64-515f-9707-7cfec826edf4', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'd08b8ce6-ec56-573b-8646-e862dca64d5c', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('1f820156-16d8-5d46-8560-f102124af0cb', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('ffacbe25-689b-5121-a7d4-bb6557773019', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('8fafebe1-42a7-5cf4-acf8-a44b2e2dc4ea', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('1cfd2ec1-8c0b-5906-8879-39cf41c8c399', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('6be9a830-76cf-57e3-b4c9-638df1ffc3fe', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ed4fc8ac-0ca8-5c4e-9353-597fd064ecd5', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e88a3d52-18d8-5e64-a3ca-4f1172282ad9', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('98bc7ac6-aae8-51c1-9dea-fa00655862bf', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('f7ed8316-0e90-5418-aaa3-24309e8d8d4d', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'OPT1', 1, 1, 'バーベルまたはダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('d6ac9719-bfc9-5afc-9a07-9a7c9fd2a273', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'f7ed8316-0e90-5418-aaa3-24309e8d8d4d', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('7aa4f2bf-ca25-5b41-9504-53169acb6fa2', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'OPT2', 2, 1, 'バーベルまたはダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('0b420492-9c3a-5205-ad51-26e78f342a35', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', '7aa4f2bf-ca25-5b41-9504-53169acb6fa2', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('47411e34-b12b-56a7-ba86-478679571626', 'EX044', 'ブルガリアンスプリットスクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'HIGH', 'MAJOR_ACCESSORY', 'COMPOUND', 'UNILATERAL_LEGS', 'MULTI_MODE', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('cdd69691-c94c-5087-a75c-3fde853fb7fa', '47411e34-b12b-56a7-ba86-478679571626', 'fc177709-495f-5f69-a70a-20ee56bd0a66', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('241a6675-f902-548b-bc3e-d2482d23d61c', '47411e34-b12b-56a7-ba86-478679571626', 'f2068657-53a1-58f0-82f1-c4c2adf847a2', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('33251936-4a98-5991-8e2c-601d77398044', '47411e34-b12b-56a7-ba86-478679571626', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('34e43b0e-0cca-55d1-a605-303a4be13597', '47411e34-b12b-56a7-ba86-478679571626', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('283a1909-d13c-5b63-b5b9-c0bf6c420ca1', '47411e34-b12b-56a7-ba86-478679571626', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('7a5fad65-d7e2-53a5-ba5c-a780a607108d', '47411e34-b12b-56a7-ba86-478679571626', 'b029826b-6c01-5715-9175-e6ce17e0d2d3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('84d46bb7-8198-5d91-8f39-525f5ae1e451', '47411e34-b12b-56a7-ba86-478679571626', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4df565b5-5ae3-53cd-afb7-c54d52407c69', '47411e34-b12b-56a7-ba86-478679571626', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('9df807bf-6653-59bd-992b-fc28cba88312', '47411e34-b12b-56a7-ba86-478679571626', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('fb830021-d44f-56b5-a812-4db278e2882c', '47411e34-b12b-56a7-ba86-478679571626', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('521dc77b-b23a-5540-b931-fdc780e2671f', '47411e34-b12b-56a7-ba86-478679571626', 'OPT1', 1, 1, 'ベンチまたは台。任意でダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('952a32b9-2de7-5e79-b857-44a729bed9e2', '47411e34-b12b-56a7-ba86-478679571626', '521dc77b-b23a-5540-b931-fdc780e2671f', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('5d7155fa-9fec-5bd9-9530-8571ed449ee2', '47411e34-b12b-56a7-ba86-478679571626', 'OPT2', 2, 1, 'ベンチまたは台。任意でダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('cc981ad5-9bcd-58a2-86c8-4abbcc30d7b7', '47411e34-b12b-56a7-ba86-478679571626', '5d7155fa-9fec-5bd9-9530-8571ed449ee2', 'fc143718-6810-5509-bce4-8346c4db8715', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('426a5860-7e4f-57ef-a18f-959420622f4f', 'EX045', 'リバースランジ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'MEDIUM', 'MAJOR_ACCESSORY', 'COMPOUND', 'UNILATERAL_LEGS', 'REPS_LOADABLE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('b0feab58-8671-573b-a68f-498350f17a95', '426a5860-7e4f-57ef-a18f-959420622f4f', 'fc177709-495f-5f69-a70a-20ee56bd0a66', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('d1975f82-e4bd-5411-ae8d-8ea686866c40', '426a5860-7e4f-57ef-a18f-959420622f4f', 'f2068657-53a1-58f0-82f1-c4c2adf847a2', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('2e45f189-1a30-522a-b35b-8036ed68805f', '426a5860-7e4f-57ef-a18f-959420622f4f', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('3eaa26b1-a13e-5fc3-9a87-c74460e8a0ac', '426a5860-7e4f-57ef-a18f-959420622f4f', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('89290290-733e-5915-b83f-457e7f416239', '426a5860-7e4f-57ef-a18f-959420622f4f', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('b0695f2f-9f0e-5522-a2cc-f4759a1f012f', '426a5860-7e4f-57ef-a18f-959420622f4f', 'b029826b-6c01-5715-9175-e6ce17e0d2d3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('bc27ac4b-8cc1-5c19-aaa6-60921cf93f05', '426a5860-7e4f-57ef-a18f-959420622f4f', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('32178afb-509e-574d-8510-65b291daa87d', '426a5860-7e4f-57ef-a18f-959420622f4f', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('53766453-86a6-5f32-b690-d72e337adc87', '426a5860-7e4f-57ef-a18f-959420622f4f', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f8736074-fdeb-51ea-b9a7-ba72db03e083', '426a5860-7e4f-57ef-a18f-959420622f4f', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('66a7824d-a6c3-53c4-959d-38d4c09ed5b5', '426a5860-7e4f-57ef-a18f-959420622f4f', 'OPT1', 1, 1, '器具なし。任意でダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('d79f9ee2-e618-5244-8c2d-50d168bad422', '426a5860-7e4f-57ef-a18f-959420622f4f', '66a7824d-a6c3-53c4-959d-38d4c09ed5b5', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('1761e525-9750-5b12-afe6-de2905489293', 'EX046', 'ステップアップ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'MEDIUM', 'MAJOR_ACCESSORY', 'COMPOUND', 'UNILATERAL_LEGS', 'REPS_LOADABLE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('2a253529-c6ee-57cc-b095-6c623cf49b41', '1761e525-9750-5b12-afe6-de2905489293', 'fc177709-495f-5f69-a70a-20ee56bd0a66', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('42f02628-88b9-55aa-9966-00092b3ae262', '1761e525-9750-5b12-afe6-de2905489293', 'f2068657-53a1-58f0-82f1-c4c2adf847a2', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('fefeea96-efef-5aca-9da1-c33e15874fb1', '1761e525-9750-5b12-afe6-de2905489293', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('0d572188-fea8-571d-80e1-5101215bcef1', '1761e525-9750-5b12-afe6-de2905489293', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('a2223dd3-4658-595b-93f3-c54591563532', '1761e525-9750-5b12-afe6-de2905489293', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('705eb432-0fbe-5c1e-9ccf-b32ddfcddb21', '1761e525-9750-5b12-afe6-de2905489293', 'b029826b-6c01-5715-9175-e6ce17e0d2d3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('df16d372-7814-54ee-8e35-e582dedb2705', '1761e525-9750-5b12-afe6-de2905489293', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('1df93fff-7b8b-54ff-ab74-5dcd31d21757', '1761e525-9750-5b12-afe6-de2905489293', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c7d26f56-f56b-5e12-9f6a-44fbc295438e', '1761e525-9750-5b12-afe6-de2905489293', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f76b910f-983f-5073-a4aa-0392b8d8a826', '1761e525-9750-5b12-afe6-de2905489293', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('e12af8b6-8922-59a0-8572-2203a08f8a49', '1761e525-9750-5b12-afe6-de2905489293', 'OPT1', 1, 1, '安定した台またはベンチ。任意でダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('f48a929e-645e-56ea-a9c5-487dfab7fd57', '1761e525-9750-5b12-afe6-de2905489293', 'e12af8b6-8922-59a0-8572-2203a08f8a49', 'fc143718-6810-5509-bce4-8346c4db8715', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('c61e6257-4598-5d29-b1ae-e145f8de9dd8', '1761e525-9750-5b12-afe6-de2905489293', 'OPT2', 2, 1, '安定した台またはベンチ。任意でダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('1cc5b143-1a60-5926-a56a-c19776c29465', '1761e525-9750-5b12-afe6-de2905489293', 'c61e6257-4598-5d29-b1ae-e145f8de9dd8', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('05f04394-df51-55d0-a371-8999be52c9a1', 'EX047', 'ケーブルプルスルー', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'MEDIUM', 'MAJOR_ACCESSORY', 'HIP_EXTENSION', 'BILATERAL_LEGS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('a8f7160d-5b48-57af-a5f1-89ba17ca19e9', '05f04394-df51-55d0-a371-8999be52c9a1', 'fc177709-495f-5f69-a70a-20ee56bd0a66', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('ee2e23a0-9f07-5c08-a297-42a00f6f32e2', '05f04394-df51-55d0-a371-8999be52c9a1', 'd08b8ce6-ec56-573b-8646-e862dca64d5c', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('664fcc1f-9614-5b1d-9e6c-62a540c49fa3', '05f04394-df51-55d0-a371-8999be52c9a1', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('84b2cb0e-942b-56c5-bfd6-1334b6abec72', '05f04394-df51-55d0-a371-8999be52c9a1', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4ccaaeb7-3d3e-52ad-8665-821a9ef2b416', '05f04394-df51-55d0-a371-8999be52c9a1', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('928b760d-9c8c-5873-b681-87db1ec833a9', '05f04394-df51-55d0-a371-8999be52c9a1', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('800ac462-538c-574d-a136-6981e7090f56', '05f04394-df51-55d0-a371-8999be52c9a1', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e1fde8ac-b16c-5b12-9dc4-dd438fb06206', '05f04394-df51-55d0-a371-8999be52c9a1', 'bd034c89-8fde-5539-b73c-feeea657d8b0', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('b9e31744-e8c7-576f-b3d9-e3acd27c0deb', '05f04394-df51-55d0-a371-8999be52c9a1', 'OPT1', 1, 1, 'ケーブルマシン、ロープアタッチメント', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('e7e87cd1-3849-5074-909f-89b9cf652325', '05f04394-df51-55d0-a371-8999be52c9a1', 'b9e31744-e8c7-576f-b3d9-e3acd27c0deb', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('0b3a37a7-d47e-52ad-abee-19cb19faeb34', '05f04394-df51-55d0-a371-8999be52c9a1', 'b9e31744-e8c7-576f-b3d9-e3acd27c0deb', '6173e25b-e304-597e-af87-231718b056b5', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 'EX048', 'ケーブルキックバック', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'UNILATERAL_LEGS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('49ade803-ad73-506b-99ea-9de8364a24da', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 'fc177709-495f-5f69-a70a-20ee56bd0a66', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('2ca5c597-19c6-5960-8e0b-f33d15b47587', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 'b63c3fa4-ddb5-5a81-acd0-c779467bd7d5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('3a05d3bd-2b53-5e94-b5d4-7f9f4e6452c0', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('deeae783-efbd-5f32-8ea0-719e6659baa4', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('cb2511c8-e7d4-5bbe-ad2a-a11d27bee3eb', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('8916d472-639c-5a53-8802-1b9c3f05cacc', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e267223a-720b-563f-8b1f-2d283af18620', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('0f8876bb-b0c3-52aa-8177-3a970347f21c', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 'OPT1', 1, 1, 'ケーブルマシン、アンクルストラップ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('d813eb07-4e80-50bd-bcc9-9d97d4294a6a', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', '0f8876bb-b0c3-52aa-8177-3a970347f21c', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('89920bc5-e21a-5c9d-a66d-675148c6bbd8', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', '0f8876bb-b0c3-52aa-8177-3a970347f21c', '8fd229c1-b772-511a-bb1f-36bfe2f746cf', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'EX049', 'ヒップアブダクションマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_LEGS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '正面斜め');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('088be07a-1332-5b1f-ba67-ba6dca00576a', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'fc177709-495f-5f69-a70a-20ee56bd0a66', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('b118d151-2741-59de-92fd-c9dc4d68fc10', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'adfa784b-a475-5e2b-b47e-75eff2b2ab4e', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f5b7fd8e-8be2-57ff-95be-3eb5ba37d4a8', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('438c16c9-231d-5c6c-ab27-324c207b0b52', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('35f3a73e-3019-5b43-ba8f-260b6008927a', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'd670e94d-96d4-5385-a70b-2b44aa9ccdbd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('dfb01b5c-5cc4-5db0-ab1f-19abe53a2c2e', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('d845ba5f-b14c-5322-b388-32eb0988853f', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'OPT1', 1, 1, 'ヒップアブダクションマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('bb27412f-1577-511a-a385-47b0a634d12d', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'd845ba5f-b14c-5322-b388-32eb0988853f', 'b1c0559c-3032-52c4-81a6-f1990284bdc2', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'EX050', 'バンドラテラルウォーク', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + band_id + band_position', 'LOW', 'WARMUP_ACCESSORY', 'HIP_ABDUCTION', 'ALTERNATING_SIDES', 'BAND_STEPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('c36eaf83-b1b6-5183-ab6e-d2ebec2f5002', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'fc177709-495f-5f69-a70a-20ee56bd0a66', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('e4befa61-8e8b-5fd5-becd-16e1949672c7', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'd72fa645-84a7-5c91-9898-f2268bd4271f', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('dee5f53e-2564-5488-b8b1-957e2be59a5f', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('da23f82c-e5fc-56ef-b24c-b6737ad33c2b', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f6ad36cc-d15d-505b-b101-8adc7ef98196', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('60605c7d-71ae-5090-9a89-12881e396505', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'd670e94d-96d4-5385-a70b-2b44aa9ccdbd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('5d448254-90a8-5bb5-9e31-d7a8f43c31ac', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('552c6a4b-6a02-5c38-b90e-b8046623bdde', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('53ec3c0e-9de2-5c4a-8c5e-6b24f7862089', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'OPT1', 1, 1, 'トレーニングバンド', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('e96eb4f6-be6d-53e3-9ceb-d72832e9fb7e', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', '53ec3c0e-9de2-5c4a-8c5e-6b24f7862089', 'bb437913-c962-52fd-9c7c-fa4a674b01a0', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'EX051', '自重スクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id', 'LOW', 'MAJOR_INTRO', 'COMPOUND', 'BILATERAL_LEGS', 'VARIATION_FIRST', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('2e6f6272-ff4b-5c7b-88ac-5a3ee00d64a6', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'daf26e81-268c-5cde-af17-102e8ac420ad', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('ef16077b-53c5-52ff-83dd-cd6811163ac8', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', '03965ec6-6d6b-5e39-9d6e-669dcbdf2168', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('244ba175-2f8c-51d6-92a0-654819001aff', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('64f235f1-ea2a-539f-a358-f904d647960f', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('ca283fb5-c79a-58d8-b4a7-2692fe283a69', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('9d2c89b8-37e5-5d14-a927-62ed5999f545', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('86b34d27-d9e8-5ca1-9672-fc15cb8a79ad', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'b029826b-6c01-5715-9175-e6ce17e0d2d3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('2166660e-0e1b-5249-b9c1-5382d5d652ec', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('6178c216-b766-5eb1-8c44-ddcb62dd15fa', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ed4c06a8-c1d6-5e16-98a0-ccf3f050178f', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('2c177221-ac52-5c14-a605-516036d436a6', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('73832c53-d7e8-50aa-a3eb-a5b51814bb65', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('b0866ac7-8b9f-5e5d-a153-fed918acb21a', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'OPT1', 1, 1, '器具なし', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('4aeb054a-4ac7-53db-ae7f-aa320ffcfa7f', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'b0866ac7-8b9f-5e5d-a153-fed918acb21a', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('2a565e8b-14b5-51bb-80bf-c713713f59fe', 'EX052', 'ゴブレットスクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'MAJOR', 'COMPOUND', 'BILATERAL_LEGS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('2e235f2b-5fc8-52d1-9b2f-ceec940fa899', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'daf26e81-268c-5cde-af17-102e8ac420ad', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('a90dd486-ad85-550f-8d83-b448730ced9c', '2a565e8b-14b5-51bb-80bf-c713713f59fe', '03965ec6-6d6b-5e39-9d6e-669dcbdf2168', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('1a051c0b-2220-5ff2-b604-d94b27cc8b92', '2a565e8b-14b5-51bb-80bf-c713713f59fe', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('4ae71f25-05f3-580e-b139-72c908d74085', '2a565e8b-14b5-51bb-80bf-c713713f59fe', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('422bae45-57a2-5947-9ca6-1f491532af9a', '2a565e8b-14b5-51bb-80bf-c713713f59fe', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('87d2b732-6756-5967-b958-71d2be7675ba', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e02a391b-f50e-56c3-9826-561e3a53e061', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'b029826b-6c01-5715-9175-e6ce17e0d2d3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f9118fe2-0aea-551b-89c8-aee7c69935f3', '2a565e8b-14b5-51bb-80bf-c713713f59fe', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e7141dd0-ddb1-5090-b98a-5b1ebe763dfa', '2a565e8b-14b5-51bb-80bf-c713713f59fe', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e5b5d0b7-3624-51cc-887e-3933d8de062e', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('723383c6-037b-5654-9290-4a319939c99e', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('825646e1-674c-57fa-b9e9-df0cc0971538', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('eeae3333-5972-516a-8c79-020b289c7971', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'OPT1', 1, 1, 'ダンベルまたはケトルベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('064947f0-b237-535f-87d0-84de210f5e6e', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'eeae3333-5972-516a-8c79-020b289c7971', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('02a675ea-42b3-5678-9710-a994d23a409d', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'OPT2', 2, 1, 'ダンベルまたはケトルベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('de5723d9-e55c-5717-a227-fe48031e530b', '2a565e8b-14b5-51bb-80bf-c713713f59fe', '02a675ea-42b3-5678-9710-a994d23a409d', '0e3f8f7d-46a7-52ec-a4cc-af1cf44fd0f4', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('066d1ba2-0850-5081-bc9b-dfa3d6144138', 'EX053', 'バーベルバックスクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'HIGH', 'MAJOR', 'COMPOUND', 'BILATERAL_LEGS', 'WEIGHT_REPS', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('507f4c8b-20cf-5ca1-a590-fc858397ff91', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'daf26e81-268c-5cde-af17-102e8ac420ad', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('b289db16-65bb-51d0-809a-6ce6807ec53c', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '03965ec6-6d6b-5e39-9d6e-669dcbdf2168', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('65bd3624-7c35-53b1-a08f-eaa5c87f6b1f', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('37e9f83c-2f31-5b79-84ce-effa039f9bbb', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('431f5502-adba-5619-9155-ee532f6758ec', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('18c4647b-e901-5059-b125-2fdfdbbba38b', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4b20302f-93cf-5a8f-868d-c09bcae36e89', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'b029826b-6c01-5715-9175-e6ce17e0d2d3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('76f747d0-5350-5c2d-84f6-05ce56b7db47', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f1c434e3-a892-5acf-ada4-0bbc63629379', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('08fdeb73-3540-560d-b4ee-8c6324d88587', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('2aa1bb39-2da1-5fb2-9f63-4de1de30dfa6', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('29e40a74-8e46-51ee-abdd-3a77fe4ff5cf', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('8938d080-9cab-5f04-b7f9-7208061b34eb', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'OPT1', 1, 1, 'バーベル、パワーラック／ハーフラック、セーフティ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('611dd331-f480-50a2-8768-bf37e568ab7a', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '8938d080-9cab-5f04-b7f9-7208061b34eb', 'b8f8a8dc-169e-5f97-82de-d1a015f697f0', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('3172637f-6b14-59b0-9308-9c3a91dbba73', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '8938d080-9cab-5f04-b7f9-7208061b34eb', '30f9cef2-8e64-58b8-9fc8-632dfd1bf3a3', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('8945b498-f05d-5c36-b08c-438f4ee10843', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '8938d080-9cab-5f04-b7f9-7208061b34eb', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'EX054', 'フロントスクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'HIGH', 'MAJOR', 'COMPOUND', 'BILATERAL_LEGS', 'WEIGHT_REPS', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('f0ef9597-8f8a-521c-aa2b-66116297cca8', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'daf26e81-268c-5cde-af17-102e8ac420ad', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('24829dda-bd45-5d9d-9697-738bf4450e8d', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', '03965ec6-6d6b-5e39-9d6e-669dcbdf2168', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('b2272f03-f7f8-5f51-aaee-e425ef394a52', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('009f7b15-db7a-57ee-abe3-113d808f0b3c', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f7a294ee-33d2-55fd-a079-e053dea8114b', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f4194a81-9ae7-5e80-8823-1ff02025381a', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('b4298f81-57cd-5a99-81d8-98405af84bb6', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0c95e486-fc29-57f1-a388-10bf8979c9f4', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'b029826b-6c01-5715-9175-e6ce17e0d2d3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4c5fa73d-d55b-54a6-bbf0-1480f61dedb7', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('05e305b1-cef4-56f3-b4a5-7fb7f0e214da', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', '005a7449-3a58-5f37-ae08-3ee76ba426d6', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('732c334b-7c63-5e0c-ad5c-fd4b0bbd1f03', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('188e92cf-d31d-5085-94ab-efb00a1c0b34', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('d8053ff6-2596-5e00-8be4-430533120a48', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'eaff0d48-92a1-5199-843d-d230bec14362', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('f5550542-7c05-508b-9e85-4b76fc6c5fb0', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'OPT1', 1, 1, 'バーベル、パワーラック／ハーフラック、セーフティ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('2c8c6689-3596-5e17-8c02-f288f269a84d', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'f5550542-7c05-508b-9e85-4b76fc6c5fb0', 'b8f8a8dc-169e-5f97-82de-d1a015f697f0', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('a50cb956-3baf-54a1-9ca3-b9109a6433a8', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'f5550542-7c05-508b-9e85-4b76fc6c5fb0', '30f9cef2-8e64-58b8-9fc8-632dfd1bf3a3', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('b185e5f7-d7eb-5695-b7d3-646e063c526f', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'f5550542-7c05-508b-9e85-4b76fc6c5fb0', 'b01886a0-9e5f-5103-94e5-4bbeb9eee8e1', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'EX055', 'レッグプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'MAJOR', 'COMPOUND', 'BILATERAL_LEGS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('365171ea-0209-556e-8e08-9404faa20666', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'daf26e81-268c-5cde-af17-102e8ac420ad', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('a3f90494-5ba0-5e36-8dd7-a8b12890e363', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', '477dd8ad-3780-5161-afdf-a91f4e13c4ba', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f03d2d99-8aac-59bf-85e8-71bac615dc84', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('3a7d7a9f-19b9-5bd4-b566-91f0afc41bbe', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('b77d5b20-acf8-56c0-8871-b34aa80a99ba', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('af22cf9f-3d3c-594b-b841-0d5c948f54f3', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('d6007c73-818f-56ce-a93f-033ec455c3db', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'b029826b-6c01-5715-9175-e6ce17e0d2d3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e9a29cdf-cd38-54e7-8dc7-bf128d000c82', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f421be0e-bfdd-5b2f-b012-44e76fb19f40', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f3cf28b0-bedb-5223-afed-3da87dc26cbf', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3d7a88d1-818e-5ad9-8d5d-cdd53c43d15a', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('eddd3058-3088-5843-bd2a-e4e752b7fb41', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'OPT1', 1, 1, 'レッグプレスマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('7214d3a6-0d52-582b-acd1-741fd22ff248', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'eddd3058-3088-5843-bd2a-e4e752b7fb41', 'fcfdebc3-fe22-5351-9178-d41a78d8716d', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('25bd9912-890e-574f-ab15-0f1eda43f095', 'EX056', 'レッグエクステンション', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_LEGS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('21034607-c616-52fb-b58a-d40f06f9dd47', '25bd9912-890e-574f-ab15-0f1eda43f095', 'daf26e81-268c-5cde-af17-102e8ac420ad', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('bd9bfcdf-6126-5660-90f0-d930c1b54bbf', '25bd9912-890e-574f-ab15-0f1eda43f095', '6132b346-08e6-54a8-a26f-122e6db12daa', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('a74e77d2-fa62-527d-9d31-ee93f23ec0ef', '25bd9912-890e-574f-ab15-0f1eda43f095', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('93c42578-b313-52f6-bd89-76dc3bd18798', '25bd9912-890e-574f-ab15-0f1eda43f095', 'b029826b-6c01-5715-9175-e6ce17e0d2d3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('edc74c8f-a576-5c7a-a8bb-5be408aa0157', '25bd9912-890e-574f-ab15-0f1eda43f095', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('b847f27b-564a-5ab9-92e8-3a1e34391a54', '25bd9912-890e-574f-ab15-0f1eda43f095', 'OPT1', 1, 1, 'レッグエクステンションマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('efe5f184-faa8-599e-a1e8-2e9368952e01', '25bd9912-890e-574f-ab15-0f1eda43f095', 'b847f27b-564a-5ab9-92e8-3a1e34391a54', 'e4645f85-d186-5bdb-8fd6-959832155402', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 'EX057', 'レッグカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'LOW', 'ACCESSORY', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_LEGS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('b54ffd8c-335b-556c-b6cc-08e059b3db95', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 'daf26e81-268c-5cde-af17-102e8ac420ad', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('43af657d-7a81-5bd3-ae84-7b9b70b126ae', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', '89079b75-f091-5d53-b5c0-728ca1d97b3a', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('4f03e21f-8e65-5e41-a64b-0d2020965d5e', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('0b3070d7-fcf4-5da1-b6f8-26bba30e1156', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('344b8982-d0d4-5d34-b975-62ec7153cdee', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('def3b679-7b3d-560d-bef6-738fcb89128b', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ef252221-96b6-5af4-a8f0-ca34aef5b55e', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 'd7016ff3-6aa8-51bb-b4cc-44f8803a4873', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('93172d13-cf8c-53d5-9e2f-8e16435325f4', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 'OPT1', 1, 1, 'レッグカールマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('5c05381d-99ec-5f11-8a28-ecbf99079982', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', '93172d13-cf8c-53d5-9e2f-8e16435325f4', '8ba366f0-a3b5-5f13-91b9-8a71b3bb1149', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 'EX058', 'ウォーキングランジ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'MEDIUM', 'MAJOR_ACCESSORY', 'COMPOUND', 'ALTERNATING_SIDES', 'REPS_LOADABLE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('03766557-d7f0-5b15-802a-ded401e4c8b9', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 'daf26e81-268c-5cde-af17-102e8ac420ad', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('ccdf43cd-33b0-5d10-830d-24897ed11f31', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '3e0e1df8-d2ea-5b6f-bd9b-d71945f0e960', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('269fa7e5-7088-5665-9ac2-f36ed5281901', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('253914f1-9ae7-5e8a-92f9-ec67262644c8', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('a96451e2-880a-51f7-885f-7f23a00d4c69', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('2b3a3779-f8ab-5051-80be-32678ea827c3', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 'b029826b-6c01-5715-9175-e6ce17e0d2d3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('fce1e24e-39ed-522a-862b-060e4e0f2f48', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('21b8cdb6-e17b-5eee-b319-539db5a7a1c1', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '2969b470-d7ec-520d-9bd3-763bc994afab', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c1f17ff1-7382-5d27-96c4-ed2f11ba770a', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 'eef589fe-ad5c-5eea-803b-6f4505dd2709', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('aec1dd58-0fb9-56b7-b47d-1e7ffe594c43', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 'c2d01fc1-b89f-55d7-bea6-4555436f8abd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('437ed65d-a7cd-5dd5-96bf-cb2265882598', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 'OPT1', 1, 1, '器具なし。任意でダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('c2c50d37-ca2c-5e32-8e35-84a8570b35e1', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '437ed65d-a7cd-5dd5-96bf-cb2265882598', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('b61c9833-ec63-5b20-8f0c-1c7197819f25', 'EX059', 'スタンディングカーフレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_LEGS', 'MULTI_MODE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('08c3ccbc-4296-5483-bc12-a4a73f29c771', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'daf26e81-268c-5cde-af17-102e8ac420ad', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('f75af2e8-89c0-57ae-9ca5-b2a088e0b871', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'c6762a7d-2d6e-51fd-a72e-22016f0fad6a', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('09c2f00f-0578-5085-bf36-9d64de4b6ea2', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('01b9f49d-2ba0-5cbe-8051-59864e9b7033', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('de653b7c-c0a2-5ae3-9973-c9ccd27bb561', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'd7016ff3-6aa8-51bb-b4cc-44f8803a4873', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3954950a-f6f8-5f8d-9562-4b7909d8b2ee', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'ea99222f-ed2e-5fe8-9107-a44a9f0e3788', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('5bfbdae5-5034-5513-b022-5ae314fb1745', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', '7cc9fb64-5ee6-5b88-96a0-252c30b0d754', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('9d787177-a272-5764-b450-60c0f4cb2517', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'OPT1', 1, 1, '器具なし、ダンベル、またはカーフマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('dd253fcd-d917-5131-bc36-85afd934871c', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', '9d787177-a272-5764-b450-60c0f4cb2517', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('1625ab21-3e55-5bb8-a3ad-e532e4134469', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'OPT2', 2, 1, '器具なし、ダンベル、またはカーフマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('17a75a20-53ea-5692-9d69-89a0d43651d7', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', '1625ab21-3e55-5bb8-a3ad-e532e4134469', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('54cac139-a97e-522d-ab81-0db4b57c6a50', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'OPT3', 3, 1, '器具なし、ダンベル、またはカーフマシン', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('54293344-eb83-57e3-ab55-c28784fc8904', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', '54cac139-a97e-522d-ab81-0db4b57c6a50', 'b662f884-4b5d-545c-ab04-ea8473c51598', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'EX060', 'シーテッドカーフレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_OR_UNILATERAL_LEGS', 'MULTI_MODE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('d488969c-6eea-5772-ab94-f29d468b62fa', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'daf26e81-268c-5cde-af17-102e8ac420ad', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('78a40ac9-23c8-562e-a2f0-dff052614a6e', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'c6762a7d-2d6e-51fd-a72e-22016f0fad6a', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('5d388d5f-7f6e-5f31-bd0c-75d6399fb4c9', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', '9d404900-1502-58c6-bfeb-d0baa6c3ba84', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('040ca1c2-220e-53e6-b96b-6bf52239d804', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', '231afa62-ad43-545d-aa57-174553f36158', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c53ee095-a98a-5c23-a84d-7479a363360f', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'd7016ff3-6aa8-51bb-b4cc-44f8803a4873', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ba67877b-2654-5a0d-bcd2-d49ae9edf968', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'ea99222f-ed2e-5fe8-9107-a44a9f0e3788', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('315ab6c6-c480-5312-9656-311e69150605', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', '7cc9fb64-5ee6-5b88-96a0-252c30b0d754', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('393d88a5-3b7f-5314-9fda-91feabd36da6', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'OPT1', 1, 1, 'シーテッドカーフマシン、またはベンチ＋ダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('7265e355-bed0-58c7-8449-2b6937f3ab18', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', '393d88a5-3b7f-5314-9fda-91feabd36da6', '8424cd43-0751-5ad9-ad2b-26cb271ffd53', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('09e0fb27-0adc-5fd8-aba4-4e7013e84f5b', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'OPT2', 2, 1, 'シーテッドカーフマシン、またはベンチ＋ダンベル', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('96c5effa-c290-5b53-b317-385efce29568', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', '09e0fb27-0adc-5fd8-aba4-4e7013e84f5b', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('723acb8e-d22f-5813-bd0b-7b4da1c4c85e', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', '09e0fb27-0adc-5fd8-aba4-4e7013e84f5b', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('c6f765f3-f227-5d17-b130-bf61a2213b40', 'EX061', 'クランチ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'LOW', 'ACCESSORY', 'TRUNK_FLEXION', 'BILATERAL', 'REPS_LOADABLE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('f6b398b3-bc1e-55bd-b44e-c88a7b4c21dc', 'c6f765f3-f227-5d17-b130-bf61a2213b40', '6779253e-e223-5b22-b0c1-180c9c7598f5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('b9b5375b-b10e-553b-891e-6524d9491236', 'c6f765f3-f227-5d17-b130-bf61a2213b40', '362f4bbb-2513-53ec-aaf1-133e3a352784', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('86967bd5-48bd-5900-b8ae-4a8f6df50c3c', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'a0e4cae0-77b6-5248-8d82-17bbd25899b8', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('fb810080-2fdb-5dff-a5fc-cd3d228df5c5', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3c635fc2-9057-5a34-9147-1a0c2635c7ef', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'f0e78eed-f404-5d9b-a4f4-b123217e1e0f', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('d0148812-6210-51ac-a60a-bcd5ed8df987', 'c6f765f3-f227-5d17-b130-bf61a2213b40', '3ea569d1-a89b-5921-a998-ea62045ddddc', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('2b1186ce-037c-5cdf-a703-7c5b15514be8', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('b00d3442-8c31-5b45-bb79-b1efb2815ee0', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'OPT1', 1, 1, '器具なし。任意でマット', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('2d254259-c2fe-5c65-b544-890ba85c0a44', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'b00d3442-8c31-5b45-bb79-b1efb2815ee0', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('641b6020-c6e2-54d7-a0ef-c0238647194d', 'EX062', 'ケーブルクランチ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + gym_id + machine_id + attachment_id + unilateral_mode', 'MEDIUM', 'MAJOR_ACCESSORY', 'TRUNK_FLEXION', 'BILATERAL', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('bba685f6-feb3-5252-a94e-4d9c940e86ad', '641b6020-c6e2-54d7-a0ef-c0238647194d', '6779253e-e223-5b22-b0c1-180c9c7598f5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('31b92f7a-3b97-5bd9-adcb-8dc894251452', '641b6020-c6e2-54d7-a0ef-c0238647194d', '362f4bbb-2513-53ec-aaf1-133e3a352784', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('ce64654e-8015-52c4-921a-512d6523c125', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'a0e4cae0-77b6-5248-8d82-17bbd25899b8', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('9cbe7798-006a-501e-9f9e-919fb3ae9270', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('140d5ee7-14de-55a3-bfb9-0ce6544315e5', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'f0e78eed-f404-5d9b-a4f4-b123217e1e0f', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4d83254f-b6e0-564b-b93c-e6235122ff34', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('83e05ebc-fd12-5d73-a91f-7017eb938104', '641b6020-c6e2-54d7-a0ef-c0238647194d', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('9adef506-5ca3-55aa-b57c-9ed207bed1c8', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'OPT1', 1, 1, 'ケーブルマシン、ロープアタッチメント', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('dd996fb4-323d-5325-80e5-4748ad66038f', '641b6020-c6e2-54d7-a0ef-c0238647194d', '9adef506-5ca3-55aa-b57c-9ed207bed1c8', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('52a5121a-35d3-5bfc-aba1-b11d5a7f40fc', '641b6020-c6e2-54d7-a0ef-c0238647194d', '9adef506-5ca3-55aa-b57c-9ed207bed1c8', '6173e25b-e304-597e-af87-231718b056b5', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('c6b9ee08-6c1a-57c9-b145-371306d842b6', 'EX063', 'リバースクランチ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id', 'MEDIUM', 'ACCESSORY', 'TRUNK_FLEXION_POSTERIOR_TILT', 'BILATERAL_LEGS', 'REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('220bc80f-e629-59bc-a907-8e1d33ea7533', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', '6779253e-e223-5b22-b0c1-180c9c7598f5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('0ef8c5bd-06fd-57e6-8cbc-0e4923c454c5', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', '72962a81-d5d3-57d2-93ef-1710c2eb2187', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('8100fbee-d4d9-5742-8760-82016a833790', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('d86cd0e8-4c15-5ed3-b3d3-17d9dee198b9', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'ae6d0bf5-a803-57dc-84de-b2be3df0fe9d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3728d147-9966-5229-a732-acbd4bf7386d', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', '33996a24-8bb3-5165-afe1-d7768356dda5', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('71ff1197-a516-57ba-8e90-9faecc47d96c', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('6b8ad3a1-ccdf-5c45-b157-16ef00cb0781', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'OPT1', 1, 1, '器具なし。任意でマット', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('95c57e34-e222-5dec-a992-cb1a4fe97d0c', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', '6b8ad3a1-ccdf-5c45-b157-16ef00cb0781', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'EX064', 'ハンギングニーレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'HIGH', 'MAJOR_ACCESSORY', 'TRUNK_FLEXION', 'BILATERAL_LEGS', 'REPS_LOADABLE', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('9213b12a-6127-5ef3-a9ec-661d17a3cfdf', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', '6779253e-e223-5b22-b0c1-180c9c7598f5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('3d310cb6-bf43-5147-b756-57475075df5e', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'a8f5205a-66e0-5843-a322-4e5ce5654ff2', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('aeb0f03d-4ac3-5f24-81c9-0cad1bb6f3cf', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('f9996d5b-07f7-5e77-875b-eeb103dbdfbf', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('7dafa618-6e54-5ab3-89d8-a835fa8fbfe9', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('96e913a9-210e-5101-b3bc-4b8ee2db976a', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('52919102-646f-5719-8bad-c1310a219a8b', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', '005a7449-3a58-5f37-ae08-3ee76ba426d6', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('18ef79e7-70c9-55dd-a332-2c4a5eab260d', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', '33996a24-8bb3-5165-afe1-d7768356dda5', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('fd8b9324-44e0-56d5-91e1-936923d08634', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'e52b3685-8229-5955-a06a-c01d2c7c54ea', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('33085122-abf4-54f5-8675-2956a159d944', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('6897414d-2607-518f-a09b-658e1a6381b1', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'OPT1', 1, 1, '懸垂器具', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('2f0882ba-1af1-525d-8403-d2cd62e17ffd', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', '6897414d-2607-518f-a09b-658e1a6381b1', '4ce67979-7939-5157-96d1-07f06333b953', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('ff5db848-560b-56b9-a7b6-786495b5df4c', 'EX065', 'プランク', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'LOW', 'ACCESSORY_CORE_STABILITY', 'ANTI_EXTENSION', 'BILATERAL', 'DURATION', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('ae760b97-b2a1-532b-9248-ec138edc0512', 'ff5db848-560b-56b9-a7b6-786495b5df4c', '6779253e-e223-5b22-b0c1-180c9c7598f5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('a780a470-3f42-580f-826c-ac3a82fd2232', 'ff5db848-560b-56b9-a7b6-786495b5df4c', '15c5b087-7e7b-5d52-abf3-c059000bd211', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('0044e75d-9075-5baa-bbad-cd4ce1e69e84', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('277e44e0-4387-54f9-be60-593d3910a9ee', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('91af5c8b-8a8b-5dfc-baf5-1b40669a7ca7', 'ff5db848-560b-56b9-a7b6-786495b5df4c', '005a7449-3a58-5f37-ae08-3ee76ba426d6', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ce18316c-6b6c-580b-a092-c0222bd9876c', 'ff5db848-560b-56b9-a7b6-786495b5df4c', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4da18079-732e-5685-b65b-69dee45492a3', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('af5a8b9c-f64b-5096-ad3b-3b26f00af7c0', 'ff5db848-560b-56b9-a7b6-786495b5df4c', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('808be36a-460d-52e0-a9a7-f28aa1c30a9d', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'OPT1', 1, 1, '器具なし。任意でマット', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('4118adae-1ca0-5b19-96a5-8f78b5bca895', 'ff5db848-560b-56b9-a7b6-786495b5df4c', '808be36a-460d-52e0-a9a7-f28aa1c30a9d', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('5ad48491-19a8-569e-b4ae-459c0ec94498', 'EX066', 'サイドプランク', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id + load_mode', 'MEDIUM', 'ACCESSORY_CORE_STABILITY', 'ANTI_LATERAL_FLEXION', 'LEFT_RIGHT', 'DURATION', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('0927c3fe-3d41-5c55-b865-0c6bc1676998', '5ad48491-19a8-569e-b4ae-459c0ec94498', '6779253e-e223-5b22-b0c1-180c9c7598f5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('9a93eeb8-4b4a-5701-8cd7-3ee8a620dca5', '5ad48491-19a8-569e-b4ae-459c0ec94498', '1d6b476a-6dc2-5ea0-8f01-72c7cf5b0755', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('fbfd6877-d7bb-51e2-a248-2910cca51323', '5ad48491-19a8-569e-b4ae-459c0ec94498', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('c5719547-cdc4-546e-9d3d-775e137695b3', '5ad48491-19a8-569e-b4ae-459c0ec94498', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('4e32615d-ad92-5ad8-8249-d79226638139', '5ad48491-19a8-569e-b4ae-459c0ec94498', '1c0574e5-b041-56ff-bb9b-ab2fe9a8321e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c6ecad7a-6f4d-55b6-8782-8b652101aea4', '5ad48491-19a8-569e-b4ae-459c0ec94498', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('f127c0b4-5041-56f8-a7db-fe0e88079c51', '5ad48491-19a8-569e-b4ae-459c0ec94498', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('1dc75931-14ca-553f-8c2c-6d579d6e19f0', '5ad48491-19a8-569e-b4ae-459c0ec94498', 'OPT1', 1, 1, '器具なし。任意でマット', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('045c2524-0620-5478-8bc9-e641408b447c', '5ad48491-19a8-569e-b4ae-459c0ec94498', '1dc75931-14ca-553f-8c2c-6d579d6e19f0', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'EX067', 'デッドバグ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id', 'LOW', 'INTRO_CORE_STABILITY', 'ANTI_EXTENSION_COORDINATION', 'ALTERNATING_SIDES', 'REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め上');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('f248baa9-be1e-5f73-858f-d7dccaf7994c', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', '6779253e-e223-5b22-b0c1-180c9c7598f5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('2a780686-f2fb-56a8-887e-a6be65849c00', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', '15c5b087-7e7b-5d52-abf3-c059000bd211', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('57f4deea-19c0-5bb1-b073-62fc66ccc656', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('4d9e7c9d-9065-5045-88bf-2503b005444a', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', '187c487b-4f66-5b78-b6dd-5a5523ad179b', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('93baeccc-3abc-55e7-b1c0-e98586df30a4', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', '005a7449-3a58-5f37-ae08-3ee76ba426d6', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('a500f913-e408-50dc-b6cb-ef3b623c881b', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', '33996a24-8bb3-5165-afe1-d7768356dda5', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('23f1e8b8-8f8d-5211-afe3-95542f7e2a48', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('c9705f43-a4a2-592e-b725-fbd1688143c4', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'OPT1', 1, 1, '器具なし。任意でマット', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('31d7beb2-4ce5-5709-98f3-463da2fb00bb', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'c9705f43-a4a2-592e-b725-fbd1688143c4', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('b40d9445-b430-53e2-995a-bd16ff30da08', 'EX068', 'バードドッグ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id', 'LOW', 'INTRO_CORE_STABILITY', 'ANTI_ROTATION_COORDINATION', 'ALTERNATING_SIDES', 'REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '斜め横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('b00a80f6-7cff-5324-a958-f08fbb2e458e', 'b40d9445-b430-53e2-995a-bd16ff30da08', '6779253e-e223-5b22-b0c1-180c9c7598f5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('648486e2-8eb2-5b59-8a85-8c476714016e', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'eda5a58f-670e-5202-8a76-7860bcfde860', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('014d1762-51b4-5fb3-a6fb-cfb927de2c29', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('5be90cdb-01a8-5cb7-8653-38252400050f', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('5fc97d9c-75c3-57e3-bd40-15e88806830c', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ce43f3b5-839b-5575-8740-d5d650e84410', 'b40d9445-b430-53e2-995a-bd16ff30da08', '005a7449-3a58-5f37-ae08-3ee76ba426d6', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('78c558d3-c746-5b90-9a22-c36576da35a5', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'e7513330-a6af-529b-965e-434adb23ee1b', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3cc3cb3d-8cca-57f3-ad97-269d3eab8b58', 'b40d9445-b430-53e2-995a-bd16ff30da08', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('c6cc5bfb-9fdb-5c8b-a3cf-61a8aa35148f', 'b40d9445-b430-53e2-995a-bd16ff30da08', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('4acbbd80-d9a4-5bf9-8743-d4c7eb6f8cd1', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'OPT1', 1, 1, '器具なし。任意でマット', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('af0d7b53-ce72-588c-b414-542fc1dc45ce', 'b40d9445-b430-53e2-995a-bd16ff30da08', '4acbbd80-d9a4-5bf9-8743-d4c7eb6f8cd1', '35cd8c20-a1db-5ac3-b671-25d7d0c2ca91', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('67902963-d3f4-5986-867e-6949bfa6a9e0', 'EX069', 'パロフプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode + gym_id/machine_id/band_id', 'MEDIUM', 'ACCESSORY_CORE_STABILITY', 'ANTI_ROTATION', 'LEFT_RIGHT', 'MULTI_MODE', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'STANDARD', '正面斜め');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('c490615e-758b-5a27-baf5-0d7a121083e7', '67902963-d3f4-5986-867e-6949bfa6a9e0', '6779253e-e223-5b22-b0c1-180c9c7598f5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('97e7779d-86a3-5015-b397-0ba398b25f54', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'd3486ade-ddb8-53c7-83aa-a77615a047c4', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('cf954661-b1fb-5ec8-9379-bb1307570461', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('cefd6955-faf5-53d7-a012-cf5095fe7470', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('ff38f754-839f-5491-b70a-43bbcf576a22', '67902963-d3f4-5986-867e-6949bfa6a9e0', '1c0574e5-b041-56ff-bb9b-ab2fe9a8321e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('875b025d-3dab-5470-867d-3b063f018937', '67902963-d3f4-5986-867e-6949bfa6a9e0', '6afb5cd4-3892-5552-8fa4-bfd6c004fa17', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('616b37ab-d917-50d1-84ac-944fd255fe41', '67902963-d3f4-5986-867e-6949bfa6a9e0', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('b2445681-bf5b-5e79-8ad0-e44d5b086315', '67902963-d3f4-5986-867e-6949bfa6a9e0', '01a998c3-6f8b-5d81-8c80-a5c4d69b48bd', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('7994eb70-0db3-525e-80c7-bfaedb6cfff4', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'OPT1', 1, 1, 'ケーブルマシンまたはトレーニングバンド', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('24ae7b8b-a87f-5de5-a619-7bff6e6711fe', '67902963-d3f4-5986-867e-6949bfa6a9e0', '7994eb70-0db3-525e-80c7-bfaedb6cfff4', 'e325affa-7d33-5f9a-97b9-99776e87d26e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('0224c47b-fdd0-51f8-8459-fc962c0e96b6', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'OPT2', 2, 1, 'ケーブルマシンまたはトレーニングバンド', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('8c10aab5-f696-56f1-bb0d-5f5e44f54d5b', '67902963-d3f4-5986-867e-6949bfa6a9e0', '0224c47b-fdd0-51f8-8459-fc962c0e96b6', 'bb437913-c962-52fd-9c7c-fa4a674b01a0', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'EX070', 'アブローラー', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + variation_id', 'HIGH', 'MAJOR_CORE_STABILITY', 'ANTI_EXTENSION', 'BILATERAL', 'VARIATION_FIRST', 'CONDITIONAL', 'AVAILABLE', 'AVAILABLE', 'CONDITIONAL', '真横');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('128c1689-bdd7-579a-9cfc-41cd98e17c1d', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', '6779253e-e223-5b22-b0c1-180c9c7598f5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('de6dee63-0c3a-54a7-bbd0-5c82f171fb64', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', '15c5b087-7e7b-5d52-abf3-c059000bd211', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('c09dce4a-5dc5-5432-a6df-d9aa60e36845', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('2ad40de3-ecbf-5955-87bd-c5c0223b74a8', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('0e56968d-7cec-5d97-b2d5-b77cab322ee4', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'cafcde77-7fe1-581f-8224-b52d80500b7d', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('db15cd0f-0e49-553a-a000-9d3c1f2ffd62', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'd62a5656-fe76-5140-9198-7c3b742ef338', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3b0eb6c6-c55e-5494-b313-472c8842afb2', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', '005a7449-3a58-5f37-ae08-3ee76ba426d6', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('5a3015c5-17de-5c83-8e76-91cf89c10dd8', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', '6f8f2aac-3c91-5244-b579-8918e7390b5e', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('2a892386-32af-5d1d-b33d-0782abdf3c0b', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', '88287900-5ac0-5761-919d-84842dbbcdaa', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('dddb7fc6-ca8f-5118-8091-bed7efc7ab70', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'b394f940-1ce4-53b5-bc14-1bbd8dbee44d', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('fdd83324-0447-51c5-bee6-85edaecc605b', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'cb180d10-c29c-509c-b561-e9ee65e0a8b8', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('99d3d9f3-3e39-5299-92e5-690cd46f8c5c', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'OPT1', 1, 1, 'アブローラー、マット', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('045cfc2a-3684-5c03-a5bd-859ec855de03', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', '99d3d9f3-3e39-5299-92e5-690cd46f8c5c', 'f12c6115-5e32-58a3-9572-a658ed1a6155', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('8a2eb290-d067-53c1-b34d-46c329347149', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', '99d3d9f3-3e39-5299-92e5-690cd46f8c5c', '962c30f2-208d-57a6-b7d3-64aeee264b53', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('4103b188-119d-5652-86fe-6ab2c343d380', 'EX071', 'インクラインダンベルサイドレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'MEDIUM', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'UNILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め前');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('9666f44f-d22d-5375-85f7-de8d7714ddac', '4103b188-119d-5652-86fe-6ab2c343d380', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('d833657b-f765-555f-b173-484e89866bb6', '4103b188-119d-5652-86fe-6ab2c343d380', '625454c7-efcc-5cb1-a523-da01a7b3a143', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('0af56fe1-01ba-5d7c-8aa7-e4be3db486dd', '4103b188-119d-5652-86fe-6ab2c343d380', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('d0de65a4-4733-5176-b385-3c047e2156ac', '4103b188-119d-5652-86fe-6ab2c343d380', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('18352f2d-8c92-52ad-93d3-9e44fe7d995b', '4103b188-119d-5652-86fe-6ab2c343d380', 'a0e84e6c-eec6-536c-9b3c-0780eda119d1', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('69331711-23d0-5f6e-a952-ebb8d29e1ff0', '4103b188-119d-5652-86fe-6ab2c343d380', '810521fc-1bac-5fd0-8ead-0cd87d8f0ae4', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('694dbef0-d75c-5bc9-a5b3-eff5b291d381', '4103b188-119d-5652-86fe-6ab2c343d380', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('8f3832fa-a17f-5241-bd7d-f4b15926d9c7', '4103b188-119d-5652-86fe-6ab2c343d380', 'OPT1', 1, 1, 'ダンベル、角度調整ベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('b4645b7c-ee9c-5283-ae8d-ae8247a044e3', '4103b188-119d-5652-86fe-6ab2c343d380', '8f3832fa-a17f-5241-bd7d-f4b15926d9c7', 'af7565b6-26dc-534e-b1f6-ae9b5a887fa5', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('6af5f835-73aa-53b8-b270-6ce477e5753b', '4103b188-119d-5652-86fe-6ab2c343d380', '8f3832fa-a17f-5241-bd7d-f4b15926d9c7', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('10ad37af-c096-5071-83c6-ae74dcaf7a08', '4103b188-119d-5652-86fe-6ab2c343d380', '8f3832fa-a17f-5241-bd7d-f4b15926d9c7', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_master (id, code, name_ja, is_active, content_version, created_at, updated_at, series_code, technical_difficulty_code, role_code, exercise_class_code, execution_mode_code, recording_method_code, beginner_availability, intermediate_availability, advanced_availability, default_priority_code, image_angle_code) VALUES ('73b1b849-cfe2-5e44-8636-c89b136e11e7', 'EX072', 'インクラインダンベルリアレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'exercise_id + equipment_mode', 'LOW', 'ACCESSORY_FINISHER', 'SINGLE_JOINT', 'BILATERAL_ARMS', 'WEIGHT_REPS', 'AVAILABLE', 'AVAILABLE', 'AVAILABLE', 'OPTION', '斜め後ろ');
-- statement
INSERT OR IGNORE INTO exercise_body_part (id, exercise_id, body_part_id, relation_type) VALUES ('d3ed2893-d21f-5b25-9019-1c5b5ff7c907', '73b1b849-cfe2-5e44-8636-c89b136e11e7', '3b24a2b6-e526-53bb-8949-c8e3b2e24cb5', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_movement (id, exercise_id, movement_id, relation_type) VALUES ('76ed88ac-cc58-5cc2-a976-7a7ab070e4d1', '73b1b849-cfe2-5e44-8636-c89b136e11e7', '95283fd3-86d9-54f4-9eb1-9e4984a563cb', 'PRIMARY');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('251b4f4e-e5b1-5000-9a3d-80eaef1dff39', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 'd9ff25cd-00a9-57cc-935b-500d30d0905e', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_joint (id, exercise_id, joint_id, risk_level) VALUES ('cf3e3456-8166-552c-894b-fc8f8ed6bbbb', '73b1b849-cfe2-5e44-8636-c89b136e11e7', '507747ae-575d-5dc6-9c12-0bd36a8e3e68', 'NORMAL');
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('3e744856-6168-57cb-bcd1-e081a17b4284', '73b1b849-cfe2-5e44-8636-c89b136e11e7', '9f1e0015-5378-5326-9639-4fc8556375b3', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('652fdf28-dabd-5fd6-ad19-2619e6f94464', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 'a8e76a29-7c57-5875-8a30-1cf4d2770800', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('e2e0d052-52c9-5684-9067-e59c5c969bd6', '73b1b849-cfe2-5e44-8636-c89b136e11e7', '83adbba0-4b1b-58d9-85c8-146b50e38786', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_fatigue_tag (id, exercise_id, fatigue_tag_id, fatigue_weight) VALUES ('0e985d8a-16a7-5238-a4ff-68592c963750', '73b1b849-cfe2-5e44-8636-c89b136e11e7', '13792595-dcd6-5a35-961f-951a25310348', 1.0);
-- statement
INSERT OR IGNORE INTO exercise_equipment_option (id, exercise_id, option_code, display_order, is_active, source_text, created_at, updated_at) VALUES ('a00541b1-b5bb-5a16-a86d-eb7327c99bb4', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 'OPT1', 1, 1, 'ダンベル、角度調整ベンチ', '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z');
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('7c6757f9-6806-5d56-8c8c-2a17620d2efc', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 'a00541b1-b5bb-5a16-a86d-eb7327c99bb4', 'af7565b6-26dc-534e-b1f6-ae9b5a887fa5', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('084e9be1-064b-517f-8eb9-73ace3ca5ed8', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 'a00541b1-b5bb-5a16-a86d-eb7327c99bb4', '73213a6e-2685-586a-992a-dac6783ead75', 'REQUIRED', 2);
-- statement
INSERT OR IGNORE INTO exercise_equipment (id, exercise_id, equipment_option_id, equipment_id, requirement_type, minimum_quantity) VALUES ('1e2e7dbc-fffb-5b95-a66c-563d8bf12ea0', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 'a00541b1-b5bb-5a16-a86d-eb7327c99bb4', 'a54de8d2-d8ae-56d8-9b22-7f0ea536882e', 'REQUIRED', 1);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('f3fe59ab-a045-5f46-bc25-430423ebb825', 'PROG-EX001-HYPERTROPHY', 'インクラインプッシュアップ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '95819265-6d61-5cca-ad80-1609b3a02486', 'HYPERTROPHY', 'ALL', 'PG11_VARIATION_FIRST', 'VARIATION_FIRST', 8, 20, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('b2dc2220-6e5a-5d37-956e-a6ba8d830368', 'PROG-EX001-STRENGTH', 'インクラインプッシュアップ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '95819265-6d61-5cca-ad80-1609b3a02486', 'STRENGTH', 'ALL', 'PG11_VARIATION_FIRST', 'VARIATION_FIRST', 5, 10, NULL, NULL, 3, 5, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('6b5d8997-8bef-536f-80ab-2b5b165f1bf0', 'PROG-EX001-HEALTH', 'インクラインプッシュアップ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '95819265-6d61-5cca-ad80-1609b3a02486', 'HEALTH', 'ALL', 'PG11_VARIATION_FIRST', 'VARIATION_FIRST', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('bb5399f6-aa97-5946-a0b0-f21e4a53d03f', 'PROG-EX002-HYPERTROPHY', 'プッシュアップ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'HYPERTROPHY', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 20, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('2a60c3a5-af4d-5e91-9ac4-08415d5226b8', 'PROG-EX002-STRENGTH', 'プッシュアップ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'STRENGTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 5, 10, NULL, NULL, 3, 5, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('fefbbdc2-bf5b-51d3-8fe8-8cac2ff7b8df', 'PROG-EX002-HEALTH', 'プッシュアップ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'HEALTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('b769ee54-7394-52ee-83b1-21a6177adbc1', 'PROG-EX003-HYPERTROPHY', 'ダンベルフロアプレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '728c22d5-86f9-58b2-b702-73ca968290c8', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('58ddd06d-88bd-596b-b94a-54c944265a63', 'PROG-EX003-STRENGTH', 'ダンベルフロアプレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '728c22d5-86f9-58b2-b702-73ca968290c8', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('672ab92a-4f1e-5a68-98a1-92bed0357aa9', 'PROG-EX003-HEALTH', 'ダンベルフロアプレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '728c22d5-86f9-58b2-b702-73ca968290c8', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('52defdbf-0e8c-593b-a47f-d1c168ee91ff', 'PROG-EX004-HYPERTROPHY', 'ダンベルベンチプレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c3be154d-b150-5477-852d-553edd3155b7', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('76e8c8e8-bc89-5681-921e-142b1e006ec2', 'PROG-EX004-STRENGTH', 'ダンベルベンチプレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c3be154d-b150-5477-852d-553edd3155b7', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('2ccec5f2-1201-5247-957a-fcb475abe744', 'PROG-EX004-HEALTH', 'ダンベルベンチプレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c3be154d-b150-5477-852d-553edd3155b7', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('8cfb3a2a-0db6-5d9e-a632-6edf14a331c4', 'PROG-EX005-HYPERTROPHY', 'インクラインダンベルプレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('e2db4ce6-f634-568a-a2fa-19c91512159b', 'PROG-EX005-STRENGTH', 'インクラインダンベルプレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('dada93c7-a833-52a7-8d3e-9575b2e3ae7f', 'PROG-EX005-HEALTH', 'インクラインダンベルプレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('57fff963-e0fa-5727-84b4-8177e948c626', 'PROG-EX006-HYPERTROPHY', 'バーベルベンチプレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('251cc392-48ad-5a3a-a4ce-a17dffb841ee', 'PROG-EX006-STRENGTH', 'バーベルベンチプレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('93cf0c36-980a-59a8-b12a-b911976ddacd', 'PROG-EX006-HEALTH', 'バーベルベンチプレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('1230a0a6-8a86-508d-8de8-9c3562ffe09b', 'PROG-EX007-HYPERTROPHY', 'マシンチェストプレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('f19b7b8e-849c-547b-983f-776b568a8e98', 'PROG-EX007-STRENGTH', 'マシンチェストプレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('33a905b8-7b5a-5525-b8b4-c42a45b865b3', 'PROG-EX007-HEALTH', 'マシンチェストプレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('aca127a8-aa43-5fc8-ad06-a620dd3aec98', 'PROG-EX008-HYPERTROPHY', 'ダンベルフライ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '16228203-ecfa-552d-b068-6a645dacc7ba', 'HYPERTROPHY', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0ac1cfdc-7eba-502a-a608-1bc07cf9c020', 'PROG-EX008-STRENGTH', 'ダンベルフライ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '16228203-ecfa-552d-b068-6a645dacc7ba', 'STRENGTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('a080e7bd-80f8-5b3a-8d84-bcd534dd7804', 'PROG-EX008-HEALTH', 'ダンベルフライ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '16228203-ecfa-552d-b068-6a645dacc7ba', 'HEALTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('dbbcbd88-9cb8-500c-be19-4c3b7414c28f', 'PROG-EX009-HYPERTROPHY', 'ペックデックフライ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('1e532dcb-49a3-5fc7-abcb-f4190c338c90', 'PROG-EX009-STRENGTH', 'ペックデックフライ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('ee4a5fa2-da80-5b69-864b-e46aaa4772ce', 'PROG-EX009-HEALTH', 'ペックデックフライ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('849dc3c1-4efb-5656-b37e-7d612d095e3a', 'PROG-EX010-HYPERTROPHY', 'ケーブルフライ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('41621bca-a735-56ff-9773-cd24bf55b0d6', 'PROG-EX010-STRENGTH', 'ケーブルフライ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('b04cd570-5fca-5248-8163-199a5d62d4a5', 'PROG-EX010-HEALTH', 'ケーブルフライ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('3e0f1c63-3a23-52c7-89a1-1c7054ae1d27', 'PROG-EX011-HYPERTROPHY', 'ラットプルダウン｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '03040c5e-0485-5937-b86e-c7472ec6d488', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('867b6cb3-78de-5776-aa2e-79ff962a4da7', 'PROG-EX011-STRENGTH', 'ラットプルダウン｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '03040c5e-0485-5937-b86e-c7472ec6d488', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('21b59acc-cd4b-5e69-8b6e-6de9ed771d56', 'PROG-EX011-HEALTH', 'ラットプルダウン｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '03040c5e-0485-5937-b86e-c7472ec6d488', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('9ad0ecd7-19b9-55c0-b604-aefccc16f726', 'PROG-EX012-HYPERTROPHY', '懸垂｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'HYPERTROPHY', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 20, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('a83d606a-6994-5d2f-8385-03c7dabf0a1b', 'PROG-EX012-STRENGTH', '懸垂｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'STRENGTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 5, 10, NULL, NULL, 3, 5, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('436bd553-b292-5fc6-a3b9-bc8172ad1026', 'PROG-EX012-HEALTH', '懸垂｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'HEALTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('b4dac32e-33b2-5188-a7c6-13c02c2c374f', 'PROG-EX013-HYPERTROPHY', 'アシスト懸垂｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '7a560855-9753-561d-84cb-f821ade60469', 'HYPERTROPHY', 'ALL', 'PG07_ASSISTANCE_REVERSE', 'ASSISTANCE_REVERSE', 8, 20, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('fb06aaf2-bd64-51f5-af75-17703e59a330', 'PROG-EX013-STRENGTH', 'アシスト懸垂｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '7a560855-9753-561d-84cb-f821ade60469', 'STRENGTH', 'ALL', 'PG07_ASSISTANCE_REVERSE', 'ASSISTANCE_REVERSE', 5, 10, NULL, NULL, 3, 5, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('06ceff5e-2e43-5291-90c9-73b606a93399', 'PROG-EX013-HEALTH', 'アシスト懸垂｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '7a560855-9753-561d-84cb-f821ade60469', 'HEALTH', 'ALL', 'PG07_ASSISTANCE_REVERSE', 'ASSISTANCE_REVERSE', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('75f11a78-d613-5a58-a5f1-76d4211cbfaa', 'PROG-EX014-HYPERTROPHY', 'ワンハンドダンベルロウ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd816e412-b368-5a89-b993-e2490b242817', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('8f7faec7-eb42-585a-9c12-ad5224f27784', 'PROG-EX014-STRENGTH', 'ワンハンドダンベルロウ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd816e412-b368-5a89-b993-e2490b242817', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('8c6585a1-3f84-5244-8857-da2aab9f2efa', 'PROG-EX014-HEALTH', 'ワンハンドダンベルロウ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd816e412-b368-5a89-b993-e2490b242817', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('46332b1d-1746-595c-8ba7-da9b93967093', 'PROG-EX015-HYPERTROPHY', 'ベントオーバーダンベルロウ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('a1b3d66e-92d9-51a8-bc25-03fa1ba64826', 'PROG-EX015-STRENGTH', 'ベントオーバーダンベルロウ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('5f28aaf2-4c73-5d8c-b1cc-26d230a36d52', 'PROG-EX015-HEALTH', 'ベントオーバーダンベルロウ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('5b02c0af-885f-5c64-887e-ecda61143fe7', 'PROG-EX016-HYPERTROPHY', 'バーベルロウ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5c937e70-019c-5278-be21-8b2ceef7454b', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0c5a0503-e856-509d-be46-1c4b68faa79f', 'PROG-EX016-STRENGTH', 'バーベルロウ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5c937e70-019c-5278-be21-8b2ceef7454b', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('413e8245-5aa3-5490-96f8-6b771130ea60', 'PROG-EX016-HEALTH', 'バーベルロウ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5c937e70-019c-5278-be21-8b2ceef7454b', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('70def022-cf1d-50f8-9a34-d648ddd2ad8d', 'PROG-EX017-HYPERTROPHY', 'シーテッドケーブルロウ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('773b1614-63a0-5ace-bb84-ae12199a9525', 'PROG-EX017-STRENGTH', 'シーテッドケーブルロウ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('670af453-954c-5c46-914f-9b6652eae535', 'PROG-EX017-HEALTH', 'シーテッドケーブルロウ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('60c9a287-b62f-5ea4-8efc-a5a6f7de3ac7', 'PROG-EX018-HYPERTROPHY', 'チェストサポートロウ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('74fa910e-501d-53a6-9a52-b76b7a7afd61', 'PROG-EX018-STRENGTH', 'チェストサポートロウ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('424d798a-1eeb-50ba-b468-92ea2703e6e0', 'PROG-EX018-HEALTH', 'チェストサポートロウ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('96272505-3426-5c72-b30b-f823a419d20f', 'PROG-EX019-HYPERTROPHY', 'ストレートアームプルダウン｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('aa611c35-1604-5e15-a62f-f6a1810f36af', 'PROG-EX019-STRENGTH', 'ストレートアームプルダウン｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0ac94ce7-8a8e-53cc-bd9c-b3d23446fb7a', 'PROG-EX019-HEALTH', 'ストレートアームプルダウン｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('b5e1a390-5e5d-534f-bf0c-fc7bf7a2b098', 'PROG-EX020-HYPERTROPHY', 'バックエクステンション｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 'HYPERTROPHY', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 10, 15, NULL, NULL, 2, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('4cbf6d0c-dd2e-5e44-83c8-4d7561adb64a', 'PROG-EX020-STRENGTH', 'バックエクステンション｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 'STRENGTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 6, 10, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0c916440-1766-52c3-bc7c-87fc3acb2370', 'PROG-EX020-HEALTH', 'バックエクステンション｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 'HEALTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('ec2d2547-0186-531a-9650-8662513d7633', 'PROG-EX021-HYPERTROPHY', 'ダンベルショルダープレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('79cd4bba-abe7-54ce-9b81-cedfeb8a4f5b', 'PROG-EX021-STRENGTH', 'ダンベルショルダープレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('57d98edf-ee7f-5749-ab91-360e0d846223', 'PROG-EX021-HEALTH', 'ダンベルショルダープレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0669aaf6-7fa9-58ef-8899-f3cd66de23c0', 'PROG-EX022-HYPERTROPHY', 'マシンショルダープレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cd42319a-c019-5368-9135-d14c0c904c32', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('2bfe20fe-036a-5cc9-b9b1-df25afd91fb4', 'PROG-EX022-STRENGTH', 'マシンショルダープレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cd42319a-c019-5368-9135-d14c0c904c32', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('d60c1b09-d02e-5abf-8ec1-59171338ee5e', 'PROG-EX022-HEALTH', 'マシンショルダープレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cd42319a-c019-5368-9135-d14c0c904c32', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('2d0c0da3-9ac1-504b-a75d-3d63d3eb6ff1', 'PROG-EX023-HYPERTROPHY', 'ランドマインプレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8026feac-450b-5ab4-8641-8425d74be75f', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('a20da9d6-d9e0-5f7d-9c6c-d66f3234e82a', 'PROG-EX023-STRENGTH', 'ランドマインプレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8026feac-450b-5ab4-8641-8425d74be75f', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('eea92a38-db01-5a34-8064-67b4c3dfacd7', 'PROG-EX023-HEALTH', 'ランドマインプレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8026feac-450b-5ab4-8641-8425d74be75f', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('bf759245-87cc-5cb2-9c9e-5f759e666a87', 'PROG-EX024-HYPERTROPHY', 'ダンベルサイドレイズ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', 'HYPERTROPHY', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('3789d6f7-f9c9-5046-967c-bca24a406e1f', 'PROG-EX024-STRENGTH', 'ダンベルサイドレイズ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', 'STRENGTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('52f4e023-ddc2-5d36-889b-68b07f1bda00', 'PROG-EX024-HEALTH', 'ダンベルサイドレイズ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', 'HEALTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('2fc65f5a-fefa-5260-96de-bb57593d25d9', 'PROG-EX025-HYPERTROPHY', 'ケーブルサイドレイズ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '86ea1464-f372-502e-8bdd-f94953732cb4', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('d82bc627-1ab5-5616-9d2c-0eb296a90ac4', 'PROG-EX025-STRENGTH', 'ケーブルサイドレイズ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '86ea1464-f372-502e-8bdd-f94953732cb4', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('ae7966d1-761f-547b-8131-b63bd83067a0', 'PROG-EX025-HEALTH', 'ケーブルサイドレイズ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '86ea1464-f372-502e-8bdd-f94953732cb4', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('69a107b1-71d6-5842-925c-1e85883f5534', 'PROG-EX026-HYPERTROPHY', 'フロントレイズ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2346c3e0-d974-5556-a484-b3528dcde3ca', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('d57631a7-6548-5c77-98da-254b025f460e', 'PROG-EX026-STRENGTH', 'フロントレイズ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2346c3e0-d974-5556-a484-b3528dcde3ca', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0d1a4649-5371-5378-8379-c20414c1325f', 'PROG-EX026-HEALTH', 'フロントレイズ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2346c3e0-d974-5556-a484-b3528dcde3ca', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('4c318bda-9b29-529a-83fd-87c7f8816bcf', 'PROG-EX027-HYPERTROPHY', 'ベントオーバーリアレイズ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'HYPERTROPHY', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('97579309-c02e-55c1-8e91-e6be5e14caee', 'PROG-EX027-STRENGTH', 'ベントオーバーリアレイズ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'STRENGTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('c57665ec-49ff-5f21-9c88-bb9c061288a1', 'PROG-EX027-HEALTH', 'ベントオーバーリアレイズ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'HEALTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('f3a2be87-a3c7-5bb2-83cd-226586251053', 'PROG-EX028-HYPERTROPHY', 'リバースペックデック｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '22fd1467-a582-5642-b51f-5a32ed150885', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('b73375e8-b591-5330-82f6-fa97b037ae97', 'PROG-EX028-STRENGTH', 'リバースペックデック｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '22fd1467-a582-5642-b51f-5a32ed150885', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('30ac2755-44b7-53e1-8c7e-38d9f748d862', 'PROG-EX028-HEALTH', 'リバースペックデック｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '22fd1467-a582-5642-b51f-5a32ed150885', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('5d1cfe4c-329a-50fa-b818-343c8556dd04', 'PROG-EX029-HYPERTROPHY', 'フェイスプル｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('699b4981-3ea3-594d-9b72-ba48669fad0c', 'PROG-EX029-STRENGTH', 'フェイスプル｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('cd21f104-9dcc-5698-8c03-6b3ee13fe190', 'PROG-EX029-HEALTH', 'フェイスプル｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('1a33d2ec-0e57-5165-89d6-66dfa7af811a', 'PROG-EX030-HYPERTROPHY', 'アーノルドプレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('705e9b63-16b9-59d9-b6ca-39be39f78ce6', 'PROG-EX030-STRENGTH', 'アーノルドプレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('c9a2b7a7-bb4d-51d0-b85e-b7ec7e2dd950', 'PROG-EX030-HEALTH', 'アーノルドプレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('a171908e-6a24-514f-b5e7-95c28e03ca01', 'PROG-EX031-HYPERTROPHY', 'ダンベルカール｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'da7d770b-d85e-5460-9068-c39bcc546503', 'HYPERTROPHY', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('6abbb4b5-742c-54cc-beff-f9e9e533cbcd', 'PROG-EX031-STRENGTH', 'ダンベルカール｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'da7d770b-d85e-5460-9068-c39bcc546503', 'STRENGTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('3f7a4bbb-116b-5418-b305-01281c57dec8', 'PROG-EX031-HEALTH', 'ダンベルカール｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'da7d770b-d85e-5460-9068-c39bcc546503', 'HEALTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('35037bdb-210e-51c8-9e4f-1d56410bd98f', 'PROG-EX032-HYPERTROPHY', 'ハンマーカール｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'HYPERTROPHY', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('e59c0c14-891b-592b-8709-f8748ed34f1f', 'PROG-EX032-STRENGTH', 'ハンマーカール｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'STRENGTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('634503e1-b1d5-5030-bbe9-e06991c313bc', 'PROG-EX032-HEALTH', 'ハンマーカール｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'HEALTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('e43faea2-bd75-54cf-8e49-bfa1b80e6bdd', 'PROG-EX033-HYPERTROPHY', 'インクラインダンベルカール｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 'HYPERTROPHY', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0352c8fb-3e0f-5802-9b9d-1dfa1c94d969', 'PROG-EX033-STRENGTH', 'インクラインダンベルカール｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 'STRENGTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('17146e06-2d66-5a13-be08-aaced4fc431f', 'PROG-EX033-HEALTH', 'インクラインダンベルカール｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 'HEALTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('a2e4953a-f7c5-5800-a498-606c3ef0c689', 'PROG-EX034-HYPERTROPHY', 'プリーチャーカール｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('baf924ff-0f1e-559f-9c0b-05be150d9ea4', 'PROG-EX034-STRENGTH', 'プリーチャーカール｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('bbb9de95-b0ba-5ebb-9604-c506d35a4c29', 'PROG-EX034-HEALTH', 'プリーチャーカール｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('8636d17e-a925-5819-bd3e-c1560fcfbed5', 'PROG-EX035-HYPERTROPHY', 'リバースカール｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('35042e7d-5652-5645-8562-a52ba08e96b5', 'PROG-EX035-STRENGTH', 'リバースカール｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('63aae845-9b3c-55c3-9efd-b8abaf26c7bd', 'PROG-EX035-HEALTH', 'リバースカール｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('1fce7907-88fb-538b-8e03-e67ab4db9a03', 'PROG-EX036-HYPERTROPHY', 'ケーブルトライセプスプッシュダウン｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '792c2199-002e-5d63-b182-f3b6c645382d', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('ccb10804-5475-55b5-95b0-48d6137c6bee', 'PROG-EX036-STRENGTH', 'ケーブルトライセプスプッシュダウン｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '792c2199-002e-5d63-b182-f3b6c645382d', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('f14493ca-ec1a-5266-9d6a-d0541874830d', 'PROG-EX036-HEALTH', 'ケーブルトライセプスプッシュダウン｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '792c2199-002e-5d63-b182-f3b6c645382d', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('add89124-b7bf-5b1f-a2df-ff4cae782b7a', 'PROG-EX037-HYPERTROPHY', 'オーバーヘッドトライセプスエクステンション｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('c23c26a7-a79e-571a-8f25-cd76f4a60fac', 'PROG-EX037-STRENGTH', 'オーバーヘッドトライセプスエクステンション｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('f952af04-367a-56b2-a736-64abb649305e', 'PROG-EX037-HEALTH', 'オーバーヘッドトライセプスエクステンション｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('1f686df3-4366-560b-ace2-c4af8a9b7531', 'PROG-EX038-HYPERTROPHY', 'ライイングトライセプスエクステンション｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('573e6b5d-2486-5c1e-81c0-c16b60345958', 'PROG-EX038-STRENGTH', 'ライイングトライセプスエクステンション｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('c1adcf1a-b948-51a1-aac5-c5f33b2c0efb', 'PROG-EX038-HEALTH', 'ライイングトライセプスエクステンション｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f826ab1d-6750-5f56-b4be-938133f0222b', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('e69120d7-70fd-54b7-bf14-5d6b34a0c2e4', 'PROG-EX039-HYPERTROPHY', 'クローズグリップベンチプレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '62885afd-971e-53ef-89a0-c5799030d80c', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('9a0cd677-1216-534b-a106-8bcd424639e7', 'PROG-EX039-STRENGTH', 'クローズグリップベンチプレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '62885afd-971e-53ef-89a0-c5799030d80c', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('520cc963-d5f9-5554-84b5-33c000ba5b1c', 'PROG-EX039-HEALTH', 'クローズグリップベンチプレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '62885afd-971e-53ef-89a0-c5799030d80c', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('6ff4651f-cc66-5b6e-b65c-f8ef27d8698e', 'PROG-EX040-HYPERTROPHY', 'リストカール｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('f6131ff6-fa3a-5d11-bcd8-263007edc44f', 'PROG-EX040-STRENGTH', 'リストカール｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('12282bdc-f90e-535c-8c2d-4c1349e0d061', 'PROG-EX040-HEALTH', 'リストカール｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('ca4308bb-dfef-5aa3-9bd6-9b66029df90b', 'PROG-EX041-HYPERTROPHY', 'グルートブリッジ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'HYPERTROPHY', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('260519f4-68fb-5c23-94ad-1249cce4ed09', 'PROG-EX041-STRENGTH', 'グルートブリッジ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'STRENGTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('46fd7976-fc38-507e-bc18-066858b7600a', 'PROG-EX041-HEALTH', 'グルートブリッジ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'HEALTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('eb590017-2ca2-516f-9d53-7bec3ea4d36a', 'PROG-EX042-HYPERTROPHY', 'ヒップスラスト｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('df80248b-cfbb-568b-8f90-2f651cd2b920', 'PROG-EX042-STRENGTH', 'ヒップスラスト｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('e73c52f1-98b8-5653-9b38-92ad66b59f6b', 'PROG-EX042-HEALTH', 'ヒップスラスト｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('5ddc5ac3-f78d-5f69-9852-6e96e9662a55', 'PROG-EX043-HYPERTROPHY', 'ルーマニアンデッドリフト｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('8ee07dcc-b57d-53be-b80b-59b9a5c86ccd', 'PROG-EX043-STRENGTH', 'ルーマニアンデッドリフト｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('f72daeaa-48f5-5620-a8d9-16edb414c850', 'PROG-EX043-HEALTH', 'ルーマニアンデッドリフト｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('1081b74f-182a-584d-93ca-bcbf1cedfb23', 'PROG-EX044-HYPERTROPHY', 'ブルガリアンスプリットスクワット｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '47411e34-b12b-56a7-ba86-478679571626', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('07ede033-9eed-572a-81ce-40bb445296aa', 'PROG-EX044-STRENGTH', 'ブルガリアンスプリットスクワット｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '47411e34-b12b-56a7-ba86-478679571626', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('41b35df9-21eb-556f-bff4-fa13ed86a900', 'PROG-EX044-HEALTH', 'ブルガリアンスプリットスクワット｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '47411e34-b12b-56a7-ba86-478679571626', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 8, 12, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('58b50f56-dab9-5a69-a982-16cf9b9ed79f', 'PROG-EX045-HYPERTROPHY', 'リバースランジ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '426a5860-7e4f-57ef-a18f-959420622f4f', 'HYPERTROPHY', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('8d3e71c6-1477-5f3d-9dec-6cabd24a7642', 'PROG-EX045-STRENGTH', 'リバースランジ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '426a5860-7e4f-57ef-a18f-959420622f4f', 'STRENGTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('88b7bb0a-d898-5b86-8268-3ea02fd53d51', 'PROG-EX045-HEALTH', 'リバースランジ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '426a5860-7e4f-57ef-a18f-959420622f4f', 'HEALTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 12, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('cd92bfb2-387f-52de-831f-3b72e82c3297', 'PROG-EX046-HYPERTROPHY', 'ステップアップ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1761e525-9750-5b12-afe6-de2905489293', 'HYPERTROPHY', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('17f97a8b-cf7d-5ade-ad29-922eacde2ce5', 'PROG-EX046-STRENGTH', 'ステップアップ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1761e525-9750-5b12-afe6-de2905489293', 'STRENGTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('a7dfd559-66e6-520e-8101-7b9ef7bf0d81', 'PROG-EX046-HEALTH', 'ステップアップ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1761e525-9750-5b12-afe6-de2905489293', 'HEALTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 12, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('ae6fe94c-0fff-5925-b019-afb983db9636', 'PROG-EX047-HYPERTROPHY', 'ケーブルプルスルー｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05f04394-df51-55d0-a371-8999be52c9a1', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('1960cdae-0331-57fb-abe4-12bc3d813ac2', 'PROG-EX047-STRENGTH', 'ケーブルプルスルー｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05f04394-df51-55d0-a371-8999be52c9a1', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('1ecce58a-43be-531b-9c94-40da659b537f', 'PROG-EX047-HEALTH', 'ケーブルプルスルー｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05f04394-df51-55d0-a371-8999be52c9a1', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('e8e5073d-302f-53e8-9d11-5aef8f2c9129', 'PROG-EX048-HYPERTROPHY', 'ケーブルキックバック｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('43ffe1a9-c7f8-524d-b8d4-0898c2a8f426', 'PROG-EX048-STRENGTH', 'ケーブルキックバック｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('da5145c9-a219-57a7-bccb-0fc3642cd376', 'PROG-EX048-HEALTH', 'ケーブルキックバック｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('5c8a7d61-a0af-521f-8e61-d54808809347', 'PROG-EX049-HYPERTROPHY', 'ヒップアブダクションマシン｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('d67a090c-dcf1-5ad5-80dc-aad084c403aa', 'PROG-EX049-STRENGTH', 'ヒップアブダクションマシン｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('5e1acab3-e41f-5572-80dd-b197e0e5f6ab', 'PROG-EX049-HEALTH', 'ヒップアブダクションマシン｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('eaffd9dc-b6ed-53e8-bc73-6402e80f3926', 'PROG-EX050-HYPERTROPHY', 'バンドラテラルウォーク｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'HYPERTROPHY', 'ALL', 'PG09_BAND_STEPS', 'BAND_STEPS', 10, 20, NULL, NULL, 2, 4, 75);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('4cd46fd7-53b4-5f8a-a01f-2a2fcb223301', 'PROG-EX050-STRENGTH', 'バンドラテラルウォーク｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'STRENGTH', 'ALL', 'PG09_BAND_STEPS', 'BAND_STEPS', 8, 15, NULL, NULL, 3, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('1ec63b7e-a00a-5c6c-9d16-2454a4508b6a', 'PROG-EX050-HEALTH', 'バンドラテラルウォーク｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'HEALTH', 'ALL', 'PG09_BAND_STEPS', 'BAND_STEPS', 8, 12, NULL, NULL, 2, 3, 75);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('25f85890-83e3-51d4-b85c-1abb7f9d060d', 'PROG-EX051-HYPERTROPHY', '自重スクワット｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'HYPERTROPHY', 'ALL', 'PG11_VARIATION_FIRST', 'VARIATION_FIRST', 8, 20, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('887e52ad-941e-5ba5-ba08-c7b77689f72c', 'PROG-EX051-STRENGTH', '自重スクワット｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'STRENGTH', 'ALL', 'PG11_VARIATION_FIRST', 'VARIATION_FIRST', 5, 10, NULL, NULL, 3, 5, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0c8d9297-3863-5299-80ff-870e1b9428f9', 'PROG-EX051-HEALTH', '自重スクワット｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'HEALTH', 'ALL', 'PG11_VARIATION_FIRST', 'VARIATION_FIRST', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('c7993daa-8d2c-5eae-98c2-fa565612431c', 'PROG-EX052-HYPERTROPHY', 'ゴブレットスクワット｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0c3503d7-be6c-5f8a-a2e7-20348780632d', 'PROG-EX052-STRENGTH', 'ゴブレットスクワット｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('bf47dbd8-bdbe-5af8-993d-ee0530111829', 'PROG-EX052-HEALTH', 'ゴブレットスクワット｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('efc518c7-e988-5bf7-a968-36bcdc98be62', 'PROG-EX053-HYPERTROPHY', 'バーベルバックスクワット｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('f5822322-e70f-5f5b-b6a1-5670ba474077', 'PROG-EX053-STRENGTH', 'バーベルバックスクワット｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('241ba164-a264-5deb-9526-9183595f2202', 'PROG-EX053-HEALTH', 'バーベルバックスクワット｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('b81f5c9f-db03-53e1-87f2-d8af3211e1d8', 'PROG-EX054-HYPERTROPHY', 'フロントスクワット｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'HYPERTROPHY', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('50885ea7-122b-5cf5-8b27-ad80b2b0ddcc', 'PROG-EX054-STRENGTH', 'フロントスクワット｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'STRENGTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('e7096cdc-e7d0-5277-8055-60fa4ba10d69', 'PROG-EX054-HEALTH', 'フロントスクワット｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'HEALTH', 'ALL', 'PG01_WEIGHTED_MAJOR', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('23145678-441a-5c10-948c-b7dcf3c3f0d8', 'PROG-EX055-HYPERTROPHY', 'レッグプレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('9bda3914-bbb1-56d6-9c7b-1963c5d56593', 'PROG-EX055-STRENGTH', 'レッグプレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 3, 8, NULL, NULL, 3, 5, 240);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0f03c15e-53d6-562d-a5d7-c7726eb31b6b', 'PROG-EX055-HEALTH', 'レッグプレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('5470f943-48ed-5536-a3c1-565db3b3d550', 'PROG-EX056-HYPERTROPHY', 'レッグエクステンション｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '25bd9912-890e-574f-ab15-0f1eda43f095', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('efadba57-adf9-5f76-98c3-a07392f15298', 'PROG-EX056-STRENGTH', 'レッグエクステンション｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '25bd9912-890e-574f-ab15-0f1eda43f095', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('c5b562da-d069-52ff-95e5-0f6f8a247578', 'PROG-EX056-HEALTH', 'レッグエクステンション｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '25bd9912-890e-574f-ab15-0f1eda43f095', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('7f1050fb-4671-505b-9e46-27d6da477785', 'PROG-EX057-HYPERTROPHY', 'レッグカール｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('4e74e70c-7c3d-5a5f-9aa2-72c76395ed4d', 'PROG-EX057-STRENGTH', 'レッグカール｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('6edb9c05-9e3e-5e59-91cb-576dba50ab5f', 'PROG-EX057-HEALTH', 'レッグカール｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('998ff84a-1796-5102-b526-ea14958dae45', 'PROG-EX058-HYPERTROPHY', 'ウォーキングランジ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 'HYPERTROPHY', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 3, 4, 150);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('9e81143a-450c-595b-b937-a5444992275c', 'PROG-EX058-STRENGTH', 'ウォーキングランジ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 'STRENGTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 5, 10, NULL, NULL, 3, 4, 180);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('69f25663-fea1-584f-8a42-eb868eda08b7', 'PROG-EX058-HEALTH', 'ウォーキングランジ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 'HEALTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 12, NULL, NULL, 2, 3, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('8d9c2d4f-7352-5ea2-bef4-1fe21f4c0c96', 'PROG-EX059-HYPERTROPHY', 'スタンディングカーフレイズ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 20, NULL, NULL, 3, 5, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('c59973a8-d38c-542d-b574-6d6e3d6dcc88', 'PROG-EX059-STRENGTH', 'スタンディングカーフレイズ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 3, 5, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0b5f4166-d028-51f4-a2f0-7c7b417db881', 'PROG-EX059-HEALTH', 'スタンディングカーフレイズ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('72983a65-b6d6-52d8-bc60-50084266cc65', 'PROG-EX060-HYPERTROPHY', 'シーテッドカーフレイズ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 20, NULL, NULL, 3, 5, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('3c28a6ee-47c9-5c69-a104-f912196cf819', 'PROG-EX060-STRENGTH', 'シーテッドカーフレイズ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 3, 5, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('ebd581f6-986e-5d09-a51c-b211906b5935', 'PROG-EX060-HEALTH', 'シーテッドカーフレイズ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('31084f06-c35c-551c-8118-9f6540fa3928', 'PROG-EX061-HYPERTROPHY', 'クランチ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'HYPERTROPHY', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('bcd03fb9-9c1b-58bd-b187-ae7e8bd45b48', 'PROG-EX061-STRENGTH', 'クランチ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'STRENGTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('62af8509-a456-5cf5-8b44-b342a115b845', 'PROG-EX061-HEALTH', 'クランチ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'HEALTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('43628793-f8cc-59dd-8049-91cbfdb9144e', 'PROG-EX062-HYPERTROPHY', 'ケーブルクランチ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'HYPERTROPHY', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('fa75bd17-8ca3-5207-9dea-2ac3bfc63353', 'PROG-EX062-STRENGTH', 'ケーブルクランチ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'STRENGTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 8, 15, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0b9e2eda-05e3-56e4-bdab-17aa21ab39e3', 'PROG-EX062-HEALTH', 'ケーブルクランチ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'HEALTH', 'ALL', 'PG03_MACHINE_CABLE', 'WEIGHT_REPS', 8, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('19e24eec-d1c9-502d-b072-001c180235d5', 'PROG-EX063-HYPERTROPHY', 'リバースクランチ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'HYPERTROPHY', 'ALL', 'PG05_BODYWEIGHT_REPS', 'REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('be45a281-2e83-52e3-91eb-32f60cd57837', 'PROG-EX063-STRENGTH', 'リバースクランチ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'STRENGTH', 'ALL', 'PG05_BODYWEIGHT_REPS', 'REPS', 8, 15, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('901f6374-d4a0-5a48-bc92-74d282bfabdb', 'PROG-EX063-HEALTH', 'リバースクランチ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'HEALTH', 'ALL', 'PG05_BODYWEIGHT_REPS', 'REPS', 8, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('537e47b9-c01c-5e1f-9a75-1078e08927b4', 'PROG-EX064-HYPERTROPHY', 'ハンギングニーレイズ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'HYPERTROPHY', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('8d2eb20b-4ae6-5158-b2fb-83ed89bdc0a3', 'PROG-EX064-STRENGTH', 'ハンギングニーレイズ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'STRENGTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('326769ed-02d1-5111-9b55-dc7730427a87', 'PROG-EX064-HEALTH', 'ハンギングニーレイズ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'HEALTH', 'ALL', 'PG06_BODYWEIGHT_LOADABLE', 'REPS_LOADABLE', 8, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('2c6f53cc-8858-542b-916c-e6099ddaa516', 'PROG-EX065-HYPERTROPHY', 'プランク｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'HYPERTROPHY', 'ALL', 'PG08_TIME_HOLD', 'DURATION', NULL, NULL, 20, 60, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('db14c0b8-9d99-5b75-a2fa-35efba2ad7f3', 'PROG-EX065-STRENGTH', 'プランク｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'STRENGTH', 'ALL', 'PG08_TIME_HOLD', 'DURATION', NULL, NULL, 20, 45, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('dd3e20d7-f7f1-5920-a2e9-479155478517', 'PROG-EX065-HEALTH', 'プランク｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'HEALTH', 'ALL', 'PG08_TIME_HOLD', 'DURATION', NULL, NULL, 20, 40, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('76b6ed3c-b529-5c19-a0bb-04258a7374a5', 'PROG-EX066-HYPERTROPHY', 'サイドプランク｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5ad48491-19a8-569e-b4ae-459c0ec94498', 'HYPERTROPHY', 'ALL', 'PG08_TIME_HOLD', 'DURATION', NULL, NULL, 20, 60, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('f5814994-f9fa-5b2f-9edd-6417df22cf3b', 'PROG-EX066-STRENGTH', 'サイドプランク｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5ad48491-19a8-569e-b4ae-459c0ec94498', 'STRENGTH', 'ALL', 'PG08_TIME_HOLD', 'DURATION', NULL, NULL, 20, 45, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('dade9691-827b-56d5-b6b4-ae0ecb4ed895', 'PROG-EX066-HEALTH', 'サイドプランク｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5ad48491-19a8-569e-b4ae-459c0ec94498', 'HEALTH', 'ALL', 'PG08_TIME_HOLD', 'DURATION', NULL, NULL, 20, 40, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('0a66f532-6045-5933-ae7b-4d813e84d809', 'PROG-EX067-HYPERTROPHY', 'デッドバグ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'HYPERTROPHY', 'ALL', 'PG05_BODYWEIGHT_REPS', 'REPS', 6, 12, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('2c6faf57-db3a-5453-be5f-711eb10238c2', 'PROG-EX067-STRENGTH', 'デッドバグ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'STRENGTH', 'ALL', 'PG05_BODYWEIGHT_REPS', 'REPS', 6, 10, NULL, NULL, 3, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('56a99a6c-953a-59fe-8f55-1e461b3eb8a9', 'PROG-EX067-HEALTH', 'デッドバグ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'HEALTH', 'ALL', 'PG05_BODYWEIGHT_REPS', 'REPS', 6, 10, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('075af7ed-bea4-5e0e-be25-70b5ba5047d0', 'PROG-EX068-HYPERTROPHY', 'バードドッグ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'HYPERTROPHY', 'ALL', 'PG05_BODYWEIGHT_REPS', 'REPS', 6, 12, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('c794b7b2-258d-5588-acb1-2bc5d802b9df', 'PROG-EX068-STRENGTH', 'バードドッグ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'STRENGTH', 'ALL', 'PG05_BODYWEIGHT_REPS', 'REPS', 6, 10, NULL, NULL, 3, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('b4953ccd-1a57-5a5c-b5e6-39aedf0f7e7d', 'PROG-EX068-HEALTH', 'バードドッグ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'HEALTH', 'ALL', 'PG05_BODYWEIGHT_REPS', 'REPS', 6, 10, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('7f6542eb-6670-5fb3-9ac3-625f48b5c2b3', 'PROG-EX069-HYPERTROPHY', 'パロフプレス｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'HYPERTROPHY', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 12, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('9e3d161d-1374-55c6-997f-9e084f11747d', 'PROG-EX069-STRENGTH', 'パロフプレス｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'STRENGTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 10, NULL, NULL, 3, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('66a22468-58da-5b8a-ad2c-7a8452fbca12', 'PROG-EX069-HEALTH', 'パロフプレス｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'HEALTH', 'ALL', 'PG10_MULTI_MODE', 'MULTI_MODE', 6, 10, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('03ad6827-6ac1-5fe9-b227-e88544a5f5bf', 'PROG-EX070-HYPERTROPHY', 'アブローラー｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'HYPERTROPHY', 'ALL', 'PG11_VARIATION_FIRST', 'VARIATION_FIRST', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('57211398-35c1-575e-be60-14d9fffac001', 'PROG-EX070-STRENGTH', 'アブローラー｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'STRENGTH', 'ALL', 'PG11_VARIATION_FIRST', 'VARIATION_FIRST', 8, 15, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('9881a808-befe-569e-91fb-1a5d6be3645e', 'PROG-EX070-HEALTH', 'アブローラー｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'HEALTH', 'ALL', 'PG11_VARIATION_FIRST', 'VARIATION_FIRST', 8, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('46c24cb9-7ce4-50c6-81ba-00e1bd458b2a', 'PROG-EX071-HYPERTROPHY', 'インクラインダンベルサイドレイズ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '4103b188-119d-5652-86fe-6ab2c343d380', 'HYPERTROPHY', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('e4f6a6d1-ef71-5328-8b5d-032568d0c231', 'PROG-EX071-STRENGTH', 'インクラインダンベルサイドレイズ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '4103b188-119d-5652-86fe-6ab2c343d380', 'STRENGTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('10e78924-5251-5eaa-a985-e5b38b0c9157', 'PROG-EX071-HEALTH', 'インクラインダンベルサイドレイズ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '4103b188-119d-5652-86fe-6ab2c343d380', 'HEALTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('c2d5bacc-b1cd-5016-a161-549a91b19fb8', 'PROG-EX072-HYPERTROPHY', 'インクラインダンベルリアレイズ｜HYPERTROPHY', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 'HYPERTROPHY', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 20, NULL, NULL, 2, 4, 90);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('12312579-4b78-5830-b8ba-f56bb300d3d3', 'PROG-EX072-STRENGTH', 'インクラインダンベルリアレイズ｜STRENGTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 'STRENGTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 6, 12, NULL, NULL, 3, 4, 120);
-- statement
INSERT OR IGNORE INTO exercise_progression_profile (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, goal_code, experience_level_code, progression_group_code, target_mode_code, rep_lower, rep_upper, duration_lower_sec, duration_upper_sec, set_lower, set_upper, rest_sec) VALUES ('b1e89c5f-89a2-517c-ad17-2bbad83769ca', 'PROG-EX072-HEALTH', 'インクラインダンベルリアレイズ｜HEALTH', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 'HEALTH', 'ALL', 'PG02_WEIGHTED_ACCESSORY', 'WEIGHT_REPS', 10, 15, NULL, NULL, 2, 3, 90);
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('c07f28b3-533e-5be5-b5bc-9bb84dfd89dd', 'FORM-EX001', 'インクラインプッシュアップ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '95819265-6d61-5cca-ad80-1609b3a02486', '身体を下ろした位置', '押し上げた位置', '手の間へ胸を下ろし、台を押し離すように戻ります。台が高いほど負荷は軽くなります。', '腰を落とす、首だけを前へ出す、肘を真横へ開きすぎる動作を避けます。台が動かないことを確認します。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e2b7d500-c41b-5f67-8c35-e0ae2d1516fd', 'IMG-EX001-01', 'インクラインプッシュアップ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '95819265-6d61-5cca-ad80-1609b3a02486', 1, 'assets/images/exercises/EX001_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('4fc45999-9248-5cb7-8a68-7210dd7f2ede', 'IMG-EX001-02', 'インクラインプッシュアップ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '95819265-6d61-5cca-ad80-1609b3a02486', 2, 'assets/images/exercises/EX001_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('ca085b45-7e24-5b37-8faa-5c48380f6a6f', 'FORM-EX002', 'プッシュアップ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05c70f4f-6814-55d7-a53b-feac833cfc7d', '身体を下ろした位置', '押し上げた位置', '床を外側へ広げるように手へ力を入れ、胸から床へ近づく意識を持ちます。', '腰が落ちる、肩がすくむ、頭だけを上下させるフォームを避けます。手首に痛みがある場合はプッシュアップバーを検討します。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ed3db606-cf40-55a4-8a16-8d464be9d703', 'IMG-EX002-01', 'プッシュアップ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 1, 'assets/images/exercises/EX002_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('740b09f8-3972-56c9-9649-b90fb304a0a8', 'IMG-EX002-02', 'プッシュアップ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 2, 'assets/images/exercises/EX002_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('5b2ad96b-5ef7-5bc6-a20e-38b31391416c', 'FORM-EX003', 'ダンベルフロアプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '728c22d5-86f9-58b2-b702-73ca968290c8', '肘を下ろした位置', '押し上げた位置', '肩甲骨を軽く寄せ、前腕が床に対してほぼ垂直になる位置へ下ろします。', '肘を床へ打ちつけないようにゆっくり下ろします。床から起き上がる際はダンベルを安全に置きます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('53804351-70f6-5dc0-a579-278a0ea21ff4', 'IMG-EX003-01', 'ダンベルフロアプレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '728c22d5-86f9-58b2-b702-73ca968290c8', 1, 'assets/images/exercises/EX003_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ee5a7203-9be1-5279-954f-a0fb5029be20', 'IMG-EX003-02', 'ダンベルフロアプレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '728c22d5-86f9-58b2-b702-73ca968290c8', 2, 'assets/images/exercises/EX003_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('ef308ab5-d43c-5ec2-9171-d5ab581827eb', 'FORM-EX004', 'ダンベルベンチプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c3be154d-b150-5477-852d-553edd3155b7', '胸付近まで下ろした位置', '押し上げた位置', '肩甲骨を軽く寄せ、胸を張った状態を保ち、前腕がほぼ垂直になる軌道で押します。', '肩が前へ出る、手首が大きく反る、肩に痛みが出る深さまで下ろす動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ef18e354-5892-59ef-a9a3-926f279e77f3', 'IMG-EX004-01', 'ダンベルベンチプレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c3be154d-b150-5477-852d-553edd3155b7', 1, 'assets/images/exercises/EX004_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('5aaf4234-b150-52aa-9e8c-9653bb37e695', 'IMG-EX004-02', 'ダンベルベンチプレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c3be154d-b150-5477-852d-553edd3155b7', 2, 'assets/images/exercises/EX004_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('dfa89106-c0cc-50b5-b3e1-982e97257284', 'FORM-EX005', 'インクラインダンベルプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c4e220e7-0ec4-503b-8200-468acd7628f5', '胸上部まで下ろした位置', '押し上げた位置', 'ベンチ角度は30〜45度程度を目安にし、肩甲骨を軽く寄せたまま押します。', '角度を高くしすぎると肩中心になりやすいため、肩をすくめず、痛みが出る深さまで下ろしません。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('f3c0c800-3e70-5e85-8a39-5b2817e6604a', 'IMG-EX005-01', 'インクラインダンベルプレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 1, 'assets/images/exercises/EX005_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('955b9681-5667-5399-a670-375bc451c6e1', 'IMG-EX005-02', 'インクラインダンベルプレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 2, 'assets/images/exercises/EX005_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('bfc7cbe3-ad2e-56bb-b568-2565bee52bd8', 'FORM-EX006', 'バーベルベンチプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '胸付近まで下ろした位置', '押し上げた位置', '足、背中、肩甲骨を安定させ、毎回ほぼ同じ位置へバーを下ろします。', '胸でバーを弾ませません。高重量ではセーフティまたは補助者を使用し、親指を巻いて握ります。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('420a4c59-797f-5ccd-9178-03777c9c39f6', 'IMG-EX006-01', 'バーベルベンチプレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 1, 'assets/images/exercises/EX006_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('39c90cd4-4dff-51c5-ab19-6d06fd9ff798', 'IMG-EX006-02', 'バーベルベンチプレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 2, 'assets/images/exercises/EX006_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('d7c5c831-8895-54ff-a0e3-4557b87f615d', 'FORM-EX007', 'マシンチェストプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'ハンドルを戻した位置', '押し出した位置', '背中をパッドにつけ、胸を軽く張った状態で動かします。', '肩が前へ巻き込まれる位置まで深く戻さず、肘を強く伸ばし切りません。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('6a4ca09a-3c04-57de-9523-10e08ad5645a', 'IMG-EX007-01', 'マシンチェストプレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 1, 'assets/images/exercises/EX007_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('79f1cbbf-dd68-5eae-9804-bc6e2d46b62d', 'IMG-EX007-02', 'マシンチェストプレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 2, 'assets/images/exercises/EX007_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('9b7bfe8e-f713-5f66-a340-4b2b6bd3683e', 'FORM-EX008', 'ダンベルフライ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '16228203-ecfa-552d-b068-6a645dacc7ba', '腕を開いた位置', '腕を閉じた位置', '肘の角度を大きく変えず、上腕を胸の力で内側へ動かす意識を持ちます。', '肘を下げすぎると肩への負担が増えます。重い重量や過度な可動域を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('f9e83a7c-f9ca-5d0d-bf50-0965b22bbd68', 'IMG-EX008-01', 'ダンベルフライ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '16228203-ecfa-552d-b068-6a645dacc7ba', 1, 'assets/images/exercises/EX008_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('f278b3f1-5d80-5663-a74c-334702679833', 'IMG-EX008-02', 'ダンベルフライ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '16228203-ecfa-552d-b068-6a645dacc7ba', 2, 'assets/images/exercises/EX008_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('37566b3f-69dd-5a8f-8a67-be2d24db4821', 'FORM-EX009', 'ペックデックフライ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', '腕を開いた位置', '腕を閉じた位置', '胸を張り、両肘または両腕を近づけるように動かします。', '肩を前へ突き出す、反動を使う、深く戻しすぎる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e0f7d257-c5e1-5aff-9045-3af009abdebf', 'IMG-EX009-01', 'ペックデックフライ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 1, 'assets/images/exercises/EX009_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('5b886044-4bc1-5681-9bf6-389a6716239c', 'IMG-EX009-02', 'ペックデックフライ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 2, 'assets/images/exercises/EX009_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('99c0fe4e-099f-5c44-8248-21c5ed7a0968', 'FORM-EX010', 'ケーブルフライ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '87e7212a-24cb-5424-8c54-44c43d7abcdd', '腕を開いた位置', '腕を閉じた位置', '肘の角度を保ち、閉じた位置で胸を短く収縮させます。', '重量を重くしすぎて上体を大きく前後させないようにします。肩に違和感が出る深さを避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('1ac55b00-bf46-5021-8f88-15c0523f7ef9', 'IMG-EX010-01', 'ケーブルフライ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 1, 'assets/images/exercises/EX010_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('48e1adb5-f500-5708-908a-4be93f3f67e9', 'IMG-EX010-02', 'ケーブルフライ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 2, 'assets/images/exercises/EX010_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('cce33c31-bbe6-533f-b3aa-dced750d246c', 'FORM-EX011', 'ラットプルダウン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '03040c5e-0485-5937-b86e-c7472ec6d488', '腕を伸ばした位置', 'バーを引いた位置', '手で引くより、肘を腰へ近づける意識で動かします。', '首の後ろへ引く、上体を大きく反らす、反動を使う動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('8d34ecbc-b37b-5ad9-85f0-275acd185ab7', 'IMG-EX011-01', 'ラットプルダウン 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '03040c5e-0485-5937-b86e-c7472ec6d488', 1, 'assets/images/exercises/EX011_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('af887f11-1171-5e9b-9727-a577a9ae6d4f', 'IMG-EX011-02', 'ラットプルダウン 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '03040c5e-0485-5937-b86e-c7472ec6d488', 2, 'assets/images/exercises/EX011_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('58ff0703-12c6-5304-bb89-ffe489dd0ab1', 'FORM-EX012', '懸垂', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '69163398-4c97-5cd9-aa6b-f24bf952f178', '腕を伸ばした位置', '身体を引き上げた位置', '肩をすくめたまま引かず、肩甲骨を下げてから肘を下方向へ引きます。', '身体を大きく振る、首だけをバーの上へ出す、急に落下する動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e3e5aa9b-df50-5a12-a138-2fb78ca523e7', 'IMG-EX012-01', '懸垂 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '69163398-4c97-5cd9-aa6b-f24bf952f178', 1, 'assets/images/exercises/EX012_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('7a6ab07f-ac36-5025-a918-ac14441b7e94', 'IMG-EX012-02', '懸垂 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '69163398-4c97-5cd9-aa6b-f24bf952f178', 2, 'assets/images/exercises/EX012_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('f143fa7c-c288-53f0-8733-e74bfb1f9405', 'FORM-EX013', 'アシスト懸垂', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '7a560855-9753-561d-84cb-f821ade60469', '腕を伸ばした位置', '身体を引き上げた位置', '補助に身体を任せすぎず、最後まで自分で肘を引く意識を持ちます。', 'マシンでは補助重量が大きいほど負荷が軽くなります。バンド使用時は足元の外れに注意します。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('4054f70c-23ba-5a07-bbb5-a1a383436706', 'IMG-EX013-01', 'アシスト懸垂 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '7a560855-9753-561d-84cb-f821ade60469', 1, 'assets/images/exercises/EX013_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('b915cd0f-a507-5223-b622-6f41ac054c1d', 'IMG-EX013-02', 'アシスト懸垂 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '7a560855-9753-561d-84cb-f821ade60469', 2, 'assets/images/exercises/EX013_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('76754815-23b5-596a-a300-d7f72010ee22', 'FORM-EX014', 'ワンハンドダンベルロウ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd816e412-b368-5a89-b993-e2490b242817', '腕を伸ばした位置', '肘を引いた位置', '肘を腰方向へ引くと広背筋、やや外側へ引くと背中中央部を意識しやすくなります。', '上体を大きくひねる、肩をすくめる、腰を丸める動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('89179325-cd42-5ee7-a223-61257b213a07', 'IMG-EX014-01', 'ワンハンドダンベルロウ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd816e412-b368-5a89-b993-e2490b242817', 1, 'assets/images/exercises/EX014_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('47ff9b6e-8477-5bb2-b8e7-27dd4a1bb5b1', 'IMG-EX014-02', 'ワンハンドダンベルロウ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd816e412-b368-5a89-b993-e2490b242817', 2, 'assets/images/exercises/EX014_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('eacc2c37-7f6f-512a-b5d8-e22adb11385a', 'FORM-EX015', 'ベントオーバーダンベルロウ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1007e08b-3351-536d-afe4-0bcce09aa6ce', '腕を伸ばした位置', '肘を引いた位置', '背中の角度を維持し、ダンベルを下腹部方向へ引きます。', '疲労によって腰が丸まり始めた場合は重量を下げるか、胸を支える種目へ変更します。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('be18f1b1-c9b7-5579-84f4-fdf2e807e404', 'IMG-EX015-01', 'ベントオーバーダンベルロウ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 1, 'assets/images/exercises/EX015_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('472ffb76-2d82-5802-9dd4-1b7809e99895', 'IMG-EX015-02', 'ベントオーバーダンベルロウ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 2, 'assets/images/exercises/EX015_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('faf0d149-0fff-57dd-9053-f6d15cf80052', 'FORM-EX016', 'バーベルロウ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5c937e70-019c-5278-be21-8b2ceef7454b', 'バーを下げた位置', 'バーを引いた位置', '足裏で床を踏み、胴体の角度を固定したまま肘を後方へ引きます。', '上体を勢いよく起こす、腰を丸める、バーを急に落とす動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('10f093dd-27ed-5c1f-8167-a9e6bd7a52ae', 'IMG-EX016-01', 'バーベルロウ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5c937e70-019c-5278-be21-8b2ceef7454b', 1, 'assets/images/exercises/EX016_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('9609b8b4-c5c2-56f3-8e9f-5d87236e697b', 'IMG-EX016-02', 'バーベルロウ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5c937e70-019c-5278-be21-8b2ceef7454b', 2, 'assets/images/exercises/EX016_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('9a52b7ec-b746-5b86-977d-2bf8b3de9d8b', 'FORM-EX017', 'シーテッドケーブルロウ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '腕を伸ばした位置', 'ハンドルを引いた位置', '胸を軽く張り、肩をすくめずに肘を身体の後ろへ通します。', '上体を大きく前後させて重量を動かさないようにします。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('c428f47a-a422-5f5c-aa04-833357996457', 'IMG-EX017-01', 'シーテッドケーブルロウ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 1, 'assets/images/exercises/EX017_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('66921653-2bed-5f8a-bf7a-7f6909114140', 'IMG-EX017-02', 'シーテッドケーブルロウ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 2, 'assets/images/exercises/EX017_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('8f6d18df-1558-5655-9d40-2bb57adaa821', 'FORM-EX018', 'チェストサポートロウ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0fef9047-fefc-58ed-a78e-bae3af9f179b', '腕を伸ばした位置', '肘を引いた位置', '胸をパッドから離さず、肘を後方へ引きます。', '首を強く反らす、肩をすくめる、可動域を極端に小さくする動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('aa3c5873-8e05-5104-a111-001f8d7156b3', 'IMG-EX018-01', 'チェストサポートロウ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 1, 'assets/images/exercises/EX018_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('d46bc1dc-17db-5ee9-8247-73215f05f780', 'IMG-EX018-02', 'チェストサポートロウ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 2, 'assets/images/exercises/EX018_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('e673fb9d-83c0-513a-a077-bb144b536dd7', 'FORM-EX019', 'ストレートアームプルダウン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', '腕を上げた位置', '腕を下ろした位置', '腕で押すより、脇を閉じるように広背筋で動かします。', '腰を反りすぎる、肘を大きく曲げてプレスダウンのようになる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('9df6b948-275a-5400-beb9-e14002bc0fa8', 'IMG-EX019-01', 'ストレートアームプルダウン 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 1, 'assets/images/exercises/EX019_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('3c2e050d-6a48-521c-92ac-4bae95ff7bff', 'IMG-EX019-02', 'ストレートアームプルダウン 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', 2, 'assets/images/exercises/EX019_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('e2a405bb-b830-5744-af58-22bdb3fa2eb5', 'FORM-EX020', 'バックエクステンション', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f6a68de0-bee5-5265-84e4-dea9acafae28', '上体を下ろした位置', '身体を一直線にした位置', '腰だけではなく股関節から身体を折り、上体は一直線まで戻します。', '上体を必要以上に反らす、反動で起き上がる動作を避けます。腰痛がある場合は無理に採用しません。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('c53868cc-2bca-5cdb-89f2-1317ea61ad3c', 'IMG-EX020-01', 'バックエクステンション 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 1, 'assets/images/exercises/EX020_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('f13d7d2f-cb20-5c46-ac82-e48ec071acf7', 'IMG-EX020-02', 'バックエクステンション 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 2, 'assets/images/exercises/EX020_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('5baddff9-b053-52b7-af0f-85e748d7bb8e', 'FORM-EX021', 'ダンベルショルダープレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', '肩の横で構えた位置', '頭上へ押した位置', '前腕を垂直に保ち、肩をすくめずに押します。', '腰を大きく反る、肘を極端に後ろへ引く、痛みが出る深さまで下ろす動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('62982e59-c287-5805-8772-6072a7398b14', 'IMG-EX021-01', 'ダンベルショルダープレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 1, 'assets/images/exercises/EX021_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e42796d3-6f77-5c5a-9078-2aac5d04dfca', 'IMG-EX021-02', 'ダンベルショルダープレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 2, 'assets/images/exercises/EX021_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('c894c169-b614-5070-8df9-ae8154f6ecb4', 'FORM-EX022', 'マシンショルダープレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cd42319a-c019-5368-9135-d14c0c904c32', 'ハンドルを下ろした位置', '頭上へ押した位置', '背中をパッドにつけ、手首と肘を安定させて押します。', '座席が低すぎて肩が深く下がりすぎないようにし、肘を強く伸ばし切りません。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('dce3efc8-6b9c-5cfb-89ba-2f6e7609d2a4', 'IMG-EX022-01', 'マシンショルダープレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cd42319a-c019-5368-9135-d14c0c904c32', 1, 'assets/images/exercises/EX022_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ba27f33e-c188-54f8-8f0c-5584be9617af', 'IMG-EX022-02', 'マシンショルダープレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'cd42319a-c019-5368-9135-d14c0c904c32', 2, 'assets/images/exercises/EX022_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('ee07480b-d79f-5c52-af15-f7edd51eb989', 'FORM-EX023', 'ランドマインプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8026feac-450b-5ab4-8641-8425d74be75f', '肩付近で構えた位置', '斜め上へ押した位置', '肩甲骨が自然に動くように、腕を斜め前へ伸ばします。', '腰をひねる、身体を大きく反らす、バーを顔へ近づけすぎる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('a051f24f-ebea-5ad6-846d-71ad7dd79a1e', 'IMG-EX023-01', 'ランドマインプレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8026feac-450b-5ab4-8641-8425d74be75f', 1, 'assets/images/exercises/EX023_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ddd40570-3ce4-5bf7-baaa-fde05b417df9', 'IMG-EX023-02', 'ランドマインプレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8026feac-450b-5ab4-8641-8425d74be75f', 2, 'assets/images/exercises/EX023_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('6a617bbc-9f2a-5069-a55d-995b166635af', 'FORM-EX024', 'ダンベルサイドレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', '腕を下ろした位置', '腕を上げた位置', '手ではなく肘を外側へ持ち上げる意識を持ち、軽く前方の軌道で上げます。', '肩をすくめる、反動を使う、手だけを極端に高くする動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e80c4217-508d-5f9d-ae8d-ae6dae081068', 'IMG-EX024-01', 'ダンベルサイドレイズ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', 1, 'assets/images/exercises/EX024_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('f1e52153-1447-5629-9c86-6b4432991091', 'IMG-EX024-02', 'ダンベルサイドレイズ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', 2, 'assets/images/exercises/EX024_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('522185ec-5755-5eb8-912a-a780b2c71f64', 'FORM-EX025', 'ケーブルサイドレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '86ea1464-f372-502e-8bdd-f94953732cb4', '腕を下ろした位置', '腕を上げた位置', '開始位置から負荷が抜けない範囲で、ゆっくり動かします。', '身体を大きく傾ける、勢いよくケーブルを引く動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('57aebb26-9de5-570e-9cd8-143d5af6eaf0', 'IMG-EX025-01', 'ケーブルサイドレイズ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '86ea1464-f372-502e-8bdd-f94953732cb4', 1, 'assets/images/exercises/EX025_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e7141d68-0399-584f-a30a-41868e69650b', 'IMG-EX025-02', 'ケーブルサイドレイズ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '86ea1464-f372-502e-8bdd-f94953732cb4', 2, 'assets/images/exercises/EX025_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('c10b7ab6-a426-5344-83fc-96c7af864148', 'FORM-EX026', 'フロントレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2346c3e0-d974-5556-a484-b3528dcde3ca', '腕を下ろした位置', '腕を前へ上げた位置', '肘を軽く曲げ、肩の前側から腕を持ち上げます。', '腰を反って勢いをつける、肩より極端に高く上げる動作を避けます。プレス種目が多い場合は重複に注意します。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('8405b0d3-926c-58b2-84ab-43829eb7ef32', 'IMG-EX026-01', 'フロントレイズ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2346c3e0-d974-5556-a484-b3528dcde3ca', 1, 'assets/images/exercises/EX026_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('38b2bf83-9c3d-523e-a431-a4026fb37724', 'IMG-EX026-02', 'フロントレイズ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2346c3e0-d974-5556-a484-b3528dcde3ca', 2, 'assets/images/exercises/EX026_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('74b4b4f5-6cf6-57df-bdbc-e752daae41ec', 'FORM-EX027', 'ベントオーバーリアレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', '腕を下ろした位置', '腕を開いた位置', '手ではなく肘を外側へ広げる意識を持ちます。', '肩甲骨を強く寄せすぎると背中中心になりやすくなります。腰が丸まる場合は胸を支える姿勢へ変更します。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('8cc15b8f-8aaa-511e-91a7-26fe217b00ec', 'IMG-EX027-01', 'ベントオーバーリアレイズ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 1, 'assets/images/exercises/EX027_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('0f037804-7213-5e35-8ea1-ab45f5a1d64a', 'IMG-EX027-02', 'ベントオーバーリアレイズ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 2, 'assets/images/exercises/EX027_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('472335bf-8720-5057-98d0-04be8cfa2c9e', 'FORM-EX028', 'リバースペックデック', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '22fd1467-a582-5642-b51f-5a32ed150885', '腕を前へ置いた位置', '腕を開いた位置', '胸をパッドへ固定し、肘を後ろへ広げます。', '重量を上げすぎて可動域が小さくならないようにし、肩をすくめません。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ecf0118d-ca40-5d9b-8c03-ecf222a37242', 'IMG-EX028-01', 'リバースペックデック 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '22fd1467-a582-5642-b51f-5a32ed150885', 1, 'assets/images/exercises/EX028_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('150cb72f-c222-5918-827a-b9f4ac274b81', 'IMG-EX028-02', 'リバースペックデック 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '22fd1467-a582-5642-b51f-5a32ed150885', 2, 'assets/images/exercises/EX028_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('99b1eaae-270f-50d2-afb0-c178e02f7bc6', 'FORM-EX029', 'フェイスプル', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', '腕を伸ばした位置', '顔の横へ引いた位置', '肘を肩の高さ付近へ保ち、ロープを目や額の方向へ引きます。', '腰を反る、肩をすくめる、ロープを胸へ引く動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('3acee736-b895-51b4-935e-78ca44e0313b', 'IMG-EX029-01', 'フェイスプル 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 1, 'assets/images/exercises/EX029_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('6b0f5006-5afa-52e7-ac8c-45760069ec77', 'IMG-EX029-02', 'フェイスプル 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 2, 'assets/images/exercises/EX029_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('b04f49e4-8997-5298-ab2d-1de7031b6bdb', 'FORM-EX030', 'アーノルドプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', '顔の前で構えた位置', '頭上へ押した位置', '軽めの重量で、腕の回転とプレスを滑らかにつなげます。', '肩に違和感がある場合は無理に採用せず、通常のショルダープレスへ変更します。腰を反らしません。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('58402fde-9668-59b6-b4b5-b0d5aa0d96db', 'IMG-EX030-01', 'アーノルドプレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 1, 'assets/images/exercises/EX030_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('5e695fc4-7008-5c07-9ebf-f3151c8a4594', 'IMG-EX030-02', 'アーノルドプレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 2, 'assets/images/exercises/EX030_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('7ece467d-3800-5d6e-a5df-9f35fcbc3d8c', 'FORM-EX031', 'ダンベルカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'da7d770b-d85e-5460-9068-c39bcc546503', '肘を伸ばした位置', '肘を曲げた位置', '肘の位置を固定し、上腕二頭筋で前腕を動かします。', '上体を反らす、肘を大きく前へ動かす、急に下ろす動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('aba99902-71b1-5b69-a473-a48ccc94fa28', 'IMG-EX031-01', 'ダンベルカール 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'da7d770b-d85e-5460-9068-c39bcc546503', 1, 'assets/images/exercises/EX031_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('27488844-2ecb-5cc7-964b-c253ede151e7', 'IMG-EX031-02', 'ダンベルカール 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'da7d770b-d85e-5460-9068-c39bcc546503', 2, 'assets/images/exercises/EX031_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('c1241e3b-b84f-5446-990e-e979fbd509c8', 'FORM-EX032', 'ハンマーカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '731ac79c-b789-5809-bd32-486d0f7c9c28', '肘を伸ばした位置', '肘を曲げた位置', '親指側を上へ向けた握りを維持します。', '手首を曲げる、肩で持ち上げる、反動を使う動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('fd215838-9f4e-58f8-9df6-46e289865f0d', 'IMG-EX032-01', 'ハンマーカール 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '731ac79c-b789-5809-bd32-486d0f7c9c28', 1, 'assets/images/exercises/EX032_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('c9b73070-0b37-5d16-9fe9-8bf62835421a', 'IMG-EX032-02', 'ハンマーカール 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '731ac79c-b789-5809-bd32-486d0f7c9c28', 2, 'assets/images/exercises/EX032_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('848eb9a1-d121-513d-b802-757c7aa54489', 'FORM-EX033', 'インクラインダンベルカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', '腕を伸ばした位置', '肘を曲げた位置', '上腕を身体の後ろ側に保ち、肘の位置を動かさずに曲げます。', '肩を前へ出す、肘を持ち上げる、重すぎる重量を使う動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('14e42365-7d86-5447-b331-99f3e011620c', 'IMG-EX033-01', 'インクラインダンベルカール 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 1, 'assets/images/exercises/EX033_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('d0c57de0-3d35-5de3-a285-bda38a924faf', 'IMG-EX033-02', 'インクラインダンベルカール 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 2, 'assets/images/exercises/EX033_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('df75197f-f1f8-5462-8850-5c6198945382', 'FORM-EX034', 'プリーチャーカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8ed32064-eb89-590b-ad11-85cdfbb15794', '肘を伸ばした位置', '肘を曲げた位置', '上腕をパッドから離さず、下ろす動作をゆっくり行います。', '肘を伸ばした位置で急に力を抜かず、重すぎる重量を使いません。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('b10dabd8-70c8-5867-a628-e5505b9b8a36', 'IMG-EX034-01', 'プリーチャーカール 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8ed32064-eb89-590b-ad11-85cdfbb15794', 1, 'assets/images/exercises/EX034_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('998fbe01-94b1-5dc3-bd9c-9f252e1da893', 'IMG-EX034-02', 'プリーチャーカール 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '8ed32064-eb89-590b-ad11-85cdfbb15794', 2, 'assets/images/exercises/EX034_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('2e30b260-efb4-508d-acd4-f984e08ccab0', 'FORM-EX035', 'リバースカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', '肘を伸ばした位置', '肘を曲げた位置', '手首をまっすぐ保ち、肘を身体の横へ固定します。', '通常のカールより軽い重量から始め、手首を反らしません。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('bc14759f-be50-5f1a-b038-70469502dd37', 'IMG-EX035-01', 'リバースカール 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 1, 'assets/images/exercises/EX035_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('726e55da-e82d-59cb-9f45-03a4c38b6e9c', 'IMG-EX035-02', 'リバースカール 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 2, 'assets/images/exercises/EX035_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('18e439ca-6e50-5261-a584-969bb855b27d', 'FORM-EX036', 'ケーブルトライセプスプッシュダウン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '792c2199-002e-5d63-b182-f3b6c645382d', '肘を曲げた位置', '肘を伸ばした位置', '下で肘を伸ばし、上腕三頭筋を短く収縮させます。', '肘を前後へ動かす、肩で押す、上体を大きく倒す動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('b2005313-1a89-5a47-af9e-cf32fa82900e', 'IMG-EX036-01', 'ケーブルトライセプスプッシュダウン 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '792c2199-002e-5d63-b182-f3b6c645382d', 1, 'assets/images/exercises/EX036_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('02db47a5-e6c5-5221-9a90-582aa4242c58', 'IMG-EX036-02', 'ケーブルトライセプスプッシュダウン 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '792c2199-002e-5d63-b182-f3b6c645382d', 2, 'assets/images/exercises/EX036_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('d8ea018e-18ba-535e-8671-8bc7adc0c548', 'FORM-EX037', 'オーバーヘッドトライセプスエクステンション', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '6c86e230-f576-5e6e-a316-36ff2c7546bf', '肘を曲げた位置', '肘を伸ばした位置', '上腕の位置を固定し、肘を正面方向へ向けます。', '腰を反る、肘を大きく開く、肩に痛みが出る深さまで下ろす動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('dd904433-7bb3-594c-ab1e-4779016bb3ef', 'IMG-EX037-01', 'オーバーヘッドトライセプスエクステンション 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 1, 'assets/images/exercises/EX037_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('f2867174-fe54-53ff-8b98-6fc615be70fd', 'IMG-EX037-02', 'オーバーヘッドトライセプスエクステンション 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '6c86e230-f576-5e6e-a316-36ff2c7546bf', 2, 'assets/images/exercises/EX037_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('0b678f49-6c4a-5236-9099-5b4fdffaaa85', 'FORM-EX038', 'ライイングトライセプスエクステンション', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f826ab1d-6750-5f56-b4be-938133f0222b', '肘を曲げた位置', '肘を伸ばした位置', '上腕を安定させ、肘の曲げ伸ばしを中心に動かします。', '重量を顔へ落とさないよう無理のない重量と安定した握りで行い、肘に痛みがある場合は変更します。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('8ed2072e-9115-5cd4-a847-9d05ce56105d', 'IMG-EX038-01', 'ライイングトライセプスエクステンション 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f826ab1d-6750-5f56-b4be-938133f0222b', 1, 'assets/images/exercises/EX038_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('03d5bc40-bd6a-5fe1-b179-555e9883c1ed', 'IMG-EX038-02', 'ライイングトライセプスエクステンション 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f826ab1d-6750-5f56-b4be-938133f0222b', 2, 'assets/images/exercises/EX038_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('1048a354-e317-52c3-bd76-402d5be604ae', 'FORM-EX039', 'クローズグリップベンチプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '62885afd-971e-53ef-89a0-c5799030d80c', '胸付近まで下ろした位置', '押し上げた位置', '肘を身体へ適度に近づけ、上腕三頭筋で押します。', '手幅を狭くしすぎて手首へ負担をかけないようにし、高重量ではセーフティを使用します。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('4c9697a2-5280-5f39-b289-d6d5241095a4', 'IMG-EX039-01', 'クローズグリップベンチプレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '62885afd-971e-53ef-89a0-c5799030d80c', 1, 'assets/images/exercises/EX039_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e57f55fd-7636-5c34-9529-54a7e80d509b', 'IMG-EX039-02', 'クローズグリップベンチプレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '62885afd-971e-53ef-89a0-c5799030d80c', 2, 'assets/images/exercises/EX039_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('dbd8a555-9d32-5fe1-bc31-4d7b952f3de9', 'FORM-EX040', 'リストカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', '手首を伸ばした位置', '手首を曲げた位置', '前腕を動かさず、手首だけをゆっくり動かします。', '可動域を無理に広げる、反動を使う、重すぎる重量を使う動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ea434164-fb59-55dd-b7ba-a4d30a78c1a2', 'IMG-EX040-01', 'リストカール 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 1, 'assets/images/exercises/EX040_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('4ca263ba-2dc2-5c03-b7b0-97ccf4255869', 'IMG-EX040-02', 'リストカール 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 2, 'assets/images/exercises/EX040_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('392b3b7f-505f-5d5e-9bc4-57759d5fc7dc', 'FORM-EX041', 'グルートブリッジ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '35e88355-a311-5689-94d2-e04d60a4fdcf', '腰を下ろした位置', '腰を上げた位置', '上でお尻を締め、肋骨を開きすぎないようにします。', '腰を強く反って高さを出さず、膝が内側へ入らないようにします。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('bc3eb23a-2c25-5daf-8d11-f8994e7af912', 'IMG-EX041-01', 'グルートブリッジ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '35e88355-a311-5689-94d2-e04d60a4fdcf', 1, 'assets/images/exercises/EX041_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('871592eb-3478-5589-aba1-8b108e135874', 'IMG-EX041-02', 'グルートブリッジ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '35e88355-a311-5689-94d2-e04d60a4fdcf', 2, 'assets/images/exercises/EX041_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('db50474e-52eb-54fb-ba97-bab60ecc7d85', 'FORM-EX042', 'ヒップスラスト', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '腰を下ろした位置', '腰を上げた位置', 'あごを軽く引き、上で胴体と太ももが一直線になる位置まで上げます。', '腰を反る、足が遠すぎる・近すぎる、パッドなしでバーを当てる状態を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('70142149-8cfb-5783-ad42-ad55249762de', 'IMG-EX042-01', 'ヒップスラスト 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 1, 'assets/images/exercises/EX042_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('86c5e10d-7649-59c8-b317-5ff3be4c7385', 'IMG-EX042-02', 'ヒップスラスト 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 2, 'assets/images/exercises/EX042_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('ef3506d3-0eb4-587a-b090-5e72862a31d1', 'FORM-EX043', 'ルーマニアンデッドリフト', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', '直立した位置', '股関節を後ろへ引いた位置', '背中の形を保ち、お尻を後方へ突き出すように動かします。', '重量を床まで無理に下ろす、腰を丸める、スクワットのように膝を深く曲げる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('5d29fa3d-ef36-51b5-9aff-5e2a5b6bc30c', 'IMG-EX043-01', 'ルーマニアンデッドリフト 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 1, 'assets/images/exercises/EX043_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('22152ddd-daff-5bb1-b283-9caa8ed435a0', 'IMG-EX043-02', 'ルーマニアンデッドリフト 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 2, 'assets/images/exercises/EX043_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('0a3241b8-f9e0-5dec-b782-aed2ca1631a1', 'FORM-EX044', 'ブルガリアンスプリットスクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '47411e34-b12b-56a7-ba86-478679571626', '腰を下ろした位置', '立ち上がった位置', '上体を少し前傾させ、前脚の足裏全体で押すとお尻を使いやすくなります。', '足幅が狭すぎる、膝が内側へ入る、バランスが不安定な状態で高重量を使うことを避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('43e88695-2f19-548a-8747-82a2d1b3490c', 'IMG-EX044-01', 'ブルガリアンスプリットスクワット 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '47411e34-b12b-56a7-ba86-478679571626', 1, 'assets/images/exercises/EX044_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('aa38b772-ba8e-523d-b3d9-2bee0d58fea8', 'IMG-EX044-02', 'ブルガリアンスプリットスクワット 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '47411e34-b12b-56a7-ba86-478679571626', 2, 'assets/images/exercises/EX044_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('511d3593-49bb-5278-8f55-873d6424d8a9', 'FORM-EX045', 'リバースランジ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '426a5860-7e4f-57ef-a18f-959420622f4f', '後ろへ踏み込んだ位置', '立ち上がった位置', '前脚へ体重を残し、前脚のお尻で床を押します。', '前脚の膝が内側へ入る、後ろ足で強く蹴って戻る動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('f89c0ba5-0b17-5257-9f10-95cfc524f341', 'IMG-EX045-01', 'リバースランジ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '426a5860-7e4f-57ef-a18f-959420622f4f', 1, 'assets/images/exercises/EX045_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('db407ef9-50b6-5a09-aa99-987a8b59fe7b', 'IMG-EX045-02', 'リバースランジ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '426a5860-7e4f-57ef-a18f-959420622f4f', 2, 'assets/images/exercises/EX045_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('62a5d0d0-404f-5f36-a431-94881899e5a6', 'FORM-EX046', 'ステップアップ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1761e525-9750-5b12-afe6-de2905489293', '台へ足を置いた位置', '台へ立ち上がった位置', '台上の脚を主に使い、床側の脚で強く蹴らないようにします。', '高すぎる台を使う、膝が内側へ入る、勢いで飛び乗る動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e23351e7-77f7-5c45-8729-4b2cfb01eb60', 'IMG-EX046-01', 'ステップアップ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1761e525-9750-5b12-afe6-de2905489293', 1, 'assets/images/exercises/EX046_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('d5d36258-a595-52f6-9bdc-949de21405bd', 'IMG-EX046-02', 'ステップアップ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1761e525-9750-5b12-afe6-de2905489293', 2, 'assets/images/exercises/EX046_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('12ef4630-79ad-50d0-9224-e36bc2979b40', 'FORM-EX047', 'ケーブルプルスルー', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05f04394-df51-55d0-a371-8999be52c9a1', '股関節を後ろへ引いた位置', '立ち上がった位置', '膝を深く曲げるのではなく、股関節を中心に曲げ伸ばしします。', '腕でロープを引く、腰を反って動作を終了することを避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ca810f47-7cc1-5095-943e-5369cd3dcf97', 'IMG-EX047-01', 'ケーブルプルスルー 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05f04394-df51-55d0-a371-8999be52c9a1', 1, 'assets/images/exercises/EX047_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('f41ec57e-4910-5ee1-abb6-0cb1dde880f2', 'IMG-EX047-02', 'ケーブルプルスルー 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '05f04394-df51-55d0-a371-8999be52c9a1', 2, 'assets/images/exercises/EX047_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('371323b6-9af1-5302-acee-a33fbf16f979', 'FORM-EX048', 'ケーブルキックバック', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', '脚を前へ戻した位置', '脚を後ろへ伸ばした位置', '骨盤を正面へ保ち、お尻の力で脚を後方へ動かします。', '腰を反る、身体をひねる、脚を必要以上に高く上げる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e98a8905-e63c-50e7-b5ab-c6d3d1ec6886', 'IMG-EX048-01', 'ケーブルキックバック 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 1, 'assets/images/exercises/EX048_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('b2e5250c-1578-5a7d-80e1-da5aeb5151d3', 'IMG-EX048-02', 'ケーブルキックバック 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 2, 'assets/images/exercises/EX048_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('37f2c7dd-e9c1-5afc-a78e-3dd4f882e657', 'FORM-EX049', 'ヒップアブダクションマシン', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', '脚を閉じた位置', '脚を開いた位置', '骨盤を安定させ、開いた位置で短く止めます。', '反動で脚を開閉する、身体を大きく揺らす動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ab18916e-4213-5c82-b6e6-68d5ab2f95a2', 'IMG-EX049-01', 'ヒップアブダクションマシン 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 1, 'assets/images/exercises/EX049_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('8a8b93fd-e7e4-5ce0-a7e4-15ee8cb2e4b8', 'IMG-EX049-02', 'ヒップアブダクションマシン 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 2, 'assets/images/exercises/EX049_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('56ac3889-b264-5ea7-b1e2-10b92750721b', 'FORM-EX050', 'バンドラテラルウォーク', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', '足をそろえた位置', '横へ踏み出した位置', '足幅を保ち、常にバンドへ張力をかけます。', '膝が内側へ入る、上体が大きく左右へ揺れる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('758f72f6-702c-57c3-b0da-d5be1594c151', 'IMG-EX050-01', 'バンドラテラルウォーク 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 1, 'assets/images/exercises/EX050_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('10555b01-465d-54f2-b25e-42d53c08ad25', 'IMG-EX050-02', 'バンドラテラルウォーク 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 2, 'assets/images/exercises/EX050_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('89f88444-295a-5ff7-97a2-812cad2138b8', 'FORM-EX051', '自重スクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', '立った位置', 'しゃがんだ位置', '足裏全体で床を押し、膝とつま先を同じ方向へ向けます。', 'かかとが浮く、膝が内側へ入る、腰が大きく丸まる深さまでしゃがむ動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('8f697c83-416d-5bf8-a909-820a9da22f51', 'IMG-EX051-01', '自重スクワット 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 1, 'assets/images/exercises/EX051_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('91f6d54f-eb1d-5a08-a56c-0bc03630ad2f', 'IMG-EX051-02', '自重スクワット 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 2, 'assets/images/exercises/EX051_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('91ac3dfe-beea-51ab-bcc6-11306b2bb682', 'FORM-EX052', 'ゴブレットスクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2a565e8b-14b5-51bb-80bf-c713713f59fe', '立った位置', 'しゃがんだ位置', '重量を身体へ近づけ、胸を落とさず足裏全体で立ち上がります。', '腰を丸める、膝が内側へ入る、重量を身体から離す動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('3f3b65cd-6eb1-594f-97f7-3a995da136b3', 'IMG-EX052-01', 'ゴブレットスクワット 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 1, 'assets/images/exercises/EX052_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('32a67e7b-3d38-5bdd-9ed7-d6161c541b46', 'IMG-EX052-02', 'ゴブレットスクワット 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 2, 'assets/images/exercises/EX052_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('7db75301-29f0-5e62-b480-12cbd9fad739', 'FORM-EX053', 'バーベルバックスクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '立った位置', 'しゃがんだ位置', '足裏全体で床を押し、バーが足の中央付近を上下するようにします。', '高重量ではラックとセーフティを使用し、腰の丸まりや膝の内側への崩れを避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('447a53fa-3db1-5a1f-961d-7a3bce06fd4c', 'IMG-EX053-01', 'バーベルバックスクワット 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 1, 'assets/images/exercises/EX053_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('5d17699c-f6bc-5c2c-ad86-09f78da010e8', 'IMG-EX053-02', 'バーベルバックスクワット 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 2, 'assets/images/exercises/EX053_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('06fe1768-2240-5071-915c-3ec3237859cb', 'FORM-EX054', 'フロントスクワット', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', '立った位置', 'しゃがんだ位置', '肘を高く保ち、胸を落とさないようにします。', '手首へ無理な負担をかける、肘が下がってバーがずれる状態を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('12fe5a3a-6406-55ba-a1aa-5bc6f49cae69', 'IMG-EX054-01', 'フロントスクワット 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 1, 'assets/images/exercises/EX054_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('c512f1b9-498f-5db9-be41-70f2ec8fdba3', 'IMG-EX054-02', 'フロントスクワット 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 2, 'assets/images/exercises/EX054_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('57b8fe62-e8bf-5f99-8d50-c6a1674f62b6', 'FORM-EX055', 'レッグプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', '膝を曲げた位置', '脚を押し伸ばした位置', '腰とお尻をシートにつけ、膝とつま先を同じ方向へ向けます。', '膝を強く伸ばし切る、深く下ろしすぎて腰が丸まる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('10a474f0-eea0-5f62-bddb-9480fe915e0e', 'IMG-EX055-01', 'レッグプレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 1, 'assets/images/exercises/EX055_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('41444c6c-a4e4-5fde-8208-64f3f0e86d9e', 'IMG-EX055-02', 'レッグプレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 2, 'assets/images/exercises/EX055_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('d3d075bf-4807-54a9-8758-eff0eddf0928', 'FORM-EX056', 'レッグエクステンション', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '25bd9912-890e-574f-ab15-0f1eda43f095', '膝を曲げた位置', '膝を伸ばした位置', '膝の位置をマシンの回転軸へ合わせ、上で太ももの前側を収縮させます。', '反動で蹴り上げる、膝に痛みが出る重量や可動域で続けることを避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('0fc00d6f-39d5-5c48-8c4d-17506bd675bd', 'IMG-EX056-01', 'レッグエクステンション 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '25bd9912-890e-574f-ab15-0f1eda43f095', 1, 'assets/images/exercises/EX056_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('c1d6a66f-db53-5e41-ab63-fe38bf8fe76c', 'IMG-EX056-02', 'レッグエクステンション 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '25bd9912-890e-574f-ab15-0f1eda43f095', 2, 'assets/images/exercises/EX056_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('bd6a8aaf-ea1f-529c-95fe-8d63c10bc9dd', 'FORM-EX057', 'レッグカール', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', '膝を伸ばした位置', '膝を曲げた位置', '腰や骨盤をパッドへ固定し、膝だけを曲げます。', '反動を使う、腰を反って重量を動かすことを避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('3f9dbc72-ffe5-56b7-aff5-15545dda5880', 'IMG-EX057-01', 'レッグカール 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 1, 'assets/images/exercises/EX057_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('126900bb-b09c-5d58-9240-c91658600f43', 'IMG-EX057-02', 'レッグカール 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', 2, 'assets/images/exercises/EX057_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('8e9364da-3091-5ece-ba60-932f43384d61', 'FORM-EX058', 'ウォーキングランジ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '踏み込んだ位置', '次の一歩へ移る位置', '前脚の足裏全体で床を押し、身体を前方へ運びます。', '歩幅が狭すぎる、膝が内側へ入る、疲労時にバランスを崩したまま続けることを避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('0a2c03f4-bfad-59c6-b147-31a80e01f8a0', 'IMG-EX058-01', 'ウォーキングランジ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 1, 'assets/images/exercises/EX058_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e60fedc4-571f-5078-a4dc-afa6635af148', 'IMG-EX058-02', 'ウォーキングランジ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 2, 'assets/images/exercises/EX058_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('a7364ec8-711a-590d-b0a0-5ac00d18e030', 'FORM-EX059', 'スタンディングカーフレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'かかとを下ろした位置', 'かかとを上げた位置', '上で短く止め、下ではかかとをゆっくり下げます。', '足首を内外へ倒す、反動で上下する動作を避けます。安定した支持物を使います。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('1d451a30-48ce-59ef-a01e-dddd588b1929', 'IMG-EX059-01', 'スタンディングカーフレイズ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 1, 'assets/images/exercises/EX059_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('bd138cab-b651-5dbb-a64c-afe6b6dd15f9', 'IMG-EX059-02', 'スタンディングカーフレイズ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 2, 'assets/images/exercises/EX059_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('2374de6a-c218-5756-be3f-bd1b51c34a35', 'FORM-EX060', 'シーテッドカーフレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'かかとを下ろした位置', 'かかとを上げた位置', '親指側から小指側まで均等に床を押します。', '可動域を小さくする、重量を弾ませる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('986b456f-de49-5c84-b718-122ac73b34a1', 'IMG-EX060-01', 'シーテッドカーフレイズ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 1, 'assets/images/exercises/EX060_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('e93d5b9e-5936-5345-b4a2-12c4d7c3696a', 'IMG-EX060-02', 'シーテッドカーフレイズ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 2, 'assets/images/exercises/EX060_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('f67473a4-022d-599e-a1c1-3ca2088fac47', 'FORM-EX061', 'クランチ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6f765f3-f227-5d17-b130-bf61a2213b40', '上体を下ろした位置', '上体を丸めた位置', '肩甲骨が床から離れる程度まで腹筋を縮めます。', '首を手で引っ張る、勢いで起き上がる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('b5662e98-f931-518e-a353-91d6c8ebb3b4', 'IMG-EX061-01', 'クランチ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 1, 'assets/images/exercises/EX061_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('49b1d445-c06b-598d-bb46-d106076d9ca9', 'IMG-EX061-02', 'クランチ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 2, 'assets/images/exercises/EX061_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('c6e1f245-da6e-59d2-b698-42fa81029b90', 'FORM-EX062', 'ケーブルクランチ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '641b6020-c6e2-54d7-a0ef-c0238647194d', '上体を起こした位置', '上体を丸めた位置', '腕でロープを引かず、腹筋で背骨を丸めます。', '股関節だけを曲げる、重すぎる重量で身体を倒す動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ef402be3-d5e0-5dd6-a0d9-61e26980d4b6', 'IMG-EX062-01', 'ケーブルクランチ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '641b6020-c6e2-54d7-a0ef-c0238647194d', 1, 'assets/images/exercises/EX062_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ce478326-3cb4-5d92-84a9-ee13dc7ccfd5', 'IMG-EX062-02', 'ケーブルクランチ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '641b6020-c6e2-54d7-a0ef-c0238647194d', 2, 'assets/images/exercises/EX062_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('f48b8929-c2f4-5ee1-a659-2ef4e2898a24', 'FORM-EX063', 'リバースクランチ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', '脚を下ろした位置', '骨盤を丸めた位置', '脚を振るのではなく、腹筋で骨盤を床から持ち上げます。', '勢いで脚を振る、腰を急に床へ落とす動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('1596a5e2-7997-57b4-b5f5-fb7eaaad7716', 'IMG-EX063-01', 'リバースクランチ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 1, 'assets/images/exercises/EX063_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('04623498-9021-557d-873e-d73438a9d2d2', 'IMG-EX063-02', 'リバースクランチ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 2, 'assets/images/exercises/EX063_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('76058558-61a5-5042-a48d-3fe96bf71ed2', 'FORM-EX064', 'ハンギングニーレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', '脚を下ろした位置', '膝を上げた位置', '膝を上げるだけでなく、骨盤を後ろへ巻き込むように動かします。', '身体を大きく振る、肩が痛い状態でぶら下がり続けることを避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('8b8a32b4-42d2-50f9-b4d5-a94b49dd6d71', 'IMG-EX064-01', 'ハンギングニーレイズ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 1, 'assets/images/exercises/EX064_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('089b2571-c873-5ecb-af41-970ef5dad2a3', 'IMG-EX064-02', 'ハンギングニーレイズ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 2, 'assets/images/exercises/EX064_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('0de1f066-605b-5ee7-9182-de592e9e07f2', 'FORM-EX065', 'プランク', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ff5db848-560b-56b9-a7b6-786495b5df4c', '準備姿勢', '保持姿勢', 'お腹とお尻へ力を入れ、肋骨と骨盤を近づける意識を持ちます。', '腰が落ちる、お尻が高く上がる、息を止め続ける状態を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('bd5024d1-cc0f-5cb9-98f4-50c2e4cf4092', 'IMG-EX065-01', 'プランク 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 1, 'assets/images/exercises/EX065_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('8290a614-0253-5983-a66c-c896c871edc7', 'IMG-EX065-02', 'プランク 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 2, 'assets/images/exercises/EX065_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('26275307-e63a-51ce-8073-2a9a08ac247d', 'FORM-EX066', 'サイドプランク', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5ad48491-19a8-569e-b4ae-459c0ec94498', '準備姿勢', '保持姿勢', '下側の脇腹で床を押し、骨盤を持ち上げます。', '肩へ体重を預けすぎる、腰が床方向へ落ちる状態を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ddd8eb9b-f908-54cd-ae3a-706d299d72a1', 'IMG-EX066-01', 'サイドプランク 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5ad48491-19a8-569e-b4ae-459c0ec94498', 1, 'assets/images/exercises/EX066_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('d19a6e81-73e1-506a-8be9-d5b265187245', 'IMG-EX066-02', 'サイドプランク 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '5ad48491-19a8-569e-b4ae-459c0ec94498', 2, 'assets/images/exercises/EX066_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('762b4e68-2823-5840-b8f5-d36cb27b4069', 'FORM-EX067', 'デッドバグ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', '手脚を上げた位置', '対角の手脚を伸ばした位置', '腰と床の距離を変えないよう腹部を固定します。', '脚を下げたときに腰が反る場合は可動域を小さくします。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('b9a4708a-7adf-53d8-bade-4ebbd1d101e1', 'IMG-EX067-01', 'デッドバグ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 1, 'assets/images/exercises/EX067_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('2f7f0358-1122-5794-8092-ebd1747b8d06', 'IMG-EX067-02', 'デッドバグ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 2, 'assets/images/exercises/EX067_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('6cf26e28-d839-5145-86e4-a7338cd6545f', 'FORM-EX068', 'バードドッグ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b40d9445-b430-53e2-995a-bd16ff30da08', '四つ這いの位置', '対角の手脚を伸ばした位置', '背中へ物を乗せたように、胴体と骨盤を動かさずに伸ばします。', '骨盤を開く、腰を反る、腕や脚を必要以上に高く上げる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('58c0208f-9eb0-55a1-a5df-666648e7c45d', 'IMG-EX068-01', 'バードドッグ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b40d9445-b430-53e2-995a-bd16ff30da08', 1, 'assets/images/exercises/EX068_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('a5a0792a-08ed-5f6a-93f7-dea45a7755ee', 'IMG-EX068-02', 'バードドッグ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'b40d9445-b430-53e2-995a-bd16ff30da08', 2, 'assets/images/exercises/EX068_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('8efb7ff6-bbe2-59f4-831a-1f4a0dcb2453', 'FORM-EX069', 'パロフプレス', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '67902963-d3f4-5986-867e-6949bfa6a9e0', '胸の前で構えた位置', '腕を伸ばした位置', 'ケーブル方向へ身体が回らないよう腹部と骨盤を固定します。', '腰を反る、身体を傾ける、肩だけでケーブルへ抵抗する動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('18b00f40-5643-5c08-bd9a-2b4011f02267', 'IMG-EX069-01', 'パロフプレス 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '67902963-d3f4-5986-867e-6949bfa6a9e0', 1, 'assets/images/exercises/EX069_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('ee8a0399-7388-52ee-b580-32f30891a032', 'IMG-EX069-02', 'パロフプレス 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '67902963-d3f4-5986-867e-6949bfa6a9e0', 2, 'assets/images/exercises/EX069_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('02e0e574-36b3-5a3b-b58f-b5238b98baf9', 'FORM-EX070', 'アブローラー', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'ローラーを身体の近くに置いた位置', '身体を伸ばした位置', '肋骨を開かず、骨盤と胸郭の位置を保ったまま動きます。', '腰が反り始める手前で止めます。腰に痛みがある場合は無理に行わず、より易しい種目へ変更します。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('2b9088c2-ca52-5ace-a2c3-a68b3a22067d', 'IMG-EX070-01', 'アブローラー 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 1, 'assets/images/exercises/EX070_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('08ce0882-e9df-57a6-8873-cc02942eaaa3', 'IMG-EX070-02', 'アブローラー 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 2, 'assets/images/exercises/EX070_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('58f4c0c0-1dbd-5051-bf07-aa5abc35fc76', 'FORM-EX071', 'インクラインダンベルサイドレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '4103b188-119d-5652-86fe-6ab2c343d380', '腕を下ろした位置', '腕を上げた位置', '傾斜姿勢を保ち、手ではなく肘を外側へ持ち上げます。', '身体を起こして反動を使う、肩をすくめる、腕を高く上げすぎる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('6c0a8cff-f52c-5d81-bb1f-c6d96ab2b278', 'IMG-EX071-01', 'インクラインダンベルサイドレイズ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '4103b188-119d-5652-86fe-6ab2c343d380', 1, 'assets/images/exercises/EX071_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('125d64bb-402e-519d-847a-32ca8ad49f9d', 'IMG-EX071-02', 'インクラインダンベルサイドレイズ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '4103b188-119d-5652-86fe-6ab2c343d380', 2, 'assets/images/exercises/EX071_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_copy (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, image_1_label, image_2_label, movement_tip, caution_text) VALUES ('7268c154-8f3b-5fd9-9a22-435015466673', 'FORM-EX072', 'インクラインダンベルリアレイズ', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '73b1b849-cfe2-5e44-8636-c89b136e11e7', '腕を下ろした位置', '腕を開いた位置', '胸をベンチへつけたまま、手ではなく肘を外側へ広げます。', '肩甲骨を強く寄せすぎる、肩をすくめる、反動でダンベルを上げる動作を避けます。');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('382433ea-567e-5ec3-8623-51f92b7c038c', 'IMG-EX072-01', 'インクラインダンベルリアレイズ 画像1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 1, 'assets/images/exercises/EX072_01.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_form_asset (id, code, name_ja, is_active, content_version, created_at, updated_at, exercise_id, asset_position, asset_uri, checksum, asset_status) VALUES ('19149de8-3343-5dbd-bd3d-f5285c42bfd1', 'IMG-EX072-02', 'インクラインダンベルリアレイズ 画像2', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', '73b1b849-cfe2-5e44-8636-c89b136e11e7', 2, 'assets/images/exercises/EX072_02.png', 'PENDING', 'NOT_STARTED');
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b287a2a7-7d3d-50c8-b8ae-ca21eb222ff4', '95819265-6d61-5cca-ad80-1609b3a02486', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('9b00c043-6803-5969-a767-76617484f254', '95819265-6d61-5cca-ad80-1609b3a02486', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('235e2d8e-4926-596e-b4bd-86d4b4d44e6f', '95819265-6d61-5cca-ad80-1609b3a02486', '728c22d5-86f9-58b2-b702-73ca968290c8', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('f3f8ccb5-e0a8-50b9-bf05-27cd65de2e17', '05c70f4f-6814-55d7-a53b-feac833cfc7d', '95819265-6d61-5cca-ad80-1609b3a02486', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('f98372c5-0988-503a-8a60-cf818bffc02c', '05c70f4f-6814-55d7-a53b-feac833cfc7d', '728c22d5-86f9-58b2-b702-73ca968290c8', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('a7ce3c02-d081-5745-bf0c-b437019eee17', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('2e34d556-3be6-5e8c-96e1-306c3504601c', '728c22d5-86f9-58b2-b702-73ca968290c8', 'c3be154d-b150-5477-852d-553edd3155b7', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('76b773bf-263e-5ff7-a5d4-35464ecd0266', '728c22d5-86f9-58b2-b702-73ca968290c8', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('ae6b5656-a96c-5a85-91cb-847fcb1f4dcc', '728c22d5-86f9-58b2-b702-73ca968290c8', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('31295da2-df39-5532-93c6-d63e2fbcaa87', 'c3be154d-b150-5477-852d-553edd3155b7', '728c22d5-86f9-58b2-b702-73ca968290c8', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('eeeb3d19-c640-5e27-b028-5da6f9855f9f', 'c3be154d-b150-5477-852d-553edd3155b7', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('ff2f5573-9bd0-5cbe-bf82-b4282670882e', 'c3be154d-b150-5477-852d-553edd3155b7', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('d6559e6a-e2ee-5e61-8c92-8de9789327f0', 'c4e220e7-0ec4-503b-8200-468acd7628f5', 'c3be154d-b150-5477-852d-553edd3155b7', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('e4414371-a716-5c3e-95bf-f8e4b4f75467', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'c3be154d-b150-5477-852d-553edd3155b7', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b08a4a3b-a4b5-5129-9d39-c37195473148', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('2ba029ee-f002-54c6-887b-9b40e4a7faad', '71a3e3a9-e2e7-596d-9b6f-84edd9443ecf', '728c22d5-86f9-58b2-b702-73ca968290c8', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('24950d6c-d1c8-5440-b5bb-5eaeba2326dd', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'c3be154d-b150-5477-852d-553edd3155b7', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('97eb4524-3e0d-5643-a80d-ab50780fb90a', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', '05c70f4f-6814-55d7-a53b-feac833cfc7d', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b580711c-e58c-5954-a6de-362aa101cb0b', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('eead3b7e-c549-5fd8-9d90-6f59bb6fdbef', '16228203-ecfa-552d-b068-6a645dacc7ba', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('4bbe7f4c-c04a-5a72-90e2-ac2f91990e85', '16228203-ecfa-552d-b068-6a645dacc7ba', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('22fbab24-a057-50aa-8766-475d2895c1a6', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('c744dce3-0839-5f56-8dc7-ec15a01d83f7', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', '16228203-ecfa-552d-b068-6a645dacc7ba', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('e969ef1f-2f18-56e6-927c-4a7c4a37b4da', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('151b0378-bb7f-5e84-ac7d-1a16fc98761d', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'cc3f5a86-c002-56cd-a2e6-9327605675cd', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('0c112727-480f-5d61-baf5-59a94551441f', '87e7212a-24cb-5424-8c54-44c43d7abcdd', '16228203-ecfa-552d-b068-6a645dacc7ba', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('48c8d8b4-19a0-5146-8551-22d48f3e3106', '87e7212a-24cb-5424-8c54-44c43d7abcdd', 'a6db9fd6-a9c9-58a7-8358-78ed81670a4b', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('ef1f50fc-5ba1-52ac-8416-61b6b9d7f50b', '03040c5e-0485-5937-b86e-c7472ec6d488', '7a560855-9753-561d-84cb-f821ade60469', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('2e40ba50-6deb-580e-91f3-7a8ec8520978', '03040c5e-0485-5937-b86e-c7472ec6d488', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('f9e203e1-df20-5717-9263-47cecec2f26c', '69163398-4c97-5cd9-aa6b-f24bf952f178', '7a560855-9753-561d-84cb-f821ade60469', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('ac3b1f69-f706-5c52-83b4-3b1118c92aba', '69163398-4c97-5cd9-aa6b-f24bf952f178', '03040c5e-0485-5937-b86e-c7472ec6d488', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('a8153988-10a6-58de-a6de-3c253bef809f', '7a560855-9753-561d-84cb-f821ade60469', '69163398-4c97-5cd9-aa6b-f24bf952f178', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('7d3c79ab-8593-5cdb-a4ec-584b299eba75', '7a560855-9753-561d-84cb-f821ade60469', '03040c5e-0485-5937-b86e-c7472ec6d488', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('0825c790-3163-51d2-8cb7-02dff893cc12', 'd816e412-b368-5a89-b993-e2490b242817', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b2e40209-b395-573a-ab5f-8a40f92c89d1', 'd816e412-b368-5a89-b993-e2490b242817', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('92ab4934-211e-5840-966c-719375de38db', 'd816e412-b368-5a89-b993-e2490b242817', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('d75cc2a7-c6a7-5152-9361-efa347ae15e7', '1007e08b-3351-536d-afe4-0bcce09aa6ce', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('ad11577e-7026-5e81-8efa-becbac9dcdfc', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'd816e412-b368-5a89-b993-e2490b242817', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('f5098739-aa46-5cd4-a282-1844d5c630b1', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b330ff2c-d32b-593e-aace-842f44c66c4a', '5c937e70-019c-5278-be21-8b2ceef7454b', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('7b6e3304-10bf-5215-85f3-6b4b15839d52', '5c937e70-019c-5278-be21-8b2ceef7454b', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('0ac6522e-cd0e-58c8-acbe-6564f9d32518', '5c937e70-019c-5278-be21-8b2ceef7454b', '1007e08b-3351-536d-afe4-0bcce09aa6ce', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('e4d4c79f-e1c6-5210-a2e1-c8c8252aaec4', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('a7678f0a-a9ff-5b37-b7ab-e1846d289d6e', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'd816e412-b368-5a89-b993-e2490b242817', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('6199b508-c8b0-5aaa-a1e5-2c817d8b6e73', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', '5c937e70-019c-5278-be21-8b2ceef7454b', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('261c4524-2d1a-533f-b020-b0ace9008084', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'd35fe9d2-2062-5865-a64a-99a7a4dd9555', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('96056d51-c648-5227-858c-91e9d81dd711', '0fef9047-fefc-58ed-a78e-bae3af9f179b', 'd816e412-b368-5a89-b993-e2490b242817', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('9c414eb1-7851-59fb-9f91-0273d1e1e81d', '0fef9047-fefc-58ed-a78e-bae3af9f179b', '5c937e70-019c-5278-be21-8b2ceef7454b', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('54529db3-a961-5ca2-8665-e5b0e425a495', '072ba9bb-3f6d-561a-bfbe-283c98bcc0ec', '03040c5e-0485-5937-b86e-c7472ec6d488', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('57499e25-e052-5692-89b1-4e67a552800e', 'f6a68de0-bee5-5265-84e4-dea9acafae28', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('66e170a2-7c5a-595d-afd1-530f26fd9e4d', 'f6a68de0-bee5-5265-84e4-dea9acafae28', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('5599e62b-00a9-56c8-84a5-1658eddae818', 'f6a68de0-bee5-5265-84e4-dea9acafae28', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('0da86c19-0217-519a-aaae-4e381aa53182', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'cd42319a-c019-5368-9135-d14c0c904c32', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('45929d77-2547-5b8a-8259-e486d77b1501', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', '8026feac-450b-5ab4-8641-8425d74be75f', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('bb641b6f-b911-52cb-a1f7-12beb36c7e5e', 'cd42319a-c019-5368-9135-d14c0c904c32', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('1a1f6f59-4be1-56c6-a311-5220b65abe19', 'cd42319a-c019-5368-9135-d14c0c904c32', '8026feac-450b-5ab4-8641-8425d74be75f', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('7dc7db1a-4911-5b4c-a9ab-dc551c5a5e67', '8026feac-450b-5ab4-8641-8425d74be75f', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('a8d2b180-ed6e-5eb7-8acd-8a4c364d18c4', '8026feac-450b-5ab4-8641-8425d74be75f', 'cd42319a-c019-5368-9135-d14c0c904c32', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b9116228-35dd-5e8a-bd4f-b194afe57e97', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', '86ea1464-f372-502e-8bdd-f94953732cb4', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('d1a8f675-dee5-5798-af5f-69e25367ba7a', '86ea1464-f372-502e-8bdd-f94953732cb4', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('790ad4a4-6c41-5e0d-9ca8-9449577559ee', '2346c3e0-d974-5556-a484-b3528dcde3ca', '8026feac-450b-5ab4-8641-8425d74be75f', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b9a5cb41-e1d7-51c3-bf43-750ab0676900', '2346c3e0-d974-5556-a484-b3528dcde3ca', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b2e0a7c8-f7c8-5569-b4c4-55d5ee3eadfe', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', '22fd1467-a582-5642-b51f-5a32ed150885', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('c153f1a5-9444-52e5-936a-ea55d6bcae32', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('a400ba2b-a26e-5dae-a7a1-96efb2b0b0f8', '22fd1467-a582-5642-b51f-5a32ed150885', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('5b72cbfd-09d3-54cd-a838-efb0babb0985', '22fd1467-a582-5642-b51f-5a32ed150885', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('f9491882-bdfa-5bbc-a331-64d4c53ffa8b', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', '22fd1467-a582-5642-b51f-5a32ed150885', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('a3ecec51-1919-5d2a-9205-851d9cceb7ad', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b955b8ef-c272-5ea4-9282-04811f64c06a', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', '0c1f88e9-a9a6-53bb-80c0-8afd00714cb9', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('d55bb275-7e46-5149-aa80-383ea52056c4', '252b6672-6dfc-50b3-97de-7827a2ec1fe6', 'cd42319a-c019-5368-9135-d14c0c904c32', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('7af0880e-63d9-5979-847e-aeba31b590e4', 'da7d770b-d85e-5460-9068-c39bcc546503', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('671a8f24-7166-591f-bf8b-c013eb76c9b6', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'da7d770b-d85e-5460-9068-c39bcc546503', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('2d75b4ec-2413-54ff-98f0-fe885df860eb', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('1cde692a-dd83-5e54-a206-beb728f44a3a', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 'da7d770b-d85e-5460-9068-c39bcc546503', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('c484ecda-babd-50f3-a897-89c300c8230d', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('0ab7ef85-3b8c-52a5-a8b7-519c23a64c4b', '8ed32064-eb89-590b-ad11-85cdfbb15794', 'da7d770b-d85e-5460-9068-c39bcc546503', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('0a739c88-978a-5a93-b061-5410ee776e8e', '8ed32064-eb89-590b-ad11-85cdfbb15794', '54e7da48-2d4e-5a7c-95f7-52fc2fb8a558', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('2e0a2696-7fb8-5e90-9256-b2f5192e3fd9', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('e93c6730-366d-5cae-b821-507b956d59e9', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'da7d770b-d85e-5460-9068-c39bcc546503', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('0ea3c103-eef7-5a60-a87a-7312c1e3110b', 'f826ab1d-6750-5f56-b4be-938133f0222b', '62885afd-971e-53ef-89a0-c5799030d80c', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('46e437a9-ca03-5c4f-becc-902400c3cce8', '62885afd-971e-53ef-89a0-c5799030d80c', '728c22d5-86f9-58b2-b702-73ca968290c8', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('ddd1f882-c681-54e0-95cf-0e65799cbb9b', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', '731ac79c-b789-5809-bd32-486d0f7c9c28', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('ee0989a5-365e-5087-aa32-2a1925c5aeac', '3bdac120-e1ba-556d-a0c9-a654a8777f9b', 'c10f2e44-65be-59fb-bf2f-dcec3f447a35', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b3246377-7a8f-5c72-8adf-1165642a9e96', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('f9c02ae5-a342-5e7b-acc3-023e18c6bb00', '35e88355-a311-5689-94d2-e04d60a4fdcf', '05f04394-df51-55d0-a371-8999be52c9a1', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('9875d6e7-275f-5dc8-84f2-4e716fc5881a', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('dccdd96f-3f3f-5c3b-8bce-fc7fb7c68f64', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', '05f04394-df51-55d0-a371-8999be52c9a1', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('f9a97a33-0908-5b83-b35f-8790faf13f28', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', '05f04394-df51-55d0-a371-8999be52c9a1', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('2eba4028-d27a-5ffd-9e4c-ef107698f557', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('d37aa18b-998a-552a-a6ca-2a8087dd4497', '47411e34-b12b-56a7-ba86-478679571626', '426a5860-7e4f-57ef-a18f-959420622f4f', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('0dc43b3e-19d3-5a8f-953b-6fd05cb3b251', '47411e34-b12b-56a7-ba86-478679571626', '1761e525-9750-5b12-afe6-de2905489293', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('ebe5c448-dcb7-5cfb-8959-9a9f9341a41c', '426a5860-7e4f-57ef-a18f-959420622f4f', '47411e34-b12b-56a7-ba86-478679571626', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('9637c444-e800-55c1-a378-9d453c447009', '426a5860-7e4f-57ef-a18f-959420622f4f', '1761e525-9750-5b12-afe6-de2905489293', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('a0fdb2ef-4e1c-516d-ac62-b9f6f77d75fe', '426a5860-7e4f-57ef-a18f-959420622f4f', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('97ad419a-6c7e-52b1-acfb-67992b83c0f3', '1761e525-9750-5b12-afe6-de2905489293', '426a5860-7e4f-57ef-a18f-959420622f4f', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('665dffdf-2646-5976-b9fe-7489ea0109e4', '1761e525-9750-5b12-afe6-de2905489293', '47411e34-b12b-56a7-ba86-478679571626', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('3be17e22-2ee0-544d-b4b4-ca9224da1cfb', '1761e525-9750-5b12-afe6-de2905489293', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('79a82d48-7231-5840-a090-5c022d6e49d6', '05f04394-df51-55d0-a371-8999be52c9a1', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('7112fcdc-eb5b-58d0-b147-3f1ec96b1949', '05f04394-df51-55d0-a371-8999be52c9a1', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('3320efbb-9656-51be-90c9-ee1ff680f665', '05f04394-df51-55d0-a371-8999be52c9a1', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('14f3d8f3-788d-5b31-b496-4c5d9cd430d0', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', '35e88355-a311-5689-94d2-e04d60a4fdcf', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('57fce896-f5f2-5e22-aefe-926183e0a153', 'c7cd6a4a-be1c-5d4f-9ba0-66d8a9d43248', 'ac4f8e17-25f0-57f4-b03e-fda11ce71b4b', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('c925a87b-1432-5950-9ebc-0f19a0fabed2', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('bd166ac5-59e6-5bd8-9b35-ff096a6a57ca', '1d3cbcb9-1b53-50bc-8fa3-3b3c3c81296d', 'de2e5b44-ad86-5cfb-b040-e49bbaadfee5', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('77823995-fa61-56b4-84ac-977665fcf4c1', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('f29373e4-7971-5e2d-b94e-3968559ea630', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('97a7bbeb-4025-5b7c-8ffb-d9a139dbead0', '2a565e8b-14b5-51bb-80bf-c713713f59fe', '014a6e54-f1d3-5348-a0e2-24ff20b9d216', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('23c977aa-ed82-5849-b9a3-b01b7f850c99', '2a565e8b-14b5-51bb-80bf-c713713f59fe', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('91aa2b9e-425f-569f-a5c8-b367a4fd143b', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('26a06fd6-191a-5eab-b7a1-563c60194cba', '066d1ba2-0850-5081-bc9b-dfa3d6144138', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('449a2adf-eb0c-5d49-8467-9af05e1891fe', '066d1ba2-0850-5081-bc9b-dfa3d6144138', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('3f777266-3429-5a35-9e3a-fbc2ebb0dff0', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('89325bc9-4241-580d-8ab6-8d10c7965dac', 'c24244dc-1f7f-5664-8ddc-bf1792d401d4', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('ea85d37d-a33c-5f06-9595-6bb7ed6b514f', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('481a614a-d0c3-50b9-a51b-572eeb676010', '25bd9912-890e-574f-ab15-0f1eda43f095', '93aa2535-bd8b-5c9f-bbf6-c843c9cf7b63', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('338d38a5-7b31-5631-b413-e4c6aabdad4c', '25bd9912-890e-574f-ab15-0f1eda43f095', '2a565e8b-14b5-51bb-80bf-c713713f59fe', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('81fb0b70-0cf7-5ce4-8821-86a33057d21d', '1042a575-ddf1-52b6-9b7e-4c4f9ae47076', '677a3e31-ce8f-51b6-bff9-6f48dea8b3b0', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('8350b8a0-7147-57da-8092-e73aee313ff1', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '426a5860-7e4f-57ef-a18f-959420622f4f', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('df6d3050-c5a3-5808-90c6-251ac639824d', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '1761e525-9750-5b12-afe6-de2905489293', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('0ed1fa49-1f81-5f1d-b176-8e58cb1638ff', '181a78cc-e2b7-5fb5-9e7e-f59da8ef8385', '47411e34-b12b-56a7-ba86-478679571626', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('cd0f6056-e545-5c11-84dc-f9bda35092a9', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('763a6603-08ee-5d34-a93b-f4bd8f52ea37', 'a6691d83-ced3-513f-85da-b00ecbdc4ed5', 'b61c9833-ec63-5b20-8f0c-1c7197819f25', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('37ebd42f-6bb4-5f5a-a958-77d08f6048ee', 'c6f765f3-f227-5d17-b130-bf61a2213b40', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('90db4a8d-d70f-5f3a-bc60-d71ef600ec85', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('8c6b103f-e3a1-5d42-95a9-87678c72cb9d', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('c433a8b5-1a3d-56be-b84c-71c7f6b9f335', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('d275d20c-05f8-5d21-a4b9-82b48f52d53c', '641b6020-c6e2-54d7-a0ef-c0238647194d', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b95f1bf9-0ed0-59fc-aa0b-208ff9b364bc', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('32bb1790-3a0f-5ffc-b515-d1c5ac414264', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('0741246f-b7be-564f-98db-6f964478469a', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('267237dc-4ca6-5051-b06f-8a20ebdbbe37', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'c6b9ee08-6c1a-57c9-b145-371306d842b6', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('feab1756-4489-5411-88da-4e402d8c5059', 'e70c74a4-f67a-5d42-9318-3bf2fe88c1e3', 'c6f765f3-f227-5d17-b130-bf61a2213b40', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('8324a82f-b3ff-583b-8561-6656bf266353', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('04943ac3-66a6-51f7-baf4-0d7f09d99353', 'ff5db848-560b-56b9-a7b6-786495b5df4c', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('851948a4-4c6c-5a3a-9cd2-7a1ea317deef', '5ad48491-19a8-569e-b4ae-459c0ec94498', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('8fb0f8d2-65b7-5a20-8dd2-5019eb8ce6e8', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('736af34f-4acc-5fa6-8107-5cfdf88dbfab', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('affc5407-9226-5581-a379-2851c15c4127', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('84e82b53-6181-5f01-ac11-c48db5440f15', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('a601bae4-211d-5686-b0cb-ec2a81d16e62', 'b40d9445-b430-53e2-995a-bd16ff30da08', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b5328526-b9c9-5de0-80b5-903d1d38411f', '67902963-d3f4-5986-867e-6949bfa6a9e0', 'b40d9445-b430-53e2-995a-bd16ff30da08', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('66d37675-321c-5ad6-9cef-5770496bd3c4', '67902963-d3f4-5986-867e-6949bfa6a9e0', '5ad48491-19a8-569e-b4ae-459c0ec94498', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('52e2f78e-d8c9-59d7-8130-cd17f255dfac', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'ff5db848-560b-56b9-a7b6-786495b5df4c', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('7e01cd52-b76c-5367-b404-4af55c62f21b', '93e5dab5-fc18-5e74-9ff1-9c17ac09ec47', 'f42e9a0c-3fb8-5cdc-ac3b-0e2a9e4db507', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('b2ddf5d2-0dee-5f09-9b18-e7c174771aa0', '4103b188-119d-5652-86fe-6ab2c343d380', 'ef47c102-303b-5969-b341-b4ab6cb5e7a6', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('57039ed3-6bb7-5941-a0f8-b8921cc9f616', '4103b188-119d-5652-86fe-6ab2c343d380', '86ea1464-f372-502e-8bdd-f94953732cb4', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('22465249-81c4-56aa-8c50-31f9dcd00402', '73b1b849-cfe2-5e44-8636-c89b136e11e7', '726f6a81-f0b5-5f51-bace-4f37ca053a4c', 'GENERAL', 1);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('eaad4ddd-cebb-5d81-bc41-6f357d85996d', '73b1b849-cfe2-5e44-8636-c89b136e11e7', '22fd1467-a582-5642-b51f-5a32ed150885', 'GENERAL', 2);
-- statement
INSERT OR IGNORE INTO exercise_alternative (id, exercise_id, alternative_exercise_id, reason_code, priority) VALUES ('d0bd738f-89be-57a5-8992-8deff07a1dd2', '73b1b849-cfe2-5e44-8636-c89b136e11e7', '96c0bf70-924f-571a-ab00-dcf3bffd7ffd', 'GENERAL', 3);
-- statement
INSERT OR IGNORE INTO rule_version (id, code, name_ja, is_active, content_version, created_at, updated_at, rule_type_code, version_label, released_at, checksum) VALUES ('9bebe177-be26-5d83-954f-f943600bd8cd', 'MENU_RULE_V1_1', 'MENU_RULE_V1_1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'MENU', '1.1', '2026-07-14T00:00:00Z', '4044e24bc7664fdbaf9a7f26a0f848c57fa1a672d206d58b27d47ff76b9f916a');
-- statement
INSERT OR IGNORE INTO rule_version (id, code, name_ja, is_active, content_version, created_at, updated_at, rule_type_code, version_label, released_at, checksum) VALUES ('0ad53cd6-800c-57b8-a375-20bb2f80d2a6', 'PROGRESSION_RULE_V1_1', 'PROGRESSION_RULE_V1_1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PROGRESSION', '1.1', '2026-07-14T00:00:00Z', 'd9a9479856500522fa6ca28bba2b9c06e388f7a18162e680699b21c70abecd05');
-- statement
INSERT OR IGNORE INTO rule_version (id, code, name_ja, is_active, content_version, created_at, updated_at, rule_type_code, version_label, released_at, checksum) VALUES ('5c1f7176-05e5-5061-871f-2fbc836b78e6', 'FORM_COPY_V1_1', 'FORM_COPY_V1_1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'FORM_COPY', '1.1', '2026-07-14T00:00:00Z', '2afcba85d892ca25a192d93a5bcecb5ec184b5b027508f7bd92cda428a63cbcf');
-- statement
INSERT OR IGNORE INTO rule_version (id, code, name_ja, is_active, content_version, created_at, updated_at, rule_type_code, version_label, released_at, checksum) VALUES ('08b4f42f-4701-55de-b044-e45ed69eace7', 'SEED_V1', '初期72種目Seed v1', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'SEED', '1.0', '2026-07-14T00:00:00Z', '6dab6b02cf2f573e5444b82cdfe46ace6773c1f62ada328c32b5284ed6bddce6');
-- statement
INSERT OR IGNORE INTO reason_template (id, code, name_ja, is_active, content_version, created_at, updated_at, template_type_code, template_text, placeholder_schema_json) VALUES ('cc2e0af1-87b3-5c4f-88d2-454508d94079', 'REASON-EXERCISE_SELECTION', '種目採用理由', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'EXERCISE_SELECTION', '{priority_part}を優先し、{equipment}で実施できるため採用しました。', '{"required":["priority_part","equipment"]}');
-- statement
INSERT OR IGNORE INTO reason_template (id, code, name_ja, is_active, content_version, created_at, updated_at, template_type_code, template_text, placeholder_schema_json) VALUES ('88db9bd0-7fca-59d9-ba86-e99e9fdf445c', 'REASON-PROGRESSION_INCREASE', '増量提案', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PROGRESSION_INCREASE', '全ワークセットで目標上限を達成したため、次回は{next_value}を提案します。', '{"required":["next_value"]}');
-- statement
INSERT OR IGNORE INTO reason_template (id, code, name_ja, is_active, content_version, created_at, updated_at, template_type_code, template_text, placeholder_schema_json) VALUES ('96c9b621-415f-53a7-bb30-f9893d230226', 'REASON-PROGRESSION_MAINTAIN', '維持提案', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PROGRESSION_MAINTAIN', '目標範囲内で進行しているため、次回も同じ条件で回数を伸ばします。', '{"required":[]}');
-- statement
INSERT OR IGNORE INTO reason_template (id, code, name_ja, is_active, content_version, created_at, updated_at, template_type_code, template_text, placeholder_schema_json) VALUES ('bb3caa23-709a-57fe-ae02-1c36c922820c', 'REASON-PAIN_ADJUSTMENT', '痛み対応', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'PAIN_ADJUSTMENT', '{body_part}に違和感があるため、増量せず{action}を優先します。', '{"required":["body_part","action"]}');
-- statement
INSERT OR IGNORE INTO reason_template (id, code, name_ja, is_active, content_version, created_at, updated_at, template_type_code, template_text, placeholder_schema_json) VALUES ('849945b9-d308-5e88-93f0-d828d5d2ef37', 'REASON-TIME_ADJUSTMENT', '時間調整', 1, 1, '2026-07-14T00:00:00Z', '2026-07-14T00:00:00Z', 'TIME_ADJUSTMENT', '利用可能時間に合わせて、優先度の低い種目から調整しました。', '{"required":[]}');
