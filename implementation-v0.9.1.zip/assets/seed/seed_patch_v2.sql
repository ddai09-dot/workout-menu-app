INSERT OR IGNORE INTO equipment_master (id, code, name_ja, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('d1b59835-057e-5bf5-9638-8c70dfee640f', 'SMITH_MACHINE', 'スミスマシン', 'MACHINE', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('56c9296f-7a89-58d1-aee4-81429412e477', 'CHEST_MACHINE_GROUP', '胸のトレーニングマシン', 'MACHINE_GROUP', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('18e20949-6eab-5152-8444-77f07d31a4c5', 'SHOULDER_MACHINE_GROUP', '肩のトレーニングマシン', 'MACHINE_GROUP', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('feddd670-849c-537b-9842-eb964b19152f', 'ARM_MACHINE_GROUP', '腕のトレーニングマシン', 'MACHINE_GROUP', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('048e6966-1636-5198-af2d-0b1506d74bbd', 'BACK_MACHINE_GROUP', '背中のトレーニングマシン', 'MACHINE_GROUP', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('8b86fce1-df4b-5e46-9dba-a82791f9b1ce', 'LEG_MACHINE_GROUP', '脚のトレーニングマシン', 'MACHINE_GROUP', 0, 0);
-- statement
INSERT OR IGNORE INTO equipment_master (id, code, name_ja, equipment_category_code, supports_weight_options, supports_quantity) VALUES ('e8c8c84d-8ff6-5261-b122-2eae3f586080', 'CARDIO_MACHINE', '有酸素運動マシン', 'MACHINE_GROUP', 0, 0);
-- statement
INSERT OR IGNORE INTO rule_version (id, code, name_ja, rule_type_code, version_label, released_at, checksum) VALUES ('2c43cd17-6970-5234-8eb4-86dee35bd3ce', 'SEED_PATCH_V2', '初期登録器具カテゴリ追加 v2', 'SEED', '2.0', '2026-07-17T00:00:00Z', 'seed-patch-v2');
