UPDATE exercise_form_copy
SET movement_tip = 'ダンベルを身体（鎖骨）と平行に保ち、肩甲骨を寄せて前腕を床と垂直にします。',
    content_version = 2,
    updated_at = '2026-07-21T00:00:00Z'
WHERE code = 'FORM-EX003';
-- statement
INSERT OR IGNORE INTO rule_version
  (id, code, name_ja, rule_type_code, version_label, released_at, checksum)
VALUES
  ('3e6f29e9-9e85-534a-85f2-097cdc220b33',
   'SEED_PATCH_V3',
   'フォーム説明文言 v1.2 同期',
   'SEED',
   '3.0',
   '2026-07-21T00:00:00Z',
   'seed-patch-v3-form-copy-v1-2');
