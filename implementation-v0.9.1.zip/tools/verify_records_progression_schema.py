from __future__ import annotations

import json
import sqlite3
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def uid() -> str:
    return str(uuid.uuid4())


def statements(path: Path) -> list[str]:
    return [
        value.strip()
        for value in path.read_text(encoding="utf-8").split("\n-- statement\n")
        if value.strip()
    ]


def load_seed(db: sqlite3.Connection) -> None:
    for path in [
        ROOT / "assets/seed/seed_v1.sql",
        ROOT / "assets/seed/seed_patch_v2.sql",
    ]:
        for statement in statements(path):
            db.execute(statement)


def assert_catalog(db: sqlite3.Connection) -> None:
    count = db.execute(
        "SELECT COUNT(*) FROM sqlite_master "
        "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchone()[0]
    assert count == 60, count
    assert db.execute("SELECT COUNT(*) FROM exercise_master").fetchone()[0] == 72
    assert db.execute("SELECT COUNT(*) FROM exercise_form_asset").fetchone()[0] == 144
    assert db.execute("SELECT COUNT(*) FROM exercise_progression_profile").fetchone()[0] == 216
    fk_errors = db.execute("PRAGMA foreign_key_check").fetchall()
    assert not fk_errors, fk_errors


def verify_fresh_schema() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v5.sqlite.sql").read_text(encoding="utf-8"))
    load_seed(db)
    assert_catalog(db)
    db.close()


def verify_migration() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v4.sqlite.sql").read_text(encoding="utf-8"))
    load_seed(db)
    db.executescript((ROOT / "docs/migrations/v4_to_v5.sql").read_text(encoding="utf-8"))
    assert_catalog(db)
    columns = {
        row[1]
        for row in db.execute("PRAGMA table_info(progression_proposal)").fetchall()
    }
    assert {
        "source_evaluation_id",
        "proposal_key",
        "priority",
        "expires_at",
        "applied_at",
    }.issubset(columns)
    db.close()


def verify_progression_lifecycle() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v5.sqlite.sql").read_text(encoding="utf-8"))
    load_seed(db)

    user_id = uid()
    rule_id = db.execute(
        "SELECT id FROM rule_version WHERE code='MENU_RULE_V1_1'"
    ).fetchone()[0]
    exercise_id, exercise_name, recording = db.execute(
        "SELECT id,name_ja,recording_method_code FROM exercise_master "
        "WHERE code='EX001'"
    ).fetchone()
    db.execute(
        "INSERT INTO user_account(id,auth_provider,account_status,locale,timezone) "
        "VALUES (?, 'ANONYMOUS','ACTIVE','ja-JP','Asia/Tokyo')",
        (user_id,),
    )
    session_id = uid()
    session_exercise_id = uid()
    db.execute(
        "INSERT INTO workout_session("
        "id,user_id,rule_version_id,status_code,started_at,ended_at,record_date,"
        "last_local_saved_at,last_interaction_at"
        ") VALUES (?,?,?,'COMPLETED','2026-07-14T10:00:00Z',"
        "'2026-07-14T10:40:00Z','2026-07-14','2026-07-14T10:40:00Z',"
        "'2026-07-14T10:40:00Z')",
        (session_id, user_id, rule_id),
    )
    db.execute(
        "INSERT INTO session_exercise("
        "id,user_id,rule_version_id,workout_session_id,exercise_id,order_index,"
        "status_code,exercise_name_snapshot,recording_method_snapshot,"
        "performance_series_key,original_order_index,original_set_count,target_set_count"
        ") VALUES (?,?,?,?,?,1,'COMPLETED',?,?,?,1,3,3)",
        (
            session_exercise_id,
            user_id,
            rule_id,
            session_id,
            exercise_id,
            exercise_name,
            recording,
            exercise_id,
        ),
    )
    db.execute(
        "INSERT INTO post_workout_assessment("
        "id,user_id,rule_version_id,workout_session_id,overall_difficulty_score,"
        "had_pain,completed_exercise_count,completed_work_set_count,actual_duration_sec"
        ") VALUES (?,?,?,?,3,0,1,3,2400)",
        (uid(), user_id, rule_id, session_id),
    )
    for set_number in (1, 2, 3):
        target_id = uid()
        db.execute(
            "INSERT INTO session_set_target("
            "id,user_id,rule_version_id,session_exercise_id,set_number,is_warmup,"
            "target_weight_kg,target_reps_lower,target_reps_upper,rest_sec"
            ") VALUES (?,?,?,?,?,0,20,8,12,90)",
            (target_id, user_id, rule_id, session_exercise_id, set_number),
        )
        db.execute(
            "INSERT INTO work_set_record("
            "id,user_id,session_exercise_id,set_number,side_code,is_warmup,"
            "actual_weight_kg,actual_reps,equipment_mode_code,completed_at"
            ") VALUES (?,?,?,?,'BOTH',0,20,12,'DUMBBELL',?)",
            (
                uid(),
                user_id,
                session_exercise_id,
                set_number,
                f"2026-07-14T10:{set_number * 5:02d}:00Z",
            ),
        )

    series_id = uid()
    series_key = f"{exercise_id}|mode:DUMBBELL|machine:NONE|variation:STANDARD|side:BOTH"
    db.execute(
        "INSERT INTO exercise_performance_series("
        "id,user_id,exercise_id,series_key,display_name_snapshot,"
        "progression_group_code,target_mode_code,first_recorded_at,last_recorded_at,"
        "valid_session_count,stall_count,pain_count"
        ") VALUES (?,?,?,?,?,'PG01_WEIGHTED_MAJOR','REPS',"
        "'2026-07-14T10:40:00Z','2026-07-14T10:40:00Z',1,0,0)",
        (series_id, user_id, exercise_id, series_key, exercise_name),
    )
    evaluation_id = uid()
    db.execute(
        "INSERT INTO session_exercise_evaluation("
        "id,user_id,rule_version_id,session_exercise_id,workout_session_id,"
        "performance_series_id,evaluated_at,result_class_code,valid_for_performance,"
        "work_set_count,representative_weight_kg,total_reps,minimum_reps,maximum_reps,"
        "progression_metric_value,progress_detected,stall_count_after,pain_detected,"
        "reason_text_snapshot,input_snapshot_json"
        ") VALUES (?,?,?,?,?,?,'2026-07-14T10:40:00Z','RS_ALL_UPPER',1,3,20,36,12,12,"
        "200036,1,0,0,'全セットで上限達成','{}')",
        (
            evaluation_id,
            user_id,
            rule_id,
            session_exercise_id,
            session_id,
            series_id,
        ),
    )
    try:
        db.execute(
            "INSERT INTO session_exercise_evaluation("
            "id,user_id,rule_version_id,session_exercise_id,workout_session_id,"
            "performance_series_id,evaluated_at,result_class_code,reason_text_snapshot"
            ") VALUES (?,?,?,?,?,?,'2026-07-14T10:41:00Z','RS_IN_RANGE','duplicate')",
            (uid(), user_id, rule_id, session_exercise_id, session_id, series_id),
        )
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("Duplicate active evaluation was accepted.")

    try:
        db.execute(
            "INSERT INTO progression_proposal("
            "id,user_id,rule_version_id,exercise_id,source_evaluation_id,"
            "proposal_key,proposal_type_code,proposed_value_json,"
            "reason_text_snapshot,status_code"
            ") VALUES (?,?,?,?,?,'invalid-source','INCREASE_WEIGHT','{}',"
            "'invalid source','PENDING')",
            (uid(), user_id, rule_id, exercise_id, uid()),
        )
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("Invalid source evaluation was accepted.")

    proposal_id = uid()
    proposal_key = f"{exercise_id}|{series_key}|INCREASE_WEIGHT"
    db.execute(
        "INSERT INTO progression_proposal("
        "id,user_id,rule_version_id,exercise_id,performance_series_key,"
        "source_workout_session_id,source_evaluation_id,proposal_key,"
        "proposal_type_code,priority,current_value_json,proposed_value_json,"
        "reason_text_snapshot,status_code"
        ") VALUES (?,?,?,?,?,?,?,?, 'INCREASE_WEIGHT',20,?,?,?,'PENDING')",
        (
            proposal_id,
            user_id,
            rule_id,
            exercise_id,
            series_key,
            session_id,
            evaluation_id,
            proposal_key,
            json.dumps({"weightKg": 20}),
            json.dumps({"weightKg": 22}),
            "全セット上限達成のため次の登録重量を提案",
        ),
    )
    try:
        db.execute(
            "INSERT INTO progression_proposal("
            "id,user_id,rule_version_id,exercise_id,proposal_key,proposal_type_code,"
            "proposed_value_json,reason_text_snapshot,status_code"
            ") VALUES (?,?,?,?,?,'INCREASE_WEIGHT','{}','duplicate','PENDING')",
            (uid(), user_id, rule_id, exercise_id, proposal_key),
        )
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("Duplicate active proposal key was accepted.")

    adjustment_id = uid()
    db.execute(
        "INSERT INTO accepted_progression_adjustment("
        "id,user_id,progression_proposal_id,exercise_id,performance_series_key,"
        "adjustment_type_code,payload_json,status_code,queued_at"
        ") VALUES (?,?,?,?,?,'INCREASE_WEIGHT',?,'QUEUED','2026-07-14T10:41:00Z')",
        (
            adjustment_id,
            user_id,
            proposal_id,
            exercise_id,
            series_key,
            json.dumps({"weightKg": 22}),
        ),
    )
    db.execute(
        "INSERT INTO progression_proposal_decision("
        "id,user_id,progression_proposal_id,decision_code,applies_to_code,"
        "decided_at,application_result_code"
        ") VALUES (?,?,?,'ACCEPT','NEXT_MATCHING_SESSION',"
        "'2026-07-14T10:41:00Z','QUEUED_FOR_NEXT_MENU')",
        (uid(), user_id, proposal_id),
    )
    db.execute(
        "UPDATE progression_proposal SET status_code='ACCEPTED', "
        "applied_at='2026-07-14T10:41:00Z' WHERE id=?",
        (proposal_id,),
    )
    db.execute(
        "INSERT INTO body_measurement("
        "id,user_id,measured_at,weight_kg,body_fat_percent,source_code"
        ") VALUES (?,?,'2026-07-14T07:00:00Z',65.2,16.5,'MANUAL')",
        (uid(), user_id),
    )
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []
    assert db.execute(
        "SELECT COUNT(*) FROM progression_proposal_decision"
    ).fetchone()[0] == 1
    assert db.execute(
        "SELECT COUNT(*) FROM accepted_progression_adjustment WHERE status_code='QUEUED'"
    ).fetchone()[0] == 1
    db.close()


def main() -> None:
    verify_fresh_schema()
    verify_migration()
    verify_progression_lifecycle()
    print(
        "Records/progression schema verification passed "
        "(fresh v5, v4→v5 migration, lifecycle, uniqueness, FK)."
    )


if __name__ == "__main__":
    main()
