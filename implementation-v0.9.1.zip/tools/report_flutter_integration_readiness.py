#!/usr/bin/env python3
"""Report Task 20-B Flutter/iOS execution readiness without overstating completion."""

from __future__ import annotations

import argparse
import json
import platform
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PINNED_FLUTTER = "3.44.6"


def command_version(command: list[str]) -> str | None:
    if shutil.which(command[0]) is None:
        return None
    try:
        completed = subprocess.run(
            command,
            cwd=ROOT,
            check=False,
            capture_output=True,
            text=True,
            timeout=20,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    output = (completed.stdout or completed.stderr).strip()
    return output if output else None


def build_report() -> dict[str, object]:
    blockers: list[str] = []
    flutter = shutil.which("flutter")
    dart = shutil.which("dart")
    xcodebuild = shutil.which("xcodebuild")
    xcrun = shutil.which("xcrun")
    if flutter is None:
        blockers.append(f"Flutter SDK {PINNED_FLUTTER} is not installed")
    if dart is None:
        blockers.append("Dart executable is not installed")
    if platform.system() != "Darwin":
        blockers.append("Host OS is not macOS; iOS Simulator/device execution cannot run here")
    if xcodebuild is None:
        blockers.append("Xcode/xcodebuild is unavailable")
    if xcrun is None:
        blockers.append("xcrun is unavailable")
    if not (ROOT / "pubspec.lock").is_file():
        blockers.append("pubspec.lock has not been generated")
    if not (ROOT / "lib/core/database/app_database.g.dart").is_file():
        blockers.append("Drift generated code app_database.g.dart is absent")
    if not (ROOT / "ios").is_dir():
        blockers.append("Flutter iOS platform directory has not been generated")

    return {
        "status": "READY" if not blockers else "BLOCKED",
        "task": "20-B Flutter/iOS integration execution",
        "checked_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "host": {
            "os": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "python": platform.python_version(),
        },
        "pinned_flutter": PINNED_FLUTTER,
        "commands": {
            "flutter": flutter,
            "dart": dart,
            "xcodebuild": xcodebuild,
            "xcrun": xcrun,
        },
        "versions": {
            "flutter": command_version(["flutter", "--version"]),
            "dart": command_version(["dart", "--version"]),
            "xcode": command_version(["xcodebuild", "-version"]),
        },
        "artifacts": {
            "pubspec_lock": (ROOT / "pubspec.lock").is_file(),
            "drift_generated_code": (ROOT / "lib/core/database/app_database.g.dart").is_file(),
            "ios_platform_directory": (ROOT / "ios").is_dir(),
            "flutter_runner": (ROOT / "tools/run_task20_b_flutter_checks.sh").is_file(),
            "ios_runner": (ROOT / "tools/run_task20_b_ios_simulator.sh").is_file(),
        },
        "blockers": blockers,
        "runners": {
            "flutter": "tools/run_task20_b_flutter_checks.sh",
            "ios": "tools/run_task20_b_ios_simulator.sh",
        },
        "note": "This report is not a Flutter compile or iOS execution result.",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    report = build_report()
    payload = json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.out is not None:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(payload, encoding="utf-8")
    print(payload, end="")


if __name__ == "__main__":
    main()
