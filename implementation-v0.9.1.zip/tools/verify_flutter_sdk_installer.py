#!/usr/bin/env python3
"""Offline contract tests for the official Flutter SDK installer."""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "tools/install_pinned_flutter_sdk.py"
FIXTURE = ROOT / "tools/fixtures/flutter_releases_3_44_6.json"

spec = importlib.util.spec_from_file_location("flutter_installer", SCRIPT)
if spec is None or spec.loader is None:
    raise AssertionError("Could not load installer module")
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
metadata = json.loads(FIXTURE.read_text(encoding="utf-8"))
checks: list[str] = []


def require(name: str, condition: bool) -> None:
    if not condition:
        raise AssertionError(name)
    checks.append(name)


linux = module.resolve_release(
    metadata,
    host_platform="linux",
    architecture="x64",
    version="3.44.6",
    channel="stable",
    ref_prefix="ee80f08",
)
require("linux_archive", linux.archive == "stable/linux/flutter_linux_3.44.6-stable.tar.xz")
require("linux_sha", linux.sha256 == "a6320fd72e9a2690c08e2a6a70874a30cb120dee7c78f49d2c628bd7c9e20525")
require("linux_url", linux.archive_url.startswith("https://storage.googleapis.com/flutter_infra_release/releases/"))
require("linux_dart", linux.dart_sdk_version == "3.12.2")

mac_x64 = module.resolve_release(
    metadata,
    host_platform="macos",
    architecture="x64",
    version="3.44.6",
    channel="stable",
    ref_prefix="ee80f08",
)
require("mac_x64_archive", mac_x64.archive == "stable/macos/flutter_macos_3.44.6-stable.zip")

mac_arm = module.resolve_release(
    metadata,
    host_platform="macos",
    architecture="arm64",
    version="3.44.6",
    channel="stable",
    ref_prefix="ee80f08",
)
require("mac_arm_archive", mac_arm.archive == "stable/macos/flutter_macos_arm64_3.44.6-stable.zip")

for name, kwargs in [
    ("wrong_version_rejected", {"version": "3.44.7", "ref_prefix": "ee80f08"}),
    ("wrong_ref_rejected", {"version": "3.44.6", "ref_prefix": "deadbeef"}),
]:
    try:
        module.resolve_release(
            metadata,
            host_platform="linux",
            architecture="x64",
            channel="stable",
            **kwargs,
        )
    except ValueError:
        checks.append(name)
    else:
        raise AssertionError(name)

source = SCRIPT.read_text(encoding="utf-8")
for name, marker in [
    ("sha_verification", "Flutter archive SHA-256 mismatch"),
    ("safe_extract", "Unsafe archive member path"),
    ("official_metadata", "flutter_infra_release/releases/releases_{platform}.json"),
    ("github_output", "flutter_bin_directory"),
    ("deterministic_marker", ".workout-menu-release.json"),
]:
    require(name, marker in source)

print(json.dumps({
    "status": "PASS",
    "checks": len(checks),
    "version": linux.version,
    "release_ref_prefix": "ee80f08",
    "platforms": ["linux/x64", "macos/x64", "macos/arm64"],
    "network_download": "NOT_RUN_BY_THIS_OFFLINE_CONTRACT_TEST",
}, ensure_ascii=False, indent=2, sort_keys=True))
