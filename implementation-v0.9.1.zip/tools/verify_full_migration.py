#!/usr/bin/env python3
"""Verify the complete SQLite migration path from Schema v1 to Schema v9.

This verifier is intentionally independent from Flutter and Drift code generation.
It proves that:
- every migration file exists and can be applied in order;
- table counts progress as designed;
- Schema v1 seed/content rows survive every migration;
- representative user, plan, workout, record and legacy notification rows survive;
- v8 -> v9 consolidates notification settings without losing source rows;
- the final migrated structure is identical to direct Schema v9 creation;
- seed SQL remains idempotent on the final schema.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
MIGRATIONS = DOCS / "migrations"
SEEDS = [
    ROOT / "assets" / "seed" / "seed_v1.sql",
    ROOT / "assets" / "seed" / "seed_patch_v2.sql",
]
EXPECTED_TABLE_COUNTS = {1: 50, 2: 53, 3: 54, 4: 56, 5: 60, 6: 65, 7: 72, 8: 75, 9: 75}
EXPECTED_SEED_COUNTS = {
    "exercise_master": 72,
    "equipment_master": 48,
    "exercise_form_copy": 72,
    "exercise_form_asset": 144,
    "exercise_progression_profile": 216,
}


def split_seed(path: Path) -> list[str]:
    return [
        value.strip()
        for value in path.read_text(encoding="utf-8").split("\n-- statement\n")
        if value.strip()
    ]


def apply_seed(db: sqlite3.Connection) -> None:
    for path in SEEDS:
        for statement in split_seed(path):
            db.execute(statement)
    db.commit()


def table_names(db: sqlite3.Connection) -> set[str]:
    return {
        row[0]
        for row in db.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    }


def schema_objects(db: sqlite3.Connection) -> list[dict[str, Any]]:
    objects: list[dict[str, Any]] = []
    rows = db.execute(
        "SELECT type,name,tbl_name,sql FROM sqlite_master "
        "WHERE name NOT LIKE 'sqlite_%' AND type IN ('table','index','trigger') "
        "ORDER BY type,name"
    ).fetchall()
    for object_type, name, table_name, sql in rows:
        item: dict[str, Any] = {
            "type": object_type,
            "name": name,
            "table": table_name,
            "sql": " ".join((sql or "").split()),
        }
        if object_type == "table":
            item["columns"] = [list(row) for row in db.execute(f'PRAGMA table_info("{name}")')]
            item["foreign_keys"] = [
                list(row) for row in db.execute(f'PRAGMA foreign_key_list("{name}")')
            ]
        elif object_type == "index":
            item["index_info"] = [
                list(row) for row in db.execute(f'PRAGMA index_info("{name}")')
            ]
            item["index_xinfo"] = [
                list(row) for row in db.execute(f'PRAGMA index_xinfo("{name}")')
            ]
        objects.append(item)
    return objects


def signature(objects: list[dict[str, Any]]) -> str:
    payload = json.dumps(objects, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def table_digest(db: sqlite3.Connection, table: str) -> str:
    columns = [row[1] for row in db.execute(f'PRAGMA table_info("{table}")')]
    order = "id" if "id" in columns else ",".join(f'"{name}"' for name in columns)
    rows = db.execute(
        f'SELECT {",".join(f"\"{name}\"" for name in columns)} '
        f'FROM "{table}" ORDER BY {order}'
    ).fetchall()
    payload = json.dumps([columns, rows], ensure_ascii=False, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def assert_fk_clean(db: sqlite3.Connection, stage: str) -> None:
    violations = db.execute("PRAGMA foreign_key_check").fetchall()
    if violations:
        raise AssertionError(f"Foreign key violations after {stage}: {violations}")


def insert_v1_fixture(db: sqlite3.Connection) -> dict[str, str]:
    ids = {
        "user": "full_migration_user",
        "device": "full_migration_device",
        "profile": "full_migration_profile",
        "location": "full_migration_location",
        "location_equipment": "full_migration_location_equipment",
        "preference": "full_migration_app_preference",
        "week": "full_migration_week",
        "weekly_input": "full_migration_weekly_input",
        "weekly_day": "full_migration_weekly_day",
        "weekly_priority": "full_migration_weekly_priority",
        "menu": "full_migration_menu",
        "day_plan": "full_migration_day_plan",
        "planned_exercise": "full_migration_planned_exercise",
        "planned_set": "full_migration_planned_set",
        "session": "full_migration_session",
        "session_exercise": "full_migration_session_exercise",
        "set_record": "full_migration_set_record",
        "measurement": "full_migration_measurement",
    }
    rule_id = db.execute(
        "SELECT id FROM rule_version WHERE code='MENU_RULE_V1_1'"
    ).fetchone()[0]
    exercise_id, exercise_name, recording_method = db.execute(
        "SELECT id,name_ja,recording_method_code FROM exercise_master WHERE code='EX001'"
    ).fetchone()
    chest_id = db.execute(
        "SELECT id FROM body_part_master WHERE code='CHEST'"
    ).fetchone()[0]
    dumbbell_id = db.execute(
        "SELECT id FROM equipment_master WHERE code='DUMBBELL'"
    ).fetchone()[0]

    db.execute(
        "INSERT INTO user_account(id,auth_provider,account_status,locale,timezone) "
        "VALUES(?, 'ANONYMOUS','ACTIVE','ja-JP','Asia/Tokyo')",
        (ids["user"],),
    )
    db.execute(
        "INSERT INTO device_registration(id,user_id,app_version,last_seen_at) "
        "VALUES(?,?, '0.1.0','2026-07-01T00:00:00Z')",
        (ids["device"], ids["user"]),
    )
    db.execute(
        "INSERT INTO user_profile(id,user_id,source_device_id,nickname,age_years,age_updated_on,height_cm,onboarding_completed_at) "
        "VALUES(?,?,?,?,?,'2026-07-01',163,'2026-07-01T00:00:00Z')",
        (ids["profile"], ids["user"], ids["device"], "継続移行", 30),
    )
    db.execute(
        "INSERT INTO training_location(id,user_id,source_device_id,location_type_code,display_name,is_primary) "
        "VALUES(?,?,?,'HOME','自宅',1)",
        (ids["location"], ids["user"], ids["device"]),
    )
    db.execute(
        "INSERT INTO location_equipment(id,user_id,source_device_id,training_location_id,equipment_id,quantity,min_weight,max_weight,increment_weight) "
        "VALUES(?,?,?,?,?,2,2,40,2)",
        (
            ids["location_equipment"], ids["user"], ids["device"],
            ids["location"], dumbbell_id,
        ),
    )
    db.execute(
        "INSERT INTO app_preference(id,user_id,source_device_id,weight_unit_code,height_unit_code,appearance_code,sound_enabled,rest_timer_default_sec) "
        "VALUES(?,?,?,'KG','CM','SYSTEM',0,75)",
        (ids["preference"], ids["user"], ids["device"]),
    )
    for legacy_id, day, enabled, time_value, row_version in [
        ("full_migration_notification_mon", "MON", 1, "18:00", 1),
        ("full_migration_notification_wed", "WED", 1, "18:30", 2),
    ]:
        db.execute(
            "INSERT INTO notification_setting(id,user_id,created_at,updated_at,row_version,sync_status,source_device_id,notification_type_code,is_enabled,time_local,weekday_code) "
            "VALUES(?,?,'2026-07-01T00:00:00Z','2026-07-02T00:00:00Z',?,'LOCAL_ONLY',?,'WORKOUT_PLAN',?,?,?)",
            (legacy_id, ids["user"], row_version, ids["device"], enabled, time_value, day),
        )

    db.execute(
        "INSERT INTO training_week(id,user_id,rule_version_id,week_start_date,week_end_date,status_code) "
        "VALUES(?,?,?,'2026-07-06','2026-07-12','FINALIZED')",
        (ids["week"], ids["user"], rule_id),
    )
    db.execute(
        "INSERT INTO weekly_input(id,user_id,rule_version_id,training_week_id,same_as_last_week,sleep_score,motivation_score,weekly_load_direction_code,rest_week) "
        "VALUES(?,?,?,?,0,3,4,'APP',0)",
        (ids["weekly_input"], ids["user"], rule_id, ids["week"]),
    )
    db.execute(
        "INSERT INTO weekly_available_day(id,user_id,rule_version_id,training_week_id,weekday_code,plan_date,is_available,duration_min,training_location_id) "
        "VALUES(?,?,?,?,'MON','2026-07-06',1,45,?)",
        (ids["weekly_day"], ids["user"], rule_id, ids["week"], ids["location"]),
    )
    db.execute(
        "INSERT INTO weekly_priority_part(id,user_id,rule_version_id,training_week_id,body_part_id,priority_type) "
        "VALUES(?,?,?,?,?,'MAIN')",
        (ids["weekly_priority"], ids["user"], rule_id, ids["week"], chest_id),
    )
    db.execute(
        "INSERT INTO weekly_menu(id,user_id,rule_version_id,training_week_id,menu_version,status_code,split_code,generated_at,finalized_at,is_active,generation_input_snapshot_json) "
        "VALUES(?,?,?,?,1,'FINALIZED','FULL_BODY','2026-07-01T00:00:00Z','2026-07-01T00:00:00Z',1,'{}')",
        (ids["menu"], ids["user"], rule_id, ids["week"]),
    )
    db.execute(
        "INSERT INTO workout_day_plan(id,user_id,rule_version_id,weekly_menu_id,plan_date,weekday_code,training_location_id,duration_min,status_code,session_focus_snapshot,reason_text_snapshot) "
        "VALUES(?,?,?,?,'2026-07-06','MON',?,45,'COMPLETED','胸','継続移行')",
        (ids["day_plan"], ids["user"], rule_id, ids["menu"], ids["location"]),
    )
    db.execute(
        "INSERT INTO planned_exercise(id,user_id,rule_version_id,workout_day_plan_id,exercise_id,order_index,exercise_name_snapshot,role_code_snapshot,recording_method_snapshot,target_part_snapshot,reason_text_snapshot,progression_profile_snapshot_json,status_code) "
        "VALUES(?,?,?,?,?,1,?,'PRIMARY',?,'胸','継続移行','{}','COMPLETED')",
        (
            ids["planned_exercise"], ids["user"], rule_id, ids["day_plan"],
            exercise_id, exercise_name, recording_method,
        ),
    )
    db.execute(
        "INSERT INTO planned_set(id,user_id,rule_version_id,planned_exercise_id,set_number,is_warmup,target_weight_kg,input_weight_value,input_weight_unit_code,target_reps_lower,target_reps_upper,rest_sec) "
        "VALUES(?,?,?,?,1,0,20,20,'KG',8,10,90)",
        (ids["planned_set"], ids["user"], rule_id, ids["planned_exercise"]),
    )
    db.execute(
        "INSERT INTO workout_session(id,user_id,rule_version_id,workout_day_plan_id,attempt_number,status_code,started_at,ended_at,record_date,training_location_id,last_local_saved_at,day_adjustment_snapshot_json) "
        "VALUES(?,?,?,?,1,'COMPLETED','2026-07-06T10:00:00Z','2026-07-06T10:45:00Z','2026-07-06',?,'2026-07-06T10:45:00Z','{}')",
        (ids["session"], ids["user"], rule_id, ids["day_plan"], ids["location"]),
    )
    db.execute(
        "INSERT INTO session_exercise(id,user_id,rule_version_id,workout_session_id,planned_exercise_id,exercise_id,order_index,status_code,exercise_name_snapshot,recording_method_snapshot,performance_series_key) "
        "VALUES(?,?,?,?,?,?,1,'COMPLETED',?,?,?)",
        (
            ids["session_exercise"], ids["user"], rule_id, ids["session"],
            ids["planned_exercise"], exercise_id, exercise_name, recording_method,
            exercise_id,
        ),
    )
    db.execute(
        "INSERT INTO work_set_record(id,user_id,source_device_id,session_exercise_id,planned_set_id,set_number,side_code,is_warmup,actual_weight_kg,input_weight_value,input_weight_unit_code,actual_reps,completed_at) "
        "VALUES(?,?,?,?,?,1,'BOTH',0,20,20,'KG',10,'2026-07-06T10:10:00Z')",
        (ids["set_record"], ids["user"], ids["device"], ids["session_exercise"], ids["planned_set"]),
    )
    db.execute(
        "INSERT INTO body_measurement(id,user_id,measured_at,weight_kg,body_fat_percent,source_code) "
        "VALUES(?,?, '2026-07-01T00:00:00Z',65,15,'USER')",
        (ids["measurement"], ids["user"]),
    )
    db.commit()
    return ids | {"rule": rule_id, "exercise": exercise_id}


def selected_values(db: sqlite3.Connection, ids: dict[str, str]) -> dict[str, Any]:
    return {
        "user": db.execute(
            "SELECT id,auth_provider,account_status,locale,timezone FROM user_account WHERE id=?",
            (ids["user"],),
        ).fetchone(),
        "profile": db.execute(
            "SELECT nickname,age_years,height_cm FROM user_profile WHERE id=?",
            (ids["profile"],),
        ).fetchone(),
        "plan": db.execute(
            "SELECT plan_date,status_code,session_focus_snapshot FROM workout_day_plan WHERE id=?",
            (ids["day_plan"],),
        ).fetchone(),
        "set_record": db.execute(
            "SELECT set_number,actual_weight_kg,actual_reps,completed_at FROM work_set_record WHERE id=?",
            (ids["set_record"],),
        ).fetchone(),
        "measurement": db.execute(
            "SELECT measured_at,weight_kg,body_fat_percent FROM body_measurement WHERE id=?",
            (ids["measurement"],),
        ).fetchone(),
    }


def run(project_root: Path) -> dict[str, Any]:
    docs = project_root / "docs"
    migrations = docs / "migrations"
    required = [migrations / f"v{v}_to_v{v + 1}.sql" for v in range(1, 9)]
    missing = [str(path.relative_to(project_root)) for path in required if not path.is_file()]
    if missing:
        raise AssertionError(f"Missing migration files: {missing}")

    app_database = (project_root / "lib/core/database/app_database.dart").read_text(encoding="utf-8")
    markers = [
        "schema/schema_v9.drift",
        "int get schemaVersion => 9;",
        *[f"Future<void> _migrateToV{v}() async" for v in range(2, 10)],
    ]
    missing_markers = [marker for marker in markers if marker not in app_database]
    if missing_markers:
        raise AssertionError(f"AppDatabase migration wiring is incomplete: {missing_markers}")

    with tempfile.TemporaryDirectory(prefix="full_migration_v1_to_v9_") as tmp_name:
        tmp = Path(tmp_name)
        direct = sqlite3.connect(tmp / "direct_v9.sqlite")
        direct.execute("PRAGMA foreign_keys = ON")
        direct.executescript((docs / "schema_v9.sqlite.sql").read_text(encoding="utf-8"))
        apply_seed(direct)

        migrated = sqlite3.connect(tmp / "migrated_v9.sqlite")
        migrated.execute("PRAGMA foreign_keys = ON")
        migrated.executescript((docs / "schema_v1.sqlite.sql").read_text(encoding="utf-8"))
        apply_seed(migrated)
        ids = insert_v1_fixture(migrated)
        fixture_before = selected_values(migrated, ids)

        seed_tables = [
            table
            for table in sorted(table_names(direct))
            if direct.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0] > 0
        ]
        seed_digests_before = {table: table_digest(migrated, table) for table in seed_tables}
        stage_counts = {1: len(table_names(migrated))}
        if stage_counts[1] != EXPECTED_TABLE_COUNTS[1]:
            raise AssertionError(stage_counts)
        assert_fk_clean(migrated, "Schema v1 fixture")

        for version, path in enumerate(required, start=1):
            migrated.executescript(path.read_text(encoding="utf-8"))
            migrated.commit()
            target = version + 1
            stage_counts[target] = len(table_names(migrated))
            if stage_counts[target] != EXPECTED_TABLE_COUNTS[target]:
                raise AssertionError(
                    f"Schema v{target} table count: {stage_counts[target]}"
                )
            assert_fk_clean(migrated, f"Schema v{target}")

        direct_objects = schema_objects(direct)
        migrated_objects = schema_objects(migrated)
        if direct_objects != migrated_objects:
            raise AssertionError(
                "Migrated Schema v9 differs from direct Schema v9: "
                f"direct={signature(direct_objects)} migrated={signature(migrated_objects)}"
            )

        fixture_after = selected_values(migrated, ids)
        if fixture_before != fixture_after:
            raise AssertionError(
                f"Representative v1 data changed: before={fixture_before} after={fixture_after}"
            )

        seed_digests_after = {table: table_digest(migrated, table) for table in seed_tables}
        if seed_digests_before != seed_digests_after:
            changed = sorted(
                table for table in seed_tables
                if seed_digests_before[table] != seed_digests_after[table]
            )
            raise AssertionError(f"Seed content changed during migration: {changed}")

        archived = migrated.execute(
            "SELECT id,notification_type_code,is_enabled,time_local,weekday_code "
            "FROM notification_setting_legacy_archive "
            "WHERE user_id=? ORDER BY id",
            (ids["user"],),
        ).fetchall()
        if archived != [
            ("full_migration_notification_mon", "WORKOUT_PLAN", 1, "18:00", "MON"),
            ("full_migration_notification_wed", "WORKOUT_PLAN", 1, "18:30", "WED"),
        ]:
            raise AssertionError(f"Legacy notification archive mismatch: {archived}")
        canonical = migrated.execute(
            "SELECT is_enabled,local_time,weekday_mask,source_device_id "
            "FROM notification_preference "
            "WHERE user_id=? AND notification_type_code='WORKOUT_PLAN' AND deleted_at IS NULL",
            (ids["user"],),
        ).fetchone()
        if canonical != (1, "18:30", 5, ids["device"]):
            raise AssertionError(f"Canonical notification mismatch: {canonical}")
        if "notification_setting" in table_names(migrated):
            raise AssertionError("Legacy operational notification_setting still exists")

        counts_before_reseed = {
            table: migrated.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
            for table in seed_tables
        }
        apply_seed(migrated)
        counts_after_reseed = {
            table: migrated.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
            for table in seed_tables
        }
        if counts_before_reseed != counts_after_reseed:
            raise AssertionError("Seed SQL is not idempotent on Schema v9")

        for table, expected in EXPECTED_SEED_COUNTS.items():
            actual = migrated.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
            if actual != expected:
                raise AssertionError(f"{table}: expected {expected}, got {actual}")
        assert_fk_clean(migrated, "final reseed")

        result = {
            "status": "PASS",
            "migration_files": [path.name for path in required],
            "stage_table_counts": stage_counts,
            "direct_and_migrated_schema_equal": True,
            "schema_object_count": len(direct_objects),
            "schema_signature_sha256": signature(direct_objects),
            "representative_v1_rows_preserved": True,
            "seed_content_tables_verified": len(seed_tables),
            "seed_sql_idempotent_on_v9": True,
            "seed_counts": EXPECTED_SEED_COUNTS,
            "legacy_notification_rows_archived": len(archived),
            "notification_canonical_weekday_mask": canonical[2],
            "foreign_key_violations": 0,
            "app_database_migration_wiring_verified": True,
        }
        direct.close()
        migrated.close()
        return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, default=ROOT)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    result = run(args.project_root.resolve())
    output = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)
    print(output)
    if args.json_output:
        args.json_output.write_text(output + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
