#!/usr/bin/env python3
"""Verify Task 19.5-C4 notification SQLite repository contract.

This verifier is intentionally independent of Flutter and generated Drift code.
It checks source wiring and exercises the canonical Schema v9 constraints with
representative preference and cancellation operations.
"""

from __future__ import annotations

import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]


def require(text: str, marker: str, label: str) -> None:
    if marker not in text:
        raise AssertionError(f"{label} is missing marker: {marker}")


def main() -> None:
    repository_path = ROOT / "lib/features/notifications/data/local_notification_repository.dart"
    models_path = ROOT / "lib/features/notifications/domain/notification_models.dart"
    contract_path = ROOT / "lib/features/notifications/domain/notification_repository.dart"
    provider_path = ROOT / "lib/features/notifications/presentation/notification_settings_notifier.dart"
    page_path = ROOT / "lib/features/notifications/presentation/notification_settings_page.dart"
    gateway_path = ROOT / "lib/features/notifications/data/local_notification_gateway.dart"
    test_path = ROOT / "test/features/notifications/data/local_notification_repository_test.dart"

    repository = repository_path.read_text(encoding="utf-8")
    models = models_path.read_text(encoding="utf-8")
    contract = contract_path.read_text(encoding="utf-8")
    provider = provider_path.read_text(encoding="utf-8")
    page = page_path.read_text(encoding="utf-8")
    gateway = gateway_path.read_text(encoding="utf-8")
    tests = test_path.read_text(encoding="utf-8")

    source_requirements = {
        "repository": (
            "final AppDatabase _database;",
            "FROM notification_preference",
            "INSERT INTO notification_preference",
            "UPDATE notification_preference",
            "row_version = row_version + 1",
            "sync_status = 'LOCAL_ONLY'",
            "FROM notification_schedule",
            "status_code = 'CANCELLED'",
            "_ensureDefaults",
            "_cancelSchedulesForType",
            "_localTimePattern",
        ),
        "models": (
            "workoutPlan('WORKOUT_PLAN')",
            "weeklyPlanning('WEEKLY_PLANNING')",
            "inactivity('INACTIVITY')",
            "restTimer('REST_TIMER')",
            "weekdayMask",
            "soundEnabled",
            "vibrationEnabled",
            "timezone",
        ),
        "contract": (
            "Future<bool> isPermissionGranted();",
            "Future<void> rescheduleAll();",
            "Future<void> cancelAll();",
        ),
        "provider": (
            "appDatabaseProvider",
            "LocalNotificationRepository(",
            "localNotificationGatewayProvider",
            "setLocalTime",
            "setAdvanceMinutes",
        ),
        "page": (
            "CupertinoPicker",
            "通知時刻",
            "予定より前に通知",
            "許可しなくても",
            "hour > 23",
            "minute > 59",
        ),
        "gateway": (
            "LocalNotificationGatewayStub",
            "Future<bool> isPermissionGranted() async => false;",
            "Future<bool> requestPermission() async => false;",
        ),
        "tests": (
            "4種類の既定値をSQLiteへ作成する",
            "Repositoryを作り直してもSQLiteから復元する",
            "旧予約を取消してDB状態も更新する",
        ),
    }
    texts = {
        "repository": repository,
        "models": models,
        "contract": contract,
        "provider": provider,
        "page": page,
        "gateway": gateway,
        "tests": tests,
    }
    for label, markers in source_requirements.items():
        for marker in markers:
            require(texts[label], marker, label)

    if "final Map<ReminderType" in repository or "_store =" in repository:
        raise AssertionError("Notification preferences are still stored in memory")
    for unavailable_label in ("ホーム画面ウィジェット", "Live Activity"):
        if unavailable_label in page:
            raise AssertionError(
                f"Unavailable feature is exposed in normal notification UI: {unavailable_label}"
            )
    pubspec = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
    if "flutter_local_notifications" in pubspec:
        raise AssertionError("Native notification plugin must not be claimed before iOS verification")

    schema = (ROOT / "docs/schema_v9.sqlite.sql").read_text(encoding="utf-8")
    con = sqlite3.connect(":memory:")
    con.execute("PRAGMA foreign_keys = ON")
    con.executescript(schema)
    con.execute(
        "INSERT INTO user_account(id, timezone) VALUES('c4-user', 'Asia/Tokyo')"
    )
    con.execute(
        "INSERT INTO app_preference(id, user_id, sound_enabled) VALUES('c4-app', 'c4-user', 0)"
    )

    defaults = (
        ("c4-workout", "WORKOUT_PLAN", 1, "18:00", None, 60),
        ("c4-weekly", "WEEKLY_PLANNING", 1, "19:00", None, 0),
        ("c4-inactivity", "INACTIVITY", 0, "19:00", None, 0),
        ("c4-rest", "REST_TIMER", 1, None, None, 0),
    )
    for row_id, type_code, enabled, local_time, weekday_mask, advance in defaults:
        con.execute(
            """
            INSERT INTO notification_preference(
              id, user_id, notification_type_code, is_enabled, local_time,
              weekday_mask, advance_minutes, sound_enabled,
              vibration_enabled, timezone
            ) VALUES(?, 'c4-user', ?, ?, ?, ?, ?, 0, 1, 'Asia/Tokyo')
            """,
            (row_id, type_code, enabled, local_time, weekday_mask, advance),
        )
    con.commit()

    rows = con.execute(
        """
        SELECT notification_type_code, is_enabled, local_time, weekday_mask,
               advance_minutes, sound_enabled, vibration_enabled, timezone
        FROM notification_preference
        WHERE user_id='c4-user' AND deleted_at IS NULL
        ORDER BY notification_type_code
        """
    ).fetchall()
    if len(rows) != 4:
        raise AssertionError(f"Expected 4 defaults, got {len(rows)}")

    try:
        con.execute(
            "INSERT INTO notification_preference(id,user_id,notification_type_code) "
            "VALUES('duplicate','c4-user','WORKOUT_PLAN')"
        )
        con.commit()
    except sqlite3.IntegrityError:
        con.rollback()
    else:
        raise AssertionError("Duplicate active notification preference accepted")

    con.execute(
        """
        UPDATE notification_preference
        SET local_time='20:15', advance_minutes=30,
            row_version=row_version+1, sync_status='LOCAL_ONLY'
        WHERE id='c4-workout'
        """
    )
    persisted = con.execute(
        "SELECT local_time, advance_minutes, row_version, sync_status "
        "FROM notification_preference WHERE id='c4-workout'"
    ).fetchone()
    if persisted != ("20:15", 30, 2, "LOCAL_ONLY"):
        raise AssertionError(f"Preference update did not persist: {persisted}")

    con.execute(
        """
        INSERT INTO notification_schedule(
          id, user_id, notification_type_code, scheduled_at,
          title_text, body_text, platform_notification_id
        ) VALUES(
          'c4-schedule', 'c4-user', 'WORKOUT_PLAN',
          '2026-08-01T09:00:00Z', '予定', '本文', 101
        )
        """
    )
    con.execute(
        """
        UPDATE notification_schedule
        SET status_code='CANCELLED', cancelled_at='2026-07-22T00:00:00Z',
            updated_at='2026-07-22T00:00:00Z',
            row_version=row_version+1, sync_status='LOCAL_ONLY'
        WHERE id='c4-schedule' AND status_code='SCHEDULED'
        """
    )
    cancelled = con.execute(
        "SELECT status_code, cancelled_at, row_version, sync_status "
        "FROM notification_schedule WHERE id='c4-schedule'"
    ).fetchone()
    if cancelled != (
        "CANCELLED",
        "2026-07-22T00:00:00Z",
        2,
        "LOCAL_ONLY",
    ):
        raise AssertionError(f"Schedule cancellation did not persist: {cancelled}")

    fk = con.execute("PRAGMA foreign_key_check").fetchall()
    if fk:
        raise AssertionError(f"Foreign-key violations: {fk}")
    table_count = con.execute(
        "SELECT COUNT(*) FROM sqlite_master "
        "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchone()[0]
    con.close()

    result = {
        "status": "PASS",
        "schema_version": 9,
        "tables": table_count,
        "default_preferences": 4,
        "sqlite_persistence": True,
        "active_preference_unique": True,
        "schedule_cancellation_persisted": True,
        "native_gateway": "STUB_NOT_IOS_VERIFIED",
        "flutter_tests": "AUTHORED_NOT_EXECUTED",
        "foreign_key_violations": 0,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
