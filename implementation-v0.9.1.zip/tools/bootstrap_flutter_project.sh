#!/usr/bin/env bash
set -euo pipefail

EXPECTED_FLUTTER="3.44.6"

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK ${EXPECTED_FLUTTER}が見つかりません。FVMまたは公式SDKを導入してください。" >&2
  exit 2
fi

ACTUAL_FLUTTER="$(flutter --version --machine | python3 -c 'import json,sys; print(json.load(sys.stdin)["frameworkVersion"])')"
if [[ "$ACTUAL_FLUTTER" != "$EXPECTED_FLUTTER" ]]; then
  echo "Flutter ${EXPECTED_FLUTTER}が必要です。現在は${ACTUAL_FLUTTER}です。" >&2
  exit 2
fi

# 既存のlibやpubspecは保持し、欠けているプラットフォーム雛形だけを生成します。
flutter create \
  --platforms=ios,android,web \
  --org jp.workoutmenu \
  --project-name workout_menu_app \
  .

mkdir -p config
for env in dev stg prod; do
  if [[ ! -f "config/${env}.json" ]]; then
    cp "config/${env}.example.json" "config/${env}.json"
  fi
done

flutter pub get
dart run build_runner build --delete-conflicting-outputs
make verify

echo "実装基盤の準備が完了しました。Flutter/iOS統合成功の判定にはTask 20-B runnerを実行してください。"
