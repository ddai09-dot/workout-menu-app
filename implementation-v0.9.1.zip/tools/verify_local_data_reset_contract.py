#!/usr/bin/env python3
"""Verify Task 20-A local-only data reset coverage, order and SQLite behavior."""

from __future__ import annotations

import json
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "docs/schema_v9.sqlite.sql"
REPOSITORY = ROOT / "lib/features/account/data/local_account_repository.dart"
INTERFACE = ROOT / "lib/features/account/domain/account_repository.dart"
NOTIFIER = ROOT / "lib/features/account/presentation/account_notifier.dart"
PAGE = ROOT / "lib/features/data_management/presentation/local_data_reset_page.dart"
ROUTER = ROOT / "lib/app/router/app_router.dart"
MY_PAGE = ROOT / "lib/features/my_page/presentation/my_page.dart"


def require(text: str, marker: str, label: str) -> None:
    if marker not in text:
        raise AssertionError(f"{label} is missing marker: {marker}")


def table_names(db: sqlite3.Connection) -> set[str]:
    return {
        row[0]
        for row in db.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    }


def user_owned_tables(db: sqlite3.Connection) -> set[str]:
    owned: set[str] = set()
    for table in table_names(db):
        columns = {row[1] for row in db.execute(f'PRAGMA table_info("{table}")')}
        if table == "user_account" or "user_id" in columns:
            owned.add(table)
    return owned


def parse_delete_order(source: str) -> list[str]:
    match = re.search(
        r"_userOwnedTablesInDeleteOrder\s*=\s*<String>\[(.*?)\];",
        source,
        re.DOTALL,
    )
    if match is None:
        raise AssertionError("Reset delete-order allowlist is missing")
    return re.findall(r"'([A-Za-z0-9_]+)'", match.group(1))


def verify_child_first_order(db: sqlite3.Connection, order: list[str]) -> list[tuple[str, str]]:
    position = {table: index for index, table in enumerate(order)}
    checked: list[tuple[str, str]] = []
    for child in order:
        for fk in db.execute(f'PRAGMA foreign_key_list("{child}")'):
            parent = fk[2]
            if parent in position:
                checked.append((child, parent))
                if position[child] >= position[parent]:
                    raise AssertionError(
                        f"Delete order is not child-first: {child} must precede {parent}"
                    )
    return checked


def count(db: sqlite3.Connection, table: str, where: str = "1=1", args: tuple = ()) -> int:
    return int(db.execute(f'SELECT COUNT(*) FROM "{table}" WHERE {where}', args).fetchone()[0])


def verify_sqlite_reset(order: list[str]) -> dict[str, int | bool]:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript(SCHEMA.read_text(encoding="utf-8"))

    # Master/content rows must survive a local-user reset.
    db.execute(
        "INSERT INTO rule_version(id,code,name_ja,rule_type_code,version_label,released_at,checksum) "
        "VALUES('rule-1','RULE','ルール','GENERATION','1.0','2026-07-22','hash')"
    )
    db.execute(
        "INSERT INTO ai_faq(id,category_code,question_text,answer_text,content_version) "
        "VALUES('faq-1','GENERAL','質問','回答','1')"
    )
    db.execute(
        "INSERT INTO reason_template(id,code,name_ja,template_type_code,template_text) "
        "VALUES('reason-1','WHY','理由','GENERATION','説明')"
    )

    # Current user plus a second local user prove owner isolation.
    db.execute("INSERT INTO user_account(id) VALUES('old-user')")
    db.execute("INSERT INTO user_account(id) VALUES('other-user')")
    db.execute(
        "INSERT INTO user_profile(id,user_id,nickname,age_years,age_updated_on) "
        "VALUES('profile-old','old-user','削除対象',30,'2026-07-22')"
    )
    db.execute(
        "INSERT INTO user_profile(id,user_id,nickname,age_years,age_updated_on) "
        "VALUES('profile-other','other-user','保持対象',31,'2026-07-22')"
    )
    db.execute("INSERT INTO app_preference(id,user_id) VALUES('pref-old','old-user')")
    db.execute(
        "INSERT INTO training_location(id,user_id,location_type_code,display_name) "
        "VALUES('location-old','old-user','HOME','自宅')"
    )
    db.execute(
        "INSERT INTO onboarding_draft(id,user_id,draft_json) "
        "VALUES('draft-old','old-user','{}')"
    )
    db.execute("INSERT INTO ai_chat_session(id,user_id) VALUES('chat-old','old-user')")
    db.execute(
        "INSERT INTO notification_preference(id,user_id,notification_type_code) "
        "VALUES('notification-old','old-user','WORKOUT_PLAN')"
    )
    db.execute(
        "INSERT INTO body_measurement(id,user_id,measured_at,weight_kg) "
        "VALUES('measurement-old','old-user','2026-07-22T09:00:00Z',65.0)"
    )
    db.execute(
        "INSERT INTO training_week(id,user_id,rule_version_id,week_start_date,week_end_date) "
        "VALUES('week-old','old-user','rule-1','2026-07-20','2026-07-26')"
    )
    db.execute(
        "INSERT INTO weekly_menu(id,user_id,rule_version_id,training_week_id,generated_at,generation_input_snapshot_json) "
        "VALUES('menu-old','old-user','rule-1','week-old','2026-07-22T09:00:00Z','{}')"
    )
    db.commit()

    master_before = {
        table: count(db, table)
        for table in ("rule_version", "ai_faq", "reason_template")
    }

    db.execute("BEGIN")
    for table in order:
        db.execute(f'DELETE FROM "{table}" WHERE user_id = ?', ("old-user",))
    db.execute("DELETE FROM user_account WHERE id = ?", ("old-user",))
    db.execute(
        "INSERT INTO user_account(id,auth_provider,account_status) "
        "VALUES('replacement-user','ANONYMOUS','ACTIVE')"
    )
    db.commit()

    all_owned = user_owned_tables(db)
    for table in sorted(all_owned - {"user_account"}):
        if count(db, table, "user_id = ?", ("old-user",)) != 0:
            raise AssertionError(f"Old user rows remain in {table}")
    if count(db, "user_account", "id = ?", ("old-user",)) != 0:
        raise AssertionError("Old user_account remains")
    if count(db, "user_account", "id = ?", ("replacement-user",)) != 1:
        raise AssertionError("Replacement anonymous account is missing")
    if count(db, "user_account", "id = ?", ("other-user",)) != 1:
        raise AssertionError("Other user_account was deleted")
    if count(db, "user_profile", "user_id = ?", ("other-user",)) != 1:
        raise AssertionError("Other user's profile was deleted")

    master_after = {
        table: count(db, table)
        for table in ("rule_version", "ai_faq", "reason_template")
    }
    if master_after != master_before:
        raise AssertionError(
            f"Master/content rows changed: before={master_before}, after={master_after}"
        )
    violations = db.execute("PRAGMA foreign_key_check").fetchall()
    if violations:
        raise AssertionError(f"Foreign-key violations after reset: {violations}")
    db.close()
    return {
        "seeded_current_user_rows": 9,
        "other_user_preserved": True,
        "replacement_account_created": True,
        "master_tables_preserved": len(master_before),
        "foreign_key_violations": 0,
    }


def main() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript(SCHEMA.read_text(encoding="utf-8"))

    repository = REPOSITORY.read_text(encoding="utf-8")
    interface = INTERFACE.read_text(encoding="utf-8")
    notifier = NOTIFIER.read_text(encoding="utf-8")
    page = PAGE.read_text(encoding="utf-8")
    router = ROUTER.read_text(encoding="utf-8")
    my_page = MY_PAGE.read_text(encoding="utf-8")

    order = parse_delete_order(repository)
    if len(order) != len(set(order)):
        raise AssertionError("Reset delete-order allowlist contains duplicates")

    owned = user_owned_tables(db)
    expected = owned - {"user_account"}
    actual = set(order)
    if actual != expected:
        raise AssertionError(
            "Reset table coverage mismatch: "
            f"missing={sorted(expected - actual)}, extra={sorted(actual - expected)}"
        )
    fk_edges = verify_child_first_order(db, order)

    require(interface, "Future<AccountSnapshot> resetLocalData();", "AccountRepository")
    require(repository, "_resetCompletion", "LocalAccountRepository concurrency guard")
    require(repository, "await _secureStore.write(", "LocalAccountRepository secure key rotation")
    require(repository, "value: currentUserId", "LocalAccountRepository rollback")
    require(repository, "DELETE FROM user_account WHERE id = ?", "LocalAccountRepository")
    require(repository, "replacementUserId", "LocalAccountRepository")
    require(notifier, "Future<bool> resetLocalData()", "AccountNotifier")
    require(page, "削除したデータは元に戻せない", "LocalDataResetPage")
    require(page, "削除されるもの", "LocalDataResetPage")
    require(page, "削除されないもの", "LocalDataResetPage")
    require(page, "context.go('/launch')", "LocalDataResetPage")
    require(page, "ref.invalidate(aiCoachProvider)", "LocalDataResetPage")
    require(router, "path: 'data'", "app_router")
    require(my_page, "端末内データ", "MyPage")
    require(my_page, "/my-page/data", "MyPage")
    repository_test = ROOT / "test/features/account/data/local_account_repository_test.dart"
    widget_test = ROOT / "test/features/data_management/presentation/local_data_reset_page_test.dart"
    if not repository_test.is_file() or not widget_test.is_file():
        raise AssertionError("Local reset Flutter tests are missing")
    require(repository_test.read_text(encoding="utf-8"), "other user are preserved", "Repository test")
    require(widget_test.read_text(encoding="utf-8"), "irreversible deletion is acknowledged", "Widget test")

    sqlite_result = verify_sqlite_reset(order)
    db.close()

    result = {
        "status": "PASS",
        "schema": "v9",
        "user_owned_tables_including_account": len(owned),
        "delete_allowlist_tables": len(order),
        "coverage_exact": True,
        "duplicate_tables": 0,
        "child_first_fk_edges_checked": len(fk_edges),
        "runtime_table_identifiers": "FIXED_INTERNAL_ALLOWLIST",
        "master_or_content_tables_in_delete_allowlist": 0,
        "ui_confirmation_steps": 2,
        **sqlite_result,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
