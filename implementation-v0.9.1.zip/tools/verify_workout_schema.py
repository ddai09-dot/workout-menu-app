from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def uid() -> str:
    return str(uuid.uuid4())


def statements(path: Path) -> list[str]:
    return [
        value.strip()
        for value in path.read_text(encoding="utf-8").split("\n-- statement\n")
        if value.strip()
    ]


def load_seed(db: sqlite3.Connection) -> None:
    for path in [
        ROOT / "assets/seed/seed_v1.sql",
        ROOT / "assets/seed/seed_patch_v2.sql",
    ]:
        for statement in statements(path):
            db.execute(statement)


def insert_plan_fixture(db: sqlite3.Connection) -> dict[str, str]:
    user_id = uid()
    location_id = uid()
    week_id = uid()
    menu_id = uid()
    day_id = uid()
    planned_exercise_id = uid()
    planned_set_1 = uid()
    planned_set_2 = uid()
    rule_id = db.execute(
        "SELECT id FROM rule_version WHERE code='MENU_RULE_V1_1'"
    ).fetchone()[0]
    exercise = db.execute(
        "SELECT id,name_ja,recording_method_code FROM exercise_master "
        "WHERE code='EX001'"
    ).fetchone()
    exercise_id, exercise_name, recording_method = exercise

    db.execute(
        "INSERT INTO user_account(id,auth_provider,account_status,locale,timezone) "
        "VALUES (?, 'ANONYMOUS','ACTIVE','ja-JP','Asia/Tokyo')",
        (user_id,),
    )
    db.execute(
        "INSERT INTO training_location(id,user_id,location_type_code,display_name,is_primary) "
        "VALUES (?,?, 'HOME','自宅',1)",
        (location_id, user_id),
    )
    db.execute(
        "INSERT INTO training_week(id,user_id,rule_version_id,week_start_date,week_end_date,status_code) "
        "VALUES (?,?,?,?,?,'FINALIZED')",
        (week_id, user_id, rule_id, "2026-07-13", "2026-07-19"),
    )
    db.execute(
        "INSERT INTO weekly_menu("
        "id,user_id,rule_version_id,training_week_id,menu_version,status_code,"
        "split_code,generated_at,finalized_at,is_active,"
        "generation_input_snapshot_json,generation_trace_json,estimated_total_min"
        ") VALUES (?,?,?,?,1,'FINALIZED','FULL_BODY','2026-07-13T00:00:00Z',"
        "'2026-07-13T00:00:00Z',1,'{}','{}',45)",
        (menu_id, user_id, rule_id, week_id),
    )
    db.execute(
        "INSERT INTO workout_day_plan("
        "id,user_id,rule_version_id,weekly_menu_id,plan_date,weekday_code,"
        "training_location_id,duration_min,status_code,session_focus_snapshot,"
        "reason_text_snapshot,estimated_duration_min"
        ") VALUES (?,?,?,?,?,'MON',?,45,'PLANNED','胸・肩','優先部位を先に実施',45)",
        (day_id, user_id, rule_id, menu_id, "2026-07-13", location_id),
    )
    db.execute(
        "INSERT INTO planned_exercise("
        "id,user_id,rule_version_id,workout_day_plan_id,exercise_id,order_index,"
        "exercise_name_snapshot,role_code_snapshot,recording_method_snapshot,"
        "target_part_snapshot,reason_text_snapshot,progression_profile_snapshot_json,"
        "selection_score,selection_reason_ids_json,status_code"
        ") VALUES (?,?,?,?,?,1,?,'PRIMARY',?,'胸','主種目','{}',100,'[]','PLANNED')",
        (
            planned_exercise_id,
            user_id,
            rule_id,
            day_id,
            exercise_id,
            exercise_name,
            recording_method,
        ),
    )
    for set_id, set_number in [(planned_set_1, 1), (planned_set_2, 2)]:
        db.execute(
            "INSERT INTO planned_set("
            "id,user_id,rule_version_id,planned_exercise_id,set_number,is_warmup,"
            "target_weight_kg,input_weight_value,input_weight_unit_code,"
            "target_reps_lower,target_reps_upper,rest_sec"
            ") VALUES (?,?,?,?,?,0,20,20,'KG',8,12,90)",
            (set_id, user_id, rule_id, planned_exercise_id, set_number),
        )
    return {
        "user_id": user_id,
        "rule_id": rule_id,
        "location_id": location_id,
        "day_id": day_id,
        "exercise_id": exercise_id,
        "exercise_name": exercise_name,
        "recording_method": recording_method,
        "planned_exercise_id": planned_exercise_id,
        "planned_set_1": planned_set_1,
        "planned_set_2": planned_set_2,
    }


def verify_fresh_and_lifecycle() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v4.sqlite.sql").read_text(encoding="utf-8"))
    load_seed(db)

    table_count = db.execute(
        "SELECT COUNT(*) FROM sqlite_master "
        "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchone()[0]
    assert table_count == 56, table_count
    assert db.execute("SELECT COUNT(*) FROM exercise_master").fetchone()[0] == 72

    fixture = insert_plan_fixture(db)
    session_id = uid()
    session_exercise_id = uid()
    started = datetime(2026, 7, 13, 23, 58, tzinfo=timezone.utc)
    started_text = started.isoformat().replace("+00:00", "Z")
    interaction_text = (started + timedelta(minutes=1)).isoformat().replace(
        "+00:00", "Z"
    )
    db.execute(
        "INSERT INTO workout_session("
        "id,user_id,rule_version_id,workout_day_plan_id,attempt_number,status_code,"
        "started_at,record_date,training_location_id,current_session_exercise_id,"
        "current_set_number,last_local_saved_at,day_adjustment_snapshot_json,"
        "current_input_draft_json,last_interaction_at"
        ") VALUES (?,?,?,?,1,'IN_PROGRESS',?,'2026-07-13',?, ?,1,?,'{}','{}',?)",
        (
            session_id,
            fixture["user_id"],
            fixture["rule_id"],
            fixture["day_id"],
            started_text,
            fixture["location_id"],
            session_exercise_id,
            interaction_text,
            interaction_text,
        ),
    )

    # A double tap or retry must not create a second open workout for the user.
    try:
        db.execute(
            "INSERT INTO workout_session("
            "id,user_id,rule_version_id,workout_day_plan_id,attempt_number,status_code,"
            "started_at,record_date,last_local_saved_at,last_interaction_at"
            ") VALUES (?,?,?,?,2,'IN_PROGRESS',?,'2026-07-13',?,?)",
            (
                uid(),
                fixture["user_id"],
                fixture["rule_id"],
                fixture["day_id"],
                started_text,
                interaction_text,
                interaction_text,
            ),
        )
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("A second open workout session was accepted.")
    db.execute(
        "INSERT INTO session_exercise("
        "id,user_id,rule_version_id,workout_session_id,planned_exercise_id,exercise_id,"
        "order_index,status_code,exercise_name_snapshot,recording_method_snapshot,"
        "performance_series_key,started_at,original_order_index,original_set_count,"
        "target_set_count"
        ") VALUES (?,?,?,?,?,?,1,'IN_PROGRESS',?,?,?, ?,1,2,2)",
        (
            session_exercise_id,
            fixture["user_id"],
            fixture["rule_id"],
            session_id,
            fixture["planned_exercise_id"],
            fixture["exercise_id"],
            fixture["exercise_name"],
            fixture["recording_method"],
            fixture["exercise_id"],
            started_text,
        ),
    )
    target_ids: list[str] = []
    for number, planned_set_id in [
        (1, fixture["planned_set_1"]),
        (2, fixture["planned_set_2"]),
    ]:
        target_id = uid()
        target_ids.append(target_id)
        db.execute(
            "INSERT INTO session_set_target("
            "id,user_id,rule_version_id,session_exercise_id,planned_set_id,set_number,"
            "is_warmup,target_weight_kg,input_weight_value,input_weight_unit_code,"
            "target_reps_lower,target_reps_upper,rest_sec,source_code"
            ") VALUES (?,?,?,?,?,?,0,20,20,'KG',8,12,90,'PLANNED')",
            (
                target_id,
                fixture["user_id"],
                fixture["rule_id"],
                session_exercise_id,
                planned_set_id,
                number,
            ),
        )

    completed_at = (started + timedelta(minutes=4)).isoformat().replace(
        "+00:00", "Z"
    )
    original_record_id = uid()
    db.execute(
        "INSERT INTO work_set_record("
        "id,user_id,session_exercise_id,planned_set_id,set_number,side_code,is_warmup,"
        "actual_weight_kg,input_weight_value,input_weight_unit_code,actual_reps,"
        "completed_at"
        ") VALUES (?,?,?,?,1,'BOTH',0,20,20,'KG',10,?)",
        (
            original_record_id,
            fixture["user_id"],
            session_exercise_id,
            fixture["planned_set_1"],
            completed_at,
        ),
    )

    # Repeated submission of the same active set must be rejected. A correction
    # becomes insertable only after the previous row is voided.
    try:
        db.execute(
            "INSERT INTO work_set_record("
            "id,user_id,session_exercise_id,planned_set_id,set_number,side_code,is_warmup,"
            "actual_weight_kg,input_weight_value,input_weight_unit_code,actual_reps,"
            "completed_at"
            ") VALUES (?,?,?,?,1,'BOTH',0,20,20,'KG',10,?)",
            (
                uid(),
                fixture["user_id"],
                session_exercise_id,
                fixture["planned_set_1"],
                completed_at,
            ),
        )
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("A duplicate active work set was accepted.")
    rest_started = datetime(2026, 7, 14, 0, 2, tzinfo=timezone.utc)
    db.execute(
        "UPDATE workout_session SET rest_started_at=?,rest_duration_sec=90 "
        "WHERE id=?",
        (rest_started.isoformat().replace("+00:00", "Z"), session_id),
    )
    remaining_at_30 = max(
        0,
        90
        - int(
            (
                rest_started + timedelta(seconds=30) - rest_started
            ).total_seconds()
        ),
    )
    assert remaining_at_30 == 60

    correction_time = (started + timedelta(minutes=5)).isoformat().replace(
        "+00:00", "Z"
    )
    replacement_record_id = uid()
    db.execute(
        "UPDATE work_set_record SET voided_at=?,correction_reason_code='USER_EDIT' "
        "WHERE id=?",
        (correction_time, original_record_id),
    )
    db.execute(
        "INSERT INTO work_set_record("
        "id,user_id,supersedes_id,session_exercise_id,planned_set_id,set_number,"
        "side_code,is_warmup,actual_weight_kg,input_weight_value,"
        "input_weight_unit_code,actual_reps,correction_reason_code,completed_at"
        ") VALUES (?,?,?,?,?,1,'BOTH',0,20,20,'KG',11,'USER_EDIT',?)",
        (
            replacement_record_id,
            fixture["user_id"],
            original_record_id,
            session_exercise_id,
            fixture["planned_set_1"],
            completed_at,
        ),
    )
    assert db.execute(
        "SELECT COUNT(*) FROM work_set_record WHERE session_exercise_id=?",
        (session_exercise_id,),
    ).fetchone()[0] == 2
    assert db.execute(
        "SELECT COUNT(*) FROM work_set_record WHERE session_exercise_id=? "
        "AND voided_at IS NULL",
        (session_exercise_id,),
    ).fetchone()[0] == 1

    event_id = uid()
    db.execute(
        "INSERT INTO workout_session_event("
        "id,user_id,workout_session_id,session_exercise_id,event_type_code,"
        "payload_json,occurred_at"
        ") VALUES (?,?,?,?, 'SET_CORRECTED', ?, ?)",
        (
            event_id,
            fixture["user_id"],
            session_id,
            session_exercise_id,
            json.dumps(
                {
                    "voidedRecordId": original_record_id,
                    "replacementRecordId": replacement_record_id,
                }
            ),
            correction_time,
        ),
    )

    ended = datetime(2026, 7, 14, 0, 10, tzinfo=timezone.utc)
    ended_text = ended.isoformat().replace("+00:00", "Z")
    db.execute(
        "UPDATE workout_session SET status_code='AWAITING_ASSESSMENT',ended_at=?,"
        "rest_started_at=NULL,rest_duration_sec=NULL WHERE id=?",
        (ended_text, session_id),
    )
    assessment_id = uid()
    db.execute(
        "INSERT INTO post_workout_assessment("
        "id,user_id,rule_version_id,workout_session_id,overall_difficulty_score,"
        "had_pain,incomplete_reason_code,completed_exercise_count,"
        "completed_work_set_count,actual_duration_sec"
        ") VALUES (?,?,?,?,4,0,'TIME',0,1,720)",
        (
            assessment_id,
            fixture["user_id"],
            fixture["rule_id"],
            session_id,
        ),
    )
    db.execute(
        "UPDATE workout_session SET status_code='PARTIAL',completion_reason_code='NORMAL' "
        "WHERE id=?",
        (session_id,),
    )

    try:
        db.execute(
            "INSERT INTO post_workout_assessment("
            "id,user_id,rule_version_id,workout_session_id,overall_difficulty_score"
            ") VALUES (?,?,?,?,3)",
            (uid(), fixture["user_id"], fixture["rule_id"], session_id),
        )
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("Duplicate active assessment was accepted.")

    try:
        db.execute(
            "INSERT INTO session_set_target("
            "id,user_id,rule_version_id,session_exercise_id,set_number,rest_sec"
            ") VALUES (?,?,?,?,1,90)",
            (uid(), fixture["user_id"], fixture["rule_id"], session_exercise_id),
        )
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("Duplicate active set target was accepted.")

    record_date = db.execute(
        "SELECT record_date FROM workout_session WHERE id=?", (session_id,)
    ).fetchone()[0]
    assert record_date == "2026-07-13", record_date
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []


def insert_minimal_v3_session(db: sqlite3.Connection) -> str:
    load_seed(db)
    fixture = insert_plan_fixture(db)
    session_id = uid()
    db.execute(
        "INSERT INTO workout_session("
        "id,user_id,rule_version_id,workout_day_plan_id,status_code,started_at,"
        "record_date,last_local_saved_at"
        ") VALUES (?,?,?,?,'IN_PROGRESS','2026-07-13T01:00:00Z','2026-07-13',"
        "'2026-07-13T01:05:00Z')",
        (session_id, fixture["user_id"], fixture["rule_id"], fixture["day_id"]),
    )
    return session_id


def verify_v3_to_v4_migration() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v3.sqlite.sql").read_text(encoding="utf-8"))
    session_id = insert_minimal_v3_session(db)
    db.executescript((ROOT / "docs/migrations/v3_to_v4.sql").read_text(encoding="utf-8"))

    tables = {
        row[0]
        for row in db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    }
    assert {"session_set_target", "workout_session_event"}.issubset(tables)
    session_columns = {
        row[1] for row in db.execute("PRAGMA table_info(workout_session)")
    }
    assert {
        "current_input_draft_json",
        "last_interaction_at",
        "completion_reason_code",
    }.issubset(session_columns)
    exercise_columns = {
        row[1] for row in db.execute("PRAGMA table_info(session_exercise)")
    }
    assert {
        "skip_reason_code",
        "started_at",
        "ended_at",
        "original_order_index",
        "original_set_count",
        "target_set_count",
    }.issubset(exercise_columns)
    indexes = {
        row[1] for row in db.execute("PRAGMA index_list(workout_session)")
    }
    assert "uq_open_workout_session" in indexes
    work_set_indexes = {
        row[1] for row in db.execute("PRAGMA index_list(work_set_record)")
    }
    assert "uq_active_work_set" in work_set_indexes
    backfilled = db.execute(
        "SELECT last_interaction_at FROM workout_session WHERE id=?", (session_id,)
    ).fetchone()[0]
    assert backfilled == "2026-07-13T01:05:00Z", backfilled
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []


def verify_full_migration_chain() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v1.sqlite.sql").read_text(encoding="utf-8"))
    for migration in [
        "v1_to_v2.sql",
        "v2_to_v3.sql",
        "v3_to_v4.sql",
    ]:
        db.executescript((ROOT / "docs/migrations" / migration).read_text(encoding="utf-8"))
    table_count = db.execute(
        "SELECT COUNT(*) FROM sqlite_master "
        "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchone()[0]
    assert table_count == 56, table_count
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []


def main() -> None:
    verify_fresh_and_lifecycle()
    verify_v3_to_v4_migration()
    verify_full_migration_chain()
    print(
        "Workout schema verification passed "
        "(fresh lifecycle + v3→v4 + v1→v2→v3→v4)."
    )


if __name__ == "__main__":
    main()
