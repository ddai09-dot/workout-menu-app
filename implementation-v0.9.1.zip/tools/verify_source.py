from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / "lib"


def verify_imports() -> None:
    missing = []
    pattern = re.compile(r"import 'package:workout_menu_app/([^']+)';")
    for path in LIB.rglob("*.dart"):
        text = path.read_text(encoding="utf-8")
        for relative in pattern.findall(text):
            target = LIB / relative
            if not target.exists():
                missing.append((path.relative_to(ROOT), target.relative_to(ROOT)))
    assert not missing, f"Missing local imports: {missing}"


def verify_delimiters() -> None:
    pairs = {')': '(', ']': '[', '}': '{'}
    for path in LIB.rglob("*.dart"):
        text = path.read_text(encoding="utf-8")
        # Strip simple quoted strings and comments. This is a smoke check, not a Dart parser.
        text = re.sub(r"'''[\s\S]*?'''", "", text)
        text = re.sub(r'"""[\s\S]*?"""', "", text)
        text = re.sub(r"'([^'\\]|\\.)*'", "''", text)
        text = re.sub(r'"([^"\\]|\\.)*"', '""', text)
        text = re.sub(r"//.*", "", text)
        stack = []
        for char in text:
            if char in "([{":
                stack.append(char)
            elif char in ")]}":
                assert stack and stack[-1] == pairs[char], (
                    f"Delimiter mismatch in {path}: {char}"
                )
                stack.pop()
        assert not stack, f"Unclosed delimiters in {path}: {stack}"


def main() -> None:
    verify_imports()
    verify_delimiters()
    print("Source smoke verification passed (imports + delimiters).")


if __name__ == "__main__":
    main()
