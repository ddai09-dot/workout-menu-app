#!/usr/bin/env python3
"""Verify Task 19.5-C1 form-copy, image-gate, fallback, and integration contracts."""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "docs/schema_v9.sqlite.sql"
SEEDS = [
    ROOT / "assets/seed/seed_v1.sql",
    ROOT / "assets/seed/seed_patch_v2.sql",
    ROOT / "assets/seed/seed_patch_v3.sql",
]
FIXED_TIP = "ダンベルを身体（鎖骨）と平行に保ち、肩甲骨を寄せて前腕を床と垂直にします。"
FIXED_POSE_1 = "床に仰向けになり、ダンベルを身体（鎖骨）と平行に保ち、上腕が床へ軽く触れるまで胸の横へ下ろした姿勢"
FIXED_POSE_2 = "ダンベルを身体（鎖骨）と平行に保ち、肩を安定させたまま胸の上へ押し上げた姿勢"


def statements(path: Path) -> list[str]:
    return [
        part.strip()
        for part in path.read_text(encoding="utf-8").split("\n-- statement\n")
        if part.strip()
    ]


def require(path: Path, markers: tuple[str, ...]) -> None:
    text = path.read_text(encoding="utf-8")
    missing = [marker for marker in markers if marker not in text]
    if missing:
        raise AssertionError(f"{path.relative_to(ROOT)} missing markers: {missing}")


def main() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript(SCHEMA.read_text(encoding="utf-8"))
    for seed in SEEDS:
        for statement in statements(seed):
            db.execute(statement)
    db.commit()

    active_copy = db.execute(
        "SELECT COUNT(*) FROM exercise_form_copy WHERE is_active = 1"
    ).fetchone()[0]
    active_assets = db.execute(
        "SELECT COUNT(*) FROM exercise_form_asset WHERE is_active = 1"
    ).fetchone()[0]
    per_exercise = {
        row[0]: row[1]
        for row in db.execute(
            "SELECT em.code, COUNT(efa.id) FROM exercise_master em "
            "LEFT JOIN exercise_form_asset efa "
            "ON efa.exercise_id = em.id AND efa.is_active = 1 "
            "WHERE em.is_active = 1 GROUP BY em.code"
        )
    }
    assert active_copy == 72
    assert active_assets == 144
    assert set(per_exercise.values()) == {2}

    statuses = dict(
        db.execute(
            "SELECT asset_status, COUNT(*) FROM exercise_form_asset "
            "WHERE is_active = 1 GROUP BY asset_status"
        )
    )
    assert statuses == {"NOT_STARTED": 144}
    assert db.execute(
        "SELECT COUNT(*) FROM exercise_form_asset WHERE checksum = 'PENDING'"
    ).fetchone()[0] == 144

    form_rows = json.loads(
        (ROOT / "assets/seed/form_copy_v1_2.json").read_text(encoding="utf-8")
    )
    exercise_rows = json.loads(
        (ROOT / "assets/seed/exercises_v2_2.json").read_text(encoding="utf-8")
    )
    assert len(form_rows) == 72 and len(exercise_rows) == 72
    ex003_form = next(row for row in form_rows if row["ID"] == "EX003")
    ex003_exercise = next(row for row in exercise_rows if row["ID"] == "EX003")
    assert ex003_form["動作のポイント"] == FIXED_TIP
    assert ex003_exercise["コツ"] == FIXED_TIP
    assert ex003_exercise["画像用動作ポイント"] == FIXED_TIP
    assert ex003_exercise["画像1姿勢"] == FIXED_POSE_1
    assert ex003_exercise["画像2姿勢"] == FIXED_POSE_2
    db_ex003 = db.execute(
        "SELECT efc.movement_tip, efc.content_version "
        "FROM exercise_form_copy efc "
        "JOIN exercise_master em ON em.id = efc.exercise_id "
        "WHERE em.code = 'EX003'"
    ).fetchone()
    assert db_ex003 == (FIXED_TIP, 2)

    require(
        ROOT / "lib/features/exercise_form/data/local_exercise_form_repository.dart",
        (
            "exercise_form_copy",
            "exercise_form_asset",
            "ORDER BY efa.asset_position ASC",
            "for (final position in const <int>[1, 2])",
        ),
    )
    require(
        ROOT / "lib/features/exercise_form/data/asset_bundle_exercise_form_image_resolver.dart",
        (
            "'READY'",
            "'PUBLISHED'",
            "assets/images/exercises/",
            "sha256.convert(bytes)",
            "checksumPending",
            "checksumMismatch",
            "missingAsset",
            "_successCache",
        ),
    )
    require(
        ROOT / "lib/features/exercise_form/presentation/exercise_form_section.dart",
        (
            "画像は準備中です",
            "動作のポイント",
            "注意点",
            "Image.memory",
            "errorBuilder",
            "もう一度試す",
        ),
    )
    require(
        ROOT / "lib/app/router/app_router.dart",
        ("/exercise-form/:exerciseId", "ExerciseFormPage"),
    )
    require(
        ROOT / "lib/features/workout/presentation/workout_session_page.dart",
        ("フォームを確認", "/exercise-form/${exercise.exerciseId}"),
    )
    require(
        ROOT / "lib/features/records/presentation/exercise_detail_page.dart",
        ("フォームを確認", "/exercise-form/$exerciseId"),
    )
    require(
        ROOT / "lib/core/database/seed/seed_loader.dart",
        ("SEED_PATCH_V3", "seed_patch_v3.sql"),
    )

    bundled_images = sorted(
        path
        for path in (ROOT / "assets/images/exercises").glob("*.png")
        if path.is_file()
    )
    assert not bundled_images, bundled_images

    result = {
        "status": "PASS",
        "active_form_copy": active_copy,
        "active_form_assets": active_assets,
        "assets_per_exercise": 2,
        "current_asset_statuses": statuses,
        "bundled_exercise_images": len(bundled_images),
        "text_fallback_required_for_exercises": 72,
        "repository_slot_contract": "PASS",
        "repository_availability_gate": "PASS",
        "checksum_verification": "PASS",
        "ui_fallback_contract": "PASS",
        "workout_integration": "PASS",
        "record_detail_integration": "PASS",
        "ex003_orientation_rule": "PASS",
        "foreign_key_violations": len(db.execute("PRAGMA foreign_key_check").fetchall()),
    }
    assert result["foreign_key_violations"] == 0
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
