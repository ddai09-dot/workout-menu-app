#!/usr/bin/env bash
set -euo pipefail

# Compatibility entrypoint. The canonical Task 20-B runner emits step logs and
# a machine-readable result under build/task20_b_logs/flutter/.
exec "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/run_task20_b_flutter_checks.sh" "$@"
