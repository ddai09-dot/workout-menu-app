#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

EXPECTED_FLUTTER="3.44.6"
EXPECTED_FLUTTER_REF_PREFIX="ee80f08"
LOG_DIR="${TASK20_B_LOG_DIR:-$ROOT/build/task20_b_logs/flutter}"
STEPS_FILE="$LOG_DIR/steps.ndjson"
mkdir -p "$LOG_DIR"
: > "$STEPS_FILE"
STARTED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

record_step() {
  local name="$1"
  local status="$2"
  local exit_code="$3"
  local started_at="$4"
  local finished_at="$5"
  local duration_seconds="$6"
  local log_file="${7:-}"
  TASK20_B_STEP_NAME="$name" TASK20_B_STEP_STATUS="$status" \
  TASK20_B_STEP_EXIT_CODE="$exit_code" TASK20_B_STEP_STARTED_AT="$started_at" \
  TASK20_B_STEP_FINISHED_AT="$finished_at" TASK20_B_STEP_DURATION="$duration_seconds" \
  TASK20_B_STEP_LOG="$log_file" TASK20_B_STEPS_FILE="$STEPS_FILE" \
  python3 - <<'PY'
import json
import os
from pathlib import Path

payload = {
    "name": os.environ["TASK20_B_STEP_NAME"],
    "status": os.environ["TASK20_B_STEP_STATUS"],
    "exit_code": int(os.environ["TASK20_B_STEP_EXIT_CODE"]),
    "started_at_utc": os.environ["TASK20_B_STEP_STARTED_AT"],
    "finished_at_utc": os.environ["TASK20_B_STEP_FINISHED_AT"],
    "duration_seconds": int(os.environ["TASK20_B_STEP_DURATION"]),
    "log_file": os.environ["TASK20_B_STEP_LOG"] or None,
}
with Path(os.environ["TASK20_B_STEPS_FILE"]).open("a", encoding="utf-8") as stream:
    stream.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
PY
}

record_gate() {
  local name="$1"
  local status="$2"
  local exit_code="$3"
  local message="$4"
  local now
  now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  printf '%s\n' "$message" | tee "$LOG_DIR/${name}.log"
  record_step "$name" "$status" "$exit_code" "$now" "$now" 0 "$LOG_DIR/${name}.log"
}

run_logged_step() {
  local name="$1"
  local log_name="$2"
  shift 2
  local started_at finished_at start_epoch finish_epoch code status
  started_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  start_epoch="$(date +%s)"
  set +e
  "$@" 2>&1 | tee "$LOG_DIR/$log_name"
  code="${PIPESTATUS[0]}"
  set -e
  finished_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  finish_epoch="$(date +%s)"
  status="PASS"
  if [[ "$code" -ne 0 ]]; then
    status="FAIL"
  fi
  record_step "$name" "$status" "$code" "$started_at" "$finished_at" "$((finish_epoch - start_epoch))" "$LOG_DIR/$log_name"
  if [[ "$code" -ne 0 ]]; then
    return "$code"
  fi
}

run_optional_step() {
  local name="$1"
  local log_name="$2"
  shift 2
  local started_at finished_at start_epoch finish_epoch code status
  started_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  start_epoch="$(date +%s)"
  set +e
  "$@" 2>&1 | tee "$LOG_DIR/$log_name"
  code="${PIPESTATUS[0]}"
  set -e
  finished_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  finish_epoch="$(date +%s)"
  status="PASS"
  if [[ "$code" -ne 0 ]]; then
    status="WARN"
  fi
  record_step "$name" "$status" "$code" "$started_at" "$finished_at" "$((finish_epoch - start_epoch))" "$LOG_DIR/$log_name"
}

write_result() {
  local exit_code="$1"
  local status="FAIL"
  if [[ "$exit_code" -eq 0 ]]; then
    status="PASS"
  elif [[ "$exit_code" -eq 2 ]]; then
    status="BLOCKED"
  fi
  TASK20_B_STATUS="$status" TASK20_B_EXIT_CODE="$exit_code" \
  TASK20_B_STARTED_AT="$STARTED_AT" TASK20_B_LOG_DIR="$LOG_DIR" \
  TASK20_B_STEPS_FILE="$STEPS_FILE" \
  python3 - <<'PY'
import json
import os
import platform
import shutil
from datetime import datetime, timezone
from pathlib import Path

root = Path.cwd()
steps_file = Path(os.environ["TASK20_B_STEPS_FILE"])
steps = []
if steps_file.is_file():
    for line in steps_file.read_text(encoding="utf-8").splitlines():
        if line.strip():
            steps.append(json.loads(line))
generated = sorted(str(path.relative_to(root)) for path in root.glob("lib/**/*.g.dart"))
result = {
    "task": "20-B Flutter integration execution",
    "status": os.environ["TASK20_B_STATUS"],
    "exit_code": int(os.environ["TASK20_B_EXIT_CODE"]),
    "host_os": platform.system(),
    "host_architecture": platform.machine(),
    "started_at_utc": os.environ["TASK20_B_STARTED_AT"],
    "finished_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    "pinned_flutter": "3.44.6",
    "pinned_flutter_ref_prefix": "ee80f08",
    "commands": {
        "flutter": shutil.which("flutter"),
        "dart": shutil.which("dart"),
    },
    "artifacts": {
        "pubspec_lock": (root / "pubspec.lock").is_file(),
        "drift_generated_code": (root / "lib/core/database/app_database.g.dart").is_file(),
        "generated_dart_file_count": len(generated),
        "generated_dart_files": generated,
    },
    "steps": steps,
    "failed_or_blocked_steps": [step["name"] for step in steps if step["status"] in {"FAIL", "BLOCKED"}],
    "warning_steps": [step["name"] for step in steps if step["status"] == "WARN"],
    "log_directory": os.environ["TASK20_B_LOG_DIR"],
    "note": "PASS is emitted only after pub get, Drift generation, make verify, analyze, custom_lint and flutter test all succeed.",
}
path = Path(os.environ["TASK20_B_LOG_DIR"]) / "result.json"
path.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
}
trap 'code=$?; write_result "$code"' EXIT
exec > >(tee "$LOG_DIR/console.log") 2>&1

echo "Task 20-B Flutter integration checks"
echo "UTC start: $STARTED_AT"
echo "Root: $ROOT"

if ! command -v flutter >/dev/null 2>&1; then
  record_gate "preflight_flutter" "BLOCKED" 2 "ERROR: Flutter SDK ${EXPECTED_FLUTTER} is required but flutter was not found."
  exit 2
fi
if ! command -v dart >/dev/null 2>&1; then
  record_gate "preflight_dart" "BLOCKED" 2 "ERROR: Dart executable was not found."
  exit 2
fi
record_gate "preflight_commands" "PASS" 0 "Flutter and Dart commands are available."

run_logged_step "flutter_version" "flutter_version.txt" flutter --version
run_optional_step "flutter_doctor" "flutter_doctor.txt" flutter doctor -v

ACTUAL_FLUTTER="$(flutter --version --machine | python3 -c 'import json,sys; print(json.load(sys.stdin)["frameworkVersion"])')"
ACTUAL_FRAMEWORK_REVISION="$(flutter --version --machine | python3 -c 'import json,sys; print(json.load(sys.stdin).get("frameworkRevision", ""))')"
if [[ "$ACTUAL_FLUTTER" != "$EXPECTED_FLUTTER" ]]; then
  record_gate "pinned_flutter_version" "BLOCKED" 2 "ERROR: Flutter ${EXPECTED_FLUTTER} is pinned; found ${ACTUAL_FLUTTER}."
  exit 2
fi
if [[ "$ACTUAL_FRAMEWORK_REVISION" != "$EXPECTED_FLUTTER_REF_PREFIX"* ]]; then
  record_gate "pinned_flutter_revision" "BLOCKED" 2 "ERROR: Flutter ref prefix ${EXPECTED_FLUTTER_REF_PREFIX} is pinned; found ${ACTUAL_FRAMEWORK_REVISION}."
  exit 2
fi
record_gate "pinned_flutter_release" "PASS" 0 "Flutter ${ACTUAL_FLUTTER} / ${ACTUAL_FRAMEWORK_REVISION} matches the pinned release."

mkdir -p config
for environment in dev stg prod; do
  if [[ ! -f "config/${environment}.json" ]]; then
    cp "config/${environment}.example.json" "config/${environment}.json"
  fi
done
record_gate "runtime_config" "PASS" 0 "Local runtime configuration files are available."

run_logged_step "flutter_pub_get" "flutter_pub_get.log" flutter pub get
run_logged_step "build_runner" "build_runner.log" dart run build_runner build --delete-conflicting-outputs
run_logged_step "make_verify" "make_verify.log" make verify
run_logged_step "flutter_analyze" "flutter_analyze.log" flutter analyze
run_logged_step "custom_lint" "custom_lint.log" dart run custom_lint
run_logged_step "flutter_test" "flutter_test.log" flutter test --reporter expanded

python3 - <<'PY' | tee "$LOG_DIR/generated_artifacts.json"
import hashlib
import json
from pathlib import Path

root = Path.cwd()
lock = root / "pubspec.lock"
generated = sorted(str(path.relative_to(root)) for path in root.glob("lib/**/*.g.dart"))
print(json.dumps({
    "pubspec_lock": str(lock.relative_to(root)) if lock.is_file() else None,
    "pubspec_lock_sha256": hashlib.sha256(lock.read_bytes()).hexdigest() if lock.is_file() else None,
    "generated_dart_files": generated,
    "generated_dart_file_count": len(generated),
}, ensure_ascii=False, indent=2, sort_keys=True))
PY
record_gate "generated_artifact_manifest" "PASS" 0 "Generated artifact manifest was written."

echo "Task 20-B Flutter integration checks passed."
