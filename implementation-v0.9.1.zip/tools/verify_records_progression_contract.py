from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def require(path: str, *tokens: str) -> None:
    text = (ROOT / path).read_text(encoding="utf-8")
    for token in tokens:
        assert token in text, f"{path}: missing {token!r}"


def main() -> None:
    require(
        "lib/features/progression/domain/result_classifier.dart",
        "ProgressionResultCodes.pain",
        "ProgressionResultCodes.allUpper",
        "ProgressionResultCodes.mixedLoad",
        "validForPerformance",
    )
    require(
        "lib/features/progression/domain/progression_engine.dart",
        "consecutiveAllUpper",
        "stallCount >= 3",
        "sleepScore",
        "ProgressionProposalTypes.reduceWeight",
    )
    require(
        "lib/features/progression/data/local_progression_repository.dart",
        "processUnevaluatedSessions",
        "performance_series_key",
        "cooldown_remaining_sessions",
        "accepted_progression_adjustment",
        "ProposalDecisionCodes.accept",
        "ProposalDecisionCodes.maintain",
        "ProposalDecisionCodes.defer",
        "ProposalDecisionCodes.reject",
    )
    require(
        "lib/features/records/data/local_records_repository.dart",
        "loadDashboard",
        "loadWorkoutDetail",
        "loadExerciseHistory",
        "saveBodyMeasurement",
        "voided_at",
        "supersedes_id",
    )
    require(
        "lib/app/router/app_router.dart",
        "path: 'history'",
        "path: 'session/:sessionId'",
        "path: 'exercise/:exerciseId'",
        "path: 'measurements'",
        "path: 'proposals'",
    )
    require(
        "lib/features/workout/presentation/workout_notifier.dart",
        "processCompletedSession(id)",
        "The workout completion is authoritative",
    )
    require(
        "lib/features/weekly_planner/data/local_weekly_planner_repository.dart",
        "_applyQueuedProgressionAdjustment",
        "status_code = 'APPLIED'",
    )
    source = "\n".join(
        path.read_text(encoding="utf-8")
        for path in (ROOT / "lib/features/progression").rglob("*.dart")
    )
    assert "RIR" not in source
    assert "RPE" not in source
    print("Records/progression contract verification passed.")


if __name__ == "__main__":
    main()
