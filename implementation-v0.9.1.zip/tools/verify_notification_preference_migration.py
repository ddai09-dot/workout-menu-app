#!/usr/bin/env python3
"""Verify Schema v8 -> v9 notification preference consolidation.

The migration must:
- make notification_preference the only operational source of truth;
- preserve every legacy notification_setting row verbatim in an archive table;
- consolidate weekday rows into a bit mask without overwriting an existing
  active notification_preference;
- flag unknown weekday codes for manual review;
- produce the same structural Schema v9 as direct creation.

This verifier intentionally does not require Flutter or Drift.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import tempfile
from typing import Any

LEGACY_COLUMNS = (
    'id', 'user_id', 'created_at', 'updated_at', 'deleted_at', 'row_version',
    'sync_status', 'source_device_id', 'notification_type_code', 'is_enabled',
    'time_local', 'weekday_code',
)


def normalize_sql(sql: str | None) -> str | None:
    if sql is None:
        return None
    text = re.sub(r'\s+', ' ', sql.strip()).replace(' ;', ';')
    text = re.sub(r'\s*,\s*', ',', text)
    text = re.sub(r'\(\s+', '(', text)
    text = re.sub(r'\s+\)', ')', text)
    return text


def create_db(path: Path, *scripts: str) -> sqlite3.Connection:
    con = sqlite3.connect(path)
    con.execute('PRAGMA foreign_keys = ON')
    for script in scripts:
        con.executescript(script)
    con.commit()
    return con


def index_signature(con: sqlite3.Connection, table: str) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for row in con.execute(f'PRAGMA index_list("{table}")').fetchall():
        _, name, unique, origin, partial = row[:5]
        sql_row = con.execute(
            "SELECT sql FROM sqlite_master WHERE type='index' AND name=?", (name,)
        ).fetchone()
        result.append({
            'name': name,
            'unique': unique,
            'origin': origin,
            'partial': partial,
            'columns': con.execute(f'PRAGMA index_info("{name}")').fetchall(),
            'xinfo': con.execute(f'PRAGMA index_xinfo("{name}")').fetchall(),
            'sql': normalize_sql(sql_row[0]) if sql_row else None,
        })
    return sorted(result, key=lambda item: item['name'])


def database_signature(con: sqlite3.Connection) -> dict[str, Any]:
    tables = [row[0] for row in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ).fetchall()]
    return {
        'tables': {
            table: {
                'columns': con.execute(f'PRAGMA table_info("{table}")').fetchall(),
                'foreign_keys': con.execute(f'PRAGMA foreign_key_list("{table}")').fetchall(),
                'indexes': index_signature(con, table),
                'checks_and_table_sql': normalize_sql(con.execute(
                    "SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table,)
                ).fetchone()[0]),
            }
            for table in tables
        },
        'triggers': [
            (name, table, normalize_sql(sql))
            for name, table, sql in con.execute(
                "SELECT name, tbl_name, sql FROM sqlite_master "
                "WHERE type='trigger' ORDER BY name"
            ).fetchall()
        ],
    }


def structural_signature(con: sqlite3.Connection) -> dict[str, Any]:
    """Compare physical behavior, ignoring ALTER TABLE formatting differences."""
    sig = database_signature(con)
    for table in sig['tables'].values():
        # PRAGMA output, indexes and triggers are authoritative. Table SQL remains
        # useful for CHECK constraints; normalize punctuation and ALTER spacing.
        sql = table['checks_and_table_sql']
        if sql:
            sql = sql.replace(' ,', ',')
            table['checks_and_table_sql'] = sql
    return sig


def table_rows(con: sqlite3.Connection, table: str, columns: tuple[str, ...]) -> dict[str, tuple[Any, ...]]:
    column_list = ', '.join(columns)
    return {
        row[0]: tuple(row)
        for row in con.execute(f'SELECT {column_list} FROM "{table}" ORDER BY id').fetchall()
    }


def expect_integrity_error(con: sqlite3.Connection, sql: str, params: tuple[Any, ...]) -> None:
    try:
        con.execute(sql, params)
        con.commit()
    except sqlite3.IntegrityError:
        con.rollback()
        return
    raise AssertionError(f'Expected IntegrityError: {sql}')


def seed_legacy_cases(con: sqlite3.Connection) -> dict[str, tuple[Any, ...]]:
    con.executescript('''
      INSERT INTO user_account(id, timezone) VALUES
        ('notif_u1', 'Asia/Tokyo'),
        ('notif_u2', 'America/New_York'),
        ('notif_u3', 'Asia/Tokyo'),
        ('notif_u4', 'Asia/Tokyo');

      INSERT INTO device_registration(id, user_id, app_version) VALUES
        ('notif_d1', 'notif_u1', '0.8.2'),
        ('notif_d2', 'notif_u2', '0.8.2'),
        ('notif_d3', 'notif_u3', '0.8.2');

      INSERT INTO app_preference(id, user_id, sound_enabled) VALUES
        ('notif_ap1', 'notif_u1', 0),
        ('notif_ap2', 'notif_u2', 1);

      INSERT INTO notification_setting(
        id, user_id, created_at, updated_at, deleted_at, row_version,
        sync_status, source_device_id, notification_type_code, is_enabled,
        time_local, weekday_code
      ) VALUES
        ('legacy_mon', 'notif_u1', '2026-01-01T00:00:00Z', '2026-01-01T00:00:00Z', NULL, 1,
         'SYNCED', 'notif_d1', 'WORKOUT_PLAN', 1, '18:00', 'MON'),
        ('legacy_wed', 'notif_u1', '2026-01-02T00:00:00Z', '2026-01-02T00:00:00Z', NULL, 2,
         'SYNCED', 'notif_d1', 'WORKOUT_PLAN', 1, '18:30', 'WED'),
        ('legacy_fri', 'notif_u1', '2026-01-03T00:00:00Z', '2026-01-03T00:00:00Z', NULL, 3,
         'SYNCED', 'notif_d1', 'WORKOUT_PLAN', 0, '19:00', 'FRI'),
        ('legacy_rest', 'notif_u1', '2026-01-04T00:00:00Z', '2026-01-04T00:00:00Z', NULL, 1,
         'LOCAL_ONLY', 'notif_d1', 'REST_TIMER', 1, NULL, NULL),
        ('legacy_existing', 'notif_u2', '2026-01-01T00:00:00Z', '2026-01-02T00:00:00Z', NULL, 1,
         'LOCAL_ONLY', 'notif_d2', 'WORKOUT_PLAN', 1, '17:00', 'TUE'),
        ('legacy_unknown', 'notif_u3', '2026-01-01T00:00:00Z', '2026-01-03T00:00:00Z', NULL, 1,
         'LOCAL_ONLY', 'notif_d3', 'INACTIVITY', 1, '20:00', 'HOLIDAY'),
        ('legacy_deleted', 'notif_u4', '2026-01-01T00:00:00Z', '2026-01-01T00:00:00Z',
         '2026-02-01T00:00:00Z', 1, 'LOCAL_ONLY', NULL, 'WEEKLY_PLANNING', 1, '19:00', 'SUN');

      INSERT INTO notification_preference(
        id, user_id, notification_type_code, is_enabled, local_time,
        weekday_mask, advance_minutes, sound_enabled, vibration_enabled,
        timezone, created_at, updated_at, row_version, sync_status
      ) VALUES(
        'existing_preference', 'notif_u2', 'WORKOUT_PLAN', 0, '16:00',
        127, 30, 0, 0, 'America/New_York',
        '2026-01-10T00:00:00Z', '2026-01-10T00:00:00Z', 5, 'LOCAL_ONLY'
      );
    ''')
    con.commit()
    return table_rows(con, 'notification_setting', LEGACY_COLUMNS)


def run(project_root: Path) -> dict[str, Any]:
    docs = project_root / 'docs'
    app_database_text = (project_root / 'lib/core/database/app_database.dart').read_text(encoding='utf-8')
    required_app_markers = (
        "schema/schema_v9.drift",
        "int get schemaVersion => 9;",
        "Future<void> _migrateToV9() async",
        "notification_setting_legacy_archive",
    )
    missing_markers = [marker for marker in required_app_markers if marker not in app_database_text]
    if missing_markers:
        raise AssertionError(f'AppDatabase is not wired to Schema v9: {missing_markers}')

    schema_v8 = (docs / 'schema_v8.sqlite.sql').read_text(encoding='utf-8')
    schema_v9 = (docs / 'schema_v9.sqlite.sql').read_text(encoding='utf-8')
    migration = (docs / 'migrations/v8_to_v9.sql').read_text(encoding='utf-8')
    seed_v1 = (project_root / 'assets/seed/seed_v1.sql').read_text(encoding='utf-8')
    seed_patch = (project_root / 'assets/seed/seed_patch_v2.sql').read_text(encoding='utf-8')

    with tempfile.TemporaryDirectory(prefix='notification_v8_to_v9_') as tmp_dir:
        tmp = Path(tmp_dir)
        direct = create_db(tmp / 'direct_v9.sqlite', schema_v9, seed_v1, seed_patch)
        migrated = create_db(tmp / 'migrated_v9.sqlite', schema_v8, seed_v1, seed_patch)

        legacy_before = seed_legacy_cases(migrated)
        preexisting_counts = {
            table: migrated.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
            for table in (
                'exercise_master', 'equipment_master', 'exercise_form_asset',
                'exercise_progression_profile', 'user_account',
            )
        }

        migrated.executescript(migration)
        migrated.commit()

        if migrated.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='notification_setting'"
        ).fetchone():
            raise AssertionError('Legacy operational notification_setting still exists')

        table_names = {
            row[0] for row in migrated.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        }
        required = {
            'notification_preference', 'notification_schedule',
            'notification_delivery_log', 'notification_setting_legacy_archive',
        }
        if len(table_names) != 75 or not required.issubset(table_names):
            raise AssertionError(
                f'Unexpected Schema v9 tables: count={len(table_names)} missing={sorted(required - table_names)}'
            )

        legacy_after = table_rows(
            migrated, 'notification_setting_legacy_archive', LEGACY_COLUMNS
        )
        if legacy_before != legacy_after:
            raise AssertionError('Legacy notification rows were not preserved verbatim')

        if len(legacy_after) != 7:
            raise AssertionError(f'Expected 7 archived rows, got {len(legacy_after)}')

        workout = migrated.execute('''
          SELECT is_enabled, local_time, weekday_mask, sound_enabled, timezone, source_device_id
          FROM notification_preference
          WHERE user_id='notif_u1' AND notification_type_code='WORKOUT_PLAN' AND deleted_at IS NULL
        ''').fetchone()
        if workout != (0, '19:00', 21, 0, 'Asia/Tokyo', 'notif_d1'):
            raise AssertionError(f'Unexpected consolidated workout preference: {workout}')

        rest = migrated.execute('''
          SELECT weekday_mask, local_time
          FROM notification_preference
          WHERE user_id='notif_u1' AND notification_type_code='REST_TIMER' AND deleted_at IS NULL
        ''').fetchone()
        if rest != (None, None):
            raise AssertionError(f'All-day/rest preference mapping failed: {rest}')

        existing = migrated.execute('''
          SELECT id, is_enabled, local_time, weekday_mask, advance_minutes,
                 sound_enabled, vibration_enabled, timezone, source_device_id
          FROM notification_preference
          WHERE user_id='notif_u2' AND notification_type_code='WORKOUT_PLAN' AND deleted_at IS NULL
        ''').fetchone()
        if existing != (
            'existing_preference', 0, '16:00', 127, 30,
            0, 0, 'America/New_York', 'notif_d2'
        ):
            raise AssertionError(f'Existing canonical preference was overwritten: {existing}')

        unknown = migrated.execute('''
          SELECT weekday_mask
          FROM notification_preference
          WHERE user_id='notif_u3' AND notification_type_code='INACTIVITY' AND deleted_at IS NULL
        ''').fetchone()
        if unknown != (None,):
            raise AssertionError(f'Unknown weekday must map to NULL: {unknown}')

        deleted_only = migrated.execute('''
          SELECT COUNT(*) FROM notification_preference
          WHERE user_id='notif_u4' AND notification_type_code='WEEKLY_PLANNING' AND deleted_at IS NULL
        ''').fetchone()[0]
        if deleted_only != 0:
            raise AssertionError('Deleted-only legacy setting created an active preference')

        statuses = dict(migrated.execute(
            'SELECT id, migration_status_code FROM notification_setting_legacy_archive'
        ).fetchall())
        expected_statuses = {
            'legacy_mon': 'CONSOLIDATED',
            'legacy_wed': 'CONSOLIDATED',
            'legacy_fri': 'CONSOLIDATED',
            'legacy_rest': 'MIGRATED',
            'legacy_existing': 'MAPPED_TO_EXISTING',
            'legacy_unknown': 'REVIEW_REQUIRED_WEEKDAY',
            'legacy_deleted': 'DELETED_SOURCE',
        }
        if statuses != expected_statuses:
            raise AssertionError(f'Unexpected archive statuses: {statuses}')

        archive_mappings = migrated.execute('''
          SELECT COUNT(*)
          FROM notification_setting_legacy_archive a
          LEFT JOIN notification_preference p ON p.id = a.migrated_preference_id
          WHERE a.migrated_preference_id IS NOT NULL AND p.id IS NULL
        ''').fetchone()[0]
        if archive_mappings != 0:
            raise AssertionError('Archive contains invalid migrated_preference_id')

        post_counts = {
            table: migrated.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
            for table in preexisting_counts
        }
        if preexisting_counts != post_counts:
            raise AssertionError(
                f'Unrelated row counts changed: before={preexisting_counts} after={post_counts}'
            )

        direct_sig = structural_signature(direct)
        migrated_sig = structural_signature(migrated)
        if direct_sig != migrated_sig:
            direct_json = json.dumps(direct_sig, ensure_ascii=False, sort_keys=True, default=str)
            migrated_json = json.dumps(migrated_sig, ensure_ascii=False, sort_keys=True, default=str)
            raise AssertionError(
                'Migrated Schema v9 differs from direct Schema v9. '
                f'direct_sha256={hashlib.sha256(direct_json.encode()).hexdigest()} '
                f'migrated_sha256={hashlib.sha256(migrated_json.encode()).hexdigest()}'
            )

        fk_direct = direct.execute('PRAGMA foreign_key_check').fetchall()
        fk_migrated = migrated.execute('PRAGMA foreign_key_check').fetchall()
        if fk_direct or fk_migrated:
            raise AssertionError(f'Foreign key violations: direct={fk_direct}, migrated={fk_migrated}')

        expect_integrity_error(
            migrated,
            '''INSERT INTO notification_preference(
                 id, user_id, notification_type_code, source_device_id
               ) VALUES (?, ?, ?, ?)''',
            ('bad_device_pref', 'notif_u1', 'BAD_DEVICE_TEST', 'missing_device'),
        )
        expect_integrity_error(
            migrated,
            '''INSERT INTO notification_preference(
                 id, user_id, notification_type_code
               ) VALUES (?, ?, ?)''',
            ('duplicate_active_pref', 'notif_u1', 'WORKOUT_PLAN'),
        )
        expect_integrity_error(
            migrated,
            '''INSERT INTO notification_setting_legacy_archive(
                 id, user_id, created_at, updated_at, row_version, sync_status,
                 notification_type_code, is_enabled, migration_status_code
               ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (
                'bad_archive_status', 'notif_u1', '2026-01-01', '2026-01-01',
                1, 'LOCAL_ONLY', 'WORKOUT_PLAN', 1, 'UNKNOWN_STATUS'
            ),
        )

        signature_json = json.dumps(
            direct_sig, ensure_ascii=False, sort_keys=True, default=str
        )
        result = {
            'status': 'PASS',
            'schema_v8_tables_before': 75,
            'schema_v9_tables_after': 75,
            'operational_notification_source': 'notification_preference',
            'legacy_archive_table': 'notification_setting_legacy_archive',
            'legacy_rows_preserved_verbatim': True,
            'legacy_rows_archived': len(legacy_after),
            'weekday_mask_mapping_verified': {'MON_WED_FRI': 21, 'ALL_DAY': None},
            'unknown_weekday_review_flag_verified': True,
            'existing_preference_preserved': True,
            'deleted_only_row_did_not_create_active_preference': True,
            'direct_and_migrated_schema_equal': True,
            'foreign_key_violations': 0,
            'active_preference_unique_constraint_verified': True,
            'source_device_foreign_key_verified': True,
            'archive_status_check_verified': True,
            'app_database_schema_v9_wiring_verified': True,
            'schema_object_count': sum(len(v) if isinstance(v, list) else 1 for v in []),
            'signature_sha256': hashlib.sha256(signature_json.encode('utf-8')).hexdigest(),
        }
        result['schema_object_count'] = migrated.execute(
            "SELECT COUNT(*) FROM sqlite_master WHERE name NOT LIKE 'sqlite_%'"
        ).fetchone()[0]
        direct.close()
        migrated.close()
        return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--project-root', type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument('--json-output', type=Path)
    args = parser.parse_args()
    result = run(args.project_root)
    text = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)
    print(text)
    if args.json_output:
        args.json_output.write_text(text + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
