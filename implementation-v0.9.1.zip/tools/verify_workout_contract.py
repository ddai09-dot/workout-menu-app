from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED = {
    "lib/features/workout/domain/workout_models.dart": [
        "WEIGHT_REPS",
        "REPS_LOADABLE",
        "ASSISTANCE_REVERSE",
        "VARIATION_FIRST",
        "BAND_STEPS",
        "MULTI_MODE",
        "variationCode",
        "equipmentModeCode",
    ],
    "lib/features/workout/data/local_workout_repository.dart": [
        "class LocalWorkoutRepository",
        "Future<WorkoutExecutionState> startSession",
        "current_input_draft_json",
        "rest_started_at",
        "rest_duration_sec",
        "session_set_target",
        "workout_session_event",
        "SET_COMPLETED",
        "SET_CORRECTED",
        "EXERCISE_MOVED_LATER",
        "EXERCISE_SKIPPED",
        "EXERCISE_SUBSTITUTED",
        "SESSION_STOPPED_EARLY",
        "SESSION_FINALIZED",
        "supersedes_id",
        "voided_at",
        "AWAITING_ASSESSMENT",
        "record_date",
        "result.length == 3",
        "REDUCE_LOAD",
        "variation_code",
        "equipment_mode_code",
        "se.exercise_id = ?",
        "seed.targets.clear();",
        "completed + 1",
        "effectiveEnd",
    ],
    "lib/features/workout/presentation/workout_notifier.dart": [
        "AsyncNotifierProvider",
        "Timer.periodic",
        "_inputSaveQueue",
        "await _inputSaveQueue",
        "completeSet",
        "correctLastSet",
        "finishRestAndAdvance",
        "moveLater",
        "stopEarly",
        "finishAssessment",
        "current.isSaving",
        "rethrow",
    ],
    "lib/features/workout/presentation/workout_start_page.dart": [
        "WorkoutStartPage",
        "予定どおり開始",
        "今日の状態を調整",
    ],
    "lib/features/workout/presentation/workout_adjustment_page.dart": [
        "WorkoutAdjustmentPage",
        "15",
        "30",
        "45",
        "60",
        "90",
        "REDUCE_LOAD",
        "LOW_IMPACT_ALTERNATIVE",
        "MOVE_LATER",
    ],
    "lib/features/workout/presentation/workout_session_page.dart": [
        "セット完了",
        "前回記録",
        "−15秒",
        "＋15秒",
        "休憩を終了する",
        "次のセットへ",
        "最後のセットを修正",
        "種目を変更",
        "セット数を変更",
        "後へ移動",
        "スキップ",
        "途中で終了",
        "PopScope",
    ],
    "lib/features/workout/presentation/workout_assessment_page.dart": [
        "WorkoutAssessmentPage",
        "記録して終了",
        "difficulty",
        "incompleteReason",
        "関連した種目（任意）",
    ],
    "docs/schema_v4.sqlite.sql": [
        "uq_open_workout_session",
        "uq_active_work_set",
    ],
    "docs/migrations/v3_to_v4.sql": [
        "uq_open_workout_session",
        "uq_active_work_set",
    ],
    "lib/app/router/app_router.dart": [
        "/workout/start/:dayPlanId",
        "/workout/session/:sessionId",
        "/workout/assessment/:sessionId",
    ],
    "lib/features/home/data/local_today_action_repository.dart": [
        "AWAITING_ASSESSMENT",
        "IN_PROGRESS",
        "/workout/session/",
    ],
    "lib/features/menu/presentation/menu_page.dart": [
        "/workout/start/",
        "開始",
    ],
}


def main() -> None:
    errors: list[str] = []
    for relative, tokens in REQUIRED.items():
        path = ROOT / relative
        if not path.exists():
            errors.append(f"missing: {relative}")
            continue
        text = path.read_text(encoding="utf-8")
        for token in tokens:
            if token not in text:
                errors.append(f"{relative}: missing token {token!r}")

    all_workout_source = "\n".join(
        path.read_text(encoding="utf-8")
        for path in (ROOT / "lib/features/workout").rglob("*.dart")
    )
    if "RIR" in all_workout_source or "RPE入力" in all_workout_source:
        errors.append("Workout UI must not require RIR/RPE input.")
    if "flutter_local_notifications" in (ROOT / "pubspec.yaml").read_text(
        encoding="utf-8"
    ):
        errors.append(
            "OS notification plugin was added without native configuration and test evidence."
        )

    assert not errors, "; ".join(errors)
    print("Workout execution source contract verification passed.")


if __name__ == "__main__":
    main()
