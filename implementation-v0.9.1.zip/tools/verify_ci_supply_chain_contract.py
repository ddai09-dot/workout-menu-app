#!/usr/bin/env python3
"""Verify Task 20-B GitHub Actions supply-chain and evidence contracts."""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOWS = [ROOT / ".github/workflows/ci.yml", ROOT / ".github/workflows/ios-build.yml"]
FULL_SHA = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+@([0-9a-f]{40})(?:\s+#.*)?$")
EXPECTED = {
    "actions/checkout": "08eba0b27e820071cde6df949e0beb9ba4906955",
    "actions/upload-artifact": "ea165f8d65b6e75b540449e92b4886f43607fa02",
}
checks: list[str] = []
uses_count = 0


def require(name: str, condition: bool, detail: str) -> None:
    if not condition:
        raise AssertionError(f"{name}: {detail}")
    checks.append(name)


for workflow in WORKFLOWS:
    content = workflow.read_text(encoding="utf-8")
    label = workflow.name
    require(f"{label}_least_privilege", "permissions:\n  contents: read" in content, "contents must be read-only")
    require(f"{label}_concurrency", "concurrency:" in content and "cancel-in-progress: true" in content, "duplicate runs must cancel")
    require(f"{label}_official_installer", "tools/install_pinned_flutter_sdk.py" in content, "official SDK installer missing")
    require(f"{label}_version", "--version 3.44.6" in content, "Flutter version not pinned")
    require(f"{label}_ref", "--ref-prefix ee80f08" in content, "Flutter release ref not pinned")
    require(f"{label}_no_third_party_setup", "subosito/flutter-action" not in content, "third-party setup action must be absent")
    require(f"{label}_no_cache_action", "actions/cache@" not in content and "cache: true" not in content, "cache is deferred until first PASS")
    require(f"{label}_credentials", "persist-credentials: false" in content, "checkout token must not persist")
    require(f"{label}_logs", "build/task20_b_logs" in content and "result" in content, "evidence path missing")
    require(f"{label}_lock_artifact", "pubspec.lock" in content, "lock file must be collected")
    require(f"{label}_generated_artifact", "lib/**/*.g.dart" in content, "generated code must be collected")
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped.startswith("uses: "):
            continue
        uses_count += 1
        value = stripped.removeprefix("uses: ")
        match = FULL_SHA.match(value)
        require(f"{label}_uses_{uses_count}_full_sha", match is not None, f"action not pinned to full SHA: {value}")
        action, sha_comment = value.split("@", 1)
        sha = sha_comment.split()[0]
        if action in EXPECTED:
            require(f"{label}_{action}_expected_sha", sha == EXPECTED[action], f"unexpected SHA {sha}")

require("uses_present", uses_count == 4, f"expected 4 action uses, found {uses_count}")
flutter_workflow = WORKFLOWS[0].read_text(encoding="utf-8")
ios_workflow = WORKFLOWS[1].read_text(encoding="utf-8")
require("flutter_runner", "run_task20_b_flutter_checks.sh" in flutter_workflow, "Flutter runner missing")
require("ios_runner", "run_task20_b_ios_simulator.sh" in ios_workflow, "iOS runner missing")
require("ios_app_artifact", "build/ios/iphonesimulator/*.app" in ios_workflow, "Simulator app must be collected")

print(json.dumps({
    "status": "PASS",
    "checks": len(checks),
    "workflows": len(WORKFLOWS),
    "action_uses": uses_count,
    "all_actions_pinned_to_full_sha": True,
    "third_party_flutter_setup_action": "REMOVED_PERMANENTLY",
    "cross_run_cache": "TEMPORARILY_DEFERRED_UNTIL_FIRST_PASS",
    "permissions": "contents:read",
}, ensure_ascii=False, indent=2, sort_keys=True))
