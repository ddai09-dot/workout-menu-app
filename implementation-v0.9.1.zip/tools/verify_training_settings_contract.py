#!/usr/bin/env python3
"""Verify Task 19.5-C2 training-setting editing contracts.

This verifier is intentionally independent from Flutter. It checks Schema v9,
master-code availability, the seven editing routes, normalized persistence,
future-menu-only application, impact review behavior, and the prohibition on
silently rewriting existing plans or records.
"""
from __future__ import annotations

import json
import re
import sqlite3
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "docs/schema_v9.sqlite.sql"
SEEDS = [
    ROOT / "assets/seed/seed_v1.sql",
    ROOT / "assets/seed/seed_patch_v2.sql",
    ROOT / "assets/seed/seed_patch_v3.sql",
]
SECTIONS = {
    "goals",
    "experience",
    "environment",
    "schedule",
    "split",
    "priorities",
    "restrictions",
}
FORBIDDEN_CURRENT_MENU_TABLES = {
    "training_week",
    "weekly_input",
    "weekly_available_day",
    "weekly_priority_part",
    "weekly_menu",
    "workout_day_plan",
    "planned_exercise",
    "planned_set",
    "workout_session",
    "session_exercise",
    "session_set_target",
    "work_set_record",
    "post_workout_assessment",
    "performance_series",
    "progression_evaluation",
    "progression_proposal",
    "progression_decision",
    "progression_adjustment_log",
}
MOVEMENT_GROUPS = {
    "PUSH": ["MV001", "MV002", "MV003", "MV008", "MV013", "MV016"],
    "PULL": ["MV004", "MV005", "MV006", "MV012"],
    "OVERHEAD_PRESS": ["MV008", "MV013"],
    "SQUAT": ["MV020", "MV023", "MV024", "MV027"],
    "HIP_HINGE": ["MV007", "MV018", "MV019"],
    "SINGLE_LEG": ["MV020", "MV027"],
    "TRUNK_FLEXION": ["MV029", "MV030", "MV031"],
    "TRUNK_EXTENSION": ["MV007"],
}


def statements(path: Path) -> list[str]:
    return [
        part.strip()
        for part in path.read_text(encoding="utf-8").split("\n-- statement\n")
        if part.strip()
    ]


def require(path: Path, markers: tuple[str, ...]) -> str:
    text = path.read_text(encoding="utf-8")
    missing = [marker for marker in markers if marker not in text]
    if missing:
        raise AssertionError(f"{path.relative_to(ROOT)} missing markers: {missing}")
    return text


def extract_method(text: str, signature: str) -> str:
    start = text.find(signature)
    if start < 0:
        raise AssertionError(f"Method not found: {signature}")
    async_marker = text.find(") async {", start)
    if async_marker < 0:
        raise AssertionError(f"Method body not found: {signature}")
    opening = async_marker + len(") async ")
    depth = 0
    for index in range(opening, len(text)):
        if text[index] == "{":
            depth += 1
        elif text[index] == "}":
            depth -= 1
            if depth == 0:
                return text[start : index + 1]
    raise AssertionError(f"Unclosed method: {signature}")


def verify_movement_group_reversibility(database: sqlite3.Connection) -> None:
    movement_codes = {
        row[0] for row in database.execute("SELECT code FROM movement_master")
    }
    referenced = {code for codes in MOVEMENT_GROUPS.values() for code in codes}
    missing = sorted(referenced - movement_codes)
    if missing:
        raise AssertionError(f"Movement groups reference missing codes: {missing}")

    signatures: dict[tuple[tuple[str, int], ...], tuple[str, ...]] = {}
    keys = list(MOVEMENT_GROUPS)
    for mask in range(1 << len(keys)):
        selected = tuple(keys[index] for index in range(len(keys)) if mask & (1 << index))
        counts: Counter[str] = Counter()
        for group in selected:
            counts.update(MOVEMENT_GROUPS[group])
        signature = tuple(sorted(counts.items()))
        previous = signatures.get(signature)
        if previous is not None and previous != selected:
            raise AssertionError(
                f"Movement-group persistence is ambiguous: {previous} vs {selected}"
            )
        signatures[signature] = selected


def main() -> None:
    database = sqlite3.connect(":memory:")
    database.execute("PRAGMA foreign_keys = ON")
    database.executescript(SCHEMA.read_text(encoding="utf-8"))
    for seed in SEEDS:
        for statement in statements(seed):
            database.execute(statement)
    database.commit()

    tables = {
        row[0]
        for row in database.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    }
    required_tables = {
        "user_training_setting",
        "user_experience_profile",
        "training_location",
        "location_equipment",
        "location_dumbbell_detail",
        "location_barbell_detail",
        "equipment_weight_option",
        "standard_schedule_day",
        "user_goal",
        "user_priority_part",
        "user_restriction",
    }
    missing_tables = sorted(required_tables - tables)
    if missing_tables:
        raise AssertionError(f"C2 tables missing from Schema v9: {missing_tables}")

    training_setting_columns = {
        row[1] for row in database.execute("PRAGMA table_info(user_training_setting)")
    }
    assert "change_applies_from" in training_setting_columns
    assert database.execute("PRAGMA foreign_key_check").fetchall() == []
    verify_movement_group_reversibility(database)

    section_source = require(
        ROOT / "lib/features/settings/domain/training_settings_section.dart",
        (
            "enum TrainingSettingsSection",
            "currentWeekReviewRecommended",
            "_environmentReduction",
            "_restrictionIncrease",
            "作成済みのメニューと記録は変更していません",
        ),
    )
    path_values = set(re.findall(r"=> '([a-z]+)'", section_source)) & SECTIONS
    assert path_values == SECTIONS, path_values

    require(
        ROOT / "lib/features/settings/data/local_training_settings_repository.dart",
        (
            "implements TrainingSettingsRepository",
            "TrainingSettingsSnapshot",
            "_decodeMovementGroups",
            "自動推測せず未選択",
            "saveTrainingSettingsSection",
        ),
    )
    onboarding_source = require(
        ROOT / "lib/features/onboarding/data/local_onboarding_repository.dart",
        (
            "Future<void> saveTrainingSettingsSection",
            "change_applies_from = 'NEXT_MENU'",
            "_replaceLocationsAndEquipment",
            "_upsertLocation",
            "_replaceRestrictions",
            "OnboardingOptions.avoidMovementCodesByGroup",
        ),
    )
    location_method = extract_method(
        onboarding_source,
        "Future<Map<String, String>> _replaceLocationsAndEquipment",
    )
    if "_softDeleteUserRows('training_location'" in location_method:
        raise AssertionError('Environment editing must preserve retained location IDs.')
    assert "existingLocations['HOME']" in location_method
    assert "existingLocations['GYM']" in location_method

    save_method = extract_method(
        onboarding_source,
        "Future<void> saveTrainingSettingsSection",
    )
    forbidden_references = sorted(
        table for table in FORBIDDEN_CURRENT_MENU_TABLES if table in save_method
    )
    if forbidden_references:
        raise AssertionError(
            f"C2 save entry point references current-menu/history tables: {forbidden_references}"
        )
    for section in (
        "goals",
        "experience",
        "environment",
        "schedule",
        "split",
        "priorities",
        "restrictions",
    ):
        assert f"TrainingSettingsSection.{section}" in save_method

    require(
        ROOT / "lib/features/settings/presentation/training_settings_edit_page.dart",
        (
            "変更を保存する",
            "保存していない変更があります",
            "今週のメニューも確認しますか？",
            "作成済みメニューは自動変更していません",
            "_hasChanges",
            "PrimaryGoalStep",
            "ExperienceHistoryStep",
            "LocationStep",
            "ScheduleStep",
            "SplitStep",
            "PrioritiesStep",
            "RestrictionsStep",
            "_EnvironmentScheduleLocationStep",
            "曜日ごとの利用場所",
        ),
    )
    my_page = require(
        ROOT / "lib/features/my_page/presentation/my_page.dart",
        (
            "TrainingSettingsSection.values",
            "作成済みのメニューと記録は自動で書き換えません",
            "/my-page/settings/${section.pathSegment}",
        ),
    )
    for label in (
        "トレーニング目的",
        "経験・継続状況",
        "環境・器具",
        "通常の予定",
        "メニューの分け方",
        "優先部位",
        "痛み・身体上の制限",
    ):
        assert label in section_source or label in my_page

    require(
        ROOT / "lib/app/router/app_router.dart",
        (
            "settings/:section",
            "TrainingSettingsSectionDefinition.fromPath",
            "TrainingSettingsEditPage",
        ),
    )
    require(
        ROOT / "test/features/settings/domain/training_settings_section_test.dart",
        (
            "equipment removal recommends current-week review",
            "new or stronger restriction recommends current-week review",
            "all seven sections have stable unique routes",
            "environment fingerprint includes weekday location assignments",
        ),
    )
    require(
        ROOT / "test/features/settings/presentation/my_page_training_settings_test.dart",
        ("all seven training setting categories",),
    )

    result = {
        "status": "PASS",
        "schema": "v9",
        "schema_tables": len(tables),
        "editable_sections": len(SECTIONS),
        "normalized_setting_tables": len(required_tables),
        "movement_group_combinations_verified": 1 << len(MOVEMENT_GROUPS),
        "future_menu_marker": "NEXT_MENU",
        "current_menu_or_history_writes_from_save_entry_point": 0,
        "equipment_reduction_review_contract": "PASS",
        "restriction_increase_review_contract": "PASS",
        "unsaved_change_guard_contract": "PASS",
        "existing_menu_immutability_contract": "PASS",
        "retained_location_identity_contract": "PASS",
        "weekday_location_dependency_contract": "PASS",
        "flutter_tests": "SPECIFIED_NOT_EXECUTED",
        "foreign_key_violations": 0,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
