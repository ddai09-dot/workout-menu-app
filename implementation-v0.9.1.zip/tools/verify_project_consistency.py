#!/usr/bin/env python3
"""Verify version, schema snapshot, documentation and CI consistency."""

from __future__ import annotations

import json
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_APP_VERSION = "0.9.1+19"
EXPECTED_SCHEMA_VERSION = 9
EXPECTED_TABLE_COUNT = 75
REQUIRED_VERIFY_SCRIPTS = [
    "verify_full_migration.py",
    "verify_app_database_migrations.py",
    "verify_seed.py",
    "verify_v6_to_v7_migration.py",
    "verify_notification_preference_migration.py",
    "verify_notification_schema.py",
    "verify_notification_repository_contract.py",
    "verify_mvp_external_feature_scope.py",
    "verify_local_data_reset_contract.py",
    "verify_onboarding_schema.py",
    "verify_onboarding_contract.py",
    "verify_weekly_planner_schema.py",
    "verify_weekly_planner_contract.py",
    "verify_workout_schema.py",
    "verify_workout_contract.py",
    "verify_records_progression_schema.py",
    "verify_records_progression_contract.py",
    "verify_exercise_form_contract.py",
    "verify_training_settings_contract.py",
    "verify_weekly_algorithm_traceability.py",
    "verify_repository_sql.py",
    "verify_source.py",
    "verify_task20_b_execution_lane.py",
    "verify_flutter_sdk_installer.py",
    "verify_ci_supply_chain_contract.py",
    "verify_project_consistency.py",
]


def require(text: str, marker: str, label: str) -> None:
    if marker not in text:
        raise AssertionError(f"{label} is missing marker: {marker}")


def main() -> None:
    pubspec = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")
    version_match = re.search(r"^version:\s*(\S+)", pubspec, re.MULTILINE)
    if version_match is None or version_match.group(1) != EXPECTED_APP_VERSION:
        raise AssertionError(f"pubspec version: {version_match.group(1) if version_match else None}")

    app_database = (ROOT / "lib/core/database/app_database.dart").read_text(encoding="utf-8")
    require(app_database, "schema/schema_v9.drift", "AppDatabase")
    require(app_database, "int get schemaVersion => 9;", "AppDatabase")

    schema_counts: dict[int, int] = {}
    for version in range(1, EXPECTED_SCHEMA_VERSION + 1):
        schema_path = ROOT / f"docs/schema_v{version}.sqlite.sql"
        drift_path = ROOT / f"lib/core/database/schema/schema_v{version}.drift"
        if not schema_path.is_file():
            raise AssertionError(f"Missing {schema_path.relative_to(ROOT)}")
        first_line = schema_path.read_text(encoding="utf-8").splitlines()[0]
        if first_line != f"-- Workout Menu App / Drift schema v{version}":
            raise AssertionError(f"Wrong schema header: {schema_path.name}: {first_line}")
        if version >= 2:
            if not drift_path.is_file():
                raise AssertionError(f"Missing {drift_path.relative_to(ROOT)}")
            if drift_path.read_text(encoding="utf-8") != schema_path.read_text(encoding="utf-8"):
                raise AssertionError(f"Drift/SQL snapshot differs for Schema v{version}")
        db = sqlite3.connect(":memory:")
        db.execute("PRAGMA foreign_keys = ON")
        db.executescript(schema_path.read_text(encoding="utf-8"))
        schema_counts[version] = db.execute(
            "SELECT COUNT(*) FROM sqlite_master "
            "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        ).fetchone()[0]
        fk = db.execute("PRAGMA foreign_key_check").fetchall()
        if fk:
            raise AssertionError(f"Schema v{version} FK violations: {fk}")
        db.close()

    if schema_counts[9] != EXPECTED_TABLE_COUNT:
        raise AssertionError(schema_counts)

    migrations = [ROOT / f"docs/migrations/v{version}_to_v{version + 1}.sql" for version in range(1, 9)]
    missing_migrations = [str(path.relative_to(ROOT)) for path in migrations if not path.is_file()]
    if missing_migrations:
        raise AssertionError(f"Missing migrations: {missing_migrations}")

    makefile = (ROOT / "Makefile").read_text(encoding="utf-8")
    ci = (ROOT / ".github/workflows/ci.yml").read_text(encoding="utf-8")
    bootstrap = (ROOT / "tools/bootstrap_flutter_project.sh").read_text(encoding="utf-8")
    for script in REQUIRED_VERIFY_SCRIPTS:
        require(makefile, f"tools/{script}", "Makefile")
    require(bootstrap, "make verify", "bootstrap script")

    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    matrix = (ROOT / "docs/VERSION_MATRIX.md").read_text(encoding="utf-8")
    roadmap = (ROOT / "docs/IMPLEMENTATION_ROADMAP.md").read_text(encoding="utf-8")
    for text, label in [(readme, "README"), (matrix, "Version Matrix")]:
        require(text, "0.9.1", label)
        require(text, "Schema v9", label)
    require(readme, "v1→v9", "README")
    require(readme, "フォーム説明", "README")
    require(readme, "マイページ通常設定編集", "README")
    require(matrix, "0.9.1+19", "Version Matrix")
    require(roadmap, "タスク19.5-C3", "Roadmap")
    require(roadmap, "タスク19.5-C4", "Roadmap")
    require(roadmap, "タスク19.5-D", "Roadmap")
    require(readme, "通知設定SQLite Repository", "README")
    require(readme, "MVP通常UIとルートから除外", "README")
    require(readme, "pubspec.lock", "README")
    require(matrix, "lockファイルはまだ存在しません", "Version Matrix")
    require(roadmap, "MVP除外／接続境界保持", "Roadmap")
    require(roadmap, "MVP除外／SQLite境界保持", "Roadmap")
    require(roadmap, "ローカルMVP", "Roadmap")
    require(roadmap, "タスク20-A", "Roadmap")
    require(roadmap, "タスク20-B", "Roadmap")
    require(readme, "端末内データ", "README")
    require(readme, "一時的に除外・後回し", "README")
    require(matrix, "タスク20-A", "Version Matrix")
    require((ROOT / "docs/PARKING_LOT.md").read_text(encoding="utf-8"), "PL-003", "Parking Lot")
    require((ROOT / "docs/DECISION_LOG.md").read_text(encoding="utf-8"), "D-002", "Decision Log")
    require((ROOT / "docs/TASK20_A_LOCAL_DATA_RESET_AND_FLUTTER_PREFLIGHT.md").read_text(encoding="utf-8"), "タスク20全体は未完了", "Task 20-A")
    require((ROOT / "docs/TASK20_B_FLUTTER_IOS_EXECUTION.md").read_text(encoding="utf-8"), "タスク20-B全体は未完了", "Task 20-B")
    require((ROOT / "docs/TASK20_B_FLUTTER_IOS_EXECUTION.md").read_text(encoding="utf-8"), "BLOCKED", "Task 20-B")
    require(ci, "run_task20_b_flutter_checks.sh", "CI")
    require(ci, "install_pinned_flutter_sdk.py", "CI")
    require(ci, "upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02", "CI")
    require(ci, "actions/checkout@08eba0b27e820071cde6df949e0beb9ba4906955", "CI")
    require((ROOT / ".github/workflows/ios-build.yml").read_text(encoding="utf-8"), "run_task20_b_ios_simulator.sh", "iOS workflow")
    require((ROOT / ".github/workflows/ios-build.yml").read_text(encoding="utf-8"), "install_pinned_flutter_sdk.py", "iOS workflow")
    require((ROOT / ".github/workflows/ios-build.yml").read_text(encoding="utf-8"), "upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02", "iOS workflow")
    require(readme, "タスク20-B", "README")
    require(matrix, "公式SDK検証・Action SHA固定済み／実行BLOCKED", "Version Matrix")
    require(readme, "subosito/flutter-action", "README")
    require(readme, "cross-run cache", "README")
    require((ROOT / "docs/PARKING_LOT.md").read_text(encoding="utf-8"), "PL-004", "Parking Lot")
    require((ROOT / "docs/DECISION_LOG.md").read_text(encoding="utf-8"), "D-006", "Decision Log")
    if "Task 17 completed" in roadmap or "Task 18 — Complete" in roadmap:
        raise AssertionError("Roadmap still overstates Task 17 or Task 18 completion")

    if (ROOT / "pubspec.lock").exists():
        lock_status = "present"
    else:
        lock_status = "not_generated_without_flutter_sdk"

    result = {
        "status": "PASS",
        "app_version": EXPECTED_APP_VERSION,
        "schema_version": EXPECTED_SCHEMA_VERSION,
        "schema_table_counts": schema_counts,
        "migration_files": len(migrations),
        "required_verify_scripts": len(REQUIRED_VERIFY_SCRIPTS),
        "ci_uses_make_verify": True,
        "schema_sql_and_drift_snapshots_equal": True,
        "documentation_status_labels_verified": True,
        "pubspec_lock": lock_status,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
