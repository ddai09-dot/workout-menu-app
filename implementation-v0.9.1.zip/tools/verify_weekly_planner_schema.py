from __future__ import annotations

import json
import sqlite3
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def uid() -> str:
    return str(uuid.uuid4())


def statements(path: Path):
    return [
        value.strip()
        for value in path.read_text(encoding="utf-8").split("\n-- statement\n")
        if value.strip()
    ]


def load_seed(db: sqlite3.Connection) -> None:
    for path in [ROOT / "assets/seed/seed_v1.sql", ROOT / "assets/seed/seed_patch_v2.sql"]:
        for statement in statements(path):
            db.execute(statement)


def verify_fresh_schema() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v3.sqlite.sql").read_text(encoding="utf-8"))
    load_seed(db)

    assert db.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchone()[0] == 54
    assert db.execute("SELECT COUNT(*) FROM exercise_master").fetchone()[0] == 72

    user_id = uid()
    rule_id = db.execute(
        "SELECT id FROM rule_version WHERE code='MENU_RULE_V1_1'"
    ).fetchone()[0]
    chest_id = db.execute(
        "SELECT id FROM body_part_master WHERE code='CHEST'"
    ).fetchone()[0]
    shoulders_id = db.execute(
        "SELECT id FROM body_part_master WHERE code='SHOULDERS'"
    ).fetchone()[0]
    exercise_id = db.execute(
        "SELECT id FROM exercise_master WHERE code='EX001'"
    ).fetchone()[0]

    db.execute(
        "INSERT INTO user_account(id,auth_provider,account_status,locale,timezone) "
        "VALUES (?, 'ANONYMOUS','ACTIVE','ja-JP','Asia/Tokyo')",
        (user_id,),
    )
    location_id = uid()
    db.execute(
        "INSERT INTO training_location(id,user_id,location_type_code,display_name,is_primary) "
        "VALUES (?,?, 'HOME','自宅',1)",
        (location_id, user_id),
    )

    draft_id = uid()
    draft = {
        "id": draft_id,
        "userId": user_id,
        "ruleVersionId": rule_id,
        "weekStartDate": "2026-07-13",
        "currentStepCode": "REVIEW",
        "days": [],
    }
    db.execute(
        "INSERT INTO weekly_planner_draft("
        "id,user_id,rule_version_id,week_start_date,current_step_code,draft_json,status_code"
        ") VALUES (?,?,?,?,?,?, 'IN_PROGRESS')",
        (draft_id, user_id, rule_id, "2026-07-13", "REVIEW", json.dumps(draft)),
    )

    week_id = uid()
    db.execute(
        "INSERT INTO training_week("
        "id,user_id,rule_version_id,week_start_date,week_end_date,status_code"
        ") VALUES (?,?,?,?,?, 'PROVISIONAL')",
        (week_id, user_id, rule_id, "2026-07-13", "2026-07-19"),
    )
    db.execute(
        "INSERT INTO weekly_input("
        "id,user_id,rule_version_id,training_week_id,same_as_last_week,sleep_score,"
        "motivation_score,weekly_load_direction_code,priority_mode_code,rest_week"
        ") VALUES (?,?,?,?,0,3,3,'APP','CUSTOM',0)",
        (uid(), user_id, rule_id, week_id),
    )
    day_id = uid()
    db.execute(
        "INSERT INTO weekly_available_day("
        "id,user_id,rule_version_id,training_week_id,weekday_code,plan_date,is_available,"
        "duration_min,training_location_id"
        ") VALUES (?,?,?,?, 'MON','2026-07-13',1,45,?)",
        (day_id, user_id, rule_id, week_id, location_id),
    )
    db.execute(
        "INSERT INTO weekly_priority_part("
        "id,user_id,rule_version_id,training_week_id,body_part_id,priority_type"
        ") VALUES (?,?,?,?,?,'MAIN')",
        (uid(), user_id, rule_id, week_id, chest_id),
    )
    db.execute(
        "INSERT INTO weekly_priority_part("
        "id,user_id,rule_version_id,training_week_id,body_part_id,priority_type"
        ") VALUES (?,?,?,?,?,'SECONDARY')",
        (uid(), user_id, rule_id, week_id, shoulders_id),
    )

    menu_id = uid()
    db.execute(
        "INSERT INTO weekly_menu("
        "id,user_id,rule_version_id,training_week_id,menu_version,status_code,split_code,"
        "generated_at,is_active,generation_input_snapshot_json,generation_trace_json,estimated_total_min"
        ") VALUES (?,?,?,?,1,'PROVISIONAL','FULL_BODY_2',CURRENT_TIMESTAMP,1,'{}','{}',45)",
        (menu_id, user_id, rule_id, week_id),
    )
    plan_id = uid()
    db.execute(
        "INSERT INTO workout_day_plan("
        "id,user_id,rule_version_id,weekly_menu_id,plan_date,weekday_code,training_location_id,"
        "duration_min,status_code,session_focus_snapshot,reason_text_snapshot,estimated_duration_min"
        ") VALUES (?,?,?,?, '2026-07-13','MON',?,45,'PLANNED','全身A','検証理由',42)",
        (plan_id, user_id, rule_id, menu_id, location_id),
    )
    planned_exercise_id = uid()
    db.execute(
        "INSERT INTO planned_exercise("
        "id,user_id,rule_version_id,workout_day_plan_id,exercise_id,order_index,"
        "exercise_name_snapshot,role_code_snapshot,recording_method_snapshot,"
        "target_part_snapshot,reason_text_snapshot,progression_profile_snapshot_json,"
        "selection_score,selection_reason_ids_json,status_code"
        ") VALUES (?,?,?,?,?,1,'スナップショット名','MAJOR','WEIGHT_REPS','胸',"
        "'理由','{}',42,'[\"EX_BASIC\"]','PLANNED')",
        (planned_exercise_id, user_id, rule_id, plan_id, exercise_id),
    )
    db.execute(
        "INSERT INTO planned_set("
        "id,user_id,rule_version_id,planned_exercise_id,set_number,is_warmup,"
        "target_reps_lower,target_reps_upper,rest_sec"
        ") VALUES (?,?,?,?,1,0,8,12,90)",
        (uid(), user_id, rule_id, planned_exercise_id),
    )

    # A soft-deleted weekly day may be replaced without violating the active-row index.
    db.execute(
        "UPDATE weekly_available_day SET deleted_at=CURRENT_TIMESTAMP WHERE id=?",
        (day_id,),
    )
    db.execute(
        "INSERT INTO weekly_available_day("
        "id,user_id,rule_version_id,training_week_id,weekday_code,plan_date,is_available,"
        "duration_min,training_location_id"
        ") VALUES (?,?,?,?, 'MON','2026-07-13',1,60,?)",
        (uid(), user_id, rule_id, week_id, location_id),
    )

    assert db.execute("PRAGMA foreign_key_check").fetchall() == []
    assert db.execute(
        "SELECT selection_score FROM planned_exercise WHERE id=?",
        (planned_exercise_id,),
    ).fetchone()[0] == 42
    assert db.execute(
        "SELECT COUNT(*) FROM weekly_priority_part WHERE training_week_id=? AND deleted_at IS NULL",
        (week_id,),
    ).fetchone()[0] == 2

    # "Start over" keeps history but retires only the current provisional draft/menu.
    reset_at = "2026-07-17T03:00:00Z"
    db.execute(
        "UPDATE weekly_planner_draft SET status_code='RESET', deleted_at=?, updated_at=? "
        "WHERE id=?",
        (reset_at, reset_at, draft_id),
    )
    db.execute(
        "UPDATE weekly_menu SET is_active=0, deleted_at=?, updated_at=? "
        "WHERE id=? AND status_code='PROVISIONAL'",
        (reset_at, reset_at, menu_id),
    )
    fresh_draft_id = uid()
    fresh_draft = dict(draft)
    fresh_draft["id"] = fresh_draft_id
    fresh_draft["currentStepCode"] = "START"
    db.execute(
        "INSERT INTO weekly_planner_draft("
        "id,user_id,rule_version_id,week_start_date,current_step_code,draft_json,status_code"
        ") VALUES (?,?,?,?,?,?, 'IN_PROGRESS')",
        (fresh_draft_id, user_id, rule_id, "2026-07-13", "START", json.dumps(fresh_draft)),
    )
    assert db.execute(
        "SELECT status_code, deleted_at FROM weekly_planner_draft WHERE id=?",
        (draft_id,),
    ).fetchone() == ("RESET", reset_at)
    assert db.execute(
        "SELECT is_active, deleted_at FROM weekly_menu WHERE id=?",
        (menu_id,),
    ).fetchone() == (0, reset_at)
    assert db.execute(
        "SELECT COUNT(*) FROM weekly_planner_draft "
        "WHERE user_id=? AND week_start_date='2026-07-13' "
        "AND status_code='IN_PROGRESS' AND deleted_at IS NULL",
        (user_id,),
    ).fetchone()[0] == 1
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []


def verify_migration() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v2.sqlite.sql").read_text(encoding="utf-8"))
    db.executescript((ROOT / "docs/migrations/v2_to_v3.sql").read_text(encoding="utf-8"))

    assert db.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='weekly_planner_draft'"
    ).fetchone()[0] == 1
    weekly_input_columns = {
        row[1] for row in db.execute("PRAGMA table_info(weekly_input)")
    }
    menu_columns = {row[1] for row in db.execute("PRAGMA table_info(weekly_menu)")}
    planned_columns = {
        row[1] for row in db.execute("PRAGMA table_info(planned_exercise)")
    }
    assert "priority_mode_code" in weekly_input_columns
    assert {"generation_trace_json", "estimated_total_min"}.issubset(menu_columns)
    assert {"selection_score", "selection_reason_ids_json"}.issubset(planned_columns)
    index_names = {
        row[1] for row in db.execute("PRAGMA index_list(weekly_priority_part)")
    }
    assert {"uq_weekly_priority_part", "uq_weekly_main_priority"}.issubset(index_names)
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []



def verify_v1_to_v3_migration() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v1.sqlite.sql").read_text(encoding="utf-8"))
    db.executescript((ROOT / "docs/migrations/v1_to_v2.sql").read_text(encoding="utf-8"))
    db.executescript((ROOT / "docs/migrations/v2_to_v3.sql").read_text(encoding="utf-8"))
    tables = {
        row[0]
        for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")
    }
    assert {
        "onboarding_draft",
        "location_dumbbell_detail",
        "location_barbell_detail",
        "weekly_planner_draft",
    }.issubset(tables)
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []

def main() -> None:
    verify_fresh_schema()
    verify_migration()
    verify_v1_to_v3_migration()
    print("Weekly planner schema verification passed (fresh v3 + v2 and v1 migration paths).")


if __name__ == "__main__":
    main()
