#!/usr/bin/env python3
"""Static gate for Task 20-B execution lanes and blocker reporting.

This verifier checks reproducibility contracts only. It does not claim that
Flutter, Dart, Xcode, tests, or an iOS build have run in this environment.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PINNED_FLUTTER = "3.44.6"
EXPECTED_APP_VERSION = "0.9.1+19"

checks: list[dict[str, object]] = []


def check(name: str, condition: bool, detail: str) -> None:
    checks.append({"name": name, "passed": condition, "detail": detail})
    if not condition:
        raise AssertionError(f"{name}: {detail}")


def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


flutter_runner = text("tools/run_task20_b_flutter_checks.sh")
ios_runner = text("tools/run_task20_b_ios_simulator.sh")
readiness = text("tools/report_flutter_integration_readiness.py")
ci = text(".github/workflows/ci.yml")
ios_ci = text(".github/workflows/ios-build.yml")
fvm = text(".fvmrc")
pubspec = text("pubspec.yaml")
doc = text("docs/TASK20_B_FLUTTER_IOS_EXECUTION.md")
roadmap = text("docs/IMPLEMENTATION_ROADMAP.md")
installer = text("tools/install_pinned_flutter_sdk.py")
ci_supply = text("tools/verify_ci_supply_chain_contract.py")

check("pinned_flutter", PINNED_FLUTTER in fvm, "FVM must pin Flutter 3.44.6")
check("app_version", f"version: {EXPECTED_APP_VERSION}" in pubspec, "Task 20-B preflight version must match")
for marker in [
    "flutter pub get",
    "build_runner build --delete-conflicting-outputs",
    "make verify",
    "flutter analyze",
    "custom_lint",
    "flutter test --reporter expanded",
    "steps.ndjson",
    "result.json",
    "pinned_flutter_ref_prefix",
]:
    check(f"flutter_runner_{marker}", marker in flutter_runner, f"Flutter runner must contain {marker}")
for marker in [
    "uname -s",
    "xcodebuild -version",
    "simctl list devices available",
    "flutter create",
    "--platforms=ios",
    "run_task20_b_flutter_checks.sh",
    "flutter build ios --simulator --debug",
    "steps.ndjson",
    "result.json",
    "pinned_flutter_ref_prefix",
]:
    check(f"ios_runner_{marker}", marker in ios_runner, f"iOS runner must contain {marker}")
for marker in [
    "install_pinned_flutter_sdk.py",
    "run_task20_b_flutter_checks.sh",
    "upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02",
    "task20-b-flutter-evidence",
    "pubspec.lock",
    "lib/**/*.g.dart",
]:
    check(f"ci_{marker}", marker in ci, f"CI must contain {marker}")
for marker in [
    "install_pinned_flutter_sdk.py",
    "run_task20_b_ios_simulator.sh",
    "upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02",
    "task20-b-ios-evidence",
    "build/ios/iphonesimulator/*.app",
]:
    check(f"ios_ci_{marker}", marker in ios_ci, f"iOS workflow must contain {marker}")
for marker in [
    '"status": "READY" if not blockers else "BLOCKED"',
    '"note": "This report is not a Flutter compile or iOS execution result."',
]:
    check(f"readiness_{marker[:24]}", marker in readiness, "Readiness report must not overstate execution")
for marker in [
    "BLOCKED",
    "Flutter SDK",
    "Xcode",
    "タスク20-B全体は未完了",
    "実行成功とは扱わない",
]:
    check(f"doc_{marker}", marker in doc, f"Task 20-B document must disclose {marker}")
check("roadmap_task20_b", "タスク20-B" in roadmap and "BLOCKED" in roadmap, "Roadmap must show blocked execution status")
check("no_false_pass", "Flutter統合検証完了" not in doc, "Document must not claim integration completion")
for marker in ["flutter_infra_release", "SHA-256 mismatch", "ee80f08", "--resolve-only"]:
    check(f"installer_{marker}", marker in installer, f"Installer must contain {marker}")
for marker in ["all_actions_pinned_to_full_sha", "REMOVED_PERMANENTLY", "TEMPORARILY_DEFERRED_UNTIL_FIRST_PASS"]:
    check(f"ci_supply_{marker}", marker in ci_supply, f"CI supply-chain verifier must contain {marker}")

result = {
    "status": "PASS",
    "task": "20-B execution lane contract",
    "app_version": EXPECTED_APP_VERSION,
    "pinned_flutter": PINNED_FLUTTER,
    "checks": len(checks),
    "scope": "static execution-lane contract only",
    "flutter_execution": "NOT_RUN_IN_THIS_ENVIRONMENT",
    "ios_execution": "NOT_RUN_IN_THIS_ENVIRONMENT",
}
print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
