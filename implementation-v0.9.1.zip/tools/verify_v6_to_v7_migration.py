#!/usr/bin/env python3
"""Verify that applying v6_to_v7.sql to Schema v6 produces Schema v7 exactly.

This verifier intentionally does not depend on Flutter or Drift. It checks:
- SQLite schema objects and normalized SQL
- table columns, foreign keys, indexes, and triggers
- preservation of all pre-existing Seed rows
- AI table foreign keys and unique constraints
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import tempfile
from typing import Any

AI_TABLES = {
    'ai_chat_session',
    'ai_chat_message',
    'ai_prompt_template',
    'ai_response_cache',
    'ai_feedback',
    'ai_faq',
    'ai_dictionary',
}


def normalize_sql(sql: str | None) -> str | None:
    if sql is None:
        return None
    return re.sub(r'\s+', ' ', sql.strip()).replace(' ;', ';')


def create_db(path: Path, *scripts: str) -> sqlite3.Connection:
    con = sqlite3.connect(path)
    con.execute('PRAGMA foreign_keys = ON')
    for script in scripts:
        con.executescript(script)
    con.commit()
    return con


def object_signature(con: sqlite3.Connection) -> list[tuple[str, str, str, str | None]]:
    rows = con.execute(
        "SELECT type, name, tbl_name, sql FROM sqlite_master "
        "WHERE name NOT LIKE 'sqlite_%' ORDER BY type, name"
    ).fetchall()
    return [(t, n, tbl, normalize_sql(sql)) for t, n, tbl, sql in rows]


def table_signature(con: sqlite3.Connection, table: str) -> dict[str, Any]:
    indexes = []
    for row in con.execute(f'PRAGMA index_list("{table}")').fetchall():
        seq, name, unique, origin, partial = row[:5]
        indexes.append({
            'name': name,
            'unique': unique,
            'origin': origin,
            'partial': partial,
            'columns': con.execute(f'PRAGMA index_info("{name}")').fetchall(),
            'xinfo': con.execute(f'PRAGMA index_xinfo("{name}")').fetchall(),
            'sql': normalize_sql(con.execute(
                "SELECT sql FROM sqlite_master WHERE type='index' AND name=?", (name,)
            ).fetchone()[0]) if con.execute(
                "SELECT 1 FROM sqlite_master WHERE type='index' AND name=?", (name,)
            ).fetchone() else None,
        })
    return {
        'columns': con.execute(f'PRAGMA table_info("{table}")').fetchall(),
        'foreign_keys': con.execute(f'PRAGMA foreign_key_list("{table}")').fetchall(),
        'indexes': sorted(indexes, key=lambda x: x['name']),
    }


def database_signature(con: sqlite3.Connection) -> dict[str, Any]:
    tables = [r[0] for r in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ).fetchall()]
    triggers = con.execute(
        "SELECT name, tbl_name, sql FROM sqlite_master WHERE type='trigger' ORDER BY name"
    ).fetchall()
    return {
        'objects': object_signature(con),
        'tables': {t: table_signature(con, t) for t in tables},
        'triggers': [(n, t, normalize_sql(sql)) for n, t, sql in triggers],
    }


def row_counts(con: sqlite3.Connection, tables: list[str]) -> dict[str, int]:
    return {t: con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0] for t in tables}


def expect_integrity_error(con: sqlite3.Connection, sql: str, params: tuple[Any, ...]) -> None:
    try:
        con.execute(sql, params)
        con.commit()
    except sqlite3.IntegrityError:
        con.rollback()
        return
    raise AssertionError(f'Expected IntegrityError: {sql}')


def run(project_root: Path) -> dict[str, Any]:
    docs = project_root / 'docs'
    schema_v6 = (docs / 'schema_v6.sqlite.sql').read_text(encoding='utf-8')
    schema_v7 = (docs / 'schema_v7.sqlite.sql').read_text(encoding='utf-8')
    migration = (docs / 'migrations/v6_to_v7.sql').read_text(encoding='utf-8')
    seed_v1 = (project_root / 'assets/seed/seed_v1.sql').read_text(encoding='utf-8')
    seed_patch = (project_root / 'assets/seed/seed_patch_v2.sql').read_text(encoding='utf-8')

    with tempfile.TemporaryDirectory(prefix='v6_to_v7_verify_') as tmp:
        tmp = Path(tmp)
        direct = create_db(tmp / 'direct_v7.sqlite', schema_v7)
        migrated = create_db(tmp / 'migrated_v7.sqlite', schema_v6)

        pre_tables = [r[0] for r in migrated.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        ).fetchall()]
        if len(pre_tables) != 65:
            raise AssertionError(f'Expected 65 Schema v6 tables, got {len(pre_tables)}')

        migrated.executescript(seed_v1)
        migrated.executescript(seed_patch)
        migrated.commit()
        counts_before = row_counts(migrated, pre_tables)
        migrated.executescript(migration)
        migrated.commit()
        counts_after = row_counts(migrated, pre_tables)
        if counts_before != counts_after:
            changed = {t: (counts_before[t], counts_after[t]) for t in pre_tables if counts_before[t] != counts_after[t]}
            raise AssertionError(f'Pre-existing row counts changed: {changed}')

        direct_sig = database_signature(direct)
        migrated_sig = database_signature(migrated)
        if direct_sig != migrated_sig:
            direct_json = json.dumps(direct_sig, sort_keys=True, ensure_ascii=False, default=str, indent=2)
            migrated_json = json.dumps(migrated_sig, sort_keys=True, ensure_ascii=False, default=str, indent=2)
            raise AssertionError(
                'Migrated Schema v7 differs from direct Schema v7. '
                f'direct_sha256={hashlib.sha256(direct_json.encode()).hexdigest()} '
                f'migrated_sha256={hashlib.sha256(migrated_json.encode()).hexdigest()}'
            )

        tables = set(direct_sig['tables'])
        if len(tables) != 72 or not AI_TABLES.issubset(tables):
            raise AssertionError(f'Unexpected Schema v7 tables: count={len(tables)} missing={sorted(AI_TABLES - tables)}')

        fk_direct = direct.execute('PRAGMA foreign_key_check').fetchall()
        fk_migrated = migrated.execute('PRAGMA foreign_key_check').fetchall()
        if fk_direct or fk_migrated:
            raise AssertionError(f'Foreign key violations: direct={fk_direct}, migrated={fk_migrated}')

        migrated.execute(
            "INSERT INTO user_account(id, auth_provider, account_status, locale, timezone) "
            "VALUES ('usr_b2', 'ANONYMOUS', 'ACTIVE', 'ja-JP', 'Asia/Tokyo')"
        )
        migrated.execute(
            "INSERT INTO ai_chat_session(id, user_id, title) VALUES ('chat_b2', 'usr_b2', '検証')"
        )
        migrated.execute(
            "INSERT INTO ai_chat_message(id, user_id, chat_session_id, role_code, content_text) "
            "VALUES ('msg_b2', 'usr_b2', 'chat_b2', 'USER', 'test')"
        )
        migrated.execute(
            "INSERT INTO ai_prompt_template(id, template_code, version_code, system_text) "
            "VALUES ('prompt_b2', 'COACH', '1', 'explanatory only')"
        )
        migrated.commit()

        expect_integrity_error(
            migrated,
            "INSERT INTO ai_chat_message(id, user_id, chat_session_id, role_code, content_text) "
            "VALUES (?, ?, ?, ?, ?)",
            ('msg_bad_fk', 'usr_b2', 'missing_chat', 'USER', 'bad'),
        )
        expect_integrity_error(
            migrated,
            "INSERT INTO ai_prompt_template(id, template_code, version_code, system_text) "
            "VALUES (?, ?, ?, ?)",
            ('prompt_duplicate', 'COACH', '1', 'duplicate'),
        )

        result = {
            'status': 'PASS',
            'schema_v6_tables_before': 65,
            'schema_v7_tables_after': 72,
            'ai_tables_added': sorted(AI_TABLES),
            'preexisting_row_counts_preserved': True,
            'direct_and_migrated_schema_equal': True,
            'foreign_key_violations': 0,
            'ai_fk_rejection_verified': True,
            'ai_unique_constraint_rejection_verified': True,
            'schema_object_count': len(direct_sig['objects']),
            'signature_sha256': hashlib.sha256(
                json.dumps(direct_sig, sort_keys=True, ensure_ascii=False, default=str).encode('utf-8')
            ).hexdigest(),
        }
        direct.close()
        migrated.close()
        return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--json-output', type=Path)
    args = parser.parse_args()
    result = run(args.project_root)
    text = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True)
    print(text)
    if args.json_output:
        args.json_output.write_text(text + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
