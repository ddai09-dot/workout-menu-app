#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

EXPECTED_FLUTTER="3.44.6"
EXPECTED_FLUTTER_REF_PREFIX="ee80f08"
LOG_DIR="${TASK20_B_LOG_DIR:-$ROOT/build/task20_b_logs/ios}"
STEPS_FILE="$LOG_DIR/steps.ndjson"
mkdir -p "$LOG_DIR"
: > "$STEPS_FILE"
STARTED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

record_step() {
  local name="$1" status="$2" exit_code="$3" started_at="$4" finished_at="$5" duration_seconds="$6" log_file="${7:-}"
  TASK20_B_STEP_NAME="$name" TASK20_B_STEP_STATUS="$status" TASK20_B_STEP_EXIT_CODE="$exit_code" \
  TASK20_B_STEP_STARTED_AT="$started_at" TASK20_B_STEP_FINISHED_AT="$finished_at" \
  TASK20_B_STEP_DURATION="$duration_seconds" TASK20_B_STEP_LOG="$log_file" TASK20_B_STEPS_FILE="$STEPS_FILE" \
  python3 - <<'PY'
import json
import os
from pathlib import Path
payload = {
    "name": os.environ["TASK20_B_STEP_NAME"],
    "status": os.environ["TASK20_B_STEP_STATUS"],
    "exit_code": int(os.environ["TASK20_B_STEP_EXIT_CODE"]),
    "started_at_utc": os.environ["TASK20_B_STEP_STARTED_AT"],
    "finished_at_utc": os.environ["TASK20_B_STEP_FINISHED_AT"],
    "duration_seconds": int(os.environ["TASK20_B_STEP_DURATION"]),
    "log_file": os.environ["TASK20_B_STEP_LOG"] or None,
}
with Path(os.environ["TASK20_B_STEPS_FILE"]).open("a", encoding="utf-8") as stream:
    stream.write(json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n")
PY
}

record_gate() {
  local name="$1" status="$2" exit_code="$3" message="$4" now
  now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  printf '%s\n' "$message" | tee "$LOG_DIR/${name}.log"
  record_step "$name" "$status" "$exit_code" "$now" "$now" 0 "$LOG_DIR/${name}.log"
}

run_logged_step() {
  local name="$1" log_name="$2"
  shift 2
  local started_at finished_at start_epoch finish_epoch code status
  started_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  start_epoch="$(date +%s)"
  set +e
  "$@" 2>&1 | tee "$LOG_DIR/$log_name"
  code="${PIPESTATUS[0]}"
  set -e
  finished_at="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  finish_epoch="$(date +%s)"
  status="PASS"
  if [[ "$code" -ne 0 ]]; then status="FAIL"; fi
  record_step "$name" "$status" "$code" "$started_at" "$finished_at" "$((finish_epoch - start_epoch))" "$LOG_DIR/$log_name"
  if [[ "$code" -ne 0 ]]; then return "$code"; fi
}

write_result() {
  local exit_code="$1" status="FAIL"
  if [[ "$exit_code" -eq 0 ]]; then status="PASS"; elif [[ "$exit_code" -eq 2 ]]; then status="BLOCKED"; fi
  TASK20_B_STATUS="$status" TASK20_B_EXIT_CODE="$exit_code" TASK20_B_STARTED_AT="$STARTED_AT" \
  TASK20_B_LOG_DIR="$LOG_DIR" TASK20_B_STEPS_FILE="$STEPS_FILE" python3 - <<'PY'
import json
import os
import platform
import shutil
from datetime import datetime, timezone
from pathlib import Path
root = Path.cwd()
steps_file = Path(os.environ["TASK20_B_STEPS_FILE"])
steps = [json.loads(line) for line in steps_file.read_text(encoding="utf-8").splitlines() if line.strip()] if steps_file.is_file() else []
app_dir = root / "build/ios/iphonesimulator"
apps = sorted(str(path.relative_to(root)) for path in app_dir.glob("*.app")) if app_dir.is_dir() else []
result = {
    "task": "20-B iOS Simulator build execution",
    "status": os.environ["TASK20_B_STATUS"],
    "exit_code": int(os.environ["TASK20_B_EXIT_CODE"]),
    "host_os": platform.system(),
    "host_architecture": platform.machine(),
    "started_at_utc": os.environ["TASK20_B_STARTED_AT"],
    "finished_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    "pinned_flutter": "3.44.6",
    "pinned_flutter_ref_prefix": "ee80f08",
    "commands": {name: shutil.which(name) for name in ["flutter", "dart", "xcodebuild", "xcrun"]},
    "artifacts": {
        "ios_platform_directory": (root / "ios").is_dir(),
        "simulator_apps": apps,
        "simulator_app_built": bool(apps),
    },
    "steps": steps,
    "failed_or_blocked_steps": [step["name"] for step in steps if step["status"] in {"FAIL", "BLOCKED"}],
    "log_directory": os.environ["TASK20_B_LOG_DIR"],
    "note": "PASS is emitted only after the common Flutter checks and an unsigned debug iOS Simulator build succeed.",
}
(Path(os.environ["TASK20_B_LOG_DIR"]) / "result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8"
)
PY
}
trap 'code=$?; write_result "$code"' EXIT
exec > >(tee "$LOG_DIR/console.log") 2>&1

if [[ "$(uname -s)" != "Darwin" ]]; then
  record_gate "preflight_macos" "BLOCKED" 2 "ERROR: iOS Simulator build requires macOS and Xcode."
  exit 2
fi
for command_name in flutter dart xcodebuild xcrun; do
  if ! command -v "$command_name" >/dev/null 2>&1; then
    record_gate "preflight_${command_name}" "BLOCKED" 2 "ERROR: ${command_name} was not found."
    exit 2
  fi
done
record_gate "preflight_commands" "PASS" 0 "Flutter, Dart, Xcode and xcrun commands are available."

run_logged_step "flutter_version" "flutter_version.txt" flutter --version
run_logged_step "xcode_version" "xcode_version.txt" xcodebuild -version
run_logged_step "available_simulators" "available_simulators.txt" xcrun simctl list devices available

ACTUAL_FLUTTER="$(flutter --version --machine | python3 -c 'import json,sys; print(json.load(sys.stdin)["frameworkVersion"])')"
ACTUAL_FRAMEWORK_REVISION="$(flutter --version --machine | python3 -c 'import json,sys; print(json.load(sys.stdin).get("frameworkRevision", ""))')"
if [[ "$ACTUAL_FLUTTER" != "$EXPECTED_FLUTTER" ]]; then
  record_gate "pinned_flutter_version" "BLOCKED" 2 "ERROR: Flutter ${EXPECTED_FLUTTER} is pinned; found ${ACTUAL_FLUTTER}."
  exit 2
fi
if [[ "$ACTUAL_FRAMEWORK_REVISION" != "$EXPECTED_FLUTTER_REF_PREFIX"* ]]; then
  record_gate "pinned_flutter_revision" "BLOCKED" 2 "ERROR: Flutter ref prefix ${EXPECTED_FLUTTER_REF_PREFIX} is pinned; found ${ACTUAL_FRAMEWORK_REVISION}."
  exit 2
fi
record_gate "pinned_flutter_release" "PASS" 0 "Flutter ${ACTUAL_FLUTTER} / ${ACTUAL_FRAMEWORK_REVISION} matches the pinned release."

run_logged_step "flutter_create_ios" "flutter_create_ios.log" flutter create \
  --platforms=ios \
  --org jp.workoutmenu \
  --project-name workout_menu_app \
  .

COMMON_LOG_DIR="$LOG_DIR/flutter_checks"
mkdir -p "$COMMON_LOG_DIR"
set +e
TASK20_B_LOG_DIR="$COMMON_LOG_DIR" ./tools/run_task20_b_flutter_checks.sh
COMMON_CODE="$?"
set -e
COMMON_STATUS="PASS"
if [[ "$COMMON_CODE" -eq 2 ]]; then COMMON_STATUS="BLOCKED"; elif [[ "$COMMON_CODE" -ne 0 ]]; then COMMON_STATUS="FAIL"; fi
NOW="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
record_step "common_flutter_checks" "$COMMON_STATUS" "$COMMON_CODE" "$NOW" "$NOW" 0 "$COMMON_LOG_DIR/result.json"
if [[ "$COMMON_CODE" -ne 0 ]]; then exit "$COMMON_CODE"; fi

run_logged_step "flutter_build_ios_simulator" "flutter_build_ios_simulator.log" flutter build ios --simulator --debug
record_gate "simulator_app_check" "PASS" 0 "iOS Simulator debug application was built."

echo "Task 20-B iOS Simulator build passed."
