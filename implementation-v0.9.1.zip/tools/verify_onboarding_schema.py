from __future__ import annotations

import json
import sqlite3
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def statements(path: Path):
    return [
        value.strip()
        for value in path.read_text(encoding="utf-8").split("\n-- statement\n")
        if value.strip()
    ]


def uid() -> str:
    return str(uuid.uuid4())


def verify_fresh_schema() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v2.sqlite.sql").read_text(encoding="utf-8"))
    for path in [ROOT / "assets/seed/seed_v1.sql", ROOT / "assets/seed/seed_patch_v2.sql"]:
        for statement in statements(path):
            db.execute(statement)

    user_id = uid()
    draft_id = uid()
    draft = {
        "id": draft_id,
        "userId": user_id,
        "currentStepCode": "EQUIPMENT",
        "nickname": "検証ユーザー",
    }
    db.execute(
        "INSERT INTO user_account(id, auth_provider, account_status, locale, timezone) "
        "VALUES (?, 'ANONYMOUS', 'ACTIVE', 'ja-JP', 'Asia/Tokyo')",
        (user_id,),
    )
    db.execute(
        "INSERT INTO onboarding_draft(id,user_id,current_step_code,draft_json,status_code) "
        "VALUES (?,?,?,?, 'IN_PROGRESS')",
        (draft_id, user_id, "EQUIPMENT", json.dumps(draft, ensure_ascii=False)),
    )

    home_id = uid()
    db.execute(
        "INSERT INTO training_location(id,user_id,location_type_code,display_name,is_primary) "
        "VALUES (?,?, 'HOME','自宅',1)",
        (home_id, user_id),
    )
    dumbbell_id = db.execute(
        "SELECT id FROM equipment_master WHERE code='DUMBBELL'"
    ).fetchone()[0]

    fixed_id = uid()
    adjustable_id = uid()
    for equipment_id in (fixed_id, adjustable_id):
        db.execute(
            "INSERT INTO location_equipment(id,user_id,training_location_id,equipment_id,quantity) "
            "VALUES (?,?,?,?,2)",
            (equipment_id, user_id, home_id, dumbbell_id),
        )
    db.execute(
        "INSERT INTO location_dumbbell_detail(id,user_id,location_equipment_id,setup_type_code,unit_count) "
        "VALUES (?,?,?,?,1)",
        (uid(), user_id, fixed_id, "FIXED"),
    )
    db.execute(
        "INSERT INTO location_dumbbell_detail(id,user_id,location_equipment_id,setup_type_code,unit_count) "
        "VALUES (?,?,?,?,1)",
        (uid(), user_id, adjustable_id, "ADJUSTABLE"),
    )
    db.execute(
        "INSERT INTO equipment_weight_option(id,user_id,location_equipment_id,weight_value,unit_code,quantity) "
        "VALUES (?,?,?,?, 'KG',2)",
        (uid(), user_id, fixed_id, 10.0),
    )
    db.execute(
        "INSERT INTO equipment_weight_option(id,user_id,location_equipment_id,weight_value,unit_code,quantity) "
        "VALUES (?,?,?,?, 'KG',2)",
        (uid(), user_id, adjustable_id, 24.0),
    )

    barbell_id = db.execute(
        "SELECT id FROM equipment_master WHERE code='BARBELL'"
    ).fetchone()[0]
    barbell_location_equipment_id = uid()
    db.execute(
        "INSERT INTO location_equipment("
        "id,user_id,training_location_id,equipment_id,quantity,min_weight,max_weight,increment_weight"
        ") VALUES (?,?,?,?,1,20,100,2.5)",
        (barbell_location_equipment_id, user_id, home_id, barbell_id),
    )
    db.execute(
        "INSERT INTO location_barbell_detail("
        "id,user_id,location_equipment_id,shaft_weight_kg,max_total_weight_kg,"
        "min_increment_kg,has_rack,has_safety"
        ") VALUES (?,?,?,?,?,?,1,1)",
        (uid(), user_id, barbell_location_equipment_id, 20.0, 100.0, 2.5),
    )
    db.execute(
        "INSERT INTO equipment_weight_option(id,user_id,location_equipment_id,weight_value,unit_code,quantity) "
        "VALUES (?,?,?,?, 'KG',2)",
        (uid(), user_id, barbell_location_equipment_id, 20.0),
    )

    joint_id = db.execute(
        "SELECT id FROM joint_master WHERE code='JT001'"
    ).fetchone()[0]
    db.execute(
        "INSERT INTO user_restriction("
        "id,user_id,restriction_type_code,joint_id,default_action_code,effective_from,source_code"
        ") VALUES (?,?, 'PAIN_AREA',?, 'REDUCE_LOAD','2026-07-17','USER')",
        (uid(), user_id, joint_id),
    )

    db.execute(
        "UPDATE onboarding_draft SET status_code='COMPLETED', deleted_at=CURRENT_TIMESTAMP "
        "WHERE id=?",
        (draft_id,),
    )
    db.commit()

    assert db.execute(
        "SELECT COUNT(*) FROM location_equipment WHERE equipment_id=?",
        (dumbbell_id,),
    ).fetchone()[0] == 2
    assert db.execute(
        "SELECT COUNT(*) FROM user_restriction WHERE joint_id IS NOT NULL"
    ).fetchone()[0] == 1
    assert db.execute(
        "SELECT COUNT(*) FROM equipment_weight_option"
    ).fetchone()[0] == 3
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []


def verify_migration() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript((ROOT / "docs/schema_v1.sqlite.sql").read_text(encoding="utf-8"))
    for statement in statements(ROOT / "assets/seed/seed_v1.sql"):
        db.execute(statement)
    db.executescript((ROOT / "docs/migrations/v1_to_v2.sql").read_text(encoding="utf-8"))
    for statement in statements(ROOT / "assets/seed/seed_patch_v2.sql"):
        db.execute(statement)

    columns = {
        row[1] for row in db.execute("PRAGMA table_info(user_experience_profile)")
    }
    assert "adjustment_habit_code" in columns
    assert "logging_habit_code" in columns
    restriction_columns = {
        row[1] for row in db.execute("PRAGMA table_info(user_restriction)")
    }
    assert "joint_id" in restriction_columns
    assert db.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='table' "
        "AND name IN ('onboarding_draft','location_dumbbell_detail','location_barbell_detail')"
    ).fetchone()[0] == 3
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []


def main() -> None:
    verify_fresh_schema()
    verify_migration()
    print("Onboarding schema verification passed (fresh + v1 migration).")


if __name__ == "__main__":
    main()
