#!/usr/bin/env python3
"""Verify Task 19.5-D: unavailable external features are not exposed in MVP UI."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def require(text: str, marker: str, label: str) -> None:
    if marker not in text:
        raise AssertionError(f"{label} is missing marker: {marker}")


def forbid(text: str, marker: str, label: str) -> None:
    if marker in text:
        raise AssertionError(f"{label} still exposes forbidden marker: {marker}")


def main() -> None:
    router = (ROOT / "lib/app/router/app_router.dart").read_text(encoding="utf-8")
    my_page = (ROOT / "lib/features/my_page/presentation/my_page.dart").read_text(
        encoding="utf-8"
    )
    decision = (ROOT / "docs/TASK19_5_D_MVP_EXTERNAL_FEATURE_SCOPE.md").read_text(
        encoding="utf-8"
    )
    pubspec = (ROOT / "pubspec.yaml").read_text(encoding="utf-8")

    forbidden_routes = [
        "/my-page/account",
        "/ai-coach",
        "/my-page/notifications",
        "path: 'account'",
        "path: 'notifications'",
    ]
    for marker in forbidden_routes:
        forbid(router, marker, "app_router")

    forbidden_imports = [
        "features/account/presentation/account_page.dart",
        "features/ai_coach/presentation/ai_coach_page.dart",
        "features/notifications/presentation/notification_settings_page.dart",
    ]
    for marker in forbidden_imports:
        forbid(router, marker, "app_router imports")

    forbidden_tiles = [
        "アカウントと同期",
        "AI相談",
        "通知・リマインダー",
    ]
    for marker in forbidden_tiles:
        forbid(my_page, marker, "MyPage")

    require(router, "/ai-knowledge", "app_router")
    require(my_page, "用語・FAQ", "MyPage")
    require(my_page, "トレーニング用語と基本的な使い方", "MyPage")

    retained_boundaries = [
        "lib/features/account/data/supabase_account_service.dart",
        "lib/core/sync/outbox_sync_service.dart",
        "lib/features/ai_coach/data/edge_ai_coach_gateway.dart",
        "lib/features/notifications/data/local_notification_repository.dart",
        "lib/features/notifications/data/local_notification_gateway.dart",
    ]
    missing = [path for path in retained_boundaries if not (ROOT / path).is_file()]
    if missing:
        raise AssertionError(f"Missing retained future boundaries: {missing}")

    require(decision, "アカウント同期 | MVPから除外", "Task 19.5-D decision")
    require(decision, "AI相談 | MVPから除外", "Task 19.5-D decision")
    require(decision, "ネイティブ通知 | MVPから除外", "Task 19.5-D decision")
    require(decision, "ローカルデータの初期化・削除方法", "Task 19.5-D decision")

    # Native notification must not be presented as implemented by adding a plugin dependency.
    forbid(pubspec, "flutter_local_notifications", "pubspec")

    result = {
        "status": "PASS",
        "mvp_decisions": {
            "account_sync": "EXCLUDED_FROM_NORMAL_UI",
            "ai_consultation": "EXCLUDED_FROM_NORMAL_UI",
            "native_notifications": "EXCLUDED_FROM_NORMAL_UI",
            "local_faq": "RETAINED",
            "in_app_rest_timer": "RETAINED",
        },
        "removed_routes": 3,
        "removed_my_page_entries": 3,
        "retained_future_boundaries": len(retained_boundaries),
        "schema_change": False,
        "native_notification_plugin": "ABSENT",
    }
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
