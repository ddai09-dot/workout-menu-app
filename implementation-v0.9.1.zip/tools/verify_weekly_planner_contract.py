from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED = {
    "lib/features/weekly_planner/domain/rule_based_weekly_menu_generator.dart": [
        "class RuleBasedWeeklyMenuGenerator",
        "FULL_BODY_AB",
        "UPPER_LOWER_2",
        "REST_WEEK",
        "lockedDays",
    ],
    "lib/features/weekly_planner/data/local_weekly_planner_repository.dart": [
        "class LocalWeeklyPlannerRepository",
        "weekly_planner_draft",
        "generation_input_snapshot_json",
        "generation_trace_json",
        "selection_reason_ids_json",
        "UPDATE weekly_menu",
        "Future<WeeklyPlannerDraft> resetDraft",
        "status_code = 'RESET'",
        "status_code = 'PROVISIONAL'",
    ],
    "lib/features/weekly_planner/presentation/weekly_planner_notifier.dart": [
        "AsyncNotifierProvider",
        "_saveQueue",
        "createRestWeek",
        "finalize",
        "reviseConditions",
    ],
    "lib/features/weekly_planner/presentation/weekly_planner_flow_page.dart": [
        "WeeklyPlannerFlowPage",
        "条件を修正して作り直す",
        "この内容で確定",
    ],
    "lib/features/menu/presentation/menu_page.dart": [
        "WeekdayCodes.ordered",
        "完全休養週",
        "/menu/weekly-planner",
    ],
    "lib/app/router/app_router.dart": [
        "path: 'weekly-planner'",
        "WeeklyPlannerFlowPage",
    ],
}


def main() -> None:
    errors: list[str] = []
    for relative, tokens in REQUIRED.items():
        path = ROOT / relative
        if not path.exists():
            errors.append(f"missing: {relative}")
            continue
        text = path.read_text(encoding="utf-8")
        for token in tokens:
            if token not in text:
                errors.append(f"{relative}: missing token {token!r}")
    assert not errors, "; ".join(errors)
    print("Weekly planner source contract verification passed.")


if __name__ == "__main__":
    main()
