#!/usr/bin/env python3
"""Verify AppDatabase migration SQL against the canonical migration files.

This is a static Python verification of the SQL embedded in app_database.dart.
It does not replace Flutter/Drift runtime tests, but prevents the Dart migration
body from silently diverging from docs/migrations/*.sql.
"""

from __future__ import annotations

import json
import re
import sqlite3
import tempfile
from pathlib import Path

from verify_full_migration import (
    apply_seed,
    insert_v1_fixture,
    schema_objects,
    selected_values,
    signature,
)
from verify_repository_sql import (
    call_bodies,
    evaluate_adjacent_literals,
    find_matching,
    parse_string,
    split_top_level,
)

ROOT = Path(__file__).resolve().parents[1]
APP_DATABASE = ROOT / "lib/core/database/app_database.dart"


def method_body(source: str, version: int) -> str:
    marker = f"Future<void> _migrateToV{version}() async"
    start = source.find(marker)
    if start < 0:
        raise AssertionError(f"Missing {marker}")
    opening = source.find("{", start)
    closing = find_matching(source, opening, "{", "}")
    return source[opening + 1 : closing]


def migration_statements(source: str, version: int) -> list[str]:
    body = method_body(source, version)
    list_match = re.search(r"(?:const|final)\s+statements\s*=\s*<String>\[", body)
    if list_match is not None:
        opening = body.find("[", list_match.start())
        closing = find_matching(body, opening, "[", "]")
        items = split_top_level(body[opening + 1 : closing])
        statements: list[str] = []
        for item in items:
            sql = evaluate_adjacent_literals(item)
            if sql is None:
                raise AssertionError(
                    f"Non-literal Schema v{version} migration item: {item[:80]}"
                )
            statements.append(sql.strip())
        if not statements:
            raise AssertionError(f"No SQL extracted from _migrateToV{version}")
        return statements

    statements = []
    for operation, call_body, _ in call_bodies(body):
        if operation != "customStatement":
            continue
        arguments = split_top_level(call_body)
        if not arguments:
            continue
        sql = evaluate_adjacent_literals(arguments[0])
        if sql is not None:
            statements.append(sql.strip())
    if not statements:
        raise AssertionError(f"No SQL extracted from _migrateToV{version}")
    return statements



def canonicalize_objects(objects):
    normalized = json.loads(json.dumps(objects, ensure_ascii=False))
    for item in normalized:
        sql = item.get("sql")
        if sql:
            sql = re.sub(r"\s+", " ", sql).strip()
            sql = re.sub(r"\s*([(),])\s*", r"\1", sql)
            item["sql"] = sql
    return normalized

def apply_statements(db: sqlite3.Connection, statements: list[str]) -> None:
    for statement in statements:
        db.execute(statement)
    db.commit()


def main() -> None:
    source = APP_DATABASE.read_text(encoding="utf-8")
    extracted = {version: migration_statements(source, version) for version in range(2, 10)}

    with tempfile.TemporaryDirectory(prefix="app_database_migration_contract_") as tmp_name:
        tmp = Path(tmp_name)
        docs_db = sqlite3.connect(tmp / "docs.sqlite")
        app_db = sqlite3.connect(tmp / "app.sqlite")
        for db in (docs_db, app_db):
            db.execute("PRAGMA foreign_keys = ON")
            db.executescript((ROOT / "docs/schema_v1.sqlite.sql").read_text(encoding="utf-8"))
            apply_seed(db)
        docs_ids = insert_v1_fixture(docs_db)
        app_ids = insert_v1_fixture(app_db)
        if docs_ids != app_ids:
            raise AssertionError("Fixture IDs differ")
        baseline = selected_values(docs_db, docs_ids)

        stage_signatures: dict[int, str] = {}
        for version in range(2, 10):
            docs_db.executescript(
                (ROOT / f"docs/migrations/v{version - 1}_to_v{version}.sql").read_text(encoding="utf-8")
            )
            docs_db.commit()
            apply_statements(app_db, extracted[version])
            docs_objects = canonicalize_objects(schema_objects(docs_db))
            app_objects = canonicalize_objects(schema_objects(app_db))
            if docs_objects != app_objects:
                raise AssertionError(
                    f"AppDatabase migration differs at Schema v{version}: "
                    f"docs={signature(docs_objects)} app={signature(app_objects)}"
                )
            docs_fk = docs_db.execute("PRAGMA foreign_key_check").fetchall()
            app_fk = app_db.execute("PRAGMA foreign_key_check").fetchall()
            if docs_fk or app_fk:
                raise AssertionError(
                    f"Foreign key violation at v{version}: docs={docs_fk}, app={app_fk}"
                )
            stage_signatures[version] = signature(docs_objects)

        if selected_values(docs_db, docs_ids) != baseline:
            raise AssertionError("Canonical migration changed representative v1 values")
        if selected_values(app_db, app_ids) != baseline:
            raise AssertionError("AppDatabase migration changed representative v1 values")

        docs_archive = docs_db.execute(
            "SELECT id,migration_status_code FROM notification_setting_legacy_archive ORDER BY id"
        ).fetchall()
        app_archive = app_db.execute(
            "SELECT id,migration_status_code FROM notification_setting_legacy_archive ORDER BY id"
        ).fetchall()
        if docs_archive != app_archive:
            raise AssertionError("AppDatabase notification archive differs from canonical migration")

        result = {
            "status": "PASS",
            "schema_versions_verified": list(range(2, 10)),
            "statement_counts": {str(version): len(extracted[version]) for version in extracted},
            "stage_signatures": stage_signatures,
            "app_database_matches_migration_files": True,
            "representative_v1_rows_preserved": True,
            "notification_archive_matches": True,
            "foreign_key_violations": 0,
        }
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
