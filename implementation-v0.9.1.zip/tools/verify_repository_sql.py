#!/usr/bin/env python3
"""Compile every literal Repository SQL statement against Schema v9.

The verifier covers all local data repositories and the local sync repository.
It checks SQL placeholder counts, compiles every conditional SQL branch, and
validates that dynamic table/column helper call sites use existing identifiers.
Migration SQL and SeedLoader are verified by dedicated tools.
"""

from __future__ import annotations

import json
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / "lib"
SCHEMA = ROOT / "docs" / "schema_v9.sqlite.sql"


def skip_comment(source: str, index: int) -> int:
    if source.startswith("//", index):
        end = source.find("\n", index + 2)
        return len(source) if end < 0 else end
    if source.startswith("/*", index):
        end = source.find("*/", index + 2)
        return len(source) if end < 0 else end + 2
    return index


def parse_string(source: str, index: int) -> tuple[str, int]:
    raw = False
    if (
        source[index] in "rR"
        and index + 1 < len(source)
        and source[index + 1] in "'\""
    ):
        raw = True
        index += 1
    quote = source[index]
    triple = source.startswith(quote * 3, index)
    delimiter = quote * 3 if triple else quote
    cursor = index + len(delimiter)
    output: list[str] = []
    while cursor < len(source):
        if source.startswith(delimiter, cursor):
            return "".join(output), cursor + len(delimiter)
        character = source[cursor]
        if not raw and character == "\\" and cursor + 1 < len(source):
            next_character = source[cursor + 1]
            output.append({"n": "\n", "r": "\r", "t": "\t"}.get(next_character, next_character))
            cursor += 2
            continue
        output.append(character)
        cursor += 1
    raise AssertionError("Unterminated Dart string literal.")


def find_matching(
    source: str,
    opening_index: int,
    opening: str = "(",
    closing: str = ")",
) -> int:
    depth = 0
    index = opening_index
    while index < len(source):
        skipped = skip_comment(source, index)
        if skipped != index:
            index = skipped
            continue
        if source[index] in "'\"" or (
            source[index] in "rR"
            and index + 1 < len(source)
            and source[index + 1] in "'\""
        ):
            _, index = parse_string(source, index)
            continue
        if source[index] == opening:
            depth += 1
        elif source[index] == closing:
            depth -= 1
            if depth == 0:
                return index
        index += 1
    raise AssertionError(f"Unmatched {opening}{closing} delimiter.")


def split_top_level(source: str) -> list[str]:
    output: list[str] = []
    stack: list[str] = []
    pairs = {")": "(", "]": "[", "}": "{"}
    start = 0
    index = 0
    while index < len(source):
        skipped = skip_comment(source, index)
        if skipped != index:
            index = skipped
            continue
        if source[index] in "'\"" or (
            source[index] in "rR"
            and index + 1 < len(source)
            and source[index + 1] in "'\""
        ):
            _, index = parse_string(source, index)
            continue
        character = source[index]
        if character in "([{":
            stack.append(character)
        elif character in ")]}":
            if stack and stack[-1] == pairs[character]:
                stack.pop()
        elif character == "," and not stack:
            output.append(source[start:index].strip())
            start = index + 1
        index += 1
    tail = source[start:].strip()
    if tail:
        output.append(tail)
    return output


def evaluate_adjacent_literals(expression: str) -> str | None:
    index = 0
    output: list[str] = []
    while index < len(expression):
        skipped = skip_comment(expression, index)
        if skipped != index:
            index = skipped
            continue
        if expression[index].isspace():
            index += 1
            continue
        if expression[index] in "'\"" or (
            expression[index] in "rR"
            and index + 1 < len(expression)
            and expression[index + 1] in "'\""
        ):
            value, index = parse_string(expression, index)
            output.append(value)
            continue
        return None
    return "".join(output)


def conditional_literal_branches(expression: str) -> list[str]:
    if "?" not in expression or ":" not in expression:
        return []
    output: list[str] = []
    index = 0
    while index < len(expression):
        if expression[index] in "'\"" or (
            expression[index] in "rR"
            and index + 1 < len(expression)
            and expression[index + 1] in "'\""
        ):
            value, index = parse_string(expression, index)
            output.append(value)
        else:
            index += 1
    return output if len(output) >= 2 else []


def call_bodies(source: str):
    pattern = re.compile(r"\b(customSelect|customStatement)\s*\(")
    for match in pattern.finditer(source):
        opening = source.find("(", match.start())
        closing = find_matching(source, opening)
        yield match.group(1), source[opening + 1 : closing], match.start()


def first_list(expression: str) -> str | None:
    index = 0
    while index < len(expression):
        skipped = skip_comment(expression, index)
        if skipped != index:
            index = skipped
            continue
        if expression[index] in "'\"" or (
            expression[index] in "rR"
            and index + 1 < len(expression)
            and expression[index + 1] in "'\""
        ):
            _, index = parse_string(expression, index)
            continue
        if expression[index] == "[":
            closing = find_matching(expression, index, "[", "]")
            return expression[index + 1 : closing]
        index += 1
    return None


def argument_count_options(operation: str, arguments: list[str]) -> set[int]:
    inner: str | None = None
    if operation == "customStatement":
        if len(arguments) >= 2:
            inner = first_list(arguments[1])
    else:
        for argument in arguments[1:]:
            if argument.strip().startswith("variables:"):
                inner = first_list(argument.split(":", 1)[1])
                break
    if inner is None or not inner.strip():
        return {0}
    items = split_top_level(inner)
    required = sum(1 for item in items if not item.lstrip().startswith("if ("))
    optional = sum(1 for item in items if item.lstrip().startswith("if ("))
    return set(range(required, required + optional + 1))


def placeholder_count(sql: str) -> int:
    count = 0
    index = 0
    while index < len(sql):
        if sql.startswith("--", index):
            end = sql.find("\n", index + 2)
            index = len(sql) if end < 0 else end
            continue
        if sql.startswith("/*", index):
            end = sql.find("*/", index + 2)
            index = len(sql) if end < 0 else end + 2
            continue
        if sql[index] in "'\"":
            quote = sql[index]
            index += 1
            while index < len(sql):
                if sql[index] == quote:
                    if index + 1 < len(sql) and sql[index + 1] == quote:
                        index += 2
                        continue
                    index += 1
                    break
                index += 1
            continue
        if sql[index] == "?":
            count += 1
        index += 1
    return count


def repository_paths() -> list[Path]:
    paths = {
        *LIB.glob("features/*/data/*.dart"),
        LIB / "core/sync/local_sync_repository.dart",
    }
    return sorted(path for path in paths if path.is_file())


def database_identifiers(db: sqlite3.Connection) -> tuple[set[str], dict[str, set[str]]]:
    tables = {
        row[0]
        for row in db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
        )
    }
    columns = {
        table: {row[1] for row in db.execute(f'PRAGMA table_info("{table}")')}
        for table in tables
    }
    return tables, columns


def verify_dynamic_call_sites(
    sources: dict[Path, str], tables: set[str], columns: dict[str, set[str]]
) -> dict[str, int]:
    table_calls: set[str] = set()
    for source in sources.values():
        table_calls.update(re.findall(r"_userRowId\(\s*'([A-Za-z0-9_]+)'", source))
        table_calls.update(re.findall(r"_softDeleteUserRows\(\s*'([A-Za-z0-9_]+)'", source))
        table_calls.update(re.findall(r"_requiredId\(\s*table:\s*'([A-Za-z0-9_]+)'", source))
        reset_list = re.search(
            r"_userOwnedTablesInDeleteOrder\s*=\s*<String>\[(.*?)\];",
            source,
            re.DOTALL,
        )
        if reset_list is not None:
            table_calls.update(re.findall(r"'([A-Za-z0-9_]+)'", reset_list.group(1)))
    missing_tables = sorted(table_calls - tables)
    if missing_tables:
        raise AssertionError(f"Dynamic SQL helper references missing tables: {missing_tables}")

    workout_source = next(
        text for path, text in sources.items() if path.name == "local_workout_repository.dart"
    )
    column_calls = {
        match[1]
        for match in re.findall(
            r"_(sessionValue|sessionNullableValue)\(\s*[^,]+,\s*'([A-Za-z0-9_]+)'",
            workout_source,
        )
    }
    missing_columns = sorted(column_calls - columns["workout_session"])
    if missing_columns:
        raise AssertionError(
            f"Dynamic workout_session helper references missing columns: {missing_columns}"
        )
    return {"dynamic_table_identifiers": len(table_calls), "dynamic_column_identifiers": len(column_calls)}


def substitute_dynamic_sql(sql: str) -> str:
    if "$tableName" in sql:
        if "WHERE user_id" not in sql:
            raise AssertionError(f"Unknown reset table SQL: {sql}")
        sql = sql.replace("$tableName", "user_profile")
    if "$table" in sql:
        if "WHERE user_id" in sql:
            sql = sql.replace("$table", "user_profile")
        elif "WHERE training_week_id" in sql:
            sql = sql.replace("$table", "weekly_available_day")
        elif "WHERE code" in sql:
            sql = sql.replace("$table", "body_part_master")
        else:
            raise AssertionError(f"Unknown dynamic table SQL: {sql}")
    if "$column" in sql:
        sql = sql.replace("$column", "user_id")
    if "$" in sql:
        raise AssertionError(f"Unresolved SQL interpolation: {sql}")
    return sql


def main() -> None:
    database = sqlite3.connect(":memory:")
    database.execute("PRAGMA foreign_keys = ON")
    database.executescript(SCHEMA.read_text(encoding="utf-8"))
    tables, columns = database_identifiers(database)

    paths = repository_paths()
    sources = {path: path.read_text(encoding="utf-8") for path in paths}
    dynamic_identifiers = verify_dynamic_call_sites(sources, tables, columns)

    call_count = 0
    compiled_count = 0
    conditional_branch_count = 0
    dynamic_sql_count = 0
    errors: list[str] = []
    per_file: dict[str, int] = {}

    for path in paths:
        source = sources[path]
        file_count = 0
        for operation, body, position in call_bodies(source):
            call_count += 1
            file_count += 1
            line = source.count("\n", 0, position) + 1
            arguments = split_top_level(body)
            if not arguments:
                errors.append(f"{path.name}:{line}: missing call arguments")
                continue
            sql = evaluate_adjacent_literals(arguments[0])
            branches = [sql] if sql is not None else conditional_literal_branches(arguments[0])
            if not branches:
                errors.append(
                    f"{path.name}:{line}: SQL is not a supported literal/conditional expression"
                )
                continue
            if len(branches) > 1:
                conditional_branch_count += len(branches)
            allowed_argument_counts = argument_count_options(operation, arguments)
            for branch in branches:
                if "$" in branch:
                    dynamic_sql_count += 1
                try:
                    compiled_sql = substitute_dynamic_sql(branch.strip())
                except AssertionError as error:
                    errors.append(f"{path.name}:{line}: {error}")
                    continue
                placeholders = placeholder_count(compiled_sql)
                if placeholders not in allowed_argument_counts:
                    errors.append(
                        f"{path.name}:{line}: placeholders={placeholders}, "
                        f"argument options={sorted(allowed_argument_counts)}"
                    )
                try:
                    database.execute("EXPLAIN " + compiled_sql, [None] * placeholders)
                    compiled_count += 1
                except sqlite3.Error as error:
                    errors.append(f"{path.name}:{line}: {error}: {compiled_sql}")
        if file_count:
            per_file[str(path.relative_to(ROOT))] = file_count

    if errors:
        raise AssertionError("Repository SQL verification failed:\n" + "\n".join(errors))

    result = {
        "status": "PASS",
        "schema": "v9",
        "repository_files_with_sql": len(per_file),
        "custom_sql_calls": call_count,
        "compiled_sql_branches": compiled_count,
        "conditional_sql_branches": conditional_branch_count,
        "dynamic_sql_branches": dynamic_sql_count,
        **dynamic_identifiers,
        "files": per_file,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
