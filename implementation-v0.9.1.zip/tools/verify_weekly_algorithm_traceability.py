#!/usr/bin/env python3
"""Static traceability gate for Task 19.5-C3.

This does not replace flutter test. It verifies that the 13 specification
stages have explicit implementation/persistence anchors and that known partial
areas are not silently labelled complete.
"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GENERATOR = ROOT / "lib/features/weekly_planner/domain/rule_based_weekly_menu_generator.dart"
PLAN = ROOT / "lib/features/weekly_planner/domain/weekly_menu_plan.dart"
REPOSITORY = ROOT / "lib/features/weekly_planner/data/local_weekly_planner_repository.dart"
VERSION = ROOT / "pubspec.yaml"

STEPS = [
    (1, "INPUT_NORMALIZATION"),
    (2, "REST_WEEK_CHECK"),
    (3, "TRAINING_DAY_COUNT"),
    (4, "SPLIT_CANDIDATES"),
    (5, "SPLIT_SCORING"),
    (6, "CALENDAR_PLACEMENT"),
    (7, "WEEKLY_VOLUME"),
    (8, "EXERCISE_HARD_FILTER"),
    (9, "EXERCISE_SCORING"),
    (10, "TIME_FIT"),
    (11, "LOAD_REP_CONFIGURATION"),
    (12, "FINAL_VALIDATION"),
    (13, "REASON_RENDERING"),
]

checks: list[dict[str, object]] = []

def check(name: str, passed: bool, detail: str) -> None:
    checks.append({"name": name, "passed": passed, "detail": detail})
    if not passed:
        raise SystemExit(f"FAIL: {name}: {detail}")

generator = GENERATOR.read_text(encoding="utf-8")
plan = PLAN.read_text(encoding="utf-8")
repository = REPOSITORY.read_text(encoding="utf-8")
version = VERSION.read_text(encoding="utf-8")

for number, code in STEPS:
    check(
        f"trace_step_{number:02d}_{code}",
        f"'step': {number}" in generator and f"'code': '{code}'" in generator,
        "generator must emit the specification stage",
    )

check("trace_model", "generationTrace" in plan, "WeeklyMenuPlan carries structured trace")
check(
    "trace_persistence",
    "...plan.generationTrace" in repository and "generation_trace_json" in repository,
    "structured trace is persisted to weekly_menu",
)
check(
    "trace_reload",
    "generationTrace: trace" in repository,
    "persisted trace is restored with the plan",
)
check(
    "deterministic_tie_break",
    "a.value.code.compareTo(b.value.code)" in generator,
    "split tie-break ends with stable code order",
)
check(
    "exercise_tie_break",
    "a.exercise.code.compareTo(b.exercise.code)" in generator,
    "exercise tie-break ends with stable exercise code order",
)
check(
    "rest_week_terminal",
    "TERMINATED_REST_WEEK" in generator,
    "rest week ends generation without replacement activity",
)
check(
    "partial_volume_disclosed",
    "IMPLEMENTED_SESSION_TARGET" in generator,
    "weekly body-part volume gap is explicitly disclosed",
)
check(
    "partial_load_disclosed",
    "PROFILE_SNAPSHOT_ONLY" in generator,
    "load proposal gap is explicitly disclosed",
)
check("version", "version: 0.9.1+19" in version, "project version must be 0.9.1+19")

result = {
    "task": "19.5-C3",
    "spec_version": "1.1",
    "implementation_version": "0.9.1+19",
    "trace_steps": len(STEPS),
    "checks": checks,
    "known_partial": [
        "Goal/experience-based weekly volume is not yet a complete per-body-part VolumeCalculator.",
        "ProgressionEngine owns actual next-weight proposals; weekly generation stores progression snapshots only.",
        "Flutter/Dart execution tests are pending because the SDK is unavailable.",
    ],
}
(ROOT / "docs/weekly_algorithm_traceability_verification.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)
print(json.dumps({"status": "PASS", "checks": len(checks), "trace_steps": len(STEPS)}, ensure_ascii=False))
