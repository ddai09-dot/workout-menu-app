#!/usr/bin/env python3
"""Verify the canonical notification Schema v9 foundation."""

from pathlib import Path
import sqlite3

schema = Path('docs/schema_v9.sqlite.sql').read_text(encoding='utf-8')
con = sqlite3.connect(':memory:')
con.execute('PRAGMA foreign_keys = ON')
con.executescript(schema)

tables = {
    row[0] for row in con.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    )
}
required = {
    'notification_preference',
    'notification_schedule',
    'notification_delivery_log',
    'notification_setting_legacy_archive',
}
assert required <= tables
assert 'notification_setting' not in tables
assert len(tables) == 75

con.execute("INSERT INTO user_account(id) VALUES('notification_schema_user')")
con.execute(
    "INSERT INTO notification_preference(id,user_id,notification_type_code) "
    "VALUES('notification_pref_1','notification_schema_user','WORKOUT_PLAN')"
)
try:
    con.execute(
        "INSERT INTO notification_preference(id,user_id,notification_type_code) "
        "VALUES('notification_pref_2','notification_schema_user','WORKOUT_PLAN')"
    )
    raise AssertionError('duplicate active preference accepted')
except sqlite3.IntegrityError:
    con.rollback()

fk_violations = con.execute('PRAGMA foreign_key_check').fetchall()
assert not fk_violations
print({
    'tables': len(tables),
    'canonical_table': 'notification_preference',
    'legacy_archive': 'notification_setting_legacy_archive',
    'legacy_operational_table_absent': True,
    'foreign_key_violations': 0,
})
