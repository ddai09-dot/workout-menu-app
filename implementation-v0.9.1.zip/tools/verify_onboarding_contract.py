from __future__ import annotations

import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def statements(path: Path) -> list[str]:
    return [
        value.strip()
        for value in path.read_text(encoding="utf-8").split("\n-- statement\n")
        if value.strip()
    ]


def load_database() -> sqlite3.Connection:
    database = sqlite3.connect(":memory:")
    database.execute("PRAGMA foreign_keys = ON")
    database.executescript(
        (ROOT / "docs/schema_v2.sqlite.sql").read_text(encoding="utf-8")
    )
    for path in [
        ROOT / "assets/seed/seed_v1.sql",
        ROOT / "assets/seed/seed_patch_v2.sql",
    ]:
        for statement in statements(path):
            database.execute(statement)
    return database


def codes(database: sqlite3.Connection, table: str) -> set[str]:
    return {row[0] for row in database.execute(f"SELECT code FROM {table}")}


def assert_subset(expected: set[str], actual: set[str], label: str) -> None:
    missing = sorted(expected - actual)
    assert not missing, f"{label} missing codes: {missing}"


def main() -> None:
    database = load_database()

    assert_subset(
        {
            "NONE",
            "DUMBBELL",
            "FLAT_BENCH",
            "ADJUSTABLE_BENCH",
            "BARBELL",
            "RACK",
            "PULLUP_BAR",
            "BAND",
            "KETTLEBELL",
            "SMITH_MACHINE",
            "CABLE_MACHINE",
            "CHEST_MACHINE_GROUP",
            "SHOULDER_MACHINE_GROUP",
            "ARM_MACHINE_GROUP",
            "BACK_MACHINE_GROUP",
            "LEG_MACHINE_GROUP",
            "CARDIO_MACHINE",
        },
        codes(database, "equipment_master"),
        "equipment_master",
    )
    assert_subset(
        {"CHEST", "BACK", "SHOULDERS", "ARMS", "GLUTES", "LEGS"},
        codes(database, "body_part_master"),
        "body_part_master",
    )
    assert_subset(
        {"JT001", "JT002", "JT003", "JT004", "JT005", "JT006", "JT007", "JT008"},
        codes(database, "joint_master"),
        "joint_master",
    )
    assert_subset(
        {f"MV{number:03d}" for number in range(1, 36)},
        codes(database, "movement_master"),
        "movement_master",
    )
    assert "PROGRESSION_RULE_V1_1" in codes(database, "rule_version")
    assert database.execute("SELECT COUNT(*) FROM exercise_master").fetchone()[0] == 72

    schema = (ROOT / "docs/schema_v2.sqlite.sql").read_text(encoding="utf-8")
    source = (ROOT / "lib/features/onboarding/domain/onboarding_draft.dart").read_text(
        encoding="utf-8"
    )
    assert "unit_count INTEGER" in schema
    assert "pair_count" not in schema
    assert "scheduleLocationByWeekday" in source
    assert "plateOptions" in source

    assert database.execute("PRAGMA foreign_key_check").fetchall() == []
    print("Onboarding contract verification passed.")


if __name__ == "__main__":
    main()
