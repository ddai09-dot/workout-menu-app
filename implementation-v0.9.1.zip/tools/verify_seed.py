#!/usr/bin/env python3
"""Verify Schema v9 seed SQL and source JSON assets.

The SQL seed is the runtime source used by SeedLoader. JSON assets are verified as
source/reference data and must remain aligned with the 72 stable exercise IDs.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "docs" / "schema_v9.sqlite.sql"
SEEDS = [
    ROOT / "assets" / "seed" / "seed_v1.sql",
    ROOT / "assets" / "seed" / "seed_patch_v2.sql",
    ROOT / "assets" / "seed" / "seed_patch_v3.sql",
]
JSON_ASSETS = {
    "exercises": ROOT / "assets" / "seed" / "exercises_v2_2.json",
    "form_copy": ROOT / "assets" / "seed" / "form_copy_v1_2.json",
    "progression": ROOT / "assets" / "seed" / "progression_v1_1.json",
    "ai_knowledge": ROOT / "assets" / "seed" / "ai_knowledge_v1.json",
}
EXPECTED = {
    "exercise_master": 72,
    "exercise_form_copy": 72,
    "exercise_form_asset": 144,
    "exercise_progression_profile": 216,
    "equipment_master": 48,
}


def statements(path: Path) -> list[str]:
    return [
        value.strip()
        for value in path.read_text(encoding="utf-8").split("\n-- statement\n")
        if value.strip()
    ]


def apply_seed(db: sqlite3.Connection) -> None:
    for path in SEEDS:
        for statement in statements(path):
            db.execute(statement)
    db.commit()


def counts(db: sqlite3.Connection) -> dict[str, int]:
    return {
        table: db.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
        for table in EXPECTED
    }


def main() -> None:
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript(SCHEMA.read_text(encoding="utf-8"))

    apply_seed(db)
    first_counts = counts(db)
    apply_seed(db)
    second_counts = counts(db)
    assert first_counts == second_counts, "Seed SQL is not idempotent."

    table_count = db.execute(
        "SELECT COUNT(*) FROM sqlite_master "
        "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchone()[0]
    assert table_count == 75, f"table count: {table_count}"
    for table, expected in EXPECTED.items():
        actual = first_counts[table]
        assert actual == expected, f"{table}: expected {expected}, got {actual}"

    codes = [
        row[0]
        for row in db.execute("SELECT code FROM exercise_master ORDER BY code")
    ]
    expected_codes = [f"EX{number:03d}" for number in range(1, 73)]
    assert codes == expected_codes, "Exercise IDs are not contiguous EX001-EX072."

    names = dict(
        db.execute(
            "SELECT code, name_ja FROM exercise_master "
            "WHERE code IN ('EX071', 'EX072')"
        ).fetchall()
    )
    assert names == {
        "EX071": "インクラインダンベルサイドレイズ",
        "EX072": "インクラインダンベルリアレイズ",
    }

    image_positions = dict(
        db.execute(
            "SELECT em.code, COUNT(efa.id) "
            "FROM exercise_master em "
            "LEFT JOIN exercise_form_asset efa ON efa.exercise_id = em.id "
            "GROUP BY em.code ORDER BY em.code"
        ).fetchall()
    )
    assert set(image_positions.values()) == {2}, image_positions

    exercise_json = json.loads(JSON_ASSETS["exercises"].read_text(encoding="utf-8"))
    form_json = json.loads(JSON_ASSETS["form_copy"].read_text(encoding="utf-8"))
    progression_json = json.loads(JSON_ASSETS["progression"].read_text(encoding="utf-8"))
    for label, rows in {
        "exercises": exercise_json,
        "form_copy": form_json,
        "progression": progression_json,
    }.items():
        assert len(rows) == 72, f"{label}: {len(rows)}"
        assert [row["ID"] for row in rows] == expected_codes, f"{label} IDs differ."

    db_names = dict(db.execute("SELECT code,name_ja FROM exercise_master"))
    for row in exercise_json:
        assert db_names[row["ID"]] == row["種目名"], row["ID"]
    for row in form_json:
        assert db_names[row["ID"]] == row["種目名"], row["ID"]

    db_form = {
        row[0]: row[1:]
        for row in db.execute(
            "SELECT em.code, efc.image_1_label, efc.image_2_label, "
            "efc.movement_tip, efc.caution_text, efc.content_version "
            "FROM exercise_master em "
            "JOIN exercise_form_copy efc ON efc.exercise_id = em.id "
            "WHERE em.is_active = 1 AND efc.is_active = 1"
        )
    }
    for row in form_json:
        actual = db_form[row["ID"]]
        expected = (
            row["画像1ラベル"],
            row["画像2ラベル"],
            row["動作のポイント"],
            row["注意点"],
        )
        assert actual[:4] == expected, f"form copy differs: {row['ID']}"
    ex003 = db_form["EX003"]
    assert ex003[2] == (
        "ダンベルを身体（鎖骨）と平行に保ち、肩甲骨を寄せて前腕を床と垂直にします。"
    )
    assert ex003[4] == 2

    asset_states = dict(
        db.execute(
            "SELECT asset_status, COUNT(*) FROM exercise_form_asset "
            "WHERE is_active = 1 GROUP BY asset_status"
        ).fetchall()
    )
    assert asset_states == {"NOT_STARTED": 144}, asset_states
    pending_checksums = db.execute(
        "SELECT COUNT(*) FROM exercise_form_asset "
        "WHERE is_active = 1 AND checksum = 'PENDING'"
    ).fetchone()[0]
    assert pending_checksums == 144
    for row in progression_json:
        assert db_names[row["ID"]] == row["種目名"], row["ID"]

    ai = json.loads(JSON_ASSETS["ai_knowledge"].read_text(encoding="utf-8"))
    assert set(ai) == {"faq", "dictionary"}
    assert all({"id", "category", "question", "answer"} <= set(row) for row in ai["faq"])
    assert all({"id", "code", "term", "definition"} <= set(row) for row in ai["dictionary"])

    generic_equipment = {
        row[0]
        for row in db.execute(
            "SELECT code FROM equipment_master WHERE code IN "
            "('SMITH_MACHINE','CHEST_MACHINE_GROUP','SHOULDER_MACHINE_GROUP',"
            "'ARM_MACHINE_GROUP','BACK_MACHINE_GROUP','LEG_MACHINE_GROUP',"
            "'CARDIO_MACHINE')"
        )
    }
    assert len(generic_equipment) == 7, generic_equipment

    violations = db.execute("PRAGMA foreign_key_check").fetchall()
    assert not violations, violations

    seed_digest = hashlib.sha256(
        b"".join(path.read_bytes() for path in SEEDS)
    ).hexdigest()
    print(
        json.dumps(
            {
                "status": "PASS",
                "schema": "v9",
                "tables": table_count,
                "seed_counts": first_counts,
                "exercise_ids": "EX001-EX072",
                "form_assets_per_exercise": 2,
                "form_copy_contract": "v1.2",
                "ex003_content_version": 2,
                "asset_statuses": asset_states,
                "pending_checksums": pending_checksums,
                "json_assets": {
                    "exercises": len(exercise_json),
                    "form_copy": len(form_json),
                    "progression": len(progression_json),
                    "ai_faq": len(ai["faq"]),
                    "ai_dictionary": len(ai["dictionary"]),
                },
                "seed_sql_idempotent": True,
                "foreign_key_violations": 0,
                "seed_sha256": seed_digest,
            },
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
