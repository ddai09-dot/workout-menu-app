#!/usr/bin/env python3
"""Install a pinned Flutter SDK from Google's official release archive.

The installer resolves the requested release from the official Flutter release
metadata, verifies channel, version, architecture, release ref and SHA-256, then
extracts it into a deterministic tool-cache directory.

It is intentionally independent from third-party setup actions. Use
``--resolve-only`` with ``--metadata-file`` for offline contract tests.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import stat
import sys
import tarfile
import tempfile
import urllib.request
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

DEFAULT_VERSION = "3.44.6"
DEFAULT_CHANNEL = "stable"
DEFAULT_REF_PREFIX = "ee80f08"
BASE_METADATA_URL = "https://storage.googleapis.com/flutter_infra_release/releases/releases_{platform}.json"


@dataclass(frozen=True)
class ResolvedRelease:
    platform: str
    architecture: str
    version: str
    channel: str
    release_hash: str
    dart_sdk_version: str | None
    archive: str
    archive_url: str
    sha256: str


def _normalized_platform(value: str | None = None) -> str:
    raw = (value or platform.system()).strip().lower()
    aliases = {"linux": "linux", "darwin": "macos", "macos": "macos"}
    if raw not in aliases:
        raise ValueError(f"Unsupported host platform: {raw!r}; expected Linux or macOS")
    return aliases[raw]


def _normalized_architecture(value: str | None = None) -> str:
    raw = (value or platform.machine()).strip().lower()
    aliases = {
        "x86_64": "x64",
        "amd64": "x64",
        "x64": "x64",
        "arm64": "arm64",
        "aarch64": "arm64",
    }
    if raw not in aliases:
        raise ValueError(f"Unsupported CPU architecture: {raw!r}; expected x64 or arm64")
    return aliases[raw]


def _read_json_url(url: str, timeout_seconds: int) -> dict[str, Any]:
    request = urllib.request.Request(url, headers={"User-Agent": "workout-menu-task20-b/1.0"})
    with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
        return json.load(response)


def _read_metadata(path: Path | None, host_platform: str, timeout_seconds: int) -> dict[str, Any]:
    if path is not None:
        return json.loads(path.read_text(encoding="utf-8"))
    return _read_json_url(BASE_METADATA_URL.format(platform=host_platform), timeout_seconds)


def _entry_architecture(entry: dict[str, Any], host_platform: str) -> str:
    explicit = str(entry.get("dart_sdk_arch") or entry.get("architecture") or "").lower()
    if explicit in {"x64", "arm64"}:
        return explicit
    archive = str(entry.get("archive", "")).lower()
    if "_arm64_" in archive:
        return "arm64"
    # Flutter's x64 macOS/Linux archives historically omit an explicit x64 token.
    if host_platform in {"linux", "macos"}:
        return "x64"
    raise ValueError(f"Cannot determine architecture for archive {archive!r}")


def resolve_release(
    metadata: dict[str, Any],
    *,
    host_platform: str,
    architecture: str,
    version: str,
    channel: str,
    ref_prefix: str,
) -> ResolvedRelease:
    releases = metadata.get("releases")
    if not isinstance(releases, list):
        raise ValueError("Flutter release metadata does not contain a releases list")
    candidates: list[dict[str, Any]] = []
    for entry in releases:
        if not isinstance(entry, dict):
            continue
        if str(entry.get("version")) != version:
            continue
        if str(entry.get("channel")) != channel:
            continue
        archive_value = str(entry.get("archive") or "")
        if f"/{host_platform}/" not in f"/{archive_value}":
            continue
        if _entry_architecture(entry, host_platform) != architecture:
            continue
        candidates.append(entry)
    if len(candidates) != 1:
        found = [str(item.get("archive")) for item in candidates]
        raise ValueError(
            f"Expected exactly one Flutter {version} {channel} {host_platform}/{architecture} release; "
            f"found {len(candidates)}: {found}"
        )
    entry = candidates[0]
    release_hash = str(entry.get("hash") or "")
    if not release_hash.startswith(ref_prefix):
        raise ValueError(
            f"Flutter release ref mismatch: expected prefix {ref_prefix}, found {release_hash or '<missing>'}"
        )
    archive = str(entry.get("archive") or "")
    sha256 = str(entry.get("sha256") or "").lower()
    if not archive:
        raise ValueError("Flutter release metadata is missing archive")
    if len(sha256) != 64 or any(char not in "0123456789abcdef" for char in sha256):
        raise ValueError(f"Flutter release metadata has an invalid SHA-256: {sha256!r}")
    base_url = str(metadata.get("base_url") or "https://storage.googleapis.com/flutter_infra_release/releases")
    return ResolvedRelease(
        platform=host_platform,
        architecture=architecture,
        version=version,
        channel=channel,
        release_hash=release_hash,
        dart_sdk_version=str(entry.get("dart_sdk_version")) if entry.get("dart_sdk_version") else None,
        archive=archive,
        archive_url=f"{base_url.rstrip('/')}/{archive.lstrip('/')}",
        sha256=sha256,
    )


def _sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def _download(url: str, destination: Path, timeout_seconds: int) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "workout-menu-task20-b/1.0"})
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response, temporary.open("wb") as output:
            shutil.copyfileobj(response, output, length=1024 * 1024)
        temporary.replace(destination)
    finally:
        temporary.unlink(missing_ok=True)


def _safe_destination(root: Path, member_name: str) -> Path:
    candidate = (root / member_name).resolve()
    if root.resolve() not in candidate.parents and candidate != root.resolve():
        raise ValueError(f"Unsafe archive member path: {member_name}")
    return candidate


def _extract_archive(archive_path: Path, destination: Path) -> None:
    staging = destination.parent / f".{destination.name}.extracting"
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True, exist_ok=True)
    try:
        if archive_path.name.endswith(".tar.xz"):
            with tarfile.open(archive_path, "r:xz") as archive:
                for member in archive.getmembers():
                    _safe_destination(staging, member.name)
                archive.extractall(staging, filter="data")
        elif archive_path.name.endswith(".zip"):
            with zipfile.ZipFile(archive_path) as archive:
                for member in archive.infolist():
                    _safe_destination(staging, member.filename)
                archive.extractall(staging)
        else:
            raise ValueError(f"Unsupported Flutter archive format: {archive_path.name}")
        flutter_root = staging / "flutter"
        if not (flutter_root / "bin" / "flutter").is_file():
            raise ValueError("Extracted archive does not contain flutter/bin/flutter")
        shutil.rmtree(destination, ignore_errors=True)
        flutter_root.replace(destination)
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def _ensure_executable(path: Path) -> None:
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def _write_json(path: Path | None, payload: dict[str, Any]) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if path is None:
        print(text, end="")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")


def _write_github_output(path: Path | None, values: Iterable[tuple[str, str]]) -> None:
    if path is None:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        for key, value in values:
            stream.write(f"{key}={value}\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", default=DEFAULT_VERSION)
    parser.add_argument("--channel", default=DEFAULT_CHANNEL)
    parser.add_argument("--ref-prefix", default=DEFAULT_REF_PREFIX)
    parser.add_argument("--platform", choices=["linux", "macos"])
    parser.add_argument("--architecture", choices=["x64", "arm64"])
    parser.add_argument("--metadata-file", type=Path)
    parser.add_argument("--install-root", type=Path)
    parser.add_argument("--result-file", type=Path)
    parser.add_argument("--github-output", type=Path)
    parser.add_argument("--resolve-only", action="store_true")
    parser.add_argument("--timeout-seconds", type=int, default=120)
    args = parser.parse_args()

    host_platform = _normalized_platform(args.platform)
    architecture = _normalized_architecture(args.architecture)
    metadata = _read_metadata(args.metadata_file, host_platform, args.timeout_seconds)
    release = resolve_release(
        metadata,
        host_platform=host_platform,
        architecture=architecture,
        version=args.version,
        channel=args.channel,
        ref_prefix=args.ref_prefix,
    )
    payload: dict[str, Any] = {"status": "RESOLVED", "release": asdict(release)}
    if args.resolve_only:
        _write_json(args.result_file, payload)
        return 0

    install_root = (args.install_root or Path(os.environ.get("RUNNER_TOOL_CACHE", Path.home() / ".cache")) / "workout-menu-flutter").resolve()
    destination = install_root / release.version / host_platform / architecture / "flutter"
    flutter_bin = destination / "bin" / "flutter"
    dart_bin = destination / "bin" / "dart"
    marker = destination / ".workout-menu-release.json"

    reused = False
    if flutter_bin.is_file() and marker.is_file():
        try:
            previous = json.loads(marker.read_text(encoding="utf-8"))
            reused = previous.get("release", {}).get("sha256") == release.sha256
        except (OSError, json.JSONDecodeError):
            reused = False
    if not reused:
        install_root.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="flutter-sdk-") as temporary_dir:
            archive_path = Path(temporary_dir) / Path(release.archive).name
            _download(release.archive_url, archive_path, args.timeout_seconds)
            actual_sha = _sha256(archive_path)
            if actual_sha != release.sha256:
                raise ValueError(f"Flutter archive SHA-256 mismatch: expected {release.sha256}, found {actual_sha}")
            _extract_archive(archive_path, destination)
        _ensure_executable(flutter_bin)
        if dart_bin.exists():
            _ensure_executable(dart_bin)
        marker.write_text(json.dumps({"release": asdict(release)}, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    payload.update(
        {
            "status": "REUSED" if reused else "INSTALLED",
            "install_root": str(destination),
            "flutter_bin": str(flutter_bin),
            "dart_bin": str(dart_bin),
        }
    )
    _write_json(args.result_file, payload)
    _write_github_output(
        args.github_output,
        [
            ("flutter_home", str(destination)),
            ("flutter_bin_directory", str(destination / "bin")),
            ("flutter_version", release.version),
            ("flutter_release_hash", release.release_hash),
            ("flutter_archive_sha256", release.sha256),
            ("flutter_archive", release.archive),
        ],
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:  # noqa: BLE001 - command-line boundary must emit a clear failure.
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
