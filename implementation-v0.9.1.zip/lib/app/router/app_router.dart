import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/app/router/main_shell_page.dart';
import 'package:workout_menu_app/features/home/presentation/home_page.dart';
import 'package:workout_menu_app/features/data_management/presentation/local_data_reset_page.dart';
import 'package:workout_menu_app/features/exercise_form/presentation/exercise_form_page.dart';
import 'package:workout_menu_app/features/ai_coach/presentation/ai_knowledge_page.dart';

import 'package:workout_menu_app/features/menu/presentation/menu_page.dart';
import 'package:workout_menu_app/features/my_page/presentation/my_page.dart';
import 'package:workout_menu_app/features/onboarding/presentation/launch_page.dart';
import 'package:workout_menu_app/features/onboarding/presentation/onboarding_flow_page.dart';
import 'package:workout_menu_app/features/records/presentation/records_page.dart';
import 'package:workout_menu_app/features/records/presentation/body_measurement_page.dart';
import 'package:workout_menu_app/features/records/presentation/exercise_detail_page.dart';
import 'package:workout_menu_app/features/records/presentation/exercise_list_page.dart';
import 'package:workout_menu_app/features/records/presentation/progression_proposals_page.dart';
import 'package:workout_menu_app/features/records/presentation/session_detail_page.dart';
import 'package:workout_menu_app/features/records/presentation/session_history_page.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_section.dart';
import 'package:workout_menu_app/features/settings/presentation/training_settings_edit_page.dart';
import 'package:workout_menu_app/features/weekly_planner/presentation/weekly_planner_flow_page.dart';
import 'package:workout_menu_app/features/workout/presentation/workout_adjustment_page.dart';
import 'package:workout_menu_app/features/workout/presentation/workout_assessment_page.dart';
import 'package:workout_menu_app/features/workout/presentation/workout_session_page.dart';
import 'package:workout_menu_app/features/workout/presentation/workout_start_page.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/launch',
    routes: <RouteBase>[
      GoRoute(
        path: '/launch',
        builder: (BuildContext context, GoRouterState state) {
          return const LaunchPage();
        },
      ),
      GoRoute(
        path: '/onboarding',
        builder: (BuildContext context, GoRouterState state) {
          return const OnboardingFlowPage();
        },
      ),
      GoRoute(
        path: '/workout/start/:dayPlanId',
        builder: (BuildContext context, GoRouterState state) {
          return WorkoutStartPage(
            dayPlanId: state.pathParameters['dayPlanId']!,
          );
        },
      ),
      GoRoute(
        path: '/workout/start/:dayPlanId/adjust',
        builder: (BuildContext context, GoRouterState state) {
          return WorkoutAdjustmentPage(
            dayPlanId: state.pathParameters['dayPlanId']!,
          );
        },
      ),
      GoRoute(
        path: '/workout/session/:sessionId',
        builder: (BuildContext context, GoRouterState state) {
          return WorkoutSessionPage(
            sessionId: state.pathParameters['sessionId']!,
          );
        },
      ),
      GoRoute(
        path: '/workout/assessment/:sessionId',
        builder: (BuildContext context, GoRouterState state) {
          return WorkoutAssessmentPage(
            sessionId: state.pathParameters['sessionId']!,
          );
        },
      ),
      GoRoute(
        path: '/exercise-form/:exerciseId',
        builder: (BuildContext context, GoRouterState state) {
          return ExerciseFormPage(
            exerciseId: state.pathParameters['exerciseId']!,
          );
        },
      ),
      GoRoute(path: '/ai-knowledge', builder: (BuildContext context, GoRouterState state) => const AiKnowledgePage()),
      StatefulShellRoute.indexedStack(
        builder: (
          BuildContext context,
          GoRouterState state,
          StatefulNavigationShell navigationShell,
        ) {
          return MainShellPage(navigationShell: navigationShell);
        },
        branches: <StatefulShellBranch>[
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: '/home',
                builder: (BuildContext context, GoRouterState state) {
                  return const HomePage();
                },
              ),
            ],
          ),
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: '/menu',
                builder: (BuildContext context, GoRouterState state) {
                  return const MenuPage();
                },
                routes: <RouteBase>[
                  GoRoute(
                    path: 'weekly-planner',
                    builder: (BuildContext context, GoRouterState state) {
                      return const WeeklyPlannerFlowPage();
                    },
                  ),
                ],
              ),
            ],
          ),
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: '/records',
                builder: (BuildContext context, GoRouterState state) {
                  return const RecordsPage();
                },
                routes: <RouteBase>[
                  GoRoute(
                    path: 'history',
                    builder: (BuildContext context, GoRouterState state) {
                      return const SessionHistoryPage();
                    },
                  ),
                  GoRoute(
                    path: 'session/:sessionId',
                    builder: (BuildContext context, GoRouterState state) {
                      return SessionDetailPage(
                        sessionId: state.pathParameters['sessionId']!,
                      );
                    },
                  ),
                  GoRoute(
                    path: 'exercises',
                    builder: (BuildContext context, GoRouterState state) {
                      return const ExerciseListPage();
                    },
                  ),
                  GoRoute(
                    path: 'exercise/:exerciseId',
                    builder: (BuildContext context, GoRouterState state) {
                      return ExerciseDetailPage(
                        exerciseId: state.pathParameters['exerciseId']!,
                      );
                    },
                  ),
                  GoRoute(
                    path: 'measurements',
                    builder: (BuildContext context, GoRouterState state) {
                      return const BodyMeasurementPage();
                    },
                  ),
                  GoRoute(
                    path: 'proposals',
                    builder: (BuildContext context, GoRouterState state) {
                      return const ProgressionProposalsPage();
                    },
                  ),
                ],
              ),
            ],
          ),
          StatefulShellBranch(
            routes: <RouteBase>[
              GoRoute(
                path: '/my-page',
                builder: (BuildContext context, GoRouterState state) {
                  return const MyPage();
                },
                routes: <RouteBase>[
                  GoRoute(
                    path: 'data',
                    builder: (BuildContext context, GoRouterState state) {
                      return const LocalDataResetPage();
                    },
                  ),
                  GoRoute(
                    path: 'settings/:section',
                    builder: (BuildContext context, GoRouterState state) {
                      final section = TrainingSettingsSectionDefinition.fromPath(
                        state.pathParameters['section'] ?? '',
                      );
                      if (section == null) {
                        return const Scaffold(
                          body: SafeArea(
                            child: Center(child: Text('設定項目が見つかりません。')),
                          ),
                        );
                      }
                      return TrainingSettingsEditPage(section: section);
                    },
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    ],
  );
});
