import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:workout_menu_app/app/workout_menu_app.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/database/providers/database_providers.dart';
import 'package:workout_menu_app/core/database/seed/seed_loader.dart';
import 'package:workout_menu_app/core/environment/app_environment.dart';
import 'package:workout_menu_app/core/environment/environment_provider.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/core/security/secure_store.dart';
import 'package:workout_menu_app/features/account/data/local_account_repository.dart';
import 'package:workout_menu_app/features/account/presentation/account_notifier.dart';

Future<void> bootstrap(AppEnvironment environment) async {
  WidgetsFlutterBinding.ensureInitialized();

  if (environment.hasSupabaseConfiguration) {
    await Supabase.initialize(
      url: environment.supabaseUrl,
      anonKey: environment.supabasePublishableKey,
    );
  }

  final database = AppDatabase();
  await SeedLoader(database).ensureSeeded();

  runApp(
    ProviderScope(
      overrides: <Override>[
        appEnvironmentProvider.overrideWithValue(environment),
        appDatabaseProvider.overrideWithValue(database),
        accountRepositoryProvider.overrideWithValue(
          LocalAccountRepository(
            database: database,
            secureStore: const PlatformSecureStore(),
            idGenerator: const UuidV7Generator(),
          ),
        ),
      ],
      child: const WorkoutMenuApp(),
    ),
  );
}
