import 'dart:convert';

import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/onboarding/domain/experience_level_calculator.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_option.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_repository.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_section.dart';

final class LocalOnboardingRepository implements OnboardingRepository {
  const LocalOnboardingRepository(
    this._database, {
    IdGenerator idGenerator = const UuidV7Generator(),
  }) : _idGenerator = idGenerator;

  final AppDatabase _database;
  final IdGenerator _idGenerator;

  @override
  Future<OnboardingStatus> loadStatus() async {
    final completed = await _database.customSelect('''
      SELECT 1 AS found
      FROM user_profile
      WHERE onboarding_completed_at IS NOT NULL
        AND deleted_at IS NULL
      LIMIT 1
    ''').get();
    if (completed.isNotEmpty) {
      return OnboardingStatus.completed;
    }

    final draft = await _database.customSelect('''
      SELECT 1 AS found
      FROM onboarding_draft
      WHERE status_code = 'IN_PROGRESS'
        AND deleted_at IS NULL
      LIMIT 1
    ''').get();
    return draft.isEmpty
        ? OnboardingStatus.notStarted
        : OnboardingStatus.inProgress;
  }

  @override
  Future<OnboardingDraft> loadOrCreateDraft() async {
    final existing = await _database.customSelect('''
      SELECT draft_json
      FROM onboarding_draft
      WHERE status_code = 'IN_PROGRESS'
        AND deleted_at IS NULL
      ORDER BY updated_at DESC
      LIMIT 1
    ''').get();

    if (existing.isNotEmpty) {
      final Object? decoded =
          jsonDecode(existing.first.read<String>('draft_json'));
      return OnboardingDraft.fromJson(
        Map<String, Object?>.from(
          decoded! as Map<Object?, Object?>,
        ),
      );
    }

    final userId = await _loadOrCreateUserAccount();
    final draft = OnboardingDraft(
      id: _idGenerator.next(),
      userId: userId,
    );
    await _database.customStatement(
      '''
      INSERT INTO onboarding_draft (
        id, user_id, current_step_code, draft_json, status_code
      ) VALUES (?, ?, ?, ?, 'IN_PROGRESS')
      ''',
      <Object?>[
        draft.id,
        draft.userId,
        draft.currentStep.code,
        jsonEncode(draft.toJson()),
      ],
    );
    return draft;
  }

  Future<String> _loadOrCreateUserAccount() async {
    final existing = await _database.customSelect('''
      SELECT id
      FROM user_account
      WHERE deleted_at IS NULL
      ORDER BY created_at ASC
      LIMIT 1
    ''').get();
    if (existing.isNotEmpty) {
      return existing.first.read<String>('id');
    }

    final id = _idGenerator.next();
    await _database.customStatement(
      '''
      INSERT INTO user_account (
        id, auth_provider, account_status, locale, timezone
      ) VALUES (?, 'ANONYMOUS', 'ACTIVE', 'ja-JP', 'Asia/Tokyo')
      ''',
      <Object?>[id],
    );
    return id;
  }

  @override
  Future<void> saveDraft(OnboardingDraft draft) async {
    await _database.customStatement(
      '''
      UPDATE onboarding_draft
      SET current_step_code = ?,
          draft_json = ?,
          updated_at = CURRENT_TIMESTAMP,
          row_version = row_version + 1
      WHERE id = ?
        AND status_code = 'IN_PROGRESS'
        AND deleted_at IS NULL
      ''',
      <Object?>[
        draft.currentStep.code,
        jsonEncode(draft.toJson()),
        draft.id,
      ],
    );
  }

  @override
  Future<void> resetDraft(OnboardingDraft draft) async {
    await _database.customStatement(
      '''
      UPDATE onboarding_draft
      SET status_code = 'RESET',
          deleted_at = CURRENT_TIMESTAMP,
          updated_at = CURRENT_TIMESTAMP,
          row_version = row_version + 1
      WHERE id = ?
      ''',
      <Object?>[draft.id],
    );
  }

  @override
  Future<List<ExerciseChoice>> searchExercises(String query) async {
    final normalized = query.trim();
    final rows = await _database.customSelect(
      '''
      SELECT code, name_ja
      FROM exercise_master
      WHERE is_active = 1
        AND (? = '' OR name_ja LIKE ? OR code LIKE ?)
      ORDER BY code
      LIMIT 100
      ''',
      variables: <Variable<Object>>[
        Variable.withString(normalized),
        Variable.withString('%$normalized%'),
        Variable.withString('%$normalized%'),
      ],
    ).get();
    return rows
        .map(
          (QueryRow row) => ExerciseChoice(
            code: row.read<String>('code'),
            name: row.read<String>('name_ja'),
          ),
        )
        .toList(growable: false);
  }

  @override
  Future<void> complete(OnboardingDraft draft) async {
    final invalidStep = draft.firstInvalidStep;
    if (invalidStep != null) {
      throw StateError('Onboarding is incomplete at ${invalidStep.code}.');
    }

    final now = DateTime.now();
    final nowIso = now.toUtc().toIso8601String();
    final today = DateTime(now.year, now.month, now.day)
        .toIso8601String()
        .substring(0, 10);
    final assessment = ExperienceLevelCalculator.calculate(
      cumulativeExperienceCode: draft.cumulativeExperienceCode!,
      continuityCode: draft.continuityCode!,
      hiatusCode: draft.hiatusCode,
    );
    final progressionRuleId = await _requiredId(
      table: 'rule_version',
      code: 'PROGRESSION_RULE_V1_1',
    );

    await _database.transaction(() async {
      await _upsertProfile(draft, nowIso, today);
      await _upsertTrainingSetting(draft, nowIso);
      await _upsertExperience(
        draft,
        assessment,
        progressionRuleId,
        nowIso,
      );
      final locations = await _replaceLocationsAndEquipment(draft, nowIso);
      await _upsertSchedule(draft, locations, nowIso);
      await _replaceGoals(draft, nowIso);
      await _replacePriorities(draft, nowIso);
      await _replaceRestrictions(draft, nowIso, today);
      await _upsertAppPreference(draft.userId, nowIso);
      await _appendBodyMeasurement(draft, nowIso);

      await _database.customStatement(
        '''
        UPDATE onboarding_draft
        SET status_code = 'COMPLETED',
            current_step_code = 'REVIEW',
            draft_json = ?,
            updated_at = ?,
            deleted_at = ?,
            row_version = row_version + 1
        WHERE id = ?
        ''',
        <Object?>[jsonEncode(draft.toJson()), nowIso, nowIso, draft.id],
      );
    });
  }

  Future<void> saveTrainingSettingsSection({
    required TrainingSettingsSection section,
    required OnboardingDraft draft,
  }) async {
    final validationMessage = section.validationMessage(draft);
    if (validationMessage != null) {
      throw StateError(validationMessage);
    }

    final now = DateTime.now();
    final nowIso = now.toUtc().toIso8601String();
    final today = DateTime(now.year, now.month, now.day)
        .toIso8601String()
        .substring(0, 10);

    await _database.transaction(() async {
      switch (section) {
        case TrainingSettingsSection.goals:
          await _replaceGoals(draft, nowIso);
          break;
        case TrainingSettingsSection.experience:
          final assessment = ExperienceLevelCalculator.calculate(
            cumulativeExperienceCode: draft.cumulativeExperienceCode!,
            continuityCode: draft.continuityCode!,
            hiatusCode: draft.hiatusCode,
          );
          final progressionRuleId = await _requiredId(
            table: 'rule_version',
            code: 'PROGRESSION_RULE_V1_1',
          );
          await _upsertExperience(
            draft,
            assessment,
            progressionRuleId,
            nowIso,
          );
          break;
        case TrainingSettingsSection.environment:
          await _updateEnvironmentSetting(draft, nowIso);
          final locations = await _replaceLocationsAndEquipment(draft, nowIso);
          await _upsertSchedule(draft, locations, nowIso);
          break;
        case TrainingSettingsSection.schedule:
          await _updateScheduleSetting(draft, nowIso);
          await _upsertSchedule(
            draft,
            await _activeLocationIds(draft.userId),
            nowIso,
          );
          break;
        case TrainingSettingsSection.split:
          await _updateSplitSetting(draft, nowIso);
          break;
        case TrainingSettingsSection.priorities:
          await _updatePrioritySetting(draft, nowIso);
          await _replacePriorities(draft, nowIso);
          break;
        case TrainingSettingsSection.restrictions:
          await _replaceRestrictions(draft, nowIso, today);
          break;
      }
    });
  }

  Future<void> _updateEnvironmentSetting(
    OnboardingDraft draft,
    String nowIso,
  ) async {
    await _database.customStatement(
      '''
      UPDATE user_training_setting
      SET location_mode_code = ?,
          both_usage_mode_code = ?,
          change_applies_from = 'NEXT_MENU',
          updated_at = ?,
          row_version = row_version + 1,
          sync_status = 'LOCAL_ONLY'
      WHERE user_id = ? AND deleted_at IS NULL
      ''',
      <Object?>[
        draft.locationModeCode,
        draft.bothUsageModeCode,
        nowIso,
        draft.userId,
      ],
    );
  }

  Future<void> _updateScheduleSetting(
    OnboardingDraft draft,
    String nowIso,
  ) async {
    await _database.customStatement(
      '''
      UPDATE user_training_setting
      SET desired_days_per_week = ?,
          usual_duration_min = ?,
          change_applies_from = 'NEXT_MENU',
          updated_at = ?,
          row_version = row_version + 1,
          sync_status = 'LOCAL_ONLY'
      WHERE user_id = ? AND deleted_at IS NULL
      ''',
      <Object?>[
        draft.desiredDaysPerWeek,
        draft.usualDurationMin,
        nowIso,
        draft.userId,
      ],
    );
  }

  Future<void> _updateSplitSetting(
    OnboardingDraft draft,
    String nowIso,
  ) async {
    await _database.customStatement(
      '''
      UPDATE user_training_setting
      SET split_preference_code = ?,
          change_applies_from = 'NEXT_MENU',
          updated_at = ?,
          row_version = row_version + 1,
          sync_status = 'LOCAL_ONLY'
      WHERE user_id = ? AND deleted_at IS NULL
      ''',
      <Object?>[
        draft.splitPreferenceCode,
        nowIso,
        draft.userId,
      ],
    );
  }

  Future<void> _updatePrioritySetting(
    OnboardingDraft draft,
    String nowIso,
  ) async {
    await _database.customStatement(
      '''
      UPDATE user_training_setting
      SET ab_goal_code = ?,
          change_applies_from = 'NEXT_MENU',
          updated_at = ?,
          row_version = row_version + 1,
          sync_status = 'LOCAL_ONLY'
      WHERE user_id = ? AND deleted_at IS NULL
      ''',
      <Object?>[
        draft.abGoalCode,
        nowIso,
        draft.userId,
      ],
    );
  }

  Future<Map<String, String>> _activeLocationIds(String userId) async {
    final rows = await _database.customSelect(
      '''
      SELECT id, location_type_code
      FROM training_location
      WHERE user_id = ? AND deleted_at IS NULL
      ORDER BY is_primary DESC, created_at
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    final result = <String, String>{};
    for (final row in rows) {
      result.putIfAbsent(
        row.read<String>('location_type_code'),
        () => row.read<String>('id'),
      );
    }
    return result;
  }

  Future<void> _upsertProfile(
    OnboardingDraft draft,
    String nowIso,
    String today,
  ) async {
    final id = await _userRowId('user_profile', draft.userId) ??
        _idGenerator.next();
    await _database.customStatement(
      '''
      INSERT INTO user_profile (
        id, user_id, created_at, updated_at, row_version, sync_status,
        nickname, age_years, age_updated_on, sex_code, height_cm,
        onboarding_completed_at
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        nickname = excluded.nickname,
        age_years = excluded.age_years,
        age_updated_on = excluded.age_updated_on,
        sex_code = excluded.sex_code,
        height_cm = excluded.height_cm,
        onboarding_completed_at = excluded.onboarding_completed_at,
        updated_at = excluded.updated_at,
        deleted_at = NULL,
        row_version = user_profile.row_version + 1,
        sync_status = 'LOCAL_ONLY'
      ''',
      <Object?>[
        id,
        draft.userId,
        nowIso,
        nowIso,
        draft.nickname.trim(),
        draft.ageYears,
        today,
        draft.sexCode,
        draft.heightCm,
        nowIso,
      ],
    );
  }

  Future<void> _upsertTrainingSetting(
    OnboardingDraft draft,
    String nowIso,
  ) async {
    final id = await _userRowId('user_training_setting', draft.userId) ??
        _idGenerator.next();
    await _database.customStatement(
      '''
      INSERT INTO user_training_setting (
        id, user_id, created_at, updated_at, row_version, sync_status,
        desired_days_per_week, usual_duration_min, location_mode_code,
        both_usage_mode_code, split_preference_code, ab_goal_code,
        change_applies_from
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?, 'NEXT_MENU')
      ON CONFLICT(id) DO UPDATE SET
        desired_days_per_week = excluded.desired_days_per_week,
        usual_duration_min = excluded.usual_duration_min,
        location_mode_code = excluded.location_mode_code,
        both_usage_mode_code = excluded.both_usage_mode_code,
        split_preference_code = excluded.split_preference_code,
        ab_goal_code = excluded.ab_goal_code,
        updated_at = excluded.updated_at,
        deleted_at = NULL,
        row_version = user_training_setting.row_version + 1,
        sync_status = 'LOCAL_ONLY',
        change_applies_from = 'NEXT_MENU'
      ''',
      <Object?>[
        id,
        draft.userId,
        nowIso,
        nowIso,
        draft.desiredDaysPerWeek,
        draft.usualDurationMin,
        draft.locationModeCode,
        draft.bothUsageModeCode,
        draft.splitPreferenceCode,
        draft.abGoalCode,
      ],
    );
  }

  Future<void> _upsertExperience(
    OnboardingDraft draft,
    ExperienceAssessment assessment,
    String progressionRuleId,
    String nowIso,
  ) async {
    final id = await _userRowId('user_experience_profile', draft.userId) ??
        _idGenerator.next();
    await _database.customStatement(
      '''
      INSERT INTO user_experience_profile (
        id, user_id, created_at, updated_at, row_version, sync_status,
        cumulative_experience_code, continuity_code, hiatus_code,
        current_frequency, adjusts_by_history, logs_sets,
        adjustment_habit_code, logging_habit_code,
        calculated_level_code, returning_mode, start_volume_factor,
        calculated_by_rule_version_id
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        cumulative_experience_code = excluded.cumulative_experience_code,
        continuity_code = excluded.continuity_code,
        hiatus_code = excluded.hiatus_code,
        current_frequency = excluded.current_frequency,
        adjusts_by_history = excluded.adjusts_by_history,
        logs_sets = excluded.logs_sets,
        adjustment_habit_code = excluded.adjustment_habit_code,
        logging_habit_code = excluded.logging_habit_code,
        calculated_level_code = excluded.calculated_level_code,
        returning_mode = excluded.returning_mode,
        start_volume_factor = excluded.start_volume_factor,
        calculated_by_rule_version_id = excluded.calculated_by_rule_version_id,
        updated_at = excluded.updated_at,
        deleted_at = NULL,
        row_version = user_experience_profile.row_version + 1,
        sync_status = 'LOCAL_ONLY'
      ''',
      <Object?>[
        id,
        draft.userId,
        nowIso,
        nowIso,
        draft.cumulativeExperienceCode,
        draft.continuityCode,
        draft.hiatusCode,
        draft.currentFrequency,
        draft.adjustmentHabitCode != 'NONE' ? 1 : 0,
        draft.loggingHabitCode != 'NONE' ? 1 : 0,
        draft.adjustmentHabitCode,
        draft.loggingHabitCode,
        assessment.levelCode,
        assessment.returningMode ? 1 : 0,
        assessment.startVolumeFactor,
        progressionRuleId,
      ],
    );
  }

  Future<Map<String, String>> _replaceLocationsAndEquipment(
    OnboardingDraft draft,
    String nowIso,
  ) async {
    final existingLocations = await _activeLocationIds(draft.userId);

    await _softDeleteUserRows('location_dumbbell_detail', draft.userId, nowIso);
    await _softDeleteUserRows('location_barbell_detail', draft.userId, nowIso);
    await _softDeleteUserRows('equipment_weight_option', draft.userId, nowIso);
    await _softDeleteUserRows('location_equipment', draft.userId, nowIso);

    final homeId = draft.usesHome
        ? existingLocations['HOME'] ?? _idGenerator.next()
        : null;
    final gymId = draft.usesGym
        ? existingLocations['GYM'] ?? _idGenerator.next()
        : null;
    await _database.customStatement(
      '''
      UPDATE training_location
      SET deleted_at = ?,
          updated_at = ?,
          row_version = row_version + 1,
          sync_status = 'LOCAL_ONLY'
      WHERE user_id = ?
        AND deleted_at IS NULL
        AND id <> COALESCE(?, '')
        AND id <> COALESCE(?, '')
      ''',
      <Object?>[nowIso, nowIso, draft.userId, homeId, gymId],
    );

    final result = <String, String>{};
    if (homeId != null) {
      result['HOME'] = homeId;
      await _upsertLocation(
        id: homeId,
        userId: draft.userId,
        typeCode: 'HOME',
        displayName: '自宅',
        gymProfileCode: null,
        isPrimary: draft.locationModeCode == 'HOME' ||
            draft.bothUsageModeCode == 'MAINLY_HOME',
        nowIso: nowIso,
      );
      await _insertHomeEquipment(draft, homeId, nowIso);
    }
    if (gymId != null) {
      result['GYM'] = gymId;
      await _upsertLocation(
        id: gymId,
        userId: draft.userId,
        typeCode: 'GYM',
        displayName: 'ジム',
        gymProfileCode: draft.gymProfileCode,
        isPrimary: draft.locationModeCode == 'GYM' ||
            draft.bothUsageModeCode == 'MAINLY_GYM',
        nowIso: nowIso,
      );
      if (draft.isGymLimited) {
        for (final equipmentCode in draft.limitedGymEquipmentCodes) {
          await _insertGenericEquipment(
            userId: draft.userId,
            locationId: gymId,
            equipmentCode: equipmentCode,
            nowIso: nowIso,
          );
        }
      }
    }
    return result;
  }

  Future<void> _upsertLocation({
    required String id,
    required String userId,
    required String typeCode,
    required String displayName,
    required String? gymProfileCode,
    required bool isPrimary,
    required String nowIso,
  }) async {
    await _database.customStatement(
      '''
      INSERT INTO training_location (
        id, user_id, created_at, updated_at, row_version, sync_status,
        location_type_code, display_name, gym_profile_code, is_primary
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        location_type_code = excluded.location_type_code,
        display_name = excluded.display_name,
        gym_profile_code = excluded.gym_profile_code,
        is_primary = excluded.is_primary,
        updated_at = excluded.updated_at,
        deleted_at = NULL,
        row_version = training_location.row_version + 1,
        sync_status = 'LOCAL_ONLY'
      ''',
      <Object?>[
        id,
        userId,
        nowIso,
        nowIso,
        typeCode,
        displayName,
        gymProfileCode,
        isPrimary ? 1 : 0,
      ],
    );
  }

  Future<void> _insertHomeEquipment(
    OnboardingDraft draft,
    String locationId,
    String nowIso,
  ) async {
    final codes = draft.homeEquipmentCodes;
    if (codes.contains('NONE')) {
      await _insertGenericEquipment(
        userId: draft.userId,
        locationId: locationId,
        equipmentCode: 'NONE',
        nowIso: nowIso,
      );
      return;
    }

    for (final code in codes) {
      if (code == 'FIXED_DUMBBELL') {
        await _insertDumbbell(
          draft: draft,
          locationId: locationId,
          setup: draft.fixedDumbbells!,
          nowIso: nowIso,
        );
      } else if (code == 'ADJUSTABLE_DUMBBELL') {
        await _insertDumbbell(
          draft: draft,
          locationId: locationId,
          setup: draft.adjustableDumbbells!,
          nowIso: nowIso,
        );
      } else if (code == 'BARBELL') {
        await _insertBarbell(draft, locationId, nowIso);
      } else {
        await _insertGenericEquipment(
          userId: draft.userId,
          locationId: locationId,
          equipmentCode: code,
          nowIso: nowIso,
        );
      }
    }
  }

  Future<void> _insertDumbbell({
    required OnboardingDraft draft,
    required String locationId,
    required DumbbellSetupDraft setup,
    required String nowIso,
  }) async {
    final equipmentId = await _requiredId(
      table: 'equipment_master',
      code: 'DUMBBELL',
    );
    final locationEquipmentId = _idGenerator.next();
    final unitCount = setup.setupTypeCode == 'FIXED'
        ? setup.weightOptions.fold<int>(
            0,
            (int total, WeightOptionDraft option) => total + option.quantity,
          )
        : setup.unitCount;
    await _database.customStatement(
      '''
      INSERT INTO location_equipment (
        id, user_id, created_at, updated_at, row_version, sync_status,
        training_location_id, equipment_id, quantity,
        min_weight, max_weight, increment_weight, is_available
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?, 1)
      ''',
      <Object?>[
        locationEquipmentId,
        draft.userId,
        nowIso,
        nowIso,
        locationId,
        equipmentId,
        unitCount,
        setup.minWeightKg,
        setup.maxWeightKg,
        setup.incrementWeightKg,
      ],
    );
    await _database.customStatement(
      '''
      INSERT INTO location_dumbbell_detail (
        id, user_id, created_at, updated_at, row_version, sync_status,
        location_equipment_id, setup_type_code, unit_count
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?)
      ''',
      <Object?>[
        _idGenerator.next(),
        draft.userId,
        nowIso,
        nowIso,
        locationEquipmentId,
        setup.setupTypeCode,
        unitCount,
      ],
    );
    for (final option in setup.weightOptions) {
      await _database.customStatement(
        '''
        INSERT INTO equipment_weight_option (
          id, user_id, created_at, updated_at, row_version, sync_status,
          location_equipment_id, weight_value, unit_code, quantity
        ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, 'KG', ?)
        ''',
        <Object?>[
          _idGenerator.next(),
          draft.userId,
          nowIso,
          nowIso,
          locationEquipmentId,
          option.weightKg,
          option.quantity,
        ],
      );
    }
  }

  Future<void> _insertBarbell(
    OnboardingDraft draft,
    String locationId,
    String nowIso,
  ) async {
    final setup = draft.barbellSetup!;
    final equipmentId = await _requiredId(
      table: 'equipment_master',
      code: 'BARBELL',
    );
    final locationEquipmentId = _idGenerator.next();
    await _database.customStatement(
      '''
      INSERT INTO location_equipment (
        id, user_id, created_at, updated_at, row_version, sync_status,
        training_location_id, equipment_id, quantity,
        min_weight, max_weight, increment_weight,
        has_rack, has_safety, is_available
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, 1, ?, ?, ?, ?, ?, 1)
      ''',
      <Object?>[
        locationEquipmentId,
        draft.userId,
        nowIso,
        nowIso,
        locationId,
        equipmentId,
        setup.shaftWeightKg,
        setup.maxTotalWeightKg,
        setup.minIncrementKg,
        setup.hasRack ? 1 : 0,
        setup.hasSafety ? 1 : 0,
      ],
    );
    await _database.customStatement(
      '''
      INSERT INTO location_barbell_detail (
        id, user_id, created_at, updated_at, row_version, sync_status,
        location_equipment_id, shaft_weight_kg, max_total_weight_kg,
        min_increment_kg, has_rack, has_safety
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?)
      ''',
      <Object?>[
        _idGenerator.next(),
        draft.userId,
        nowIso,
        nowIso,
        locationEquipmentId,
        setup.shaftWeightKg,
        setup.maxTotalWeightKg,
        setup.minIncrementKg,
        setup.hasRack ? 1 : 0,
        setup.hasSafety ? 1 : 0,
      ],
    );
    for (final plate in setup.plateOptions) {
      await _database.customStatement(
        '''
        INSERT INTO equipment_weight_option (
          id, user_id, created_at, updated_at, row_version, sync_status,
          location_equipment_id, weight_value, unit_code, quantity
        ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, 'KG', ?)
        ''',
        <Object?>[
          _idGenerator.next(),
          draft.userId,
          nowIso,
          nowIso,
          locationEquipmentId,
          plate.weightKg,
          plate.quantity,
        ],
      );
    }
  }

  Future<void> _insertGenericEquipment({
    required String userId,
    required String locationId,
    required String equipmentCode,
    required String nowIso,
  }) async {
    final normalizedCode = switch (equipmentCode) {
      'FLAT_BENCH' => 'FLAT_BENCH',
      'ADJUSTABLE_BENCH' => 'ADJUSTABLE_BENCH',
      _ => equipmentCode,
    };
    final equipmentId = await _requiredId(
      table: 'equipment_master',
      code: normalizedCode,
    );
    await _database.customStatement(
      '''
      INSERT INTO location_equipment (
        id, user_id, created_at, updated_at, row_version, sync_status,
        training_location_id, equipment_id, quantity, is_available
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, 1, 1)
      ''',
      <Object?>[
        _idGenerator.next(),
        userId,
        nowIso,
        nowIso,
        locationId,
        equipmentId,
      ],
    );
  }

  Future<void> _upsertSchedule(
    OnboardingDraft draft,
    Map<String, String> locations,
    String nowIso,
  ) async {
    String? defaultLocationId;
    if (draft.locationModeCode == 'HOME') {
      defaultLocationId = locations['HOME'];
    } else if (draft.locationModeCode == 'GYM') {
      defaultLocationId = locations['GYM'];
    } else if (draft.bothUsageModeCode == 'MAINLY_HOME') {
      defaultLocationId = locations['HOME'];
    } else if (draft.bothUsageModeCode == 'MAINLY_GYM') {
      defaultLocationId = locations['GYM'];
    }
    const weekdays = <String>['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
    for (final weekday in weekdays) {
      final existing = await _database.customSelect(
        '''
        SELECT id FROM standard_schedule_day
        WHERE user_id = ? AND weekday_code = ?
        LIMIT 1
        ''',
        variables: <Variable<Object>>[
          Variable.withString(draft.userId),
          Variable.withString(weekday),
        ],
      ).get();
      final id = existing.isEmpty
          ? _idGenerator.next()
          : existing.first.read<String>('id');
      final available = draft.availableWeekdayCodes.contains(weekday);
      final locationId = available &&
              draft.locationModeCode == 'BOTH' &&
              draft.bothUsageModeCode == 'BY_WEEKDAY'
          ? locations[draft.scheduleLocationByWeekday[weekday]]
          : available
              ? defaultLocationId
              : null;
      await _database.customStatement(
        '''
        INSERT INTO standard_schedule_day (
          id, user_id, created_at, updated_at, row_version, sync_status,
          weekday_code, is_available, duration_min, training_location_id
        ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          is_available = excluded.is_available,
          duration_min = excluded.duration_min,
          training_location_id = excluded.training_location_id,
          updated_at = excluded.updated_at,
          deleted_at = NULL,
          row_version = standard_schedule_day.row_version + 1,
          sync_status = 'LOCAL_ONLY'
        ''',
        <Object?>[
          id,
          draft.userId,
          nowIso,
          nowIso,
          weekday,
          available ? 1 : 0,
          available ? draft.usualDurationMin : null,
          locationId,
        ],
      );
    }
  }

  Future<void> _replaceGoals(OnboardingDraft draft, String nowIso) async {
    await _softDeleteUserRows('user_goal', draft.userId, nowIso);
    final goals = <String>[
      draft.primaryGoalCode!,
      ...draft.secondaryGoalCodes.where((String code) => code != 'NONE'),
    ];
    for (var i = 0; i < goals.length; i++) {
      await _database.customStatement(
        '''
        INSERT INTO user_goal (
          id, user_id, created_at, updated_at, row_version, sync_status,
          goal_code, goal_type, display_order
        ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?)
        ''',
        <Object?>[
          _idGenerator.next(),
          draft.userId,
          nowIso,
          nowIso,
          goals[i],
          i == 0 ? 'PRIMARY' : 'SECONDARY',
          i,
        ],
      );
    }
  }

  Future<void> _replacePriorities(
    OnboardingDraft draft,
    String nowIso,
  ) async {
    await _softDeleteUserRows('user_priority_part', draft.userId, nowIso);
    await _insertPriority(
      userId: draft.userId,
      code: draft.primaryPriorityCode!,
      contextCode: 'TRAINING',
      priorityType: 'MAIN',
      nowIso: nowIso,
    );
    for (final code in draft.secondaryPriorityCodes) {
      if (code == 'NONE') {
        continue;
      }
      await _insertPriority(
        userId: draft.userId,
        code: code,
        contextCode: 'TRAINING',
        priorityType: 'SECONDARY',
        nowIso: nowIso,
      );
    }
    for (final code in draft.appearancePriorityCodes) {
      if (code == 'NONE') {
        continue;
      }
      await _database.customStatement(
        '''
        INSERT INTO user_priority_part (
          id, user_id, created_at, updated_at, row_version, sync_status,
          context_code, priority_type, appearance_code
        ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', 'APPEARANCE', 'SECONDARY', ?)
        ''',
        <Object?>[
          _idGenerator.next(),
          draft.userId,
          nowIso,
          nowIso,
          code,
        ],
      );
    }
  }

  Future<void> _insertPriority({
    required String userId,
    required String code,
    required String contextCode,
    required String priorityType,
    required String nowIso,
  }) async {
    if (code == 'BALANCED') {
      await _database.customStatement(
        '''
        INSERT INTO user_priority_part (
          id, user_id, created_at, updated_at, row_version, sync_status,
          context_code, priority_type, appearance_code
        ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, 'BALANCED')
        ''',
        <Object?>[
          _idGenerator.next(),
          userId,
          nowIso,
          nowIso,
          contextCode,
          priorityType,
        ],
      );
      return;
    }
    final bodyPartId = await _requiredId(
      table: 'body_part_master',
      code: code,
    );
    await _database.customStatement(
      '''
      INSERT INTO user_priority_part (
        id, user_id, created_at, updated_at, row_version, sync_status,
        context_code, priority_type, body_part_id
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?)
      ''',
      <Object?>[
        _idGenerator.next(),
        userId,
        nowIso,
        nowIso,
        contextCode,
        priorityType,
        bodyPartId,
      ],
    );
  }

  Future<void> _replaceRestrictions(
    OnboardingDraft draft,
    String nowIso,
    String today,
  ) async {
    await _softDeleteUserRows('user_restriction', draft.userId, nowIso);

    for (final entry in draft.painActionsByArea.entries) {
      final parts = entry.key.split(':');
      final isJoint = parts.first == 'JOINT';
      final targetId = await _requiredId(
        table: isJoint ? 'joint_master' : 'body_part_master',
        code: parts.last,
      );
      await _insertRestriction(
        userId: draft.userId,
        restrictionType: 'PAIN_AREA',
        bodyPartId: isJoint ? null : targetId,
        jointId: isJoint ? targetId : null,
        movementId: null,
        exerciseId: null,
        actionCode: entry.value,
        effectiveFrom: today,
        nowIso: nowIso,
      );
    }

    for (final code in draft.avoidBodyPartCodes) {
      final id = await _requiredId(table: 'body_part_master', code: code);
      await _insertRestriction(
        userId: draft.userId,
        restrictionType: 'AVOID_BODY_PART',
        bodyPartId: id,
        jointId: null,
        movementId: null,
        exerciseId: null,
        actionCode: 'EXCLUDE',
        effectiveFrom: today,
        nowIso: nowIso,
      );
    }

    for (final group in draft.avoidMovementGroupCodes) {
      for (final movementCode in OnboardingOptions.avoidMovementCodesByGroup[group] ?? const <String>[]) {
        final id = await _requiredId(
          table: 'movement_master',
          code: movementCode,
        );
        await _insertRestriction(
          userId: draft.userId,
          restrictionType: 'AVOID_MOVEMENT',
          bodyPartId: null,
          jointId: null,
          movementId: id,
          exerciseId: null,
          actionCode: 'EXCLUDE',
          effectiveFrom: today,
          nowIso: nowIso,
        );
      }
    }

    for (final code in draft.avoidExerciseCodes) {
      final id = await _requiredId(table: 'exercise_master', code: code);
      await _insertRestriction(
        userId: draft.userId,
        restrictionType: 'AVOID_EXERCISE',
        bodyPartId: null,
        jointId: null,
        movementId: null,
        exerciseId: id,
        actionCode: 'EXCLUDE',
        effectiveFrom: today,
        nowIso: nowIso,
      );
    }
  }

  Future<void> _insertRestriction({
    required String userId,
    required String restrictionType,
    required String? bodyPartId,
    required String? jointId,
    required String? movementId,
    required String? exerciseId,
    required String actionCode,
    required String effectiveFrom,
    required String nowIso,
  }) async {
    await _database.customStatement(
      '''
      INSERT INTO user_restriction (
        id, user_id, created_at, updated_at, row_version, sync_status,
        restriction_type_code, body_part_id, joint_id, movement_id,
        exercise_id, default_action_code, effective_from, source_code
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?, ?, 'USER')
      ''',
      <Object?>[
        _idGenerator.next(),
        userId,
        nowIso,
        nowIso,
        restrictionType,
        bodyPartId,
        jointId,
        movementId,
        exerciseId,
        actionCode,
        effectiveFrom,
      ],
    );
  }

  Future<void> _upsertAppPreference(String userId, String nowIso) async {
    final id = await _userRowId('app_preference', userId) ?? _idGenerator.next();
    await _database.customStatement(
      '''
      INSERT INTO app_preference (
        id, user_id, created_at, updated_at, row_version, sync_status,
        weight_unit_code, height_unit_code, appearance_code,
        sound_enabled, rest_timer_default_sec
      ) VALUES (?, ?, ?, ?, 1, 'LOCAL_ONLY', 'KG', 'CM', 'SYSTEM', 1, 90)
      ON CONFLICT(id) DO UPDATE SET
        updated_at = excluded.updated_at,
        deleted_at = NULL,
        row_version = app_preference.row_version + 1,
        sync_status = 'LOCAL_ONLY'
      ''',
      <Object?>[id, userId, nowIso, nowIso],
    );
  }

  Future<void> _appendBodyMeasurement(
    OnboardingDraft draft,
    String nowIso,
  ) async {
    if (draft.weightKg == null && draft.bodyFatPercent == null) {
      return;
    }
    await _database.customStatement(
      '''
      INSERT INTO body_measurement (
        id, user_id, created_at, updated_at, sync_status,
        measured_at, weight_kg, body_fat_percent, source_code
      ) VALUES (?, ?, ?, ?, 'LOCAL_ONLY', ?, ?, ?, 'ONBOARDING')
      ''',
      <Object?>[
        _idGenerator.next(),
        draft.userId,
        nowIso,
        nowIso,
        nowIso,
        draft.weightKg,
        draft.knowsBodyFat ? draft.bodyFatPercent : null,
      ],
    );
  }

  Future<String?> _userRowId(String table, String userId) async {
    final rows = await _database.customSelect(
      'SELECT id FROM $table WHERE user_id = ? AND deleted_at IS NULL LIMIT 1',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    return rows.isEmpty ? null : rows.first.read<String>('id');
  }

  Future<void> _softDeleteUserRows(
    String table,
    String userId,
    String nowIso,
  ) async {
    await _database.customStatement(
      'UPDATE $table SET deleted_at = ?, updated_at = ?, '
      "sync_status = 'LOCAL_ONLY', row_version = row_version + 1 "
      'WHERE user_id = ? AND deleted_at IS NULL',
      <Object?>[nowIso, nowIso, userId],
    );
  }

  Future<String> _requiredId({
    required String table,
    required String code,
  }) async {
    final rows = await _database.customSelect(
      'SELECT id FROM $table WHERE code = ? LIMIT 1',
      variables: <Variable<Object>>[Variable.withString(code)],
    ).get();
    if (rows.isEmpty) {
      throw StateError('$table code not found: $code');
    }
    return rows.first.read<String>('id');
  }

}
