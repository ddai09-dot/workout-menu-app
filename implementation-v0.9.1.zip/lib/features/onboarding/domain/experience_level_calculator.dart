final class ExperienceAssessment {
  const ExperienceAssessment({
    required this.levelCode,
    required this.returningMode,
    required this.startVolumeFactor,
  });

  final String levelCode;
  final bool returningMode;
  final double startVolumeFactor;
}

abstract final class ExperienceLevelCalculator {
  static ExperienceAssessment calculate({
    required String cumulativeExperienceCode,
    required String continuityCode,
    required String? hiatusCode,
  }) {
    late final String levelCode;
    if (cumulativeExperienceCode == 'Y2_5') {
      levelCode = 'INTERMEDIATE';
    } else if (cumulativeExperienceCode == 'Y5_10' ||
        cumulativeExperienceCode == 'GTE_10Y') {
      levelCode = 'ADVANCED';
    } else {
      levelCode = 'BEGINNER';
    }

    if (continuityCode != 'NOT_ACTIVE') {
      return ExperienceAssessment(
        levelCode: levelCode,
        returningMode: false,
        startVolumeFactor: 1,
      );
    }

    final factor = <String, double>{
          'LT_1M': 0.9,
          'M1_3': 0.85,
          'M3_6': 0.75,
          'M6_12': 0.7,
          'Y1_2': 0.6,
          'GTE_2Y': 0.5,
        }[hiatusCode] ??
        0.75;

    return ExperienceAssessment(
      levelCode: levelCode,
      returningMode: true,
      startVolumeFactor: factor,
    );
  }
}
