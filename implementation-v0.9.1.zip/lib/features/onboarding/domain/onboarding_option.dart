final class OnboardingOption {
  const OnboardingOption({
    required this.code,
    required this.label,
    this.description,
  });

  final String code;
  final String label;
  final String? description;
}

abstract final class OnboardingOptions {
  static const sex = <OnboardingOption>[
    OnboardingOption(code: 'MALE', label: '男性'),
    OnboardingOption(code: 'FEMALE', label: '女性'),
    OnboardingOption(code: 'PREFER_NOT_TO_SAY', label: '回答しない'),
  ];

  static const goals = <OnboardingOption>[
    OnboardingOption(code: 'HYPERTROPHY', label: '筋肉を大きくしたい'),
    OnboardingOption(code: 'STRENGTH', label: '筋力を高めたい'),
    OnboardingOption(code: 'FAT_LOSS', label: '体脂肪を減らしたい'),
    OnboardingOption(code: 'TONING', label: '身体を引き締めたい'),
    OnboardingOption(code: 'HEALTH', label: '健康を維持したい'),
    OnboardingOption(code: 'INACTIVITY', label: '運動不足を解消したい'),
  ];

  static const cumulativeExperience = <OnboardingOption>[
    OnboardingOption(code: 'NONE', label: '未経験'),
    OnboardingOption(code: 'LT_1Y', label: '1年未満'),
    OnboardingOption(code: 'Y1_2', label: '1年以上〜2年未満'),
    OnboardingOption(code: 'Y2_5', label: '2年以上〜5年未満'),
    OnboardingOption(code: 'Y5_10', label: '5年以上〜10年未満'),
    OnboardingOption(code: 'GTE_10Y', label: '10年以上'),
  ];

  static const continuity = <OnboardingOption>[
    OnboardingOption(code: 'NOT_ACTIVE', label: '現在は行っていない'),
    OnboardingOption(code: 'LT_1M', label: '1か月未満'),
    OnboardingOption(code: 'M1_3', label: '1〜3か月'),
    OnboardingOption(code: 'M3_6', label: '3〜6か月'),
    OnboardingOption(code: 'M6_12', label: '6か月〜1年'),
    OnboardingOption(code: 'Y1_2', label: '1〜2年'),
    OnboardingOption(code: 'Y2_5', label: '2〜5年'),
    OnboardingOption(code: 'GTE_5Y', label: '5年以上'),
  ];

  static const hiatus = <OnboardingOption>[
    OnboardingOption(code: 'LT_1M', label: '1か月未満'),
    OnboardingOption(code: 'M1_3', label: '1〜3か月'),
    OnboardingOption(code: 'M3_6', label: '3〜6か月'),
    OnboardingOption(code: 'M6_12', label: '6か月〜1年'),
    OnboardingOption(code: 'Y1_2', label: '1〜2年'),
    OnboardingOption(code: 'GTE_2Y', label: '2年以上'),
  ];

  static const adjustmentHabits = <OnboardingOption>[
    OnboardingOption(code: 'NONE', label: '自分では調整していない'),
    OnboardingOption(code: 'SOMETIMES', label: 'ときどき調整している'),
    OnboardingOption(code: 'HISTORY_BASED', label: '前回結果を見て調整している'),
  ];

  static const loggingHabits = <OnboardingOption>[
    OnboardingOption(code: 'NONE', label: '記録していない'),
    OnboardingOption(code: 'SOMETIMES', label: 'ときどき記録する'),
    OnboardingOption(code: 'ALWAYS', label: '毎回記録する'),
  ];

  static const locationModes = <OnboardingOption>[
    OnboardingOption(code: 'HOME', label: '自宅'),
    OnboardingOption(code: 'GYM', label: 'ジム'),
    OnboardingOption(code: 'BOTH', label: '自宅とジムの両方'),
  ];

  static const bothUsageModes = <OnboardingOption>[
    OnboardingOption(code: 'MAINLY_HOME', label: '主に自宅'),
    OnboardingOption(code: 'MAINLY_GYM', label: '主にジム'),
    OnboardingOption(code: 'BY_WEEKDAY', label: '曜日によって使い分ける'),
  ];

  static const gymProfiles = <OnboardingOption>[
    OnboardingOption(code: 'FULL', label: '一般的な設備が一通りある'),
    OnboardingOption(code: 'MACHINE_HEAVY', label: 'マシンが多い'),
    OnboardingOption(code: 'FREE_WEIGHT_HEAVY', label: 'フリーウェイトが多い'),
    OnboardingOption(code: 'LIMITED', label: '設備が限られている'),
    OnboardingOption(code: 'UNKNOWN', label: 'よく分からない'),
  ];

  static const homeEquipment = <OnboardingOption>[
    OnboardingOption(code: 'NONE', label: '器具なし'),
    OnboardingOption(code: 'FIXED_DUMBBELL', label: '固定式ダンベル'),
    OnboardingOption(code: 'ADJUSTABLE_DUMBBELL', label: '可変式ダンベル'),
    OnboardingOption(code: 'FLAT_BENCH', label: 'フラットベンチ'),
    OnboardingOption(code: 'ADJUSTABLE_BENCH', label: '角度調整ベンチ'),
    OnboardingOption(code: 'BARBELL', label: 'バーベル'),
    OnboardingOption(code: 'RACK', label: 'パワーラック・ハーフラック'),
    OnboardingOption(code: 'PULLUP_BAR', label: '懸垂器具'),
    OnboardingOption(code: 'BAND', label: 'トレーニングチューブ'),
    OnboardingOption(code: 'KETTLEBELL', label: 'ケトルベル'),
  ];

  static const limitedGymEquipment = <OnboardingOption>[
    OnboardingOption(code: 'DUMBBELL', label: 'ダンベル'),
    OnboardingOption(code: 'BARBELL', label: 'バーベル'),
    OnboardingOption(code: 'BENCH', label: 'ベンチ'),
    OnboardingOption(code: 'RACK', label: 'ラック'),
    OnboardingOption(code: 'SMITH_MACHINE', label: 'スミスマシン'),
    OnboardingOption(code: 'CABLE_MACHINE', label: 'ケーブル'),
    OnboardingOption(code: 'CHEST_MACHINE_GROUP', label: '胸のマシン'),
    OnboardingOption(code: 'SHOULDER_MACHINE_GROUP', label: '肩のマシン'),
    OnboardingOption(code: 'ARM_MACHINE_GROUP', label: '腕のマシン'),
    OnboardingOption(code: 'BACK_MACHINE_GROUP', label: '背中のマシン'),
    OnboardingOption(code: 'LEG_MACHINE_GROUP', label: '脚のマシン'),
    OnboardingOption(code: 'PULLUP_BAR', label: '懸垂器具'),
    OnboardingOption(code: 'CARDIO_MACHINE', label: '有酸素マシン'),
  ];

  static const splitPreferences = <OnboardingOption>[
    OnboardingOption(
      code: 'MOVEMENT',
      label: '動作を基準に分ける',
      description: 'プッシュ／プル／脚など',
    ),
    OnboardingOption(
      code: 'BODY_PART',
      label: '部位を基準に分ける',
      description: '胸、背中、肩、腕、脚など',
    ),
    OnboardingOption(
      code: 'APP',
      label: 'アプリのおすすめに任せる',
      description: '経験、曜日、器具、回復から決めます',
    ),
  ];

  static const priorityParts = <OnboardingOption>[
    OnboardingOption(code: 'CHEST', label: '胸'),
    OnboardingOption(code: 'BACK', label: '背中'),
    OnboardingOption(code: 'SHOULDERS', label: '肩'),
    OnboardingOption(code: 'ARMS', label: '腕'),
    OnboardingOption(code: 'GLUTES', label: 'お尻'),
    OnboardingOption(code: 'LEGS', label: '脚'),
    OnboardingOption(code: 'BALANCED', label: '全身をバランスよく鍛えたい'),
  ];

  static const appearancePriorities = <OnboardingOption>[
    OnboardingOption(code: 'THICKER_CHEST', label: '胸を厚くしたい'),
    OnboardingOption(code: 'WIDER_BACK', label: '背中を広く見せたい'),
    OnboardingOption(code: 'WIDER_SHOULDERS', label: '肩幅を広く見せたい'),
    OnboardingOption(code: 'BIGGER_ARMS', label: '腕を太くしたい'),
    OnboardingOption(code: 'TRAIN_GLUTES', label: 'お尻を鍛えたい'),
    OnboardingOption(code: 'LEANER_LEGS', label: '脚を引き締めたい'),
    OnboardingOption(code: 'BALANCED', label: '全身をバランスよくしたい'),
  ];

  static const abGoals = <OnboardingOption>[
    OnboardingOption(code: 'TRAIN_ABS', label: '腹筋自体を鍛えたい'),
    OnboardingOption(code: 'REDUCE_FAT', label: 'お腹周りの脂肪を減らしたい'),
    OnboardingOption(code: 'BOTH', label: '両方'),
    OnboardingOption(code: 'NONE', label: '特にない'),
  ];

  static const painAreas = <OnboardingOption>[
    OnboardingOption(code: 'JOINT:JT008', label: '首'),
    OnboardingOption(code: 'JOINT:JT001', label: '肩'),
    OnboardingOption(code: 'JOINT:JT002', label: '肘'),
    OnboardingOption(code: 'JOINT:JT003', label: '手首・手'),
    OnboardingOption(code: 'BODY:CHEST', label: '胸'),
    OnboardingOption(code: 'BODY:BACK', label: '背中'),
    OnboardingOption(code: 'JOINT:JT004', label: '腰'),
    OnboardingOption(code: 'JOINT:JT005', label: '股関節'),
    OnboardingOption(code: 'JOINT:JT006', label: '膝'),
    OnboardingOption(code: 'JOINT:JT007', label: '足首・足'),
  ];

  static const painActions = <OnboardingOption>[
    OnboardingOption(code: 'AS_PLANNED', label: '予定どおり入れる'),
    OnboardingOption(code: 'REDUCE_LOAD', label: '負荷を下げる'),
    OnboardingOption(code: 'SUBSTITUTE', label: '負担の少ない種目へ変更'),
    OnboardingOption(code: 'EXCLUDE', label: 'メニューから除外'),
    OnboardingOption(code: 'MOVE_LATER', label: '週の後半へ移動'),
  ];

  static const avoidMovementGroups = <OnboardingOption>[
    OnboardingOption(code: 'PUSH', label: '押す動作'),
    OnboardingOption(code: 'PULL', label: '引く動作'),
    OnboardingOption(code: 'OVERHEAD_PRESS', label: '頭上へ押す動作'),
    OnboardingOption(code: 'SQUAT', label: 'しゃがむ動作'),
    OnboardingOption(code: 'HIP_HINGE', label: '股関節を曲げ伸ばす動作'),
    OnboardingOption(code: 'SINGLE_LEG', label: '片脚動作'),
    OnboardingOption(code: 'TRUNK_FLEXION', label: '体幹を曲げる動作'),
    OnboardingOption(code: 'TRUNK_EXTENSION', label: '体幹を反らす動作'),
  ];

  static const Map<String, List<String>> avoidMovementCodesByGroup =
      <String, List<String>>{
    'PUSH': <String>['MV001', 'MV002', 'MV003', 'MV008', 'MV013', 'MV016'],
    'PULL': <String>['MV004', 'MV005', 'MV006', 'MV012'],
    'OVERHEAD_PRESS': <String>['MV008', 'MV013'],
    'SQUAT': <String>['MV020', 'MV023', 'MV024', 'MV027'],
    'HIP_HINGE': <String>['MV007', 'MV018', 'MV019'],
    'SINGLE_LEG': <String>['MV020', 'MV027'],
    'TRUNK_FLEXION': <String>['MV029', 'MV030', 'MV031'],
    'TRUNK_EXTENSION': <String>['MV007'],
  };
}
