import 'package:workout_menu_app/features/onboarding/domain/onboarding_step.dart';

const Object _unset = Object();

final class WeightOptionDraft {
  const WeightOptionDraft({
    required this.weightKg,
    required this.quantity,
  });

  final double weightKg;
  final int quantity;

  Map<String, Object> toJson() => <String, Object>{
        'weightKg': weightKg,
        'quantity': quantity,
      };

  factory WeightOptionDraft.fromJson(Map<String, Object?> json) {
    return WeightOptionDraft(
      weightKg: (json['weightKg'] as num).toDouble(),
      quantity: (json['quantity'] as num).toInt(),
    );
  }
}

final class DumbbellSetupDraft {
  const DumbbellSetupDraft({
    required this.setupTypeCode,
    this.unitCount = 1,
    this.minWeightKg,
    this.maxWeightKg,
    this.incrementWeightKg,
    this.weightOptions = const <WeightOptionDraft>[],
  });

  final String setupTypeCode;
  final int unitCount;
  final double? minWeightKg;
  final double? maxWeightKg;
  final double? incrementWeightKg;
  final List<WeightOptionDraft> weightOptions;

  DumbbellSetupDraft copyWith({
    int? unitCount,
    Object? minWeightKg = _unset,
    Object? maxWeightKg = _unset,
    Object? incrementWeightKg = _unset,
    List<WeightOptionDraft>? weightOptions,
  }) {
    return DumbbellSetupDraft(
      setupTypeCode: setupTypeCode,
      unitCount: unitCount ?? this.unitCount,
      minWeightKg: identical(minWeightKg, _unset)
          ? this.minWeightKg
          : minWeightKg as double?,
      maxWeightKg: identical(maxWeightKg, _unset)
          ? this.maxWeightKg
          : maxWeightKg as double?,
      incrementWeightKg: identical(incrementWeightKg, _unset)
          ? this.incrementWeightKg
          : incrementWeightKg as double?,
      weightOptions: weightOptions ?? this.weightOptions,
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'setupTypeCode': setupTypeCode,
        'unitCount': unitCount,
        'minWeightKg': minWeightKg,
        'maxWeightKg': maxWeightKg,
        'incrementWeightKg': incrementWeightKg,
        'weightOptions': weightOptions
            .map((WeightOptionDraft value) => value.toJson())
            .toList(),
      };

  factory DumbbellSetupDraft.fromJson(Map<String, Object?> json) {
    return DumbbellSetupDraft(
      setupTypeCode: json['setupTypeCode']! as String,
      unitCount: (json['unitCount'] as num?)?.toInt() ??
          (json['pairCount'] as num?)?.toInt() ??
          1,
      minWeightKg: (json['minWeightKg'] as num?)?.toDouble(),
      maxWeightKg: (json['maxWeightKg'] as num?)?.toDouble(),
      incrementWeightKg: (json['incrementWeightKg'] as num?)?.toDouble(),
      weightOptions: ((json['weightOptions'] as List<Object?>?) ?? const <Object?>[])
          .map(
            (Object? value) => WeightOptionDraft.fromJson(
              Map<String, Object?>.from(
                value! as Map<Object?, Object?>,
              ),
            ),
          )
          .toList(growable: false),
    );
  }
}

final class BarbellSetupDraft {
  const BarbellSetupDraft({
    this.shaftWeightKg = 20,
    this.maxTotalWeightKg = 100,
    this.minIncrementKg = 2.5,
    this.hasRack = false,
    this.hasSafety = false,
    this.plateOptions = const <WeightOptionDraft>[],
  });

  final double shaftWeightKg;
  final double maxTotalWeightKg;
  final double minIncrementKg;
  final bool hasRack;
  final bool hasSafety;
  final List<WeightOptionDraft> plateOptions;

  BarbellSetupDraft copyWith({
    double? shaftWeightKg,
    double? maxTotalWeightKg,
    double? minIncrementKg,
    bool? hasRack,
    bool? hasSafety,
    List<WeightOptionDraft>? plateOptions,
  }) {
    return BarbellSetupDraft(
      shaftWeightKg: shaftWeightKg ?? this.shaftWeightKg,
      maxTotalWeightKg: maxTotalWeightKg ?? this.maxTotalWeightKg,
      minIncrementKg: minIncrementKg ?? this.minIncrementKg,
      hasRack: hasRack ?? this.hasRack,
      hasSafety: hasSafety ?? this.hasSafety,
      plateOptions: plateOptions ?? this.plateOptions,
    );
  }

  Map<String, Object> toJson() => <String, Object>{
        'shaftWeightKg': shaftWeightKg,
        'maxTotalWeightKg': maxTotalWeightKg,
        'minIncrementKg': minIncrementKg,
        'hasRack': hasRack,
        'hasSafety': hasSafety,
        'plateOptions': plateOptions
            .map((WeightOptionDraft value) => value.toJson())
            .toList(),
      };

  factory BarbellSetupDraft.fromJson(Map<String, Object?> json) {
    return BarbellSetupDraft(
      shaftWeightKg: (json['shaftWeightKg'] as num?)?.toDouble() ?? 20,
      maxTotalWeightKg:
          (json['maxTotalWeightKg'] as num?)?.toDouble() ?? 100,
      minIncrementKg: (json['minIncrementKg'] as num?)?.toDouble() ?? 2.5,
      hasRack: json['hasRack'] as bool? ?? false,
      hasSafety: json['hasSafety'] as bool? ?? false,
      plateOptions: ((json['plateOptions'] as List<Object?>?) ??
              const <Object?>[])
          .map(
            (Object? value) => WeightOptionDraft.fromJson(
              Map<String, Object?>.from(
                value! as Map<Object?, Object?>,
              ),
            ),
          )
          .toList(growable: false),
    );
  }
}

final class OnboardingDraft {
  const OnboardingDraft({
    required this.id,
    required this.userId,
    this.currentStep = OnboardingStep.intro,
    this.nickname = '',
    this.ageYears,
    this.sexCode,
    this.heightCm,
    this.weightKg,
    this.knowsBodyFat = false,
    this.bodyFatPercent,
    this.primaryGoalCode,
    this.secondaryGoalCodes = const <String>{},
    this.cumulativeExperienceCode,
    this.continuityCode,
    this.hiatusCode,
    this.currentFrequency,
    this.adjustmentHabitCode,
    this.loggingHabitCode,
    this.locationModeCode,
    this.bothUsageModeCode,
    this.gymProfileCode,
    this.homeEquipmentCodes = const <String>{},
    this.limitedGymEquipmentCodes = const <String>{},
    this.fixedDumbbells,
    this.adjustableDumbbells,
    this.barbellSetup,
    this.desiredDaysPerWeek,
    this.availableWeekdayCodes = const <String>{},
    this.scheduleLocationByWeekday = const <String, String>{},
    this.usualDurationMin,
    this.splitPreferenceCode,
    this.primaryPriorityCode,
    this.secondaryPriorityCodes = const <String>{},
    this.appearancePriorityCodes = const <String>{},
    this.abGoalCode,
    this.painActionsByArea = const <String, String>{},
    this.avoidBodyPartCodes = const <String>{},
    this.avoidMovementGroupCodes = const <String>{},
    this.avoidExerciseCodes = const <String>{},
  });

  final String id;
  final String userId;
  final OnboardingStep currentStep;

  final String nickname;
  final int? ageYears;
  final String? sexCode;
  final double? heightCm;
  final double? weightKg;
  final bool knowsBodyFat;
  final double? bodyFatPercent;

  final String? primaryGoalCode;
  final Set<String> secondaryGoalCodes;

  final String? cumulativeExperienceCode;
  final String? continuityCode;
  final String? hiatusCode;
  final int? currentFrequency;
  final String? adjustmentHabitCode;
  final String? loggingHabitCode;

  final String? locationModeCode;
  final String? bothUsageModeCode;
  final String? gymProfileCode;
  final Set<String> homeEquipmentCodes;
  final Set<String> limitedGymEquipmentCodes;
  final DumbbellSetupDraft? fixedDumbbells;
  final DumbbellSetupDraft? adjustableDumbbells;
  final BarbellSetupDraft? barbellSetup;

  final int? desiredDaysPerWeek;
  final Set<String> availableWeekdayCodes;
  final Map<String, String> scheduleLocationByWeekday;
  final int? usualDurationMin;

  final String? splitPreferenceCode;
  final String? primaryPriorityCode;
  final Set<String> secondaryPriorityCodes;
  final Set<String> appearancePriorityCodes;
  final String? abGoalCode;

  final Map<String, String> painActionsByArea;
  final Set<String> avoidBodyPartCodes;
  final Set<String> avoidMovementGroupCodes;
  final Set<String> avoidExerciseCodes;

  bool get usesHome => locationModeCode == 'HOME' || locationModeCode == 'BOTH';
  bool get usesGym => locationModeCode == 'GYM' || locationModeCode == 'BOTH';
  bool get isGymLimited => usesGym && gymProfileCode == 'LIMITED';

  OnboardingDraft copyWith({
    OnboardingStep? currentStep,
    String? nickname,
    Object? ageYears = _unset,
    Object? sexCode = _unset,
    Object? heightCm = _unset,
    Object? weightKg = _unset,
    bool? knowsBodyFat,
    Object? bodyFatPercent = _unset,
    Object? primaryGoalCode = _unset,
    Set<String>? secondaryGoalCodes,
    Object? cumulativeExperienceCode = _unset,
    Object? continuityCode = _unset,
    Object? hiatusCode = _unset,
    Object? currentFrequency = _unset,
    Object? adjustmentHabitCode = _unset,
    Object? loggingHabitCode = _unset,
    Object? locationModeCode = _unset,
    Object? bothUsageModeCode = _unset,
    Object? gymProfileCode = _unset,
    Set<String>? homeEquipmentCodes,
    Set<String>? limitedGymEquipmentCodes,
    Object? fixedDumbbells = _unset,
    Object? adjustableDumbbells = _unset,
    Object? barbellSetup = _unset,
    Object? desiredDaysPerWeek = _unset,
    Set<String>? availableWeekdayCodes,
    Map<String, String>? scheduleLocationByWeekday,
    Object? usualDurationMin = _unset,
    Object? splitPreferenceCode = _unset,
    Object? primaryPriorityCode = _unset,
    Set<String>? secondaryPriorityCodes,
    Set<String>? appearancePriorityCodes,
    Object? abGoalCode = _unset,
    Map<String, String>? painActionsByArea,
    Set<String>? avoidBodyPartCodes,
    Set<String>? avoidMovementGroupCodes,
    Set<String>? avoidExerciseCodes,
  }) {
    return OnboardingDraft(
      id: id,
      userId: userId,
      currentStep: currentStep ?? this.currentStep,
      nickname: nickname ?? this.nickname,
      ageYears: identical(ageYears, _unset) ? this.ageYears : ageYears as int?,
      sexCode: identical(sexCode, _unset) ? this.sexCode : sexCode as String?,
      heightCm:
          identical(heightCm, _unset) ? this.heightCm : heightCm as double?,
      weightKg:
          identical(weightKg, _unset) ? this.weightKg : weightKg as double?,
      knowsBodyFat: knowsBodyFat ?? this.knowsBodyFat,
      bodyFatPercent: identical(bodyFatPercent, _unset)
          ? this.bodyFatPercent
          : bodyFatPercent as double?,
      primaryGoalCode: identical(primaryGoalCode, _unset)
          ? this.primaryGoalCode
          : primaryGoalCode as String?,
      secondaryGoalCodes: secondaryGoalCodes ?? this.secondaryGoalCodes,
      cumulativeExperienceCode:
          identical(cumulativeExperienceCode, _unset)
              ? this.cumulativeExperienceCode
              : cumulativeExperienceCode as String?,
      continuityCode: identical(continuityCode, _unset)
          ? this.continuityCode
          : continuityCode as String?,
      hiatusCode: identical(hiatusCode, _unset)
          ? this.hiatusCode
          : hiatusCode as String?,
      currentFrequency: identical(currentFrequency, _unset)
          ? this.currentFrequency
          : currentFrequency as int?,
      adjustmentHabitCode: identical(adjustmentHabitCode, _unset)
          ? this.adjustmentHabitCode
          : adjustmentHabitCode as String?,
      loggingHabitCode: identical(loggingHabitCode, _unset)
          ? this.loggingHabitCode
          : loggingHabitCode as String?,
      locationModeCode: identical(locationModeCode, _unset)
          ? this.locationModeCode
          : locationModeCode as String?,
      bothUsageModeCode: identical(bothUsageModeCode, _unset)
          ? this.bothUsageModeCode
          : bothUsageModeCode as String?,
      gymProfileCode: identical(gymProfileCode, _unset)
          ? this.gymProfileCode
          : gymProfileCode as String?,
      homeEquipmentCodes: homeEquipmentCodes ?? this.homeEquipmentCodes,
      limitedGymEquipmentCodes:
          limitedGymEquipmentCodes ?? this.limitedGymEquipmentCodes,
      fixedDumbbells: identical(fixedDumbbells, _unset)
          ? this.fixedDumbbells
          : fixedDumbbells as DumbbellSetupDraft?,
      adjustableDumbbells: identical(adjustableDumbbells, _unset)
          ? this.adjustableDumbbells
          : adjustableDumbbells as DumbbellSetupDraft?,
      barbellSetup: identical(barbellSetup, _unset)
          ? this.barbellSetup
          : barbellSetup as BarbellSetupDraft?,
      desiredDaysPerWeek: identical(desiredDaysPerWeek, _unset)
          ? this.desiredDaysPerWeek
          : desiredDaysPerWeek as int?,
      availableWeekdayCodes:
          availableWeekdayCodes ?? this.availableWeekdayCodes,
      scheduleLocationByWeekday:
          scheduleLocationByWeekday ?? this.scheduleLocationByWeekday,
      usualDurationMin: identical(usualDurationMin, _unset)
          ? this.usualDurationMin
          : usualDurationMin as int?,
      splitPreferenceCode: identical(splitPreferenceCode, _unset)
          ? this.splitPreferenceCode
          : splitPreferenceCode as String?,
      primaryPriorityCode: identical(primaryPriorityCode, _unset)
          ? this.primaryPriorityCode
          : primaryPriorityCode as String?,
      secondaryPriorityCodes:
          secondaryPriorityCodes ?? this.secondaryPriorityCodes,
      appearancePriorityCodes:
          appearancePriorityCodes ?? this.appearancePriorityCodes,
      abGoalCode:
          identical(abGoalCode, _unset) ? this.abGoalCode : abGoalCode as String?,
      painActionsByArea: painActionsByArea ?? this.painActionsByArea,
      avoidBodyPartCodes: avoidBodyPartCodes ?? this.avoidBodyPartCodes,
      avoidMovementGroupCodes:
          avoidMovementGroupCodes ?? this.avoidMovementGroupCodes,
      avoidExerciseCodes: avoidExerciseCodes ?? this.avoidExerciseCodes,
    );
  }

  String? validationMessage(OnboardingStep step) {
    return switch (step) {
      OnboardingStep.intro => null,
      OnboardingStep.basicInfo => nickname.trim().isEmpty
          ? 'ニックネームを入力してください。'
          : ageYears == null
              ? '年齢を選択してください。'
              : null,
      OnboardingStep.primaryGoal => primaryGoalCode == null
          ? '一番の目的を選択してください。'
          : null,
      OnboardingStep.secondaryGoals => null,
      OnboardingStep.experienceHistory => cumulativeExperienceCode == null
          ? '累計経験期間を選択してください。'
          : continuityCode == null
              ? '現在の継続期間を選択してください。'
              : continuityCode == 'NOT_ACTIVE' && hiatusCode == null
                  ? '休止期間を選択してください。'
                  : null,
      OnboardingStep.experienceCurrent => currentFrequency == null
          ? '現在または直近の頻度を選択してください。'
          : adjustmentHabitCode == null
              ? '重量・回数の調整方法を選択してください。'
              : loggingHabitCode == null
                  ? '記録習慣を選択してください。'
                  : null,
      OnboardingStep.location => locationModeCode == null
          ? '利用場所を選択してください。'
          : locationModeCode == 'BOTH' && bothUsageModeCode == null
              ? '自宅とジムの使い分けを選択してください。'
              : usesGym && gymProfileCode == null
                  ? 'ジム設備の傾向を選択してください。'
                  : null,
      OnboardingStep.equipment => usesHome && homeEquipmentCodes.isEmpty
          ? '自宅で使用できる器具を選択してください。'
          : isGymLimited && limitedGymEquipmentCodes.isEmpty
              ? 'ジムで使用できる器具を選択してください。'
              : homeEquipmentCodes.contains('FIXED_DUMBBELL') &&
                      (fixedDumbbells == null ||
                          fixedDumbbells!.weightOptions.isEmpty)
                  ? '固定式ダンベルの重量を1つ以上登録してください。'
                  : homeEquipmentCodes.contains('ADJUSTABLE_DUMBBELL') &&
                          (adjustableDumbbells == null ||
                              adjustableDumbbells!.minWeightKg == null ||
                              adjustableDumbbells!.maxWeightKg == null ||
                              adjustableDumbbells!.incrementWeightKg == null)
                      ? '可変式ダンベルの重量範囲を登録してください。'
                      : homeEquipmentCodes.contains('ADJUSTABLE_DUMBBELL') &&
                              adjustableDumbbells!.minWeightKg! >
                                  adjustableDumbbells!.maxWeightKg!
                          ? '可変式ダンベルの最小重量と最大重量を確認してください。'
                          : homeEquipmentCodes.contains('ADJUSTABLE_DUMBBELL') &&
                                  adjustableDumbbells!.weightOptions.isEmpty
                              ? '可変式ダンベルで実際に使用できる重量を登録してください。'
                              : homeEquipmentCodes.contains('BARBELL') &&
                                      barbellSetup == null
                                  ? 'バーベルの詳細を登録してください。'
                                  : homeEquipmentCodes.contains('BARBELL') &&
                                          barbellSetup!.maxTotalWeightKg <
                                              barbellSetup!.shaftWeightKg
                                      ? 'バーベルの最大使用重量を確認してください。'
                                      : homeEquipmentCodes.contains('BARBELL') &&
                                              barbellSetup!.maxTotalWeightKg >
                                                  barbellSetup!.shaftWeightKg &&
                                              barbellSetup!.plateOptions.isEmpty
                                          ? '所有しているプレートを1つ以上登録してください。'
                                          : null,
      OnboardingStep.schedule => desiredDaysPerWeek == null
          ? '通常希望日数を選択してください。'
          : availableWeekdayCodes.isEmpty
              ? '実施しやすい曜日を1日以上選択してください。'
              : usualDurationMin == null
                  ? '通常のトレーニング時間を選択してください。'
                  : locationModeCode == 'BOTH' &&
                          bothUsageModeCode == 'BY_WEEKDAY' &&
                          availableWeekdayCodes.any(
                            (String weekday) =>
                                scheduleLocationByWeekday[weekday] == null,
                          )
                      ? '曜日ごとの利用場所を選択してください。'
                      : null,
      OnboardingStep.split => splitPreferenceCode == null
          ? 'メニューの分け方を選択してください。'
          : null,
      OnboardingStep.priorities => primaryPriorityCode == null
          ? '最優先部位を選択してください。'
          : abGoalCode == null
              ? '腹筋の目的を選択してください。'
              : null,
      OnboardingStep.restrictions => null,
      OnboardingStep.review => firstInvalidStep == null
          ? null
          : '未入力の項目があります。内容を確認してください。',
    };
  }

  OnboardingStep? get firstInvalidStep {
    for (final step in OnboardingStep.values) {
      if (step == OnboardingStep.intro || step == OnboardingStep.review) {
        continue;
      }
      if (validationMessage(step) != null) {
        return step;
      }
    }
    return null;
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'userId': userId,
        'currentStepCode': currentStep.code,
        'nickname': nickname,
        'ageYears': ageYears,
        'sexCode': sexCode,
        'heightCm': heightCm,
        'weightKg': weightKg,
        'knowsBodyFat': knowsBodyFat,
        'bodyFatPercent': bodyFatPercent,
        'primaryGoalCode': primaryGoalCode,
        'secondaryGoalCodes': secondaryGoalCodes.toList()..sort(),
        'cumulativeExperienceCode': cumulativeExperienceCode,
        'continuityCode': continuityCode,
        'hiatusCode': hiatusCode,
        'currentFrequency': currentFrequency,
        'adjustmentHabitCode': adjustmentHabitCode,
        'loggingHabitCode': loggingHabitCode,
        'locationModeCode': locationModeCode,
        'bothUsageModeCode': bothUsageModeCode,
        'gymProfileCode': gymProfileCode,
        'homeEquipmentCodes': homeEquipmentCodes.toList()..sort(),
        'limitedGymEquipmentCodes': limitedGymEquipmentCodes.toList()..sort(),
        'fixedDumbbells': fixedDumbbells?.toJson(),
        'adjustableDumbbells': adjustableDumbbells?.toJson(),
        'barbellSetup': barbellSetup?.toJson(),
        'desiredDaysPerWeek': desiredDaysPerWeek,
        'availableWeekdayCodes': availableWeekdayCodes.toList()..sort(),
        'scheduleLocationByWeekday': scheduleLocationByWeekday,
        'usualDurationMin': usualDurationMin,
        'splitPreferenceCode': splitPreferenceCode,
        'primaryPriorityCode': primaryPriorityCode,
        'secondaryPriorityCodes': secondaryPriorityCodes.toList()..sort(),
        'appearancePriorityCodes': appearancePriorityCodes.toList()..sort(),
        'abGoalCode': abGoalCode,
        'painActionsByArea': painActionsByArea,
        'avoidBodyPartCodes': avoidBodyPartCodes.toList()..sort(),
        'avoidMovementGroupCodes': avoidMovementGroupCodes.toList()..sort(),
        'avoidExerciseCodes': avoidExerciseCodes.toList()..sort(),
      };

  factory OnboardingDraft.fromJson(Map<String, Object?> json) {
    Set<String> stringSet(String key) =>
        ((json[key] as List<Object?>?) ?? const <Object?>[])
            .map((Object? value) => value! as String)
            .toSet();

    Map<String, String> _stringMap(Object? value) {
      if (value == null) {
        return const <String, String>{};
      }
      final source = value as Map<Object?, Object?>;
      return source.map(
        (Object? key, Object? item) =>
            MapEntry<String, String>(key! as String, item! as String),
      );
    }

    return OnboardingDraft(
      id: json['id']! as String,
      userId: json['userId']! as String,
      currentStep:
          onboardingStepFromCode(json['currentStepCode'] as String?),
      nickname: json['nickname'] as String? ?? '',
      ageYears: (json['ageYears'] as num?)?.toInt(),
      sexCode: json['sexCode'] as String?,
      heightCm: (json['heightCm'] as num?)?.toDouble(),
      weightKg: (json['weightKg'] as num?)?.toDouble(),
      knowsBodyFat: json['knowsBodyFat'] as bool? ?? false,
      bodyFatPercent: (json['bodyFatPercent'] as num?)?.toDouble(),
      primaryGoalCode: json['primaryGoalCode'] as String?,
      secondaryGoalCodes: stringSet('secondaryGoalCodes'),
      cumulativeExperienceCode:
          json['cumulativeExperienceCode'] as String?,
      continuityCode: json['continuityCode'] as String?,
      hiatusCode: json['hiatusCode'] as String?,
      currentFrequency: (json['currentFrequency'] as num?)?.toInt(),
      adjustmentHabitCode: json['adjustmentHabitCode'] as String?,
      loggingHabitCode: json['loggingHabitCode'] as String?,
      locationModeCode: json['locationModeCode'] as String?,
      bothUsageModeCode: json['bothUsageModeCode'] as String?,
      gymProfileCode: json['gymProfileCode'] as String?,
      homeEquipmentCodes: stringSet('homeEquipmentCodes'),
      limitedGymEquipmentCodes: stringSet('limitedGymEquipmentCodes'),
      fixedDumbbells: json['fixedDumbbells'] == null
          ? null
          : DumbbellSetupDraft.fromJson(
              Map<String, Object?>.from(
                json['fixedDumbbells']! as Map<Object?, Object?>,
              ),
            ),
      adjustableDumbbells: json['adjustableDumbbells'] == null
          ? null
          : DumbbellSetupDraft.fromJson(
              Map<String, Object?>.from(
                json['adjustableDumbbells']! as Map<Object?, Object?>,
              ),
            ),
      barbellSetup: json['barbellSetup'] == null
          ? null
          : BarbellSetupDraft.fromJson(
              Map<String, Object?>.from(
                json['barbellSetup']! as Map<Object?, Object?>,
              ),
            ),
      desiredDaysPerWeek: (json['desiredDaysPerWeek'] as num?)?.toInt(),
      availableWeekdayCodes: stringSet('availableWeekdayCodes'),
      scheduleLocationByWeekday:
          _stringMap(json['scheduleLocationByWeekday']),
      usualDurationMin: (json['usualDurationMin'] as num?)?.toInt(),
      splitPreferenceCode: json['splitPreferenceCode'] as String?,
      primaryPriorityCode: json['primaryPriorityCode'] as String?,
      secondaryPriorityCodes: stringSet('secondaryPriorityCodes'),
      appearancePriorityCodes: stringSet('appearancePriorityCodes'),
      abGoalCode: json['abGoalCode'] as String?,
      painActionsByArea: _stringMap(json['painActionsByArea']),
      avoidBodyPartCodes: stringSet('avoidBodyPartCodes'),
      avoidMovementGroupCodes: stringSet('avoidMovementGroupCodes'),
      avoidExerciseCodes: stringSet('avoidExerciseCodes'),
    );
  }
}
