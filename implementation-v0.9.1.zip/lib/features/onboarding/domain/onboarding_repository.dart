import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';

enum OnboardingStatus { notStarted, inProgress, completed }

final class ExerciseChoice {
  const ExerciseChoice({
    required this.code,
    required this.name,
  });

  final String code;
  final String name;
}

abstract interface class OnboardingRepository {
  Future<OnboardingStatus> loadStatus();

  Future<OnboardingDraft> loadOrCreateDraft();

  Future<void> saveDraft(OnboardingDraft draft);

  Future<void> resetDraft(OnboardingDraft draft);

  Future<List<ExerciseChoice>> searchExercises(String query);

  Future<void> complete(OnboardingDraft draft);
}
