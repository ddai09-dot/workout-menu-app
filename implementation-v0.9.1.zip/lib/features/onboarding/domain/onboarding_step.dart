enum OnboardingStep {
  intro,
  basicInfo,
  primaryGoal,
  secondaryGoals,
  experienceHistory,
  experienceCurrent,
  location,
  equipment,
  schedule,
  split,
  priorities,
  restrictions,
  review,
}

extension OnboardingStepX on OnboardingStep {
  String get code => switch (this) {
        OnboardingStep.intro => 'INTRO',
        OnboardingStep.basicInfo => 'BASIC_INFO',
        OnboardingStep.primaryGoal => 'PRIMARY_GOAL',
        OnboardingStep.secondaryGoals => 'SECONDARY_GOALS',
        OnboardingStep.experienceHistory => 'EXPERIENCE_HISTORY',
        OnboardingStep.experienceCurrent => 'EXPERIENCE_CURRENT',
        OnboardingStep.location => 'LOCATION',
        OnboardingStep.equipment => 'EQUIPMENT',
        OnboardingStep.schedule => 'SCHEDULE',
        OnboardingStep.split => 'SPLIT',
        OnboardingStep.priorities => 'PRIORITIES',
        OnboardingStep.restrictions => 'RESTRICTIONS',
        OnboardingStep.review => 'REVIEW',
      };

  String get title => switch (this) {
        OnboardingStep.intro => 'あなたに合うメニューを作ります',
        OnboardingStep.basicInfo => '基本情報',
        OnboardingStep.primaryGoal => '一番の目的',
        OnboardingStep.secondaryGoals => 'ほかの目的',
        OnboardingStep.experienceHistory => 'トレーニング経験',
        OnboardingStep.experienceCurrent => '現在の取り組み方',
        OnboardingStep.location => 'トレーニング環境',
        OnboardingStep.equipment => '使用できる器具',
        OnboardingStep.schedule => '通常の予定',
        OnboardingStep.split => 'メニューの分け方',
        OnboardingStep.priorities => '優先部位・見た目',
        OnboardingStep.restrictions => '痛み・身体上の制限',
        OnboardingStep.review => '登録内容の確認',
      };

  String get primaryButtonLabel => switch (this) {
        OnboardingStep.intro => '登録を始める',
        OnboardingStep.review => 'この内容で登録する',
        _ => '次へ',
      };

  bool get showsProgress => this != OnboardingStep.intro;

  int get progressIndex => index;

  double get progressValue {
    if (!showsProgress) {
      return 0;
    }
    return index / (OnboardingStep.values.length - 1);
  }

  OnboardingStep? get previous {
    if (this == OnboardingStep.intro) {
      return null;
    }
    return OnboardingStep.values[index - 1];
  }

  OnboardingStep? get next {
    if (this == OnboardingStep.review) {
      return null;
    }
    return OnboardingStep.values[index + 1];
  }

}

OnboardingStep onboardingStepFromCode(String? code) {
  return OnboardingStep.values.firstWhere(
    (OnboardingStep value) => value.code == code,
    orElse: () => OnboardingStep.intro,
  );
}
