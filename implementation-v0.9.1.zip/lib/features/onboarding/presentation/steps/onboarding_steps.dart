import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_option.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_repository.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_step.dart';
import 'package:workout_menu_app/features/onboarding/presentation/onboarding_notifier.dart';
import 'package:workout_menu_app/features/onboarding/presentation/widgets/choice_card.dart';
import 'package:workout_menu_app/features/onboarding/presentation/widgets/onboarding_section.dart';
import 'package:workout_menu_app/features/onboarding/presentation/widgets/picker_field.dart';

Set<String> _toggleSet(
  Set<String> current,
  String code, {
  String? exclusiveCode,
}) {
  final next = <String>{...current};
  if (exclusiveCode != null && code == exclusiveCode) {
    return next.contains(code) ? <String>{} : <String>{code};
  }
  next.remove(exclusiveCode);
  if (!next.add(code)) {
    next.remove(code);
  }
  return next;
}

String _labelFor(List<OnboardingOption> options, String? code) {
  if (code == null) {
    return '未選択';
  }
  for (final option in options) {
    if (option.code == code) {
      return option.label;
    }
  }
  return code;
}

final class IntroStep extends StatelessWidget {
  const IntroStep({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        const Icon(Icons.fitness_center, size: 72),
        const SizedBox(height: 24),
        Text(
          '目的、経験、使用できる器具、生活予定に合わせて、無理なく続けられるメニューを提案します。',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 24),
        const _IntroPoint(
          icon: Icons.tune,
          title: '回答は後から変更できます',
          description: '登録内容は種目、セット数、回数、頻度、強度の調整に使います。',
        ),
        const SizedBox(height: 12),
        const _IntroPoint(
          icon: Icons.save_outlined,
          title: '途中で閉じても続きから再開できます',
          description: '質問ごとに端末へ自動保存します。',
        ),
        const SizedBox(height: 12),
        const _IntroPoint(
          icon: Icons.health_and_safety_outlined,
          title: '痛みや身体上の制限を優先します',
          description: '強い痛みや悪化がある場合は運動を中止し、専門家へ相談してください。',
        ),
      ],
    );
  }
}

final class _IntroPoint extends StatelessWidget {
  const _IntroPoint({
    required this.icon,
    required this.title,
    required this.description,
  });

  final IconData icon;
  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Icon(icon),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(title, style: Theme.of(context).textTheme.titleSmall),
                  const SizedBox(height: 4),
                  Text(description),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final class BasicInfoStep extends StatelessWidget {
  const BasicInfoStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    final heights = <double>[
      for (var value = 100; value <= 220; value++) value.toDouble(),
    ];
    final weights = <double>[
      for (var value = 60; value <= 400; value++) value / 2,
    ];
    final bodyFat = <double>[
      for (var value = 6; value <= 120; value++) value / 2,
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        TextFormField(
          key: ValueKey<String>('nickname-${draft.id}'),
          initialValue: draft.nickname,
          maxLength: 30,
          textInputAction: TextInputAction.done,
          decoration: const InputDecoration(
            labelText: 'ニックネーム（必須）',
            hintText: '例：だいすけ',
            border: OutlineInputBorder(),
          ),
          onChanged: (String value) {
            onChanged(draft.copyWith(nickname: value));
          },
        ),
        const SizedBox(height: 16),
        PickerField<int>(
          label: '年齢（必須）',
          value: draft.ageYears,
          values: <int>[for (var value = 13; value <= 100; value++) value],
          formatValue: (int value) => '$value歳',
          onChanged: (int value) => onChanged(draft.copyWith(ageYears: value)),
        ),
        const SizedBox(height: 24),
        OnboardingSection(
          title: '性別（任意）',
          description: '優先部位や見た目の希望の判定には使用しません。',
          child: Column(
            children: OnboardingOptions.sex
                .map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected: draft.sexCode == option.code,
                      onTap: () => onChanged(
                        draft.copyWith(sexCode: option.code),
                      ),
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
        const SizedBox(height: 24),
        PickerField<double>(
          label: '身長（任意）',
          value: draft.heightCm,
          values: heights,
          formatValue: (double value) => '${value.toStringAsFixed(0)}cm',
          onChanged: (double value) => onChanged(draft.copyWith(heightCm: value)),
        ),
        const SizedBox(height: 16),
        PickerField<double>(
          label: '体重（任意）',
          value: draft.weightKg,
          values: weights,
          formatValue: (double value) => '${value.toStringAsFixed(1)}kg',
          onChanged: (double value) => onChanged(draft.copyWith(weightKg: value)),
        ),
        const SizedBox(height: 16),
        Card(
          child: SwitchListTile(
            title: const Text('体脂肪率が分かる'),
            value: draft.knowsBodyFat,
            onChanged: (bool value) {
              onChanged(
                draft.copyWith(
                  knowsBodyFat: value,
                  bodyFatPercent: value ? draft.bodyFatPercent : null,
                ),
              );
            },
          ),
        ),
        if (draft.knowsBodyFat) ...<Widget>[
          const SizedBox(height: 16),
          PickerField<double>(
            label: '体脂肪率（任意）',
            value: draft.bodyFatPercent,
            values: bodyFat,
            formatValue: (double value) => '${value.toStringAsFixed(1)}%',
            onChanged: (double value) =>
                onChanged(draft.copyWith(bodyFatPercent: value)),
          ),
        ],
      ],
    );
  }
}

final class PrimaryGoalStep extends StatelessWidget {
  const PrimaryGoalStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: OnboardingOptions.goals
          .map(
            (OnboardingOption option) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: ChoiceCard(
                label: option.label,
                selected: draft.primaryGoalCode == option.code,
                onTap: () {
                  final secondary = <String>{...draft.secondaryGoalCodes}
                    ..remove(option.code);
                  onChanged(
                    draft.copyWith(
                      primaryGoalCode: option.code,
                      secondaryGoalCodes: secondary,
                    ),
                  );
                },
              ),
            ),
          )
          .toList(growable: false),
    );
  }
}

final class SecondaryGoalsStep extends StatelessWidget {
  const SecondaryGoalsStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    final options = OnboardingOptions.goals
        .where((OnboardingOption option) => option.code != draft.primaryGoalCode)
        .toList(growable: false);
    return Column(
      children: <Widget>[
        ...options.map(
          (OnboardingOption option) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: ChoiceCard(
              label: option.label,
              selected: draft.secondaryGoalCodes.contains(option.code),
              multiple: true,
              onTap: () => onChanged(
                draft.copyWith(
                  secondaryGoalCodes: _toggleSet(
                    draft.secondaryGoalCodes,
                    option.code,
                    exclusiveCode: 'NONE',
                  ),
                ),
              ),
            ),
          ),
        ),
        ChoiceCard(
          label: '特になし',
          selected: draft.secondaryGoalCodes.contains('NONE') ||
              draft.secondaryGoalCodes.isEmpty,
          multiple: true,
          onTap: () => onChanged(
            draft.copyWith(secondaryGoalCodes: const <String>{'NONE'}),
          ),
        ),
      ],
    );
  }
}

final class ExperienceHistoryStep extends StatelessWidget {
  const ExperienceHistoryStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        OnboardingSection(
          title: '累計経験期間',
          child: Column(
            children: OnboardingOptions.cumulativeExperience
                .map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected: draft.cumulativeExperienceCode == option.code,
                      onTap: () => onChanged(
                        draft.copyWith(cumulativeExperienceCode: option.code),
                      ),
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
        const SizedBox(height: 24),
        OnboardingSection(
          title: '現在の継続期間',
          child: Column(
            children: OnboardingOptions.continuity
                .map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected: draft.continuityCode == option.code,
                      onTap: () => onChanged(
                        draft.copyWith(
                          continuityCode: option.code,
                          hiatusCode:
                              option.code == 'NOT_ACTIVE' ? draft.hiatusCode : null,
                        ),
                      ),
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
        if (draft.continuityCode == 'NOT_ACTIVE') ...<Widget>[
          const SizedBox(height: 24),
          OnboardingSection(
            title: '休止期間',
            child: Column(
              children: OnboardingOptions.hiatus
                  .map(
                    (OnboardingOption option) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: ChoiceCard(
                        label: option.label,
                        selected: draft.hiatusCode == option.code,
                        onTap: () => onChanged(
                          draft.copyWith(hiatusCode: option.code),
                        ),
                      ),
                    ),
                  )
                  .toList(growable: false),
            ),
          ),
        ],
      ],
    );
  }
}

final class ExperienceCurrentStep extends StatelessWidget {
  const ExperienceCurrentStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        PickerField<int>(
          label: '現在または直近の週頻度',
          value: draft.currentFrequency,
          values: <int>[for (var value = 0; value <= 7; value++) value],
          formatValue: (int value) => '週$value日',
          onChanged: (int value) =>
              onChanged(draft.copyWith(currentFrequency: value)),
        ),
        const SizedBox(height: 24),
        OnboardingSection(
          title: '重量・回数の調整',
          child: Column(
            children: OnboardingOptions.adjustmentHabits
                .map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected: draft.adjustmentHabitCode == option.code,
                      onTap: () => onChanged(
                        draft.copyWith(adjustmentHabitCode: option.code),
                      ),
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
        const SizedBox(height: 24),
        OnboardingSection(
          title: '記録習慣',
          child: Column(
            children: OnboardingOptions.loggingHabits
                .map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected: draft.loggingHabitCode == option.code,
                      onTap: () => onChanged(
                        draft.copyWith(loggingHabitCode: option.code),
                      ),
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          '経験レベルは回答から判定します。長い休止がある場合は経験を保持したまま、復帰用の低いボリュームから始めます。',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}

final class LocationStep extends StatelessWidget {
  const LocationStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        OnboardingSection(
          title: '主にどこで行いますか？',
          child: Column(
            children: OnboardingOptions.locationModes
                .map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected: draft.locationModeCode == option.code,
                      onTap: () => onChanged(
                        draft.copyWith(
                          locationModeCode: option.code,
                          bothUsageModeCode:
                              option.code == 'BOTH' ? draft.bothUsageModeCode : null,
                          gymProfileCode: option.code == 'HOME'
                              ? null
                              : draft.gymProfileCode,
                        ),
                      ),
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
        if (draft.locationModeCode == 'BOTH') ...<Widget>[
          const SizedBox(height: 24),
          OnboardingSection(
            title: '自宅とジムの使い分け',
            child: Column(
              children: OnboardingOptions.bothUsageModes
                  .map(
                    (OnboardingOption option) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: ChoiceCard(
                        label: option.label,
                        selected: draft.bothUsageModeCode == option.code,
                        onTap: () => onChanged(
                          draft.copyWith(bothUsageModeCode: option.code),
                        ),
                      ),
                    ),
                  )
                  .toList(growable: false),
            ),
          ),
        ],
        if (draft.usesGym) ...<Widget>[
          const SizedBox(height: 24),
          OnboardingSection(
            title: 'ジム設備の傾向',
            child: Column(
              children: OnboardingOptions.gymProfiles
                  .map(
                    (OnboardingOption option) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: ChoiceCard(
                        label: option.label,
                        selected: draft.gymProfileCode == option.code,
                        onTap: () => onChanged(
                          draft.copyWith(
                            gymProfileCode: option.code,
                            limitedGymEquipmentCodes: option.code == 'LIMITED'
                                ? draft.limitedGymEquipmentCodes
                                : const <String>{},
                          ),
                        ),
                      ),
                    ),
                  )
                  .toList(growable: false),
            ),
          ),
        ],
      ],
    );
  }
}

final class EquipmentStep extends StatefulWidget {
  const EquipmentStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  State<EquipmentStep> createState() => _EquipmentStepState();
}

final class _EquipmentStepState extends State<EquipmentStep> {
  OnboardingDraft get draft => widget.draft;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (draft.usesHome)
          OnboardingSection(
            title: '自宅で使用できる器具',
            child: Column(
              children: OnboardingOptions.homeEquipment
                  .map(
                    (OnboardingOption option) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: ChoiceCard(
                        label: option.label,
                        selected: draft.homeEquipmentCodes.contains(option.code),
                        multiple: true,
                        onTap: () => _toggleHomeEquipment(option.code),
                      ),
                    ),
                  )
                  .toList(growable: false),
            ),
          ),
        if (draft.homeEquipmentCodes.contains('FIXED_DUMBBELL')) ...<Widget>[
          const SizedBox(height: 24),
          _fixedDumbbellDetails(context),
        ],
        if (draft.homeEquipmentCodes.contains('ADJUSTABLE_DUMBBELL')) ...<Widget>[
          const SizedBox(height: 24),
          _adjustableDumbbellDetails(context),
        ],
        if (draft.homeEquipmentCodes.contains('BARBELL')) ...<Widget>[
          const SizedBox(height: 24),
          _barbellDetails(),
        ],
        if (draft.isGymLimited) ...<Widget>[
          if (draft.usesHome) const SizedBox(height: 32),
          OnboardingSection(
            title: 'ジムで使用できる器具',
            description: '設備が限られている場合だけ選択します。',
            child: Column(
              children: OnboardingOptions.limitedGymEquipment
                  .map(
                    (OnboardingOption option) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: ChoiceCard(
                        label: option.label,
                        selected:
                            draft.limitedGymEquipmentCodes.contains(option.code),
                        multiple: true,
                        onTap: () => widget.onChanged(
                          draft.copyWith(
                            limitedGymEquipmentCodes: _toggleSet(
                              draft.limitedGymEquipmentCodes,
                              option.code,
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                  .toList(growable: false),
            ),
          ),
        ],
        if (!draft.usesHome && !draft.isGymLimited)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('選択したジム設備の傾向を使って、利用可能な種目を判定します。'),
            ),
          ),
      ],
    );
  }

  void _toggleHomeEquipment(String code) {
    final selected = _toggleSet(
      draft.homeEquipmentCodes,
      code,
      exclusiveCode: 'NONE',
    );
    var next = draft.copyWith(homeEquipmentCodes: selected);
    if (selected.contains('FIXED_DUMBBELL') && next.fixedDumbbells == null) {
      next = next.copyWith(
        fixedDumbbells: const DumbbellSetupDraft(setupTypeCode: 'FIXED'),
      );
    }
    if (selected.contains('ADJUSTABLE_DUMBBELL') &&
        next.adjustableDumbbells == null) {
      next = next.copyWith(
        adjustableDumbbells: const DumbbellSetupDraft(
          setupTypeCode: 'ADJUSTABLE',
          unitCount: 1,
          minWeightKg: 2,
          maxWeightKg: 24,
          incrementWeightKg: 2,
        ),
      );
    }
    if (selected.contains('BARBELL') && next.barbellSetup == null) {
      next = next.copyWith(barbellSetup: const BarbellSetupDraft());
    }
    widget.onChanged(next);
  }

  Widget _fixedDumbbellDetails(BuildContext context) {
    final setup = draft.fixedDumbbells ??
        const DumbbellSetupDraft(setupTypeCode: 'FIXED');
    return OnboardingSection(
      title: '固定式ダンベルの詳細',
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              if (setup.weightOptions.isEmpty)
                const Text('使用できる重量を追加してください。')
              else
                ...setup.weightOptions.map(
                  (WeightOptionDraft option) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text('${option.weightKg.toStringAsFixed(1)}kg'),
                    subtitle: Text('${option.quantity}個'),
                    trailing: IconButton(
                      tooltip: '削除',
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        final nextOptions = <WeightOptionDraft>[
                          ...setup.weightOptions,
                        ]..remove(option);
                        widget.onChanged(
                          draft.copyWith(
                            fixedDumbbells:
                                setup.copyWith(weightOptions: nextOptions),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              OutlinedButton.icon(
                onPressed: () =>
                    unawaited(_addFixedWeight(context, setup)),
                icon: const Icon(Icons.add),
                label: const Text('重量を追加する'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _addFixedWeight(
    BuildContext context,
    DumbbellSetupDraft setup,
  ) async {
    final weights = <double>[
      for (var value = 2; value <= 100; value++) value / 2,
    ];
    var weightIndex = 8;
    var quantity = 2;
    final result = await showModalBottomSheet<WeightOptionDraft>(
      context: context,
      useSafeArea: true,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text('固定式ダンベルを追加',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 180,
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: CupertinoPicker.builder(
                            itemExtent: 42,
                            childCount: weights.length,
                            scrollController: FixedExtentScrollController(
                              initialItem: weightIndex,
                            ),
                            onSelectedItemChanged: (int index) {
                              setModalState(() => weightIndex = index);
                            },
                            itemBuilder: (BuildContext context, int index) {
                              return Center(
                                child: Text('${weights[index].toStringAsFixed(1)}kg'),
                              );
                            },
                          ),
                        ),
                        Expanded(
                          child: CupertinoPicker(
                            itemExtent: 42,
                            scrollController:
                                FixedExtentScrollController(initialItem: 1),
                            onSelectedItemChanged: (int index) {
                              setModalState(() => quantity = index + 1);
                            },
                            children: <Widget>[
                              for (var value = 1; value <= 4; value++)
                                Center(child: Text('$value個')),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  FilledButton(
                    onPressed: () => Navigator.of(context).pop(
                      WeightOptionDraft(
                        weightKg: weights[weightIndex],
                        quantity: quantity,
                      ),
                    ),
                    child: const Text('追加する'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
    if (result == null) {
      return;
    }
    final options = <WeightOptionDraft>[
      ...setup.weightOptions.where(
        (WeightOptionDraft value) => value.weightKg != result.weightKg,
      ),
      result,
    ]..sort((WeightOptionDraft a, WeightOptionDraft b) =>
        a.weightKg.compareTo(b.weightKg));
    widget.onChanged(
      draft.copyWith(
        fixedDumbbells: setup.copyWith(weightOptions: options),
      ),
    );
  }

  Widget _adjustableDumbbellDetails(BuildContext context) {
    final setup = draft.adjustableDumbbells!;
    final weights = <double>[
      for (var value = 2; value <= 120; value++) value / 2,
    ];
    return OnboardingSection(
      title: '可変式ダンベルの詳細',
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              PickerField<double>(
                label: '最小重量',
                value: setup.minWeightKg,
                values: weights,
                formatValue: (double value) => '${value.toStringAsFixed(1)}kg',
                onChanged: (double value) => widget.onChanged(
                  draft.copyWith(
                    adjustableDumbbells: setup.copyWith(minWeightKg: value),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              PickerField<double>(
                label: '最大重量',
                value: setup.maxWeightKg,
                values: weights,
                formatValue: (double value) => '${value.toStringAsFixed(1)}kg',
                onChanged: (double value) => widget.onChanged(
                  draft.copyWith(
                    adjustableDumbbells: setup.copyWith(maxWeightKg: value),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              PickerField<double>(
                label: '重量の刻み',
                value: setup.incrementWeightKg,
                values: const <double>[0.5, 1, 1.5, 2, 2.5, 4, 5],
                formatValue: (double value) => '${value.toStringAsFixed(1)}kg',
                onChanged: (double value) => widget.onChanged(
                  draft.copyWith(
                    adjustableDumbbells:
                        setup.copyWith(incrementWeightKg: value),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              PickerField<int>(
                label: '個数',
                value: setup.unitCount,
                values: const <int>[1, 2, 3, 4],
                formatValue: (int value) => '$value個',
                onChanged: (int value) {
                  final options = setup.weightOptions
                      .map(
                        (WeightOptionDraft option) => WeightOptionDraft(
                          weightKg: option.weightKg,
                          quantity: value,
                        ),
                      )
                      .toList(growable: false);
                  widget.onChanged(
                    draft.copyWith(
                      adjustableDumbbells: setup.copyWith(
                        unitCount: value,
                        weightOptions: options,
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 20),
              Text(
                '実際に使用できる重量',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              const SizedBox(height: 8),
              if (setup.weightOptions.isEmpty)
                const Text('重量範囲から自動作成するか、個別に追加してください。')
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: setup.weightOptions
                      .map(
                        (WeightOptionDraft option) => InputChip(
                          label: Text('${option.weightKg.toStringAsFixed(1)}kg'),
                          onDeleted: () {
                            final options = <WeightOptionDraft>[
                              ...setup.weightOptions,
                            ]..remove(option);
                            widget.onChanged(
                              draft.copyWith(
                                adjustableDumbbells:
                                    setup.copyWith(weightOptions: options),
                              ),
                            );
                          },
                        ),
                      )
                      .toList(growable: false),
                ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => _generateAdjustableWeights(setup),
                icon: const Icon(Icons.auto_fix_high),
                label: const Text('最小〜最大の重量を自動作成'),
              ),
              OutlinedButton.icon(
                onPressed: () =>
                    unawaited(_addAdjustableWeight(context, setup)),
                icon: const Icon(Icons.add),
                label: const Text('使用できる重量を追加'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _generateAdjustableWeights(DumbbellSetupDraft setup) {
    final minWeight = setup.minWeightKg;
    final maxWeight = setup.maxWeightKg;
    final increment = setup.incrementWeightKg;
    if (minWeight == null ||
        maxWeight == null ||
        increment == null ||
        increment <= 0 ||
        minWeight > maxWeight) {
      return;
    }

    final generated = <WeightOptionDraft>[];
    for (var index = 0; index < 200; index++) {
      final rawWeight = minWeight + (increment * index);
      if (rawWeight > maxWeight + 0.0001) {
        break;
      }
      final roundedWeight = (rawWeight * 100).round() / 100;
      generated.add(
        WeightOptionDraft(
          weightKg: roundedWeight,
          quantity: setup.unitCount,
        ),
      );
    }
    if (generated.isEmpty ||
        (generated.last.weightKg - maxWeight).abs() > 0.0001) {
      generated.add(
        WeightOptionDraft(
          weightKg: maxWeight,
          quantity: setup.unitCount,
        ),
      );
    }
    final byWeight = <double, WeightOptionDraft>{
      for (final option in generated) option.weightKg: option,
    };
    final options = byWeight.values.toList()
      ..sort(
        (WeightOptionDraft a, WeightOptionDraft b) =>
            a.weightKg.compareTo(b.weightKg),
      );
    widget.onChanged(
      draft.copyWith(
        adjustableDumbbells: setup.copyWith(weightOptions: options),
      ),
    );
  }

  Future<void> _addAdjustableWeight(
    BuildContext context,
    DumbbellSetupDraft setup,
  ) async {
    final weight = await _pickWeight(
      context,
      title: '使用できる重量を追加',
      values: <double>[
        for (var value = 2; value <= 120; value++) value / 2,
      ],
    );
    if (weight == null) {
      return;
    }
    final options = <WeightOptionDraft>[
      ...setup.weightOptions.where(
        (WeightOptionDraft option) => option.weightKg != weight,
      ),
      WeightOptionDraft(weightKg: weight, quantity: setup.unitCount),
    ]..sort(
        (WeightOptionDraft a, WeightOptionDraft b) =>
            a.weightKg.compareTo(b.weightKg),
      );
    widget.onChanged(
      draft.copyWith(
        adjustableDumbbells: setup.copyWith(weightOptions: options),
      ),
    );
  }

  Future<double?> _pickWeight(
    BuildContext context, {
    required String title,
    required List<double> values,
  }) async {
    var selectedIndex = 0;
    return showModalBottomSheet<double>(
      context: context,
      useSafeArea: true,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(title, style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 180,
                    child: CupertinoPicker.builder(
                      itemExtent: 42,
                      childCount: values.length,
                      onSelectedItemChanged: (int index) {
                        setModalState(() => selectedIndex = index);
                      },
                      itemBuilder: (BuildContext context, int index) {
                        return Center(
                          child: Text('${values[index].toStringAsFixed(2)}kg'),
                        );
                      },
                    ),
                  ),
                  FilledButton(
                    onPressed: () =>
                        Navigator.of(context).pop(values[selectedIndex]),
                    child: const Text('追加する'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _barbellDetails() {
    final setup = draft.barbellSetup!;
    final weights = <double>[
      for (var value = 10; value <= 400; value += 5) value.toDouble(),
    ];
    return OnboardingSection(
      title: 'バーベルの詳細',
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              PickerField<double>(
                label: 'シャフト重量',
                value: setup.shaftWeightKg,
                values: const <double>[5, 7.5, 10, 15, 20],
                formatValue: (double value) => '${value.toStringAsFixed(1)}kg',
                onChanged: (double value) => widget.onChanged(
                  draft.copyWith(
                    barbellSetup: setup.copyWith(shaftWeightKg: value),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              PickerField<double>(
                label: '最大使用重量',
                value: setup.maxTotalWeightKg,
                values: weights,
                formatValue: (double value) => '${value.toStringAsFixed(0)}kg',
                onChanged: (double value) => widget.onChanged(
                  draft.copyWith(
                    barbellSetup: setup.copyWith(maxTotalWeightKg: value),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              PickerField<double>(
                label: '最小増加単位',
                value: setup.minIncrementKg,
                values: const <double>[0.5, 1, 1.25, 2, 2.5, 5],
                formatValue: (double value) => '${value.toStringAsFixed(2)}kg',
                onChanged: (double value) => widget.onChanged(
                  draft.copyWith(
                    barbellSetup: setup.copyWith(minIncrementKg: value),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                '所有プレート',
                style: Theme.of(context).textTheme.titleSmall,
              ),
              const SizedBox(height: 8),
              if (setup.plateOptions.isEmpty)
                const Text('シャフト以外の重量を使う場合は、プレート重量と枚数を追加してください。')
              else
                ...setup.plateOptions.map(
                  (WeightOptionDraft option) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text('${option.weightKg.toStringAsFixed(2)}kg'),
                    subtitle: Text('${option.quantity}枚'),
                    trailing: IconButton(
                      tooltip: '削除',
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        final options = <WeightOptionDraft>[
                          ...setup.plateOptions,
                        ]..remove(option);
                        widget.onChanged(
                          draft.copyWith(
                            barbellSetup:
                                setup.copyWith(plateOptions: options),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              OutlinedButton.icon(
                onPressed: () => unawaited(_addPlate(context, setup)),
                icon: const Icon(Icons.add),
                label: const Text('プレートを追加'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('ラックがある'),
                value: setup.hasRack,
                onChanged: (bool value) => widget.onChanged(
                  draft.copyWith(
                    barbellSetup: setup.copyWith(hasRack: value),
                  ),
                ),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('セーフティがある'),
                value: setup.hasSafety,
                onChanged: (bool value) => widget.onChanged(
                  draft.copyWith(
                    barbellSetup: setup.copyWith(hasSafety: value),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _addPlate(
    BuildContext context,
    BarbellSetupDraft setup,
  ) async {
    const plateWeights = <double>[
      0.25,
      0.5,
      1,
      1.25,
      2,
      2.5,
      5,
      7.5,
      10,
      15,
      20,
      25,
    ];
    var weightIndex = 5;
    var quantity = 2;
    final result = await showModalBottomSheet<WeightOptionDraft>(
      context: context,
      useSafeArea: true,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(
                    '所有プレートを追加',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 180,
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: CupertinoPicker.builder(
                            itemExtent: 42,
                            childCount: plateWeights.length,
                            scrollController: FixedExtentScrollController(
                              initialItem: weightIndex,
                            ),
                            onSelectedItemChanged: (int index) {
                              setModalState(() => weightIndex = index);
                            },
                            itemBuilder: (BuildContext context, int index) {
                              return Center(
                                child: Text(
                                  '${plateWeights[index].toStringAsFixed(2)}kg',
                                ),
                              );
                            },
                          ),
                        ),
                        Expanded(
                          child: CupertinoPicker(
                            itemExtent: 42,
                            scrollController:
                                FixedExtentScrollController(initialItem: 1),
                            onSelectedItemChanged: (int index) {
                              setModalState(() => quantity = index + 1);
                            },
                            children: <Widget>[
                              for (var value = 1; value <= 12; value++)
                                Center(child: Text('$value枚')),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  FilledButton(
                    onPressed: () => Navigator.of(context).pop(
                      WeightOptionDraft(
                        weightKg: plateWeights[weightIndex],
                        quantity: quantity,
                      ),
                    ),
                    child: const Text('追加する'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
    if (result == null) {
      return;
    }
    final options = <WeightOptionDraft>[
      ...setup.plateOptions.where(
        (WeightOptionDraft option) => option.weightKg != result.weightKg,
      ),
      result,
    ]..sort(
        (WeightOptionDraft a, WeightOptionDraft b) =>
            a.weightKg.compareTo(b.weightKg),
      );
    widget.onChanged(
      draft.copyWith(
        barbellSetup: setup.copyWith(plateOptions: options),
      ),
    );
  }

}

final class ScheduleStep extends StatelessWidget {
  const ScheduleStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  static const weekdays = <String, String>{
    'MON': '月曜日',
    'TUE': '火曜日',
    'WED': '水曜日',
    'THU': '木曜日',
    'FRI': '金曜日',
    'SAT': '土曜日',
    'SUN': '日曜日',
  };

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        PickerField<int>(
          label: '通常希望日数',
          value: draft.desiredDaysPerWeek,
          values: const <int>[1, 2, 3, 4, 5, 6, 7],
          formatValue: (int value) => '週$value日',
          onChanged: (int value) =>
              onChanged(draft.copyWith(desiredDaysPerWeek: value)),
        ),
        const SizedBox(height: 24),
        OnboardingSection(
          title: '通常実施しやすい曜日',
          child: Column(
            children: weekdays.entries
                .map(
                  (MapEntry<String, String> entry) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: entry.value,
                      selected:
                          draft.availableWeekdayCodes.contains(entry.key),
                      multiple: true,
                      onTap: () {
                        final days = _toggleSet(
                          draft.availableWeekdayCodes,
                          entry.key,
                        );
                        final locations = <String, String>{
                          ...draft.scheduleLocationByWeekday,
                        };
                        if (!days.contains(entry.key)) {
                          locations.remove(entry.key);
                        }
                        onChanged(
                          draft.copyWith(
                            availableWeekdayCodes: days,
                            scheduleLocationByWeekday: locations,
                          ),
                        );
                      },
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
        if (draft.locationModeCode == 'BOTH' &&
            draft.bothUsageModeCode == 'BY_WEEKDAY' &&
            draft.availableWeekdayCodes.isNotEmpty) ...<Widget>[
          const SizedBox(height: 24),
          OnboardingSection(
            title: '曜日ごとの利用場所',
            description: '自宅とジムを曜日で使い分ける場合の通常設定です。',
            child: Column(
              children: weekdays.entries
                  .where(
                    (MapEntry<String, String> entry) =>
                        draft.availableWeekdayCodes.contains(entry.key),
                  )
                  .map(
                    (MapEntry<String, String> entry) => Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          children: <Widget>[
                            Expanded(child: Text(entry.value)),
                            DropdownButton<String>(
                              value:
                                  draft.scheduleLocationByWeekday[entry.key],
                              hint: const Text('場所を選択'),
                              underline: const SizedBox.shrink(),
                              items: const <DropdownMenuItem<String>>[
                                DropdownMenuItem<String>(
                                  value: 'HOME',
                                  child: Text('自宅'),
                                ),
                                DropdownMenuItem<String>(
                                  value: 'GYM',
                                  child: Text('ジム'),
                                ),
                              ],
                              onChanged: (String? value) {
                                if (value == null) {
                                  return;
                                }
                                final locations = <String, String>{
                                  ...draft.scheduleLocationByWeekday,
                                  entry.key: value,
                                };
                                onChanged(
                                  draft.copyWith(
                                    scheduleLocationByWeekday: locations,
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                  .toList(growable: false),
            ),
          ),
        ],
        const SizedBox(height: 24),
        PickerField<int>(
          label: '通常の1回時間',
          value: draft.usualDurationMin,
          values: const <int>[15, 30, 45, 60, 90, 120],
          formatValue: (int value) => value == 120 ? '90分以上' : '$value分',
          onChanged: (int value) =>
              onChanged(draft.copyWith(usualDurationMin: value)),
        ),
        if (draft.desiredDaysPerWeek != null &&
            draft.availableWeekdayCodes.isNotEmpty &&
            draft.desiredDaysPerWeek! > draft.availableWeekdayCodes.length) ...<Widget>[
          const SizedBox(height: 12),
          Text(
            '希望日数より実施しやすい曜日が少ないため、メニュー作成時は実施可能な曜日数を優先します。',
            style: TextStyle(color: Theme.of(context).colorScheme.primary),
          ),
        ],
      ],
    );
  }
}

final class SplitStep extends StatelessWidget {
  const SplitStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        ...OnboardingOptions.splitPreferences.map(
          (OnboardingOption option) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: ChoiceCard(
              label: option.label,
              description: option.description,
              selected: draft.splitPreferenceCode == option.code,
              onTap: () => onChanged(
                draft.copyWith(splitPreferenceCode: option.code),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          '希望は優先しますが、痛み、実施可能日数、回復、全身バランスに合わない場合は理由付きで別案を示します。',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}

final class PrioritiesStep extends StatelessWidget {
  const PrioritiesStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    final secondaryOptions = OnboardingOptions.priorityParts
        .where((OnboardingOption option) =>
            option.code != draft.primaryPriorityCode &&
            option.code != 'BALANCED')
        .toList(growable: false);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        OnboardingSection(
          title: '最優先部位',
          child: Column(
            children: OnboardingOptions.priorityParts
                .map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected: draft.primaryPriorityCode == option.code,
                      onTap: () {
                        final secondary = <String>{
                          ...draft.secondaryPriorityCodes,
                        }..remove(option.code);
                        onChanged(
                          draft.copyWith(
                            primaryPriorityCode: option.code,
                            secondaryPriorityCodes:
                                option.code == 'BALANCED'
                                    ? const <String>{'NONE'}
                                    : secondary,
                          ),
                        );
                      },
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
        if (draft.primaryPriorityCode != 'BALANCED') ...<Widget>[
          const SizedBox(height: 24),
          OnboardingSection(
            title: '副優先部位',
            child: Column(
              children: <Widget>[
                ...secondaryOptions.map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected:
                          draft.secondaryPriorityCodes.contains(option.code),
                      multiple: true,
                      onTap: () => onChanged(
                        draft.copyWith(
                          secondaryPriorityCodes: _toggleSet(
                            draft.secondaryPriorityCodes,
                            option.code,
                            exclusiveCode: 'NONE',
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                ChoiceCard(
                  label: '特になし',
                  selected: draft.secondaryPriorityCodes.contains('NONE') ||
                      draft.secondaryPriorityCodes.isEmpty,
                  multiple: true,
                  onTap: () => onChanged(
                    draft.copyWith(
                      secondaryPriorityCodes: const <String>{'NONE'},
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 24),
        OnboardingSection(
          title: '見た目として変えたい部分',
          child: Column(
            children: <Widget>[
              ...OnboardingOptions.appearancePriorities.map(
                (OnboardingOption option) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: ChoiceCard(
                    label: option.label,
                    selected:
                        draft.appearancePriorityCodes.contains(option.code),
                    multiple: true,
                    onTap: () => onChanged(
                      draft.copyWith(
                        appearancePriorityCodes: _toggleSet(
                          draft.appearancePriorityCodes,
                          option.code,
                          exclusiveCode: 'NONE',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              ChoiceCard(
                label: '特にない',
                selected: draft.appearancePriorityCodes.contains('NONE') ||
                    draft.appearancePriorityCodes.isEmpty,
                multiple: true,
                onTap: () => onChanged(
                  draft.copyWith(
                    appearancePriorityCodes: const <String>{'NONE'},
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        OnboardingSection(
          title: '腹筋の目的',
          description: '腹筋運動と腹部脂肪の減少は別です。部分痩せを前提にしません。',
          child: Column(
            children: OnboardingOptions.abGoals
                .map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected: draft.abGoalCode == option.code,
                      onTap: () =>
                          onChanged(draft.copyWith(abGoalCode: option.code)),
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
      ],
    );
  }
}

final class RestrictionsStep extends ConsumerStatefulWidget {
  const RestrictionsStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  ConsumerState<RestrictionsStep> createState() => _RestrictionsStepState();
}

final class _RestrictionsStepState extends ConsumerState<RestrictionsStep> {
  String _query = '';

  OnboardingDraft get draft => widget.draft;

  @override
  Widget build(BuildContext context) {
    final exercises = ref.watch(onboardingExerciseChoicesProvider(_query));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text(
          '強い痛み、急な痛み、悪化がある場合はトレーニングを中止してください。医療専門家からの制限がある場合は、その指示を優先します。',
          style: TextStyle(color: Theme.of(context).colorScheme.error),
        ),
        const SizedBox(height: 24),
        OnboardingSection(
          title: '現在、痛みや違和感がある部位',
          description: '該当する部位を選ぶと、メニューでの扱いを設定できます。',
          child: Column(
            children: OnboardingOptions.painAreas
                .map((OnboardingOption area) => _painArea(area))
                .toList(growable: false),
          ),
        ),
        const SizedBox(height: 24),
        OnboardingSection(
          title: '避ける部位',
          child: Column(
            children: OnboardingOptions.priorityParts
                .where((OnboardingOption option) => option.code != 'BALANCED')
                .map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected: draft.avoidBodyPartCodes.contains(option.code),
                      multiple: true,
                      onTap: () => widget.onChanged(
                        draft.copyWith(
                          avoidBodyPartCodes: _toggleSet(
                            draft.avoidBodyPartCodes,
                            option.code,
                          ),
                        ),
                      ),
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
        const SizedBox(height: 24),
        OnboardingSection(
          title: '避ける動作',
          child: Column(
            children: OnboardingOptions.avoidMovementGroups
                .map(
                  (OnboardingOption option) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: ChoiceCard(
                      label: option.label,
                      selected:
                          draft.avoidMovementGroupCodes.contains(option.code),
                      multiple: true,
                      onTap: () => widget.onChanged(
                        draft.copyWith(
                          avoidMovementGroupCodes: _toggleSet(
                            draft.avoidMovementGroupCodes,
                            option.code,
                          ),
                        ),
                      ),
                    ),
                  ),
                )
                .toList(growable: false),
          ),
        ),
        const SizedBox(height: 24),
        OnboardingSection(
          title: '避ける種目',
          description: '初期72種目から選択します。',
          child: Column(
            children: <Widget>[
              TextField(
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: '種目名を検索',
                  border: OutlineInputBorder(),
                ),
                onChanged: (String value) => setState(() => _query = value),
              ),
              const SizedBox(height: 12),
              exercises.when(
                data: (List<ExerciseChoice> values) => Column(
                  children: values
                      .map(
                        (ExerciseChoice option) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: ChoiceCard(
                            label: option.name,
                            description: option.code,
                            selected:
                                draft.avoidExerciseCodes.contains(option.code),
                            multiple: true,
                            onTap: () => widget.onChanged(
                              draft.copyWith(
                                avoidExerciseCodes: _toggleSet(
                                  draft.avoidExerciseCodes,
                                  option.code,
                                ),
                              ),
                            ),
                          ),
                        ),
                      )
                      .toList(growable: false),
                ),
                loading: () => const Padding(
                  padding: EdgeInsets.all(24),
                  child: CircularProgressIndicator(),
                ),
                error: (Object error, StackTrace stackTrace) => const Text(
                  '種目一覧を読み込めませんでした。入力内容は保存されています。',
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _painArea(OnboardingOption area) {
    final selectedAction = draft.painActionsByArea[area.code];
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          ChoiceCard(
            label: area.label,
            selected: selectedAction != null,
            multiple: true,
            onTap: () {
              final next = <String, String>{...draft.painActionsByArea};
              if (selectedAction == null) {
                next[area.code] = 'REDUCE_LOAD';
              } else {
                next.remove(area.code);
              }
              widget.onChanged(draft.copyWith(painActionsByArea: next));
            },
          ),
          if (selectedAction != null)
            Padding(
              padding: const EdgeInsets.only(left: 20, top: 6),
              child: DropdownButtonFormField<String>(
                initialValue: selectedAction,
                decoration: const InputDecoration(
                  labelText: 'メニューでの扱い',
                  border: OutlineInputBorder(),
                ),
                items: OnboardingOptions.painActions
                    .map(
                      (OnboardingOption option) => DropdownMenuItem<String>(
                        value: option.code,
                        child: Text(option.label),
                      ),
                    )
                    .toList(growable: false),
                onChanged: (String? value) {
                  if (value == null) {
                    return;
                  }
                  final next = <String, String>{...draft.painActionsByArea}
                    ..[area.code] = value;
                  widget.onChanged(draft.copyWith(painActionsByArea: next));
                },
              ),
            ),
        ],
      ),
    );
  }
}

final class ReviewStep extends StatelessWidget {
  const ReviewStep({
    required this.draft,
    required this.onEdit,
    super.key,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingStep> onEdit;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        _ReviewCard(
          title: '基本情報',
          value: '${draft.nickname}／${draft.ageYears ?? '-'}歳',
          onEdit: () => onEdit(OnboardingStep.basicInfo),
        ),
        _ReviewCard(
          title: '目的',
          value: _labelFor(OnboardingOptions.goals, draft.primaryGoalCode),
          onEdit: () => onEdit(OnboardingStep.primaryGoal),
        ),
        _ReviewCard(
          title: '経験',
          value:
              '${_labelFor(OnboardingOptions.cumulativeExperience, draft.cumulativeExperienceCode)}／週${draft.currentFrequency ?? '-'}日',
          onEdit: () => onEdit(OnboardingStep.experienceHistory),
        ),
        _ReviewCard(
          title: '環境',
          value: _labelFor(OnboardingOptions.locationModes, draft.locationModeCode),
          onEdit: () => onEdit(OnboardingStep.location),
        ),
        _ReviewCard(
          title: '通常予定',
          value:
              '週${draft.desiredDaysPerWeek ?? '-'}日／${draft.usualDurationMin == 120 ? '90分以上' : '${draft.usualDurationMin ?? '-'}分'}',
          onEdit: () => onEdit(OnboardingStep.schedule),
        ),
        _ReviewCard(
          title: 'メニューの分け方',
          value: _labelFor(
            OnboardingOptions.splitPreferences,
            draft.splitPreferenceCode,
          ),
          onEdit: () => onEdit(OnboardingStep.split),
        ),
        _ReviewCard(
          title: '最優先部位',
          value: _labelFor(
            OnboardingOptions.priorityParts,
            draft.primaryPriorityCode,
          ),
          onEdit: () => onEdit(OnboardingStep.priorities),
        ),
        _ReviewCard(
          title: '痛み・制限',
          value:
              '痛み${draft.painActionsByArea.length}件／除外${draft.avoidBodyPartCodes.length + draft.avoidMovementGroupCodes.length + draft.avoidExerciseCodes.length}件',
          onEdit: () => onEdit(OnboardingStep.restrictions),
        ),
        const SizedBox(height: 12),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              '登録後、この内容を基に今週のメニューを作成します。設定はマイページから変更できます。',
            ),
          ),
        ),
      ],
    );
  }
}

final class _ReviewCard extends StatelessWidget {
  const _ReviewCard({
    required this.title,
    required this.value,
    required this.onEdit,
  });

  final String title;
  final String value;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        child: ListTile(
          title: Text(title),
          subtitle: Text(value),
          trailing: TextButton(onPressed: onEdit, child: const Text('変更')),
        ),
      ),
    );
  }
}
