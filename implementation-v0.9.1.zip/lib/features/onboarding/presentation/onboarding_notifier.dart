import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/database/providers/database_providers.dart';
import 'package:workout_menu_app/features/onboarding/data/local_onboarding_repository.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_repository.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_step.dart';

final onboardingRepositoryProvider = Provider<OnboardingRepository>((ref) {
  return LocalOnboardingRepository(ref.watch(appDatabaseProvider));
});

final onboardingStatusProvider = FutureProvider<OnboardingStatus>((ref) {
  return ref.watch(onboardingRepositoryProvider).loadStatus();
});

final onboardingExerciseChoicesProvider =
    FutureProvider.family<List<ExerciseChoice>, String>((ref, query) {
  return ref.watch(onboardingRepositoryProvider).searchExercises(query);
});

final onboardingFlowProvider =
    AsyncNotifierProvider<OnboardingFlowNotifier, OnboardingFlowState>(
  OnboardingFlowNotifier.new,
);

final class OnboardingFlowState {
  const OnboardingFlowState({
    required this.draft,
    this.isSaving = false,
    this.isCompleting = false,
    this.returnToReviewAfterEdit = false,
    this.message,
  });

  final OnboardingDraft draft;
  final bool isSaving;
  final bool isCompleting;
  final bool returnToReviewAfterEdit;
  final String? message;

  OnboardingFlowState copyWith({
    OnboardingDraft? draft,
    bool? isSaving,
    bool? isCompleting,
    bool? returnToReviewAfterEdit,
    Object? message = _messageNotProvided,
  }) {
    return OnboardingFlowState(
      draft: draft ?? this.draft,
      isSaving: isSaving ?? this.isSaving,
      isCompleting: isCompleting ?? this.isCompleting,
      returnToReviewAfterEdit:
          returnToReviewAfterEdit ?? this.returnToReviewAfterEdit,
      message: identical(message, _messageNotProvided)
          ? this.message
          : message as String?,
    );
  }
}

const Object _messageNotProvided = Object();

final class OnboardingFlowNotifier extends AsyncNotifier<OnboardingFlowState> {
  Future<void> _saveQueue = Future<void>.value();
  int _saveRevision = 0;

  @override
  Future<OnboardingFlowState> build() async {
    final draft = await ref.watch(onboardingRepositoryProvider).loadOrCreateDraft();
    return OnboardingFlowState(draft: draft);
  }

  OnboardingFlowState? get _current => state.when(
        data: (OnboardingFlowState value) => value,
        loading: () => null,
        error: (Object error, StackTrace stackTrace) => null,
      );

  Future<void> updateDraft(
    OnboardingDraft Function(OnboardingDraft draft) update, {
    bool persist = true,
  }) async {
    final current = _current;
    if (current == null || current.isCompleting) {
      return;
    }
    final nextDraft = update(current.draft);
    state = AsyncData<OnboardingFlowState>(
      current.copyWith(
        draft: nextDraft,
        isSaving: persist,
        message: null,
      ),
    );
    if (!persist) {
      return;
    }
    final revision = ++_saveRevision;
    final previousSave = _saveQueue;
    final currentSave = () async {
      try {
        await previousSave;
      } catch (_) {
        // A failed older save must not block the latest answer from being saved.
      }
      await ref.read(onboardingRepositoryProvider).saveDraft(nextDraft);
    }();
    _saveQueue = currentSave;

    try {
      await currentSave;
      final latest = _current;
      if (latest != null && revision == _saveRevision) {
        state = AsyncData<OnboardingFlowState>(
          latest.copyWith(isSaving: false),
        );
      }
    } catch (_) {
      final latest = _current;
      if (latest != null && revision == _saveRevision) {
        state = AsyncData<OnboardingFlowState>(
          latest.copyWith(
            isSaving: false,
            message: '端末への保存に失敗しました。もう一度操作してください。',
          ),
        );
      }
    }
  }

  Future<void> next() async {
    final current = _current;
    if (current == null) {
      return;
    }
    final message = current.draft.validationMessage(current.draft.currentStep);
    if (message != null) {
      state = AsyncData<OnboardingFlowState>(current.copyWith(message: message));
      return;
    }
    final next = current.returnToReviewAfterEdit
        ? OnboardingStep.review
        : current.draft.currentStep.next;
    if (next == null) {
      return;
    }
    await updateDraft(
      (OnboardingDraft draft) => draft.copyWith(currentStep: next),
    );
    if (current.returnToReviewAfterEdit) {
      final latest = _current;
      if (latest != null) {
        state = AsyncData<OnboardingFlowState>(
          latest.copyWith(returnToReviewAfterEdit: false),
        );
      }
    }
  }

  Future<void> back() async {
    final current = _current;
    if (current == null) {
      return;
    }
    final previous = current.draft.currentStep.previous;
    if (previous == null) {
      return;
    }
    await updateDraft(
      (OnboardingDraft draft) => draft.copyWith(currentStep: previous),
    );
  }

  Future<void> goTo(OnboardingStep step) async {
    await updateDraft(
      (OnboardingDraft draft) => draft.copyWith(currentStep: step),
    );
  }

  Future<void> editFromReview(OnboardingStep step) async {
    final current = _current;
    if (current == null || step == OnboardingStep.review) {
      return;
    }
    state = AsyncData<OnboardingFlowState>(
      current.copyWith(returnToReviewAfterEdit: true, message: null),
    );
    await updateDraft(
      (OnboardingDraft draft) => draft.copyWith(currentStep: step),
    );
  }

  Future<bool> complete() async {
    final current = _current;
    if (current == null || current.isCompleting) {
      return false;
    }
    final invalidStep = current.draft.firstInvalidStep;
    if (invalidStep != null) {
      await updateDraft(
        (OnboardingDraft draft) => draft.copyWith(currentStep: invalidStep),
      );
      final latest = _current;
      if (latest != null) {
        state = AsyncData<OnboardingFlowState>(
          latest.copyWith(
            message: '未入力の項目があります。該当画面を確認してください。',
          ),
        );
      }
      return false;
    }

    state = AsyncData<OnboardingFlowState>(
      current.copyWith(isCompleting: true, message: null),
    );
    try {
      try {
        await _saveQueue;
      } catch (_) {
        // Completion persists the in-memory draft transactionally below.
      }
      await ref.read(onboardingRepositoryProvider).complete(current.draft);
      ref.invalidate(onboardingStatusProvider);
      return true;
    } catch (_) {
      final latest = _current ?? current;
      state = AsyncData<OnboardingFlowState>(
        latest.copyWith(
          isCompleting: false,
          message: '登録内容を保存できませんでした。入力内容は端末に残っています。',
        ),
      );
      return false;
    }
  }

  Future<void> reset() async {
    final current = _current;
    if (current == null) {
      return;
    }
    try {
      await _saveQueue;
    } catch (_) {
      // Reset can proceed because the repository filters drafts by status.
    }
    await ref.read(onboardingRepositoryProvider).resetDraft(current.draft);
    state = const AsyncLoading<OnboardingFlowState>();
    state = await AsyncValue.guard(() async {
      final draft =
          await ref.read(onboardingRepositoryProvider).loadOrCreateDraft();
      return OnboardingFlowState(draft: draft);
    });
  }
}
