import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/home/presentation/today_action_notifier.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_step.dart';
import 'package:workout_menu_app/features/onboarding/presentation/onboarding_notifier.dart';
import 'package:workout_menu_app/features/onboarding/presentation/steps/onboarding_steps.dart';
import 'package:workout_menu_app/features/onboarding/presentation/widgets/onboarding_scaffold.dart';

final class OnboardingFlowPage extends ConsumerWidget {
  const OnboardingFlowPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final value = ref.watch(onboardingFlowProvider);
    return value.when(
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (Object error, StackTrace stackTrace) => Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const Text('登録内容を読み込めませんでした。'),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () => ref.invalidate(onboardingFlowProvider),
                    child: const Text('もう一度試す'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      data: (OnboardingFlowState state) {
        final notifier = ref.read(onboardingFlowProvider.notifier);
        final draft = state.draft;
        return OnboardingScaffold(
          step: draft.currentStep,
          subtitle: _subtitle(draft.currentStep),
          body: _body(
            draft: draft,
            onChanged: (OnboardingDraft next) {
              unawaited(
                notifier.updateDraft((OnboardingDraft value) => next),
              );
            },
            onEdit: (OnboardingStep step) {
              unawaited(notifier.editFromReview(step));
            },
          ),
          primaryLabel: draft.currentStep.primaryButtonLabel,
          onPrimary: state.isCompleting
              ? null
              : () async {
                  if (draft.currentStep == OnboardingStep.review) {
                    final completed = await notifier.complete();
                    if (completed && context.mounted) {
                      ref.invalidate(todayActionProvider);
                      context.go('/home');
                    }
                    return;
                  }
                  await notifier.next();
                },
          onBack: draft.currentStep.previous == null
              ? null
              : () => unawaited(notifier.back()),
          secondaryLabel: draft.currentStep == OnboardingStep.intro
              ? null
              : '最初からやり直す',
          onSecondary: () => unawaited(_confirmReset(context, notifier)),
          isSaving: state.isSaving,
          isBusy: state.isCompleting,
          message: state.message,
        );
      },
    );
  }

  Future<void> _confirmReset(
    BuildContext context,
    OnboardingFlowNotifier notifier,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('最初からやり直しますか？'),
          content: const Text('現在の入力内容を破棄し、新しい登録を開始します。'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('キャンセル'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('やり直す'),
            ),
          ],
        );
      },
    );
    if (confirmed ?? false) {
      await notifier.reset();
    }
  }

  Widget _body({
    required OnboardingDraft draft,
    required ValueChanged<OnboardingDraft> onChanged,
    required ValueChanged<OnboardingStep> onEdit,
  }) {
    return switch (draft.currentStep) {
      OnboardingStep.intro => const IntroStep(),
      OnboardingStep.basicInfo =>
        BasicInfoStep(draft: draft, onChanged: onChanged),
      OnboardingStep.primaryGoal =>
        PrimaryGoalStep(draft: draft, onChanged: onChanged),
      OnboardingStep.secondaryGoals =>
        SecondaryGoalsStep(draft: draft, onChanged: onChanged),
      OnboardingStep.experienceHistory =>
        ExperienceHistoryStep(draft: draft, onChanged: onChanged),
      OnboardingStep.experienceCurrent =>
        ExperienceCurrentStep(draft: draft, onChanged: onChanged),
      OnboardingStep.location =>
        LocationStep(draft: draft, onChanged: onChanged),
      OnboardingStep.equipment =>
        EquipmentStep(draft: draft, onChanged: onChanged),
      OnboardingStep.schedule =>
        ScheduleStep(draft: draft, onChanged: onChanged),
      OnboardingStep.split => SplitStep(draft: draft, onChanged: onChanged),
      OnboardingStep.priorities =>
        PrioritiesStep(draft: draft, onChanged: onChanged),
      OnboardingStep.restrictions =>
        RestrictionsStep(draft: draft, onChanged: onChanged),
      OnboardingStep.review => ReviewStep(draft: draft, onEdit: onEdit),
    };
  }

  String? _subtitle(OnboardingStep step) {
    return switch (step) {
      OnboardingStep.intro => 'いくつかの質問に答えると、あなた専用の週間メニューを作成できます。',
      OnboardingStep.basicInfo => 'メニューの表示と身体データの記録に使います。',
      OnboardingStep.primaryGoal => '最も優先したい目的を1つ選んでください。',
      OnboardingStep.secondaryGoals => '当てはまるものを複数選べます。',
      OnboardingStep.experienceHistory => '経験年数と現在の継続状況を確認します。',
      OnboardingStep.experienceCurrent => '本人にレベルを直接選ばせず、回答から判定します。',
      OnboardingStep.location => '自宅、ジム、または両方から選んでください。',
      OnboardingStep.equipment => '実際に使用できる器具だけを登録してください。',
      OnboardingStep.schedule => '毎週の初期値として使用し、週ごとに変更できます。',
      OnboardingStep.split => 'よく分からない場合はアプリのおすすめを選べます。',
      OnboardingStep.priorities => '性別から推測せず、本人の希望を直接確認します。',
      OnboardingStep.restrictions => '該当しない場合は何も選ばず次へ進めます。',
      OnboardingStep.review => '各項目の「変更」から入力画面へ戻れます。',
    };
  }
}
