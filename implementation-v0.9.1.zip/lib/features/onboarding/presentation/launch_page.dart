import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/core/widgets/primary_action_button.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_repository.dart';
import 'package:workout_menu_app/features/onboarding/presentation/onboarding_notifier.dart';

final class LaunchPage extends ConsumerWidget {
  const LaunchPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final status = ref.watch(onboardingStatusProvider);
    ref.listen<AsyncValue<OnboardingStatus>>(
      onboardingStatusProvider,
      (
        AsyncValue<OnboardingStatus>? previous,
        AsyncValue<OnboardingStatus> next,
      ) {
        next.whenData((OnboardingStatus value) {
          if (value == OnboardingStatus.inProgress) {
            return;
          }
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!context.mounted) {
              return;
            }
            context.go(
              value == OnboardingStatus.completed ? '/home' : '/onboarding',
            );
          });
        });
      },
    );

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: status.when(
            data: (OnboardingStatus value) => switch (value) {
              OnboardingStatus.inProgress => Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      const Icon(Icons.save_outlined, size: 64),
                      const SizedBox(height: 20),
                      Text(
                        '登録の続きがあります',
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        '前回までの回答は端末に保存されています。続きから再開できます。',
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 28),
                      PrimaryActionButton(
                        label: '続きから再開',
                        onPressed: () => context.go('/onboarding'),
                      ),
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: () => unawaited(
                          _confirmReset(context, ref),
                        ),
                        child: const Text('最初からやり直す'),
                      ),
                    ],
                  ),
                ),
              OnboardingStatus.notStarted || OnboardingStatus.completed =>
                const CircularProgressIndicator(),
            },
            loading: () => const CircularProgressIndicator(),
            error: (Object error, StackTrace stackTrace) => Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const Text('端末内のデータを読み込めませんでした。'),
                  const SizedBox(height: 16),
                  PrimaryActionButton(
                    label: 'もう一度試す',
                    onPressed: () => ref.invalidate(onboardingStatusProvider),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _confirmReset(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('最初からやり直しますか？'),
          content: const Text('現在の入力内容を破棄し、新しい登録を開始します。'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('キャンセル'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('やり直す'),
            ),
          ],
        );
      },
    );
    if (!(confirmed ?? false)) {
      return;
    }

    final repository = ref.read(onboardingRepositoryProvider);
    final draft = await repository.loadOrCreateDraft();
    await repository.resetDraft(draft);
    ref.invalidate(onboardingFlowProvider);
    ref.invalidate(onboardingStatusProvider);
    if (context.mounted) {
      context.go('/onboarding');
    }
  }
}
