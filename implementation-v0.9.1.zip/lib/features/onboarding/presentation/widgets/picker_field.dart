import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:workout_menu_app/core/widgets/primary_action_button.dart';

final class PickerField<T> extends StatelessWidget {
  const PickerField({
    required this.label,
    required this.values,
    required this.formatValue,
    required this.onChanged,
    this.value,
    this.placeholder = '選択してください',
    this.helperText,
    super.key,
  });

  final String label;
  final T? value;
  final List<T> values;
  final String Function(T value) formatValue;
  final ValueChanged<T> onChanged;
  final String placeholder;
  final String? helperText;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(label, style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 8),
        Material(
          color: Theme.of(context).colorScheme.surfaceContainerLowest,
          borderRadius: BorderRadius.circular(12),
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () => unawaited(_showPicker(context)),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
              decoration: BoxDecoration(
                border: Border.all(
                  color: Theme.of(context).colorScheme.outlineVariant,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      value == null ? placeholder : formatValue(value as T),
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            color: value == null
                                ? Theme.of(context)
                                    .colorScheme
                                    .onSurfaceVariant
                                : null,
                          ),
                    ),
                  ),
                  const Icon(Icons.unfold_more),
                ],
              ),
            ),
          ),
        ),
        if (helperText != null) ...<Widget>[
          const SizedBox(height: 6),
          Text(helperText!, style: Theme.of(context).textTheme.bodySmall),
        ],
      ],
    );
  }

  Future<void> _showPicker(BuildContext context) async {
    var selectedIndex = value == null ? 0 : values.indexOf(value as T);
    if (selectedIndex < 0) {
      selectedIndex = 0;
    }
    final result = await showModalBottomSheet<T>(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(label, style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 220,
                    child: CupertinoPicker.builder(
                      scrollController: FixedExtentScrollController(
                        initialItem: selectedIndex,
                      ),
                      itemExtent: 44,
                      childCount: values.length,
                      onSelectedItemChanged: (int index) {
                        setState(() => selectedIndex = index);
                      },
                      itemBuilder: (BuildContext context, int index) {
                        return Center(
                          child: Text(
                            formatValue(values[index]),
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 12),
                  PrimaryActionButton(
                    label: 'この数値を使う',
                    onPressed: () => Navigator.of(context).pop(values[selectedIndex]),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
    if (result != null) {
      onChanged(result);
    }
  }
}
