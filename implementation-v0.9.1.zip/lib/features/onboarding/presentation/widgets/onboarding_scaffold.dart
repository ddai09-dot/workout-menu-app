import 'package:flutter/material.dart';
import 'package:workout_menu_app/core/widgets/primary_action_button.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_step.dart';

final class OnboardingScaffold extends StatelessWidget {
  const OnboardingScaffold({
    required this.step,
    required this.body,
    required this.primaryLabel,
    required this.onPrimary,
    this.subtitle,
    this.onBack,
    this.secondaryLabel,
    this.onSecondary,
    this.isSaving = false,
    this.isBusy = false,
    this.message,
    super.key,
  });

  final OnboardingStep step;
  final Widget body;
  final String primaryLabel;
  final VoidCallback? onPrimary;
  final String? subtitle;
  final VoidCallback? onBack;
  final String? secondaryLabel;
  final VoidCallback? onSecondary;
  final bool isSaving;
  final bool isBusy;
  final String? message;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: onBack == null
            ? null
            : IconButton(
                tooltip: '戻る',
                onPressed: onBack,
                icon: const Icon(Icons.arrow_back),
              ),
        title: step.showsProgress ? const Text('初期登録') : null,
        actions: <Widget>[
          if (isSaving)
            const Padding(
              padding: EdgeInsets.only(right: 16),
              child: Center(child: Text('保存中…')),
            ),
        ],
        bottom: step.showsProgress
            ? PreferredSize(
                preferredSize: const Size.fromHeight(4),
                child: LinearProgressIndicator(value: step.progressValue),
              )
            : null,
      ),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Expanded(
              child: SingleChildScrollView(
                keyboardDismissBehavior:
                    ScrollViewKeyboardDismissBehavior.onDrag,
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(
                      step.title,
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    if (subtitle != null) ...<Widget>[
                      const SizedBox(height: 8),
                      Text(
                        subtitle!,
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                    ],
                    if (message != null) ...<Widget>[
                      const SizedBox(height: 14),
                      Material(
                        color: Theme.of(context).colorScheme.errorContainer,
                        borderRadius: BorderRadius.circular(10),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(
                            message!,
                            style: TextStyle(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onErrorContainer,
                            ),
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 24),
                    body,
                  ],
                ),
              ),
            ),
            DecoratedBox(
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                boxShadow: const <BoxShadow>[
                  BoxShadow(
                    blurRadius: 12,
                    offset: Offset(0, -2),
                    color: Color(0x14000000),
                  ),
                ],
              ),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      PrimaryActionButton(
                        label: isBusy ? '保存しています…' : primaryLabel,
                        onPressed: isBusy ? null : onPrimary,
                      ),
                      if (secondaryLabel != null) ...<Widget>[
                        const SizedBox(height: 6),
                        TextButton(
                          onPressed: isBusy ? null : onSecondary,
                          child: Text(secondaryLabel!),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
