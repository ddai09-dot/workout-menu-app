import 'package:flutter/material.dart';

final class OnboardingSection extends StatelessWidget {
  const OnboardingSection({
    required this.title,
    required this.child,
    this.description,
    super.key,
  });

  final String title;
  final String? description;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text(title, style: Theme.of(context).textTheme.titleMedium),
        if (description != null) ...<Widget>[
          const SizedBox(height: 4),
          Text(description!, style: Theme.of(context).textTheme.bodyMedium),
        ],
        const SizedBox(height: 10),
        child,
      ],
    );
  }
}
