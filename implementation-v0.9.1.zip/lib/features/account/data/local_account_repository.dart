import 'dart:async';

import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/core/security/secure_store.dart';
import 'package:workout_menu_app/features/account/domain/account_models.dart';
import 'package:workout_menu_app/features/account/domain/account_repository.dart';

final class LocalAccountRepository implements AccountRepository {
  LocalAccountRepository({
    required AppDatabase database,
    required SecureStore secureStore,
    required IdGenerator idGenerator,
  })  : _db = database,
        _secureStore = secureStore,
        _ids = idGenerator;

  final AppDatabase _db;
  final SecureStore _secureStore;
  final IdGenerator _ids;
  static const _currentUserKey = 'current_user_id';
  Completer<void>? _resetCompletion;

  @override
  Future<AccountSnapshot> ensureAnonymousAccount() async {
    final resetCompletion = _resetCompletion;
    if (resetCompletion != null) {
      await resetCompletion.future;
    }
    final existing = await _secureStore.read(_currentUserKey);
    if (existing != null) {
      final snapshot = await _tryLoad(existing);
      if (snapshot != null) {
        return snapshot;
      }
      await _secureStore.delete(_currentUserKey);
    }
    return _createAnonymousAccount();
  }

  Future<AccountSnapshot> _createAnonymousAccount() async {
    final id = _ids.next();
    await _db.customStatement(
      "INSERT INTO user_account(id, auth_provider, account_status) VALUES (?, 'ANONYMOUS', 'ACTIVE')",
      <Object?>[id],
    );
    await _secureStore.write(key: _currentUserKey, value: id);
    return _load(id);
  }

  Future<AccountSnapshot?> _tryLoad(String userId) async {
    try {
      return await _load(userId);
    } on StateError {
      return null;
    }
  }

  Future<AccountSnapshot> _load(String userId) async {
    final rows = await _db.customSelect(
      '''SELECT u.id, u.auth_provider, u.account_status,
         (SELECT MAX(last_success_at) FROM sync_checkpoint WHERE user_id=u.id) AS last_sync_at,
         (SELECT COUNT(*) FROM sync_outbox WHERE user_id=u.id AND status_code IN ('PENDING','RETRY')) AS pending_count
         FROM user_account u WHERE u.id=? AND u.deleted_at IS NULL''',
      variables: <Variable<Object>>[Variable<String>(userId)],
    ).get();
    if (rows.isEmpty) throw StateError('Current account not found');
    final row = rows.single;
    final statusCode = row.read<String>('account_status');
    return AccountSnapshot(
      userId: row.read<String>('id'),
      kind: row.read<String>('auth_provider') == 'APPLE' ? AccountKind.apple : AccountKind.anonymous,
      status: switch (statusCode) {
        'DELETION_PENDING' => AccountStatus.deletionPending,
        'DELETED' => AccountStatus.deleted,
        _ => AccountStatus.active,
      },
      lastSyncAt: DateTime.tryParse(row.readNullable<String>('last_sync_at') ?? ''),
      pendingOutboxCount: row.read<int>('pending_count'),
    );
  }

  @override
  Stream<AccountSnapshot> watchCurrent() async* {
    yield await ensureAnonymousAccount();
    await for (final _ in _db.select(_db.userAccount).watch()) {
      yield await ensureAnonymousAccount();
    }
  }

  @override
  Future<void> linkApple(AppleIdentityToken credential) async {
    throw UnsupportedError('Use the Supabase account adapter to exchange the Apple credential first.');
  }

  @override
  Future<void> signOut() => _secureStore.delete(_currentUserKey);

  @override
  Future<void> requestDeletion() async {
    final id = await _secureStore.read(_currentUserKey);
    if (id == null) throw StateError('No current account');
    await _db.transaction(() async {
      await _db.customStatement(
        "UPDATE user_account SET account_status='DELETION_PENDING', updated_at=CURRENT_TIMESTAMP WHERE id=?",
        <Object?>[id],
      );
      await _db.customStatement(
        "INSERT INTO account_deletion_request(id,user_id,status_code) VALUES (?,?,'PENDING')",
        <Object?>[_ids.next(), id],
      );
    });
  }

  @override
  Future<AccountSnapshot> resetLocalData() async {
    final activeReset = _resetCompletion;
    if (activeReset != null) {
      await activeReset.future;
      return ensureAnonymousAccount();
    }

    final currentUserId = await _secureStore.read(_currentUserKey);
    if (currentUserId == null) {
      return ensureAnonymousAccount();
    }

    final completion = Completer<void>();
    _resetCompletion = completion;
    final replacementUserId = _ids.next();
    try {
      // Secure storage is switched first while account readers are suspended by
      // _resetCompletion. If the database transaction fails, the old key is
      // restored and no user-owned row has been committed as deleted.
      await _secureStore.write(
        key: _currentUserKey,
        value: replacementUserId,
      );
      try {
        await _db.transaction(() async {
          for (final tableName in _userOwnedTablesInDeleteOrder) {
            await _db.customStatement(
              'DELETE FROM $tableName WHERE user_id = ?',
              <Object?>[currentUserId],
            );
          }
          await _db.customStatement(
            'DELETE FROM user_account WHERE id = ?',
            <Object?>[currentUserId],
          );
          await _db.customStatement(
            "INSERT INTO user_account(id, auth_provider, account_status) "
            "VALUES (?, 'ANONYMOUS', 'ACTIVE')",
            <Object?>[replacementUserId],
          );
        });
      } catch (_) {
        await _secureStore.write(
          key: _currentUserKey,
          value: currentUserId,
        );
        rethrow;
      }
      return _load(replacementUserId);
    } finally {
      _resetCompletion = null;
      completion.complete();
    }
  }

  static const List<String> _userOwnedTablesInDeleteOrder = <String>[
    'workout_session_event',
    'work_set_record',
    'weekly_stalled_exercise',
    'weekly_priority_part',
    'weekly_planner_draft',
    'weekly_pain_entry',
    'weekly_input',
    'weekly_available_day',
    'user_training_setting',
    'user_restriction',
    'user_profile',
    'user_priority_part',
    'user_goal',
    'user_experience_profile',
    'sync_outbox',
    'sync_conflict_log',
    'sync_run_history',
    'sync_checkpoint',
    'standard_schedule_day',
    'session_set_target',
    'session_pain_entry',
    'session_exercise_evaluation',
    'progression_proposal_decision',
    'post_workout_assessment',
    'planned_set',
    'onboarding_draft',
    'notification_setting_legacy_archive',
    'notification_preference',
    'notification_delivery_log',
    'notification_schedule',
    'location_dumbbell_detail',
    'location_barbell_detail',
    'exercise_performance_series',
    'session_exercise',
    'equipment_weight_option',
    'location_equipment',
    'body_measurement',
    'app_preference',
    'ai_response_cache',
    'ai_feedback',
    'ai_chat_message',
    'ai_chat_session',
    'account_link_history',
    'account_deletion_request',
    'accepted_progression_adjustment',
    'progression_proposal',
    'workout_session',
    'planned_exercise',
    'workout_day_plan',
    'weekly_menu',
    'training_week',
    'training_location',
    'device_registration',
  ];
}
