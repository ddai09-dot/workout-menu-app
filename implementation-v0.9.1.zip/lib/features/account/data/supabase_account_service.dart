import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:workout_menu_app/features/account/domain/account_models.dart';

final class SupabaseAccountService {
  const SupabaseAccountService(this._client);
  final SupabaseClient _client;

  Future<AuthResponse> linkApple(AppleIdentityToken token) {
    return _client.auth.signInWithIdToken(
      provider: OAuthProvider.apple,
      idToken: token.identityToken,
      accessToken: token.authorizationCode,
      nonce: token.nonce,
    );
  }

  Future<void> signOut() => _client.auth.signOut(scope: SignOutScope.local);
  Future<void> requestRemoteDeletion() async {
    await _client.functions.invoke('delete-account');
  }
}
