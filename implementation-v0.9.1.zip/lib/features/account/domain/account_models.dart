enum AccountKind { anonymous, apple }
enum AccountStatus { active, deletionPending, deleted }

final class AccountSnapshot {
  const AccountSnapshot({
    required this.userId,
    required this.kind,
    required this.status,
    required this.lastSyncAt,
    required this.pendingOutboxCount,
  });
  final String userId;
  final AccountKind kind;
  final AccountStatus status;
  final DateTime? lastSyncAt;
  final int pendingOutboxCount;
  bool get canLinkApple => kind == AccountKind.anonymous && status == AccountStatus.active;
}

final class AppleIdentityToken {
  const AppleIdentityToken({
    required this.identityToken,
    required this.authorizationCode,
    this.nonce,
  });
  final String identityToken;
  final String authorizationCode;
  final String? nonce;
}
