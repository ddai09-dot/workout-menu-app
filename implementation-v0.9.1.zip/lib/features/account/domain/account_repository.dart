import 'package:workout_menu_app/features/account/domain/account_models.dart';

abstract interface class AccountRepository {
  Stream<AccountSnapshot> watchCurrent();
  Future<AccountSnapshot> ensureAnonymousAccount();
  Future<void> linkApple(AppleIdentityToken credential);
  Future<void> signOut();
  Future<void> requestDeletion();
  Future<AccountSnapshot> resetLocalData();
}

abstract interface class AppleAuthGateway {
  Future<AppleIdentityToken> requestCredential();
}
