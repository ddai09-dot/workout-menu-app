import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/features/account/domain/account_models.dart';
import 'package:workout_menu_app/features/account/presentation/account_notifier.dart';

final class AccountPage extends ConsumerWidget {
  const AccountPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(accountNotifierProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('アカウントと同期')),
      body: SafeArea(
        child: state.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (_, __) => const Center(child: Text('アカウントを読み込めませんでした')),
          data: (account) => ListView(
            padding: const EdgeInsets.all(16),
            children: <Widget>[
              ListTile(
                title: Text(account.kind == AccountKind.anonymous ? '匿名利用中' : 'Apple連携済み'),
                subtitle: Text('送信待ち ${account.pendingOutboxCount}件'),
              ),
              const Divider(),
              FilledButton(
                onPressed: null,
                child: const Text('Appleで連携（認証設定後に有効）'),
              ),
              TextButton(
                onPressed: account.status == AccountStatus.active
                    ? () => _confirmDeletion(context, ref)
                    : null,
                child: const Text('アカウントを削除'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmDeletion(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('アカウントを削除しますか？'),
        content: const Text('サーバー上のデータと写真も削除対象になります。処理完了までは再試行されます。'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('キャンセル')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('削除を申請')),
        ],
      ),
    );
    if (confirmed == true) {
      await ref.read(accountNotifierProvider.notifier).requestDeletion();
    }
  }
}
