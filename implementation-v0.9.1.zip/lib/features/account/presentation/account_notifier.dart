import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/features/account/domain/account_models.dart';
import 'package:workout_menu_app/features/account/domain/account_repository.dart';

final accountRepositoryProvider = Provider<AccountRepository>(
  (ref) => throw UnimplementedError('Override accountRepositoryProvider in bootstrap.'),
);

final class AccountNotifier extends AsyncNotifier<AccountSnapshot> {
  @override
  Future<AccountSnapshot> build() {
    return ref.read(accountRepositoryProvider).ensureAnonymousAccount();
  }

  Future<void> requestDeletion() async {
    await ref.read(accountRepositoryProvider).requestDeletion();
    state = AsyncData(
      await ref.read(accountRepositoryProvider).ensureAnonymousAccount(),
    );
  }

  Future<bool> resetLocalData() async {
    state = const AsyncLoading<AccountSnapshot>();
    try {
      final snapshot =
          await ref.read(accountRepositoryProvider).resetLocalData();
      state = AsyncData<AccountSnapshot>(snapshot);
      return true;
    } catch (error, stackTrace) {
      state = AsyncError<AccountSnapshot>(error, stackTrace);
      return false;
    }
  }
}

final accountNotifierProvider = AsyncNotifierProvider<AccountNotifier, AccountSnapshot>(AccountNotifier.new);
