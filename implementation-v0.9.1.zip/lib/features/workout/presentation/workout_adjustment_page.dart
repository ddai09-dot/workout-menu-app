import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/workout/domain/workout_models.dart';
import 'package:workout_menu_app/features/workout/presentation/workout_notifier.dart';

final class WorkoutAdjustmentPage extends ConsumerStatefulWidget {
  const WorkoutAdjustmentPage({required this.dayPlanId, super.key});

  final String dayPlanId;

  @override
  ConsumerState<WorkoutAdjustmentPage> createState() => _WorkoutAdjustmentPageState();
}

final class _WorkoutAdjustmentPageState extends ConsumerState<WorkoutAdjustmentPage> {
  int? _duration;
  int _fatigue = 3;
  String? _locationId;
  final List<WorkoutPainAdjustment> _painEntries = <WorkoutPainAdjustment>[];
  bool _starting = false;

  @override
  Widget build(BuildContext context) {
    final summary = ref.watch(workoutLaunchProvider(widget.dayPlanId));
    return Scaffold(
      appBar: AppBar(title: const Text('今日の状態に合わせる')),
      body: SafeArea(
        child: summary.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (Object error, StackTrace stackTrace) => const Center(
            child: Text('調整内容を読み込めませんでした。'),
          ),
          data: (WorkoutLaunchSummary value) {
            _duration ??= value.plannedDurationMin;
            _locationId ??= value.locationId;
            return ListView(
              padding: const EdgeInsets.all(20),
              children: <Widget>[
                Text('使える時間', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: <int>[15, 30, 45, 60, 90, 120]
                      .map(
                        (int minutes) => ChoiceChip(
                          label: Text(minutes == 120 ? '90分以上' : '$minutes分'),
                          selected: _duration == minutes,
                          onSelected: (_) => setState(() => _duration = minutes),
                        ),
                      )
                      .toList(growable: false),
                ),
                const SizedBox(height: 24),
                Text('疲労', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 8),
                SegmentedButton<int>(
                  segments: List<ButtonSegment<int>>.generate(
                    5,
                    (int index) => ButtonSegment<int>(
                      value: index + 1,
                      label: Text('${index + 1}'),
                    ),
                  ),
                  selected: <int>{_fatigue},
                  onSelectionChanged: (Set<int> value) {
                    setState(() => _fatigue = value.first);
                  },
                ),
                const SizedBox(height: 6),
                Text(
                  _fatigue >= 4
                      ? '高い疲労に合わせて、重量またはセットを減らします。'
                      : 'モチベーションだけを理由に負荷は増やしません。',
                ),
                if (value.availableLocations.length > 1) ...<Widget>[
                  const SizedBox(height: 24),
                  Text('今日の場所', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 8),
                  for (final location in value.availableLocations)
                    RadioListTile<String>(
                      value: location.id,
                      groupValue: _locationId,
                      title: Text(location.name),
                      onChanged: (String? id) => setState(() => _locationId = id),
                    ),
                ],
                const SizedBox(height: 24),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text('痛み・違和感', style: Theme.of(context).textTheme.titleLarge),
                    ),
                    TextButton.icon(
                      onPressed: _addPainEntry,
                      icon: const Icon(Icons.add),
                      label: const Text('追加'),
                    ),
                  ],
                ),
                if (_painEntries.isEmpty)
                  const Text('なし')
                else
                  for (var index = 0; index < _painEntries.length; index += 1)
                    Card(
                      child: ListTile(
                        title: Text(_painEntries[index].bodyPartName),
                        subtitle: Text(_painActionLabel(_painEntries[index].actionCode)),
                        trailing: IconButton(
                          tooltip: '削除',
                          onPressed: () => setState(() => _painEntries.removeAt(index)),
                          icon: const Icon(Icons.close),
                        ),
                      ),
                    ),
                const SizedBox(height: 24),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      '変更内容：${_duration ?? value.plannedDurationMin}分・疲労$_fatigue'
                      '${_painEntries.isEmpty ? '' : '・痛み対応${_painEntries.length}件'}',
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                FilledButton(
                  onPressed: _starting
                      ? null
                      : () async {
                          setState(() => _starting = true);
                          try {
                            final session = await ref
                                .read(workoutSessionProvider.notifier)
                                .start(
                                  dayPlanId: widget.dayPlanId,
                                  adjustment: WorkoutStartAdjustment(
                                    availableDurationMin:
                                        _duration ?? value.plannedDurationMin,
                                    fatigueScore: _fatigue,
                                    locationId: _locationId,
                                    painEntries: List.unmodifiable(_painEntries),
                                  ),
                                );
                            if (mounted) {
                              context.go('/workout/session/${session.sessionId}');
                            }
                          } catch (_) {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('この条件では開始できませんでした。場所・痛み対応・利用時間を見直してください。'),
                                ),
                              );
                            }
                          } finally {
                            if (mounted) setState(() => _starting = false);
                          }
                        },
                  child: Text(_starting ? '調整して保存中…' : 'この内容で開始する'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Future<void> _addPainEntry() async {
    final bodyParts = await ref.read(workoutBodyPartsProvider.future);
    if (!mounted || bodyParts.isEmpty) return;
    var bodyPart = bodyParts.first;
    var actionCode = 'REDUCE_LOAD';
    final result = await showModalBottomSheet<WorkoutPainAdjustment>(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setModalState) {
            return Padding(
              padding: EdgeInsets.fromLTRB(
                20,
                20,
                20,
                20 + MediaQuery.viewInsetsOf(context).bottom,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text('痛み・違和感の対応', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<WorkoutBodyPartChoice>(
                    value: bodyPart,
                    decoration: const InputDecoration(labelText: '部位'),
                    items: bodyParts
                        .map(
                          (value) => DropdownMenuItem<WorkoutBodyPartChoice>(
                            value: value,
                            child: Text(value.name),
                          ),
                        )
                        .toList(growable: false),
                    onChanged: (value) {
                      if (value != null) setModalState(() => bodyPart = value);
                    },
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: actionCode,
                    decoration: const InputDecoration(labelText: '対応'),
                    items: const <DropdownMenuItem<String>>[
                      DropdownMenuItem(value: 'AS_PLANNED', child: Text('予定どおり')),
                      DropdownMenuItem(value: 'REDUCE_LOAD', child: Text('重量を下げる')),
                      DropdownMenuItem(value: 'LOW_IMPACT_ALTERNATIVE', child: Text('低負担種目へ変更')),
                      DropdownMenuItem(value: 'EXCLUDE', child: Text('対象種目を除外')),
                      DropdownMenuItem(value: 'MOVE_LATER', child: Text('対象種目を後へ移動')),
                    ],
                    onChanged: (value) {
                      if (value != null) setModalState(() => actionCode = value);
                    },
                  ),
                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: () => Navigator.of(context).pop(
                      WorkoutPainAdjustment(
                        bodyPartId: bodyPart.id,
                        bodyPartName: bodyPart.name,
                        actionCode: actionCode,
                      ),
                    ),
                    child: const Text('この対応を追加する'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
    if (result != null && mounted) setState(() => _painEntries.add(result));
  }
}

String _painActionLabel(String code) => switch (code) {
      'AS_PLANNED' => '予定どおり',
      'REDUCE_LOAD' => '重量を下げる',
      'LOW_IMPACT_ALTERNATIVE' => '低負担種目へ変更',
      'EXCLUDE' => '対象種目を除外',
      'MOVE_LATER' => '対象種目を後へ移動',
      _ => code,
    };
