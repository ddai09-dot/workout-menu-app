import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/workout/domain/workout_models.dart';
import 'package:workout_menu_app/features/workout/presentation/workout_notifier.dart';
import 'package:workout_menu_app/features/workout/widgets/workout_number_picker_sheet.dart';

final class WorkoutSessionPage extends ConsumerStatefulWidget {
  const WorkoutSessionPage({required this.sessionId, super.key});

  final String sessionId;

  @override
  ConsumerState<WorkoutSessionPage> createState() => _WorkoutSessionPageState();
}

final class _WorkoutSessionPageState extends ConsumerState<WorkoutSessionPage>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      ref.read(workoutSessionProvider.notifier).reload();
    }
  }

  @override
  Widget build(BuildContext context) {
    final value = ref.watch(workoutSessionProvider);
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) async {
        if (didPop) return;
        final leave = await _confirmLeave(context);
        if (leave && context.mounted) context.go('/home');
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const Text('トレーニング中'),
          actions: <Widget>[
            TextButton(
              onPressed: () async {
                final leave = await _confirmLeave(context);
                if (leave && context.mounted) context.go('/home');
              },
              child: const Text('ホーム'),
            ),
          ],
        ),
        body: SafeArea(
          child: value.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (Object error, StackTrace stackTrace) => _SessionLoadError(
              onRetry: () => ref.read(workoutSessionProvider.notifier).reload(),
            ),
            data: (WorkoutSessionViewState view) {
              final session = view.session;
              if (session == null) {
                return const Center(child: Text('未終了のトレーニングはありません。'));
              }
              if (session.sessionId != widget.sessionId) {
                return _SessionMismatch(
                  sessionId: session.sessionId,
                  onOpen: () => context.go('/workout/session/${session.sessionId}'),
                );
              }
              if (session.isAwaitingAssessment) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (context.mounted) {
                    context.go('/workout/assessment/${session.sessionId}');
                  }
                });
                return const Center(child: CircularProgressIndicator());
              }
              if (session.rest != null) {
                return _RestView(view: view);
              }
              return _ExerciseView(view: view);
            },
          ),
        ),
      ),
    );
  }
}

final class _ExerciseView extends ConsumerWidget {
  const _ExerciseView({required this.view});

  final WorkoutSessionViewState view;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = view.session!;
    final exercise = session.currentExercise;
    final target = session.currentTarget;
    if (exercise == null || target == null) {
      return const Center(child: Text('現在の種目を読み込めませんでした。'));
    }
    final activeExercises = session.exercises
        .where((value) => value.statusCode != 'SKIPPED')
        .toList(growable: false);
    final exercisePosition = activeExercises.indexWhere(
          (value) => value.sessionExerciseId == exercise.sessionExerciseId,
        ) +
        1;
    final completedForExercise = exercise.completedWorkSetCount;
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Text(
                '$exercisePosition / ${activeExercises.length}種目',
                style: Theme.of(context).textTheme.labelLarge,
              ),
            ),
            Text('${session.completedWorkSetCount}/${session.plannedWorkSetCount}セット完了'),
          ],
        ),
        const SizedBox(height: 12),
        Text(exercise.name, style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 4),
        if (exercise.targetPart.isNotEmpty) Text('狙う部位：${exercise.targetPart}'),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerLeft,
          child: OutlinedButton.icon(
            onPressed: () => context.push('/exercise-form/${exercise.exerciseId}'),
            icon: const Icon(Icons.accessibility_new_outlined),
            label: const Text('フォームを確認'),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: <Widget>[
                Text(
                  'セット ${target.setNumber} / ${exercise.targets.where((value) => value.deletedAt == null).length}',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 6),
                Text('目標 ${target.targetText}・休憩${target.restSec}秒'),
                if (completedForExercise > 0) ...<Widget>[
                  const SizedBox(height: 6),
                  Text('$completedForExerciseセット完了済み'),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        _SetInputCard(
          session: session,
          onWeight: () => _pickWeight(context, ref, session),
          onReps: () => _pickReps(context, ref, session),
          onDuration: () => _pickDuration(context, ref, session),
          onAssistance: () => _pickAssistance(context, ref, session),
          onVariation: () => _editVariation(context, ref, session),
          onEquipmentMode: () => _editEquipmentMode(context, ref, session),
        ),
        const SizedBox(height: 12),
        Card(
          child: ListTile(
            leading: const Icon(Icons.history),
            title: const Text('前回記録'),
            subtitle: Text(exercise.previousPerformanceText),
          ),
        ),
        if (view.message != null) ...<Widget>[
          const SizedBox(height: 12),
          Text(
            view.message!,
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
        ],
        const SizedBox(height: 24),
        SizedBox(
          height: 64,
          child: FilledButton.icon(
            onPressed: view.isSaving
                ? null
                : () async {
                    await ref.read(workoutSessionProvider.notifier).completeSet();
                  },
            icon: const Icon(Icons.check_circle_outline),
            label: Text(view.isSaving ? '保存中…' : 'セット完了'),
          ),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: view.isSaving
              ? null
              : () => _showOtherActions(context, ref, session),
          icon: const Icon(Icons.more_horiz),
          label: const Text('その他の操作'),
        ),
      ],
    );
  }
}

final class _SetInputCard extends StatelessWidget {
  const _SetInputCard({
    required this.session,
    required this.onWeight,
    required this.onReps,
    required this.onDuration,
    required this.onAssistance,
    required this.onVariation,
    required this.onEquipmentMode,
  });

  final WorkoutExecutionState session;
  final VoidCallback onWeight;
  final VoidCallback onReps;
  final VoidCallback onDuration;
  final VoidCallback onAssistance;
  final VoidCallback onVariation;
  final VoidCallback onEquipmentMode;

  @override
  Widget build(BuildContext context) {
    final exercise = session.currentExercise!;
    final input = session.currentInput;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: <Widget>[
            if (exercise.requiresEquipmentMode)
              _InputRow(
                label: '器具・実施モード',
                value: input.equipmentModeCode?.trim().isEmpty ?? true
                    ? '未設定'
                    : input.equipmentModeCode!,
                onTap: onEquipmentMode,
              ),
            if (exercise.requiresVariation)
              _InputRow(
                label: exercise.recordingMethodCode == 'BAND_STEPS'
                    ? 'バンド設定'
                    : 'バリエーション',
                value: input.variationCode?.trim().isEmpty ?? true
                    ? '未設定'
                    : input.variationCode!,
                onTap: onVariation,
              ),
            if (exercise.supportsWeight)
              _InputRow(
                label: '重量',
                value: input.weightValue == null
                    ? '自重・未設定'
                    : '${_trim(input.weightValue!)}${_unitLabel(input.weightUnitCode)}',
                onTap: onWeight,
              ),
            if (exercise.recordsDuration)
              _InputRow(
                label: '時間',
                value: input.durationSec == null ? '未設定' : '${input.durationSec}秒',
                onTap: onDuration,
              ),
            if (exercise.recordsRepetitions)
              _InputRow(
                label: '回数',
                value: input.reps == null ? '未設定' : '${input.reps}回',
                onTap: onReps,
              ),
            if (exercise.requiresAssistance)
              _InputRow(
                label: '補助量・設定値',
                value: input.assistanceValue == null
                    ? '未設定'
                    : _trim(input.assistanceValue!),
                onTap: onAssistance,
              ),
          ],
        ),
      ),
    );
  }
}

final class _InputRow extends StatelessWidget {
  const _InputRow({required this.label, required this.value, required this.onTap});
  final String label;
  final String value;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(label),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(value, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(width: 4),
          const Icon(Icons.unfold_more),
        ],
      ),
      onTap: onTap,
    );
  }
}

final class _RestView extends ConsumerWidget {
  const _RestView({required this.view});

  final WorkoutSessionViewState view;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = view.session!;
    final rest = session.rest!;
    final remaining = view.restRemainingSeconds;
    final minutes = remaining ~/ 60;
    final seconds = remaining % 60;
    final nextLabel = rest.isLastExercise
        ? '終了後の記録へ'
        : rest.isLastSetOfExercise
            ? '次の種目へ'
            : '次のセットへ';
    return ListView(
      padding: const EdgeInsets.all(20),
      children: <Widget>[
        Text('休憩', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 24),
        Center(
          child: Text(
            '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}',
            style: Theme.of(context).textTheme.displayLarge?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
        ),
        const SizedBox(height: 20),
        Card(
          child: ListTile(
            title: const Text('完了したセット'),
            subtitle: Text(rest.completedSetSummary),
          ),
        ),
        TextButton(
          onPressed: view.isSaving ? null : () => _editLastSet(context, ref, session),
          child: const Text('最後のセットを修正'),
        ),
        const SizedBox(height: 12),
        Row(
          children: <Widget>[
            Expanded(
              child: OutlinedButton(
                onPressed: view.isSaving
                    ? null
                    : () => ref.read(workoutSessionProvider.notifier).changeRest(-15),
                child: const Text('−15秒'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton(
                onPressed: view.isSaving
                    ? null
                    : () => ref.read(workoutSessionProvider.notifier).changeRest(15),
                child: const Text('＋15秒'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (remaining > 0)
          FilledButton(
            onPressed: view.isSaving
                ? null
                : () => ref
                    .read(workoutSessionProvider.notifier)
                    .changeRest(-remaining),
            child: const Text('休憩を終了する'),
          )
        else
          FilledButton(
            onPressed: view.isSaving
                ? null
                : () async {
                    await ref
                        .read(workoutSessionProvider.notifier)
                        .finishRestAndAdvance();
                  },
            child: Text(nextLabel),
          ),
        if (rest.nextExerciseName != null) ...<Widget>[
          const SizedBox(height: 12),
          Text('次：${rest.nextExerciseName}', textAlign: TextAlign.center),
        ],
        if (view.message != null) ...<Widget>[
          const SizedBox(height: 12),
          Text(
            view.message!,
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
        ],
      ],
    );
  }
}

Future<void> _pickWeight(
  BuildContext context,
  WidgetRef ref,
  WorkoutExecutionState session,
) async {
  final weights = await ref.read(workoutSessionProvider.notifier).availableWeights();
  if (!context.mounted) return;
  if (weights.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('この種目で使用できる登録重量がありません。')),
    );
    return;
  }
  final selected = await showWorkoutNumberPicker<double>(
    context: context,
    title: '重量',
    values: weights,
    initialValue: session.currentInput.weightValue,
    labelBuilder: (double value) => '${_trim(value)}kg',
  );
  if (selected != null) {
    await ref.read(workoutSessionProvider.notifier).updateInput(
          (value) => value.copyWith(weightValue: selected, weightUnitCode: 'KG'),
        );
  }
}

Future<void> _pickReps(
  BuildContext context,
  WidgetRef ref,
  WorkoutExecutionState session,
) async {
  final values = List<int>.generate(101, (int index) => index);
  final selected = await showWorkoutNumberPicker<int>(
    context: context,
    title: '回数',
    values: values,
    initialValue: session.currentInput.reps,
    labelBuilder: (int value) => '$value回',
  );
  if (selected != null) {
    await ref.read(workoutSessionProvider.notifier).updateInput(
          (value) => value.copyWith(reps: selected),
        );
  }
}

Future<void> _pickDuration(
  BuildContext context,
  WidgetRef ref,
  WorkoutExecutionState session,
) async {
  final values = List<int>.generate(121, (int index) => index * 5);
  final selected = await showWorkoutNumberPicker<int>(
    context: context,
    title: '実施時間',
    values: values,
    initialValue: session.currentInput.durationSec,
    labelBuilder: (int value) => '$value秒',
  );
  if (selected != null) {
    await ref.read(workoutSessionProvider.notifier).updateInput(
          (value) => value.copyWith(durationSec: selected),
        );
  }
}

Future<void> _pickAssistance(
  BuildContext context,
  WidgetRef ref,
  WorkoutExecutionState session,
) async {
  final registered =
      await ref.read(workoutSessionProvider.notifier).availableWeights();
  if (!context.mounted) return;
  final values = registered.isNotEmpty
      ? registered
      : List<double>.generate(101, (int index) => index.toDouble());
  final selected = await showWorkoutNumberPicker<double>(
    context: context,
    title: registered.isNotEmpty ? '補助量' : '補助の設定値',
    values: values,
    initialValue: session.currentInput.assistanceValue,
    labelBuilder: (double value) => registered.isNotEmpty
        ? '${_trim(value)}kg'
        : _trim(value),
  );
  if (selected != null) {
    await ref.read(workoutSessionProvider.notifier).updateInput(
          (value) => value.copyWith(assistanceValue: selected),
        );
  }
}

Future<void> _editVariation(
  BuildContext context,
  WidgetRef ref,
  WorkoutExecutionState session,
) async {
  final isBand =
      session.currentExercise?.recordingMethodCode == 'BAND_STEPS';
  final result = await _editShortText(
    context,
    title: isBand ? 'バンド設定' : 'バリエーション',
    hintText: isBand ? '例：赤・ミディアム' : '例：膝つき・台60cm',
    initialValue: session.currentInput.variationCode,
  );
  if (result != null) {
    await ref.read(workoutSessionProvider.notifier).updateInput(
          (value) => value.copyWith(variationCode: result),
        );
  }
}

Future<void> _editEquipmentMode(
  BuildContext context,
  WidgetRef ref,
  WorkoutExecutionState session,
) async {
  final result = await _editShortText(
    context,
    title: '器具・実施モード',
    hintText: '例：ダンベル・ケーブル・マシン',
    initialValue: session.currentInput.equipmentModeCode,
  );
  if (result != null) {
    await ref.read(workoutSessionProvider.notifier).updateInput(
          (value) => value.copyWith(equipmentModeCode: result),
        );
  }
}

Future<String?> _editShortText(
  BuildContext context, {
  required String title,
  required String hintText,
  String? initialValue,
}) async {
  final controller = TextEditingController(text: initialValue ?? '');
  final result = await showDialog<String>(
    context: context,
    builder: (BuildContext context) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: controller,
        autofocus: true,
        maxLength: 30,
        decoration: InputDecoration(hintText: hintText),
      ),
      actions: <Widget>[
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('キャンセル'),
        ),
        FilledButton(
          onPressed: () {
            final value = controller.text.trim();
            if (value.isNotEmpty) Navigator.pop(context, value);
          },
          child: const Text('決定'),
        ),
      ],
    ),
  );
  controller.dispose();
  return result;
}

Future<void> _editLastSet(
  BuildContext context,
  WidgetRef ref,
  WorkoutExecutionState session,
) async {
  final previous = session.currentExercise?.lastActiveRecord;
  if (previous == null) return;
  var input = WorkoutSetInput(
    weightValue: previous.inputWeightValue ?? previous.weightKg,
    weightUnitCode: previous.inputWeightUnitCode ?? 'KG',
    reps: previous.reps,
    durationSec: previous.durationSec,
    assistanceValue: previous.assistanceValue,
    variationCode: previous.variationCode,
    equipmentModeCode: previous.equipmentModeCode,
  );
  final result = await showModalBottomSheet<WorkoutSetInput>(
    context: context,
    useSafeArea: true,
    isScrollControlled: true,
    builder: (BuildContext context) {
      return StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text('最後のセットを修正', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 12),
                if (session.currentExercise?.supportsWeight ?? false)
                  ListTile(
                    title: const Text('重量'),
                    trailing: Text(
                      input.weightValue == null ? '未設定' : '${_trim(input.weightValue!)}kg',
                    ),
                    onTap: () async {
                      final weights = await ref
                          .read(workoutSessionProvider.notifier)
                          .availableWeights();
                      if (!context.mounted || weights.isEmpty) return;
                      final selected = await showWorkoutNumberPicker<double>(
                        context: context,
                        title: '重量',
                        values: weights,
                        initialValue: input.weightValue,
                        labelBuilder: (value) => '${_trim(value)}kg',
                      );
                      if (selected != null) {
                        setState(() => input = input.copyWith(weightValue: selected));
                      }
                    },
                  ),
                ListTile(
                  title: Text(
                    (session.currentExercise?.recordsDuration ?? false)
                        ? '時間'
                        : '回数',
                  ),
                  trailing: Text(
                    (session.currentExercise?.recordsDuration ?? false)
                        ? '${input.durationSec ?? 0}秒'
                        : '${input.reps ?? 0}回',
                  ),
                  onTap: () async {
                    final isDuration =
                        session.currentExercise?.recordsDuration ?? false;
                    final values = isDuration
                        ? List<int>.generate(121, (index) => index * 5)
                        : List<int>.generate(101, (index) => index);
                    final selected = await showWorkoutNumberPicker<int>(
                      context: context,
                      title: isDuration ? '時間' : '回数',
                      values: values,
                      initialValue: isDuration ? input.durationSec : input.reps,
                      labelBuilder: (value) => isDuration ? '$value秒' : '$value回',
                    );
                    if (selected != null) {
                      setState(() {
                        input = isDuration
                            ? input.copyWith(durationSec: selected)
                            : input.copyWith(reps: selected);
                      });
                    }
                  },
                ),
                if (session.currentExercise?.requiresAssistance ?? false)
                  ListTile(
                    title: const Text('補助量・設定値'),
                    trailing: Text(
                      input.assistanceValue == null
                          ? '未設定'
                          : _trim(input.assistanceValue!),
                    ),
                    onTap: () async {
                      final registered = await ref
                          .read(workoutSessionProvider.notifier)
                          .availableWeights();
                      if (!context.mounted) return;
                      final values = registered.isNotEmpty
                          ? registered
                          : List<double>.generate(101, (index) => index.toDouble());
                      final selected = await showWorkoutNumberPicker<double>(
                        context: context,
                        title: '補助量・設定値',
                        values: values,
                        initialValue: input.assistanceValue,
                        labelBuilder: (value) => _trim(value),
                      );
                      if (selected != null) {
                        setState(
                          () => input = input.copyWith(assistanceValue: selected),
                        );
                      }
                    },
                  ),
                if (session.currentExercise?.requiresVariation ?? false)
                  ListTile(
                    title: const Text('バリエーション・バンド設定'),
                    trailing: Text(input.variationCode ?? '未設定'),
                    onTap: () async {
                      final selected = await _editShortText(
                        context,
                        title: 'バリエーション・バンド設定',
                        hintText: '例：膝つき・台60cm・赤',
                        initialValue: input.variationCode,
                      );
                      if (selected != null) {
                        setState(
                          () => input = input.copyWith(variationCode: selected),
                        );
                      }
                    },
                  ),
                if (session.currentExercise?.requiresEquipmentMode ?? false)
                  ListTile(
                    title: const Text('器具・実施モード'),
                    trailing: Text(input.equipmentModeCode ?? '未設定'),
                    onTap: () async {
                      final selected = await _editShortText(
                        context,
                        title: '器具・実施モード',
                        hintText: '例：ダンベル・ケーブル・マシン',
                        initialValue: input.equipmentModeCode,
                      );
                      if (selected != null) {
                        setState(
                          () => input = input.copyWith(equipmentModeCode: selected),
                        );
                      }
                    },
                  ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () => Navigator.of(context).pop(input),
                  child: const Text('修正内容を保存する'),
                ),
              ],
            ),
          );
        },
      );
    },
  );
  if (result != null) {
    await ref.read(workoutSessionProvider.notifier).correctLastSet(result);
  }
}

Future<void> _showOtherActions(
  BuildContext context,
  WidgetRef ref,
  WorkoutExecutionState session,
) async {
  await showModalBottomSheet<void>(
    context: context,
    useSafeArea: true,
    builder: (BuildContext sheetContext) {
      return ListView(
        shrinkWrap: true,
        padding: const EdgeInsets.symmetric(vertical: 12),
        children: <Widget>[
          const ListTile(
            title: Text('その他の操作', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          ListTile(
            leading: const Icon(Icons.swap_horiz),
            title: const Text('種目を変更する'),
            onTap: () {
              Navigator.pop(sheetContext);
              _changeExercise(context, ref);
            },
          ),
          ListTile(
            leading: const Icon(Icons.format_list_numbered),
            title: const Text('セット数を変更する'),
            onTap: () {
              Navigator.pop(sheetContext);
              _changeSetCount(context, ref, session);
            },
          ),
          ListTile(
            leading: const Icon(Icons.low_priority),
            title: const Text('この種目を後へ移動する'),
            onTap: () async {
              Navigator.pop(sheetContext);
              await ref.read(workoutSessionProvider.notifier).moveLater();
            },
          ),
          ListTile(
            leading: const Icon(Icons.skip_next),
            title: const Text('この種目をスキップする'),
            onTap: () {
              Navigator.pop(sheetContext);
              _skipExercise(context, ref);
            },
          ),
          ListTile(
            leading: const Icon(Icons.health_and_safety_outlined),
            title: const Text('痛み・違和感を記録する'),
            onTap: () {
              Navigator.pop(sheetContext);
              _recordPain(context, ref);
            },
          ),
          ListTile(
            leading: const Icon(Icons.stop_circle_outlined),
            title: const Text('途中で終了'),
            onTap: () {
              Navigator.pop(sheetContext);
              _stopEarly(context, ref);
            },
          ),
        ],
      );
    },
  );
}

Future<void> _changeSetCount(
  BuildContext context,
  WidgetRef ref,
  WorkoutExecutionState session,
) async {
  final current = session.currentExercise;
  if (current == null) return;
  final minimum = (current.completedWorkSetCount + 1).clamp(1, 10) as int;
  final values = List<int>.generate(10 - minimum + 1, (index) => minimum + index);
  final selected = await showWorkoutNumberPicker<int>(
    context: context,
    title: 'セット数',
    values: values,
    initialValue: current.activeWorkSetCount,
    labelBuilder: (value) => '$valueセット',
  );
  if (selected != null) {
    await ref.read(workoutSessionProvider.notifier).changeSetCount(selected);
  }
}

Future<void> _skipExercise(BuildContext context, WidgetRef ref) async {
  final reason = await _chooseCode(
    context,
    title: 'スキップする理由',
    values: const <String, String>{
      'TIME': '時間',
      'FATIGUE': '疲労',
      'PAIN': '痛み',
      'EQUIPMENT': '器具',
      'USER_DECISION': '自分の判断',
    },
  );
  if (reason == null) return;
  await ref.read(workoutSessionProvider.notifier).skip(reason);
}

Future<void> _changeExercise(BuildContext context, WidgetRef ref) async {
  final reason = await _chooseCode(
    context,
    title: '変更する理由',
    values: const <String, String>{
      'PAIN': '痛み',
      'EQUIPMENT_UNAVAILABLE': '器具を使えない',
      'WEIGHT_UNAVAILABLE': '適切な重量がない',
      'TOO_DIFFICULT': '難しい',
      'USER_PREFERENCE': '別の種目を行いたい',
    },
  );
  if (reason == null || !context.mounted) return;
  final alternatives = await ref.read(workoutSessionProvider.notifier).alternatives(reason);
  if (!context.mounted) return;
  if (alternatives.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('条件に合う代替種目がありません。')),
    );
    return;
  }
  final selected = await showModalBottomSheet<WorkoutAlternativeChoice>(
    context: context,
    useSafeArea: true,
    builder: (BuildContext context) {
      return ListView(
        shrinkWrap: true,
        padding: const EdgeInsets.symmetric(vertical: 12),
        children: <Widget>[
          const ListTile(title: Text('代替種目を選ぶ')),
          for (final alternative in alternatives)
            ListTile(
              title: Text(alternative.name),
              subtitle: Text(alternative.reason),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).pop(alternative),
            ),
        ],
      );
    },
  );
  if (selected != null) {
    await ref.read(workoutSessionProvider.notifier).substitute(selected, reason);
  }
}

Future<void> _recordPain(BuildContext context, WidgetRef ref) async {
  final parts = await ref.read(workoutBodyPartsProvider.future);
  if (!context.mounted || parts.isEmpty) return;
  var part = parts.first;
  var action = 'REDUCE_LOAD';
  var worsened = false;
  final saved = await showModalBottomSheet<bool>(
    context: context,
    useSafeArea: true,
    isScrollControlled: true,
    builder: (BuildContext context) {
      return StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text('痛み・違和感', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 12),
                DropdownButtonFormField<WorkoutBodyPartChoice>(
                  value: part,
                  decoration: const InputDecoration(labelText: '部位'),
                  items: parts
                      .map(
                        (value) => DropdownMenuItem(value: value, child: Text(value.name)),
                      )
                      .toList(growable: false),
                  onChanged: (value) {
                    if (value != null) setState(() => part = value);
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: action,
                  decoration: const InputDecoration(labelText: 'この後の対応'),
                  items: const <DropdownMenuItem<String>>[
                    DropdownMenuItem(value: 'REDUCE_LOAD', child: Text('重量を下げる')),
                    DropdownMenuItem(value: 'SUBSTITUTE', child: Text('種目を変更する')),
                    DropdownMenuItem(value: 'SKIP', child: Text('種目をスキップする')),
                    DropdownMenuItem(value: 'STOP', child: Text('トレーニングを終了する')),
                    DropdownMenuItem(value: 'CONTINUE', child: Text('記録して継続する')),
                  ],
                  onChanged: (value) {
                    if (value != null) setState(() => action = value);
                  },
                ),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  value: worsened,
                  title: const Text('開始前より悪化した'),
                  onChanged: (value) => setState(() => worsened = value ?? false),
                ),
                const SizedBox(height: 12),
                FilledButton(
                  onPressed: () => Navigator.of(context).pop(true),
                  child: const Text('記録する'),
                ),
              ],
            ),
          );
        },
      );
    },
  );
  if (saved != true) return;
  await ref.read(workoutSessionProvider.notifier).recordPain(
        bodyPartId: part.id,
        actionCode: action,
        timingCode: 'DURING',
        worsened: worsened,
      );
  if (!context.mounted) return;
  if (action == 'SUBSTITUTE') await _changeExercise(context, ref);
  if (action == 'SKIP') await ref.read(workoutSessionProvider.notifier).skip('PAIN');
  if (action == 'STOP') await _stopEarly(context, ref);
}

Future<void> _stopEarly(BuildContext context, WidgetRef ref) async {
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (BuildContext context) => AlertDialog(
      title: const Text('ここまでを記録して終了しますか？'),
      content: const Text('完了済みのセットは失われません。終了後に未完了理由を記録します。'),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('続ける')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('終了する')),
      ],
    ),
  );
  if (confirmed == true) {
    await ref.read(workoutSessionProvider.notifier).stopEarly();
  }
}

Future<String?> _chooseCode(
  BuildContext context, {
  required String title,
  required Map<String, String> values,
}) {
  return showModalBottomSheet<String>(
    context: context,
    useSafeArea: true,
    builder: (BuildContext context) => ListView(
      shrinkWrap: true,
      padding: const EdgeInsets.symmetric(vertical: 12),
      children: <Widget>[
        ListTile(title: Text(title)),
        for (final entry in values.entries)
          ListTile(
            title: Text(entry.value),
            onTap: () => Navigator.of(context).pop(entry.key),
          ),
      ],
    ),
  );
}

Future<bool> _confirmLeave(BuildContext context) async {
  return await showDialog<bool>(
        context: context,
        builder: (BuildContext context) => AlertDialog(
          title: const Text('トレーニングは保存されています'),
          content: const Text('ホームへ戻っても、未終了トレーニングとして再開できます。'),
          actions: <Widget>[
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('続ける')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ホームへ戻る')),
          ],
        ),
      ) ??
      false;
}

final class _SessionLoadError extends StatelessWidget {
  const _SessionLoadError({required this.onRetry});
  final VoidCallback onRetry;
  @override
  Widget build(BuildContext context) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Text('途中記録を読み込めませんでした。'),
            const SizedBox(height: 12),
            FilledButton(onPressed: onRetry, child: const Text('もう一度試す')),
          ],
        ),
      );
}

final class _SessionMismatch extends StatelessWidget {
  const _SessionMismatch({required this.sessionId, required this.onOpen});
  final String sessionId;
  final VoidCallback onOpen;
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const Text('別の未終了トレーニングがあります。'),
              const SizedBox(height: 12),
              FilledButton(onPressed: onOpen, child: const Text('未終了トレーニングを開く')),
            ],
          ),
        ),
      );
}

String _trim(double value) =>
    value.toStringAsFixed(2).replaceFirst(RegExp(r'\.?0+$'), '');

String _unitLabel(String code) => code.toUpperCase() == 'LB' ? 'lb' : 'kg';
