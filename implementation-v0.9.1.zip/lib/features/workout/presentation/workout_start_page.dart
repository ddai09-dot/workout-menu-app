import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/workout/domain/workout_models.dart';
import 'package:workout_menu_app/features/workout/presentation/workout_notifier.dart';

final class WorkoutStartPage extends ConsumerWidget {
  const WorkoutStartPage({required this.dayPlanId, super.key});

  final String dayPlanId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final summary = ref.watch(workoutLaunchProvider(dayPlanId));
    final sessionState = ref.watch(workoutSessionProvider);
    final busy = sessionState.maybeWhen(
      data: (WorkoutSessionViewState value) => value.isSaving,
      orElse: () => false,
    );
    return Scaffold(
      appBar: AppBar(title: const Text('開始前の確認')),
      body: SafeArea(
        child: summary.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (Object error, StackTrace stackTrace) => _LoadError(
            onRetry: () => ref.invalidate(workoutLaunchProvider(dayPlanId)),
          ),
          data: (WorkoutLaunchSummary value) {
            return ListView(
              padding: const EdgeInsets.all(20),
              children: <Widget>[
                Text(value.focus, style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 8),
                Text(
                  '${value.locationName}・約${value.plannedDurationMin}分・${value.exerciseCount}種目',
                ),
                const SizedBox(height: 20),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: <Widget>[
                        for (final exercise in value.exercises)
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text(exercise.name),
                            subtitle: Text('${exercise.targetPart}・${exercise.workSetCount}セット'),
                          ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.health_and_safety_outlined),
                    title: const Text('痛み・違和感がありますか？'),
                    subtitle: const Text('開始前に調整できます。無理に予定どおり行わないでください。'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => context.push('/workout/start/$dayPlanId/adjust'),
                  ),
                ),
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: busy
                      ? null
                      : () async {
                          try {
                            final session = await ref
                                .read(workoutSessionProvider.notifier)
                                .start(dayPlanId: dayPlanId);
                            if (context.mounted) {
                              context.go('/workout/session/${session.sessionId}');
                            }
                          } catch (_) {
                            if (context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('開始できませんでした。未終了の記録や今日の条件を確認してください。'),
                                ),
                              );
                            }
                          }
                        },
                  child: Text(busy ? '保存中…' : '予定どおり開始する'),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: busy
                      ? null
                      : () => context.push('/workout/start/$dayPlanId/adjust'),
                  child: const Text('今日の状態を調整'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

final class _LoadError extends StatelessWidget {
  const _LoadError({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Text('今日のメニューを読み込めませんでした。'),
            const SizedBox(height: 16),
            FilledButton(onPressed: onRetry, child: const Text('もう一度試す')),
          ],
        ),
      ),
    );
  }
}
