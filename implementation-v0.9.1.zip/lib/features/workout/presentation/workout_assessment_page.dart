import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/home/presentation/today_action_notifier.dart';
import 'package:workout_menu_app/features/weekly_planner/presentation/weekly_planner_notifier.dart';
import 'package:workout_menu_app/features/workout/domain/workout_models.dart';
import 'package:workout_menu_app/features/workout/presentation/workout_notifier.dart';

final class WorkoutAssessmentPage extends ConsumerStatefulWidget {
  const WorkoutAssessmentPage({required this.sessionId, super.key});

  final String sessionId;

  @override
  ConsumerState<WorkoutAssessmentPage> createState() =>
      _WorkoutAssessmentPageState();
}

final class _WorkoutAssessmentPageState
    extends ConsumerState<WorkoutAssessmentPage> {
  int _difficulty = 3;
  bool _hadPain = false;
  String? _painBodyPartId;
  String? _painExerciseId;
  String? _incompleteReason;
  bool _saving = false;

  @override
  Widget build(BuildContext context) {
    final value = ref.watch(workoutSessionProvider);
    final bodyParts = ref.watch(workoutBodyPartsProvider);
    return PopScope(
      canPop: false,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const Text('終了後の記録'),
        ),
        body: SafeArea(
          child: value.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (Object error, StackTrace stackTrace) => const Center(
              child: Text('終了記録を読み込めませんでした。'),
            ),
            data: (WorkoutSessionViewState view) {
              final session = view.session;
              if (session == null || session.sessionId != widget.sessionId) {
                return const Center(child: Text('対象のトレーニングがありません。'));
              }
              final effectiveEnd = session.endedAt ?? DateTime.now();
              final duration = effectiveEnd.difference(session.startedAt).inMinutes;
              return ListView(
                padding: const EdgeInsets.all(20),
                children: <Widget>[
                  Text('今回の結果', style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: <Widget>[
                          _SummaryRow(label: '実施時間', value: '約${duration < 0 ? 0 : duration}分'),
                          _SummaryRow(
                            label: '完了種目',
                            value: '${session.completedExerciseCount}/${session.exercises.where((value) => value.statusCode != 'SKIPPED').length}',
                          ),
                          _SummaryRow(
                            label: '完了セット',
                            value: '${session.completedWorkSetCount}/${session.plannedWorkSetCount}',
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text('全体のきつさ', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 8),
                  SegmentedButton<int>(
                    segments: List<ButtonSegment<int>>.generate(
                      5,
                      (index) => ButtonSegment<int>(
                        value: index + 1,
                        label: Text('${index + 1}'),
                      ),
                    ),
                    selected: <int>{_difficulty},
                    onSelectionChanged: (value) {
                      setState(() => _difficulty = value.first);
                    },
                  ),
                  const SizedBox(height: 24),
                  Text('痛み・違和感', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 8),
                  SegmentedButton<bool>(
                    segments: const <ButtonSegment<bool>>[
                      ButtonSegment<bool>(value: false, label: Text('なし')),
                      ButtonSegment<bool>(value: true, label: Text('あり')),
                    ],
                    selected: <bool>{_hadPain},
                    onSelectionChanged: (value) {
                      setState(() {
                        _hadPain = value.first;
                        if (!_hadPain) {
                          _painBodyPartId = null;
                          _painExerciseId = null;
                        }
                      });
                    },
                  ),
                  if (_hadPain) ...<Widget>[
                    const SizedBox(height: 12),
                    bodyParts.when(
                      loading: () => const LinearProgressIndicator(),
                      error: (Object error, StackTrace stackTrace) => const Text('部位を読み込めませんでした。'),
                      data: (List<WorkoutBodyPartChoice> values) {
                        return DropdownButtonFormField<String>(
                          value: _painBodyPartId,
                          decoration: const InputDecoration(labelText: '痛みがあった部位'),
                          items: values
                              .map(
                                (value) => DropdownMenuItem<String>(
                                  value: value.id,
                                  child: Text(value.name),
                                ),
                              )
                              .toList(growable: false),
                          onChanged: (value) => setState(() => _painBodyPartId = value),
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: _painExerciseId,
                      decoration: const InputDecoration(labelText: '関連した種目（任意）'),
                      items: session.exercises
                          .map(
                            (value) => DropdownMenuItem<String>(
                              value: value.sessionExerciseId,
                              child: Text(value.name),
                            ),
                          )
                          .toList(growable: false),
                      onChanged: (value) => setState(() => _painExerciseId = value),
                    ),
                  ],
                  if (session.hasIncompleteWork) ...<Widget>[
                    const SizedBox(height: 24),
                    Text('未完了の理由', style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<String>(
                      value: _incompleteReason,
                      decoration: const InputDecoration(labelText: '理由を選択'),
                      items: const <DropdownMenuItem<String>>[
                        DropdownMenuItem(value: 'TIME', child: Text('時間')),
                        DropdownMenuItem(value: 'FATIGUE', child: Text('疲労')),
                        DropdownMenuItem(value: 'PAIN', child: Text('痛み')),
                        DropdownMenuItem(value: 'EQUIPMENT', child: Text('器具')),
                        DropdownMenuItem(value: 'USER_DECISION', child: Text('自分の判断')),
                      ],
                      onChanged: (value) => setState(() => _incompleteReason = value),
                    ),
                  ],
                  if (view.message != null) ...<Widget>[
                    const SizedBox(height: 16),
                    Text(
                      view.message!,
                      style: TextStyle(color: Theme.of(context).colorScheme.error),
                    ),
                  ],
                  const SizedBox(height: 28),
                  FilledButton(
                    onPressed: _saving ? null : () => _finish(context, session),
                    child: Text(_saving ? '記録を保存中…' : '記録して終了'),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Future<void> _finish(
    BuildContext context,
    WorkoutExecutionState session,
  ) async {
    if (_hadPain && _painBodyPartId == null) {
      _showMessage('痛みがあった部位を選択してください。');
      return;
    }
    if (session.hasIncompleteWork && _incompleteReason == null) {
      _showMessage('未完了の理由を選択してください。');
      return;
    }
    setState(() => _saving = true);
    final saved = await ref.read(workoutSessionProvider.notifier).finishAssessment(
          WorkoutAssessmentDraft(
            difficultyScore: _difficulty,
            hadPain: _hadPain,
            painBodyPartId: _painBodyPartId,
            painSessionExerciseId: _painExerciseId,
            incompleteReasonCode: _incompleteReason,
          ),
        );
    if (!mounted) return;
    setState(() => _saving = false);
    if (saved) {
      ref.invalidate(todayActionProvider);
      ref.invalidate(weeklyPlannerProvider);
      context.go('/home');
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

final class _SummaryRow extends StatelessWidget {
  const _SummaryRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: <Widget>[
          Expanded(child: Text(label)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
