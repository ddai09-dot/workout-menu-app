import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/database/providers/database_providers.dart';
import 'package:workout_menu_app/features/progression/presentation/progression_notifier.dart';
import 'package:workout_menu_app/features/records/presentation/records_notifier.dart';
import 'package:workout_menu_app/features/workout/data/local_workout_repository.dart';
import 'package:workout_menu_app/features/workout/domain/workout_models.dart';
import 'package:workout_menu_app/features/workout/domain/workout_repository.dart';

final workoutRepositoryProvider = Provider<WorkoutRepository>((ref) {
  return LocalWorkoutRepository(ref.watch(appDatabaseProvider));
});

final workoutLaunchProvider = FutureProvider.family<WorkoutLaunchSummary, String>(
  (ref, String dayPlanId) {
    return ref.watch(workoutRepositoryProvider).loadLaunchSummary(dayPlanId);
  },
);

final workoutBodyPartsProvider = FutureProvider<List<WorkoutBodyPartChoice>>(
  (ref) => ref.watch(workoutRepositoryProvider).loadBodyParts(),
);

final workoutSessionProvider =
    AsyncNotifierProvider<WorkoutSessionNotifier, WorkoutSessionViewState>(
  WorkoutSessionNotifier.new,
);

final class WorkoutSessionViewState {
  const WorkoutSessionViewState({
    required this.now,
    this.session,
    this.isSaving = false,
    this.message,
  });

  final DateTime now;
  final WorkoutExecutionState? session;
  final bool isSaving;
  final String? message;

  int get restRemainingSeconds =>
      session?.rest?.remainingSecondsAt(now) ?? 0;

  WorkoutSessionViewState copyWith({
    DateTime? now,
    Object? session = _unset,
    bool? isSaving,
    Object? message = _unset,
  }) {
    return WorkoutSessionViewState(
      now: now ?? this.now,
      session: identical(session, _unset)
          ? this.session
          : session as WorkoutExecutionState?,
      isSaving: isSaving ?? this.isSaving,
      message: identical(message, _unset) ? this.message : message as String?,
    );
  }
}

const Object _unset = Object();

final class WorkoutSessionNotifier extends AsyncNotifier<WorkoutSessionViewState> {
  Timer? _ticker;
  Future<void> _inputSaveQueue = Future<void>.value();
  int _inputRevision = 0;

  @override
  Future<WorkoutSessionViewState> build() async {
    _ticker ??= Timer.periodic(const Duration(seconds: 1), (_) {
      final current = _current;
      if (current?.session?.isResting ?? false) {
        state = AsyncData<WorkoutSessionViewState>(
          current!.copyWith(now: DateTime.now()),
        );
      }
    });
    ref.onDispose(() {
      _ticker?.cancel();
      _ticker = null;
    });
    final open = await ref.watch(workoutRepositoryProvider).loadOpenSession();
    return WorkoutSessionViewState(now: DateTime.now(), session: open);
  }

  WorkoutSessionViewState? get _current => state.when(
        data: (WorkoutSessionViewState value) => value,
        loading: () => null,
        error: (Object error, StackTrace stackTrace) => null,
      );

  Future<WorkoutExecutionState> start({
    required String dayPlanId,
    WorkoutStartAdjustment? adjustment,
  }) async {
    final current = _current ?? WorkoutSessionViewState(now: DateTime.now());
    if (current.isSaving) {
      throw StateError('Workout start is already being saved.');
    }
    state = AsyncData<WorkoutSessionViewState>(
      current.copyWith(isSaving: true, message: null),
    );
    try {
      final session = await ref.read(workoutRepositoryProvider).startSession(
            dayPlanId: dayPlanId,
            adjustment: adjustment,
          );
      state = AsyncData<WorkoutSessionViewState>(
        WorkoutSessionViewState(now: DateTime.now(), session: session),
      );
      return session;
    } catch (_) {
      state = AsyncData<WorkoutSessionViewState>(
        current.copyWith(
          isSaving: false,
          message: 'トレーニングを開始できませんでした。未終了記録や条件を確認してください。',
        ),
      );
      rethrow;
    }
  }

  Future<void> reload() async {
    final current = _current;
    final id = current?.session?.sessionId;
    if (id == null) {
      final open = await ref.read(workoutRepositoryProvider).loadOpenSession();
      state = AsyncData<WorkoutSessionViewState>(
        WorkoutSessionViewState(now: DateTime.now(), session: open),
      );
      return;
    }
    final loaded = await ref.read(workoutRepositoryProvider).loadSession(id);
    state = AsyncData<WorkoutSessionViewState>(
      (current ?? WorkoutSessionViewState(now: DateTime.now())).copyWith(
        session: loaded,
        now: DateTime.now(),
        isSaving: false,
        message: null,
      ),
    );
  }

  Future<void> updateInput(
    WorkoutSetInput Function(WorkoutSetInput value) update,
  ) async {
    final current = _current;
    final session = current?.session;
    if (current == null || session == null || current.isSaving) return;
    final nextInput = update(session.currentInput);
    final nextSession = session.copyWith(currentInput: nextInput);
    state = AsyncData<WorkoutSessionViewState>(
      current.copyWith(session: nextSession, message: null),
    );
    final revision = ++_inputRevision;
    final previous = _inputSaveQueue;
    final save = () async {
      try {
        await previous;
      } catch (_) {
        // The latest value still needs to be persisted after an older failure.
      }
      await ref.read(workoutRepositoryProvider).saveCurrentInput(
            sessionId: session.sessionId,
            input: nextInput,
          );
    }();
    _inputSaveQueue = save;
    try {
      await save;
    } catch (_) {
      if (revision == _inputRevision) {
        final latest = _current;
        if (latest != null) {
          state = AsyncData<WorkoutSessionViewState>(
            latest.copyWith(message: '入力値を端末へ保存できませんでした。もう一度変更してください。'),
          );
        }
      }
    }
  }

  Future<bool> completeSet() async {
    final current = _current;
    final session = current?.session;
    if (current == null || session == null || current.isSaving) return false;
    return _replaceSession(
      () => ref.read(workoutRepositoryProvider).completeCurrentSet(
            sessionId: session.sessionId,
            input: session.currentInput,
          ),
      failureMessage: 'セットを保存できませんでした。入力値は画面に残っています。',
    );
  }

  Future<bool> correctLastSet(WorkoutSetInput input) async {
    final id = _current?.session?.sessionId;
    if (id == null) return false;
    return _replaceSession(
      () => ref.read(workoutRepositoryProvider).updateLastCompletedSet(
            sessionId: id,
            input: input,
          ),
      failureMessage: 'セット記録を修正できませんでした。',
    );
  }

  Future<void> changeRest(int deltaSeconds) async {
    final id = _current?.session?.sessionId;
    if (id == null) return;
    await _replaceSession(
      () => ref.read(workoutRepositoryProvider).changeRestDuration(
            sessionId: id,
            deltaSeconds: deltaSeconds,
          ),
      failureMessage: '休憩時間を変更できませんでした。',
    );
  }

  Future<bool> finishRestAndAdvance() async {
    final id = _current?.session?.sessionId;
    if (id == null) return false;
    return _replaceSession(
      () => ref.read(workoutRepositoryProvider).finishRestAndAdvance(id),
      failureMessage: '次のセットへ進めませんでした。もう一度押してください。',
    );
  }

  Future<void> changeSetCount(int value) async {
    final id = _current?.session?.sessionId;
    if (id == null) return;
    await _replaceSession(
      () => ref.read(workoutRepositoryProvider).changeCurrentSetCount(
            sessionId: id,
            targetSetCount: value,
          ),
      failureMessage: 'セット数を変更できませんでした。',
    );
  }

  Future<bool> moveLater() async {
    final id = _current?.session?.sessionId;
    if (id == null) return false;
    return _replaceSession(
      () => ref.read(workoutRepositoryProvider).moveCurrentExerciseLater(id),
      failureMessage: 'この種目を後へ移動できませんでした。',
    );
  }

  Future<bool> skip(String reasonCode) async {
    final id = _current?.session?.sessionId;
    if (id == null) return false;
    return _replaceSession(
      () => ref.read(workoutRepositoryProvider).skipCurrentExercise(
            sessionId: id,
            reasonCode: reasonCode,
          ),
      failureMessage: '種目をスキップできませんでした。',
    );
  }

  Future<List<double>> availableWeights() async {
    final id = _current?.session?.sessionId;
    if (id == null) return const <double>[];
    return ref.read(workoutRepositoryProvider).loadAvailableWeights(id);
  }

  Future<List<WorkoutAlternativeChoice>> alternatives(String reasonCode) async {
    final id = _current?.session?.sessionId;
    if (id == null) return const <WorkoutAlternativeChoice>[];
    return ref.read(workoutRepositoryProvider).loadAlternatives(
          sessionId: id,
          reasonCode: reasonCode,
        );
  }

  Future<bool> substitute(
    WorkoutAlternativeChoice alternative,
    String reasonCode,
  ) async {
    final id = _current?.session?.sessionId;
    if (id == null) return false;
    return _replaceSession(
      () => ref.read(workoutRepositoryProvider).substituteCurrentExercise(
            sessionId: id,
            alternative: alternative,
            reasonCode: reasonCode,
          ),
      failureMessage: '代替種目へ変更できませんでした。',
    );
  }

  Future<void> recordPain({
    required String bodyPartId,
    required String actionCode,
    required String timingCode,
    required bool worsened,
  }) async {
    final session = _current?.session;
    if (session == null) return;
    try {
      await ref.read(workoutRepositoryProvider).recordPain(
            sessionId: session.sessionId,
            sessionExerciseId: session.currentSessionExerciseId,
            bodyPartId: bodyPartId,
            actionCode: actionCode,
            timingCode: timingCode,
            worsened: worsened,
          );
    } catch (_) {
      final latest = _current;
      if (latest != null) {
        state = AsyncData<WorkoutSessionViewState>(
          latest.copyWith(message: '痛みの記録を保存できませんでした。'),
        );
      }
    }
  }

  Future<bool> stopEarly() async {
    final id = _current?.session?.sessionId;
    if (id == null) return false;
    return _replaceSession(
      () => ref.read(workoutRepositoryProvider).stopEarly(id),
      failureMessage: '途中終了の状態を保存できませんでした。',
    );
  }

  Future<bool> finishAssessment(WorkoutAssessmentDraft assessment) async {
    final current = _current;
    final id = current?.session?.sessionId;
    if (current == null || id == null || current.isSaving) return false;
    state = AsyncData<WorkoutSessionViewState>(
      current.copyWith(isSaving: true, message: null),
    );
    try {
      await ref.read(workoutRepositoryProvider).finishSession(
            sessionId: id,
            assessment: assessment,
          );
      try {
        await ref.read(progressionRepositoryProvider).processCompletedSession(id);
      } catch (_) {
        // The workout completion is authoritative. Evaluation can be retried later.
      }
      ref.invalidate(progressionProposalsProvider);
      ref.invalidate(pendingProposalCountProvider);
      ref.invalidate(recordsDashboardProvider);
      ref.invalidate(workoutHistoryProvider);
      ref.invalidate(exerciseRecordSummariesProvider);
      state = AsyncData<WorkoutSessionViewState>(
        WorkoutSessionViewState(now: DateTime.now()),
      );
      return true;
    } catch (_) {
      final latest = _current ?? current;
      state = AsyncData<WorkoutSessionViewState>(
        latest.copyWith(
          isSaving: false,
          message: '終了記録を保存できませんでした。入力内容は保持されています。',
        ),
      );
      return false;
    }
  }

  Future<bool> _replaceSession(
    Future<WorkoutExecutionState> Function() operation, {
    required String failureMessage,
  }) async {
    final current = _current;
    if (current == null || current.isSaving) return false;
    state = AsyncData<WorkoutSessionViewState>(
      current.copyWith(isSaving: true, message: null),
    );
    try {
      try {
        await _inputSaveQueue;
      } catch (_) {
        // The operation carries the in-memory value or intentionally replaces it.
      }
      final next = await operation();
      state = AsyncData<WorkoutSessionViewState>(
        current.copyWith(
          session: next,
          now: DateTime.now(),
          isSaving: false,
          message: null,
        ),
      );
      return true;
    } catch (_) {
      final latest = _current ?? current;
      state = AsyncData<WorkoutSessionViewState>(
        latest.copyWith(isSaving: false, message: failureMessage),
      );
      return false;
    }
  }
}
