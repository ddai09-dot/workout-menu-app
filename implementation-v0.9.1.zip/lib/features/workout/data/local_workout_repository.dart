import 'dart:convert';
import 'dart:math' as math;

import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/workout/domain/workout_models.dart';
import 'package:workout_menu_app/features/workout/domain/workout_repository.dart';

final class LocalWorkoutRepository implements WorkoutRepository {
  const LocalWorkoutRepository(
    this._database, {
    IdGenerator idGenerator = const UuidV7Generator(),
  }) : _idGenerator = idGenerator;

  final AppDatabase _database;
  final IdGenerator _idGenerator;

  @override
  Future<WorkoutLaunchSummary> loadLaunchSummary(String dayPlanId) async {
    final dayRows = await _database.customSelect(
      '''
      SELECT wdp.id, wdp.plan_date, wdp.session_focus_snapshot,
             wdp.duration_min, wdp.estimated_duration_min,
             wdp.training_location_id,
             COALESCE(tl.display_name, '場所未設定') AS location_name
      FROM workout_day_plan wdp
      JOIN weekly_menu wm ON wm.id = wdp.weekly_menu_id
      LEFT JOIN training_location tl ON tl.id = wdp.training_location_id
      WHERE wdp.id = ?
        AND wdp.deleted_at IS NULL
        AND wm.deleted_at IS NULL
        AND wm.is_active = 1
        AND wm.status_code = 'FINALIZED'
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(dayPlanId)],
    ).get();
    if (dayRows.isEmpty) {
      throw StateError('The selected workout day is not available.');
    }
    final day = dayRows.first;
    final exerciseRows = await _database.customSelect(
      '''
      SELECT pe.id AS planned_exercise_id, pe.exercise_id,
             pe.exercise_name_snapshot, pe.target_part_snapshot,
             pe.reason_text_snapshot,
             SUM(CASE WHEN ps.is_warmup = 0 THEN 1 ELSE 0 END) AS work_set_count
      FROM planned_exercise pe
      LEFT JOIN planned_set ps
        ON ps.planned_exercise_id = pe.id AND ps.deleted_at IS NULL
      WHERE pe.workout_day_plan_id = ?
        AND pe.deleted_at IS NULL
        AND pe.status_code <> 'SKIPPED'
      GROUP BY pe.id, pe.exercise_id, pe.exercise_name_snapshot,
               pe.target_part_snapshot, pe.reason_text_snapshot, pe.order_index
      ORDER BY pe.order_index
      ''',
      variables: <Variable<Object>>[Variable.withString(dayPlanId)],
    ).get();
    final locationRows = await _database.customSelect(
      '''
      SELECT id, display_name, location_type_code
      FROM training_location
      WHERE user_id = (
        SELECT user_id FROM workout_day_plan WHERE id = ? LIMIT 1
      )
        AND deleted_at IS NULL
      ORDER BY is_primary DESC, display_name
      ''',
      variables: <Variable<Object>>[Variable.withString(dayPlanId)],
    ).get();
    return WorkoutLaunchSummary(
      dayPlanId: day.read<String>('id'),
      planDate: DateTime.parse(day.read<String>('plan_date')),
      focus: day.read<String>('session_focus_snapshot'),
      locationId: day.readNullable<String>('training_location_id'),
      locationName: day.read<String>('location_name'),
      plannedDurationMin: math.max(
        1,
        day.read<int>('estimated_duration_min') == 0
            ? day.read<int>('duration_min')
            : day.read<int>('estimated_duration_min'),
      ),
      exercises: exerciseRows
          .map(
            (QueryRow row) => WorkoutLaunchExercise(
              plannedExerciseId: row.read<String>('planned_exercise_id'),
              exerciseId: row.read<String>('exercise_id'),
              name: row.read<String>('exercise_name_snapshot'),
              targetPart: row.read<String>('target_part_snapshot'),
              workSetCount: row.read<int>('work_set_count'),
              reason: row.read<String>('reason_text_snapshot'),
            ),
          )
          .toList(growable: false),
      availableLocations: locationRows
          .map(
            (QueryRow row) => WorkoutLocationChoice(
              id: row.read<String>('id'),
              name: row.read<String>('display_name'),
              typeCode: row.read<String>('location_type_code'),
            ),
          )
          .toList(growable: false),
    );
  }

  @override
  Future<WorkoutExecutionState?> loadOpenSession() async {
    final rows = await _database.customSelect(
      '''
      SELECT id
      FROM workout_session
      WHERE deleted_at IS NULL
        AND status_code IN ('IN_PROGRESS', 'AWAITING_ASSESSMENT')
      ORDER BY last_interaction_at DESC, last_local_saved_at DESC
      LIMIT 1
      ''',
    ).get();
    if (rows.isEmpty) return null;
    return loadSession(rows.first.read<String>('id'));
  }

  @override
  Future<WorkoutExecutionState> startSession({
    required String dayPlanId,
    WorkoutStartAdjustment? adjustment,
  }) async {
    final open = await loadOpenSession();
    if (open != null) {
      if (open.dayPlanId != dayPlanId) {
        throw StateError('Finish the open workout before starting another one.');
      }
      return open;
    }
    final summary = await loadLaunchSummary(dayPlanId);
    final metadataRows = await _database.customSelect(
      '''
      SELECT wdp.user_id, wdp.rule_version_id, wdp.training_location_id
      FROM workout_day_plan wdp
      WHERE wdp.id = ? AND wdp.deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(dayPlanId)],
    ).get();
    if (metadataRows.isEmpty) throw StateError('Workout day is missing.');
    final metadata = metadataRows.first;
    final userId = metadata.read<String>('user_id');
    final ruleVersionId = metadata.read<String>('rule_version_id');
    final locationId = adjustment?.locationId ??
        metadata.readNullable<String>('training_location_id');
    final now = DateTime.now();
    final nowText = now.toUtc().toIso8601String();
    final sessionId = _idGenerator.next();
    final exerciseSeeds = await _loadStartExerciseSeeds(dayPlanId);
    await _applyStartAdjustments(
      exerciseSeeds,
      summary: summary,
      adjustment: adjustment,
      locationId: locationId,
    );
    final availableSeeds = exerciseSeeds
        .where((value) => !value.skipped && value.targets.isNotEmpty)
        .toList(growable: false);
    final first = availableSeeds.isEmpty ? null : availableSeeds.first;
    if (first == null) {
      throw StateError('No exercise can be performed with the selected conditions.');
    }

    await _database.transaction(() async {
      await _database.customStatement(
        '''
        INSERT INTO workout_session (
          id, user_id, rule_version_id, workout_day_plan_id,
          attempt_number, status_code, started_at, record_date,
          training_location_id, current_session_exercise_id,
          current_set_number, rest_started_at, rest_duration_sec,
          last_local_saved_at, day_adjustment_snapshot_json,
          current_input_draft_json, last_interaction_at,
          created_at, updated_at, sync_status
        ) VALUES (?, ?, ?, ?, 1, 'IN_PROGRESS', ?, ?, ?, ?, 1,
                  NULL, NULL, ?, ?, '{}', ?, ?, ?, 'LOCAL_ONLY')
        ''',
        <Object?>[
          sessionId,
          userId,
          ruleVersionId,
          dayPlanId,
          nowText,
          _dateOnly(now),
          locationId,
          first.sessionExerciseId,
          nowText,
          jsonEncode(adjustment?.toJson() ?? <String, Object?>{
            'availableDurationMin': summary.plannedDurationMin,
            'fatigueScore': 3,
            'locationId': locationId,
            'painEntries': <Object?>[],
          }),
          nowText,
          nowText,
          nowText,
        ],
      );
      for (final seed in exerciseSeeds) {
        await _database.customStatement(
          '''
          INSERT INTO session_exercise (
            id, user_id, rule_version_id, workout_session_id,
            planned_exercise_id, exercise_id, order_index, status_code,
            exercise_name_snapshot, recording_method_snapshot,
            performance_series_key, substitution_reason_code,
            skip_reason_code, started_at, ended_at,
            original_order_index, original_set_count, target_set_count,
            created_at, updated_at, sync_status
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'LOCAL_ONLY')
          ''',
          <Object?>[
            seed.sessionExerciseId,
            userId,
            ruleVersionId,
            sessionId,
            seed.plannedExerciseId,
            seed.exerciseId,
            seed.orderIndex,
            seed.skipped
                ? 'SKIPPED'
                : seed.sessionExerciseId == first.sessionExerciseId
                    ? 'IN_PROGRESS'
                    : 'PLANNED',
            seed.name,
            seed.recordingMethodCode,
            seed.performanceSeriesKey,
            seed.substitutionReasonCode,
            seed.skipReasonCode,
            seed.sessionExerciseId == first.sessionExerciseId ? nowText : null,
            seed.skipped ? nowText : null,
            seed.originalOrderIndex,
            seed.originalSetCount,
            seed.targets.where((value) => !value.isWarmup).length,
            nowText,
            nowText,
          ],
        );
        for (final target in seed.targets) {
          await _insertSessionTarget(
            userId: userId,
            ruleVersionId: ruleVersionId,
            sessionExerciseId: seed.sessionExerciseId,
            target: target,
            nowText: nowText,
          );
        }
      }
      await _database.customStatement(
        '''
        UPDATE workout_day_plan
        SET status_code = 'IN_PROGRESS', updated_at = ?,
            row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
        WHERE id = ?
        ''',
        <Object?>[nowText, dayPlanId],
      );
      await _insertEvent(
        userId: userId,
        sessionId: sessionId,
        eventType: 'SESSION_STARTED',
        payload: adjustment?.toJson() ?? <String, Object?>{},
        occurredAt: nowText,
      );
    });
    final loaded = await loadSession(sessionId);
    final initialInput = WorkoutSetInput.fromTarget(loaded.currentTarget);
    await saveCurrentInput(sessionId: sessionId, input: initialInput);
    return loadSession(sessionId);
  }

  @override
  Future<WorkoutExecutionState> loadSession(String sessionId) async {
    final sessionRows = await _database.customSelect(
      '''
      SELECT ws.*, wdp.session_focus_snapshot,
             COALESCE(tl.display_name, '場所未設定') AS location_name
      FROM workout_session ws
      LEFT JOIN workout_day_plan wdp ON wdp.id = ws.workout_day_plan_id
      LEFT JOIN training_location tl ON tl.id = ws.training_location_id
      WHERE ws.id = ? AND ws.deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(sessionId)],
    ).get();
    if (sessionRows.isEmpty) throw StateError('Workout session was not found.');
    final session = sessionRows.first;
    final exerciseRows = await _database.customSelect(
      '''
      SELECT se.*, COALESCE(pe.target_part_snapshot, '') AS target_part_snapshot
      FROM session_exercise se
      LEFT JOIN planned_exercise pe ON pe.id = se.planned_exercise_id
      WHERE se.workout_session_id = ? AND se.deleted_at IS NULL
      ORDER BY se.order_index
      ''',
      variables: <Variable<Object>>[Variable.withString(sessionId)],
    ).get();
    final exercises = <WorkoutSessionExercise>[];
    for (final row in exerciseRows) {
      final sessionExerciseId = row.read<String>('id');
      final targets = await _loadTargets(sessionExerciseId);
      final records = await _loadRecords(sessionExerciseId);
      exercises.add(
        WorkoutSessionExercise(
          sessionExerciseId: sessionExerciseId,
          plannedExerciseId: row.readNullable<String>('planned_exercise_id'),
          exerciseId: row.read<String>('exercise_id'),
          name: row.read<String>('exercise_name_snapshot'),
          recordingMethodCode: row.read<String>('recording_method_snapshot'),
          performanceSeriesKey: row.read<String>('performance_series_key'),
          targetPart: row.read<String>('target_part_snapshot'),
          orderIndex: row.read<int>('order_index'),
          originalOrderIndex: row.read<int>('original_order_index'),
          originalSetCount: row.read<int>('original_set_count'),
          targetSetCount: row.read<int>('target_set_count'),
          statusCode: row.read<String>('status_code'),
          substitutionReasonCode:
              row.readNullable<String>('substitution_reason_code'),
          skipReasonCode: row.readNullable<String>('skip_reason_code'),
          targets: targets,
          records: records,
          previousPerformanceText: await _loadPreviousPerformance(
            userId: session.read<String>('user_id'),
            exerciseId: row.read<String>('exercise_id'),
            excludeSessionId: sessionId,
          ),
        ),
      );
    }
    var input = WorkoutSetInput.fromJsonText(
      session.read<String>('current_input_draft_json'),
    );
    final currentId = session.readNullable<String>('current_session_exercise_id');
    final currentNumber = session.readNullable<int>('current_set_number');
    WorkoutSessionSetTarget? currentTarget;
    if (currentId != null && currentNumber != null) {
      for (final exercise in exercises) {
        if (exercise.sessionExerciseId != currentId) continue;
        for (final target in exercise.targets) {
          if (target.setNumber == currentNumber && target.deletedAt == null) {
            currentTarget = target;
            break;
          }
        }
      }
    }
    if (session.read<String>('current_input_draft_json') == '{}') {
      input = WorkoutSetInput.fromTarget(currentTarget);
    }

    WorkoutRestState? rest;
    final restStartText = session.readNullable<String>('rest_started_at');
    final restDuration = session.readNullable<int>('rest_duration_sec');
    if (restStartText != null && restDuration != null && currentId != null) {
      final currentExercise = exercises.firstWhere(
        (value) => value.sessionExerciseId == currentId,
      );
      final currentRecord = currentExercise.lastActiveRecord;
      final nextExercise = _nextActiveExercise(exercises, currentExercise.orderIndex);
      rest = WorkoutRestState(
        startedAt: DateTime.parse(restStartText),
        durationSec: restDuration,
        completedSetSummary: currentRecord?.summaryText ?? 'セット完了',
        isLastSetOfExercise:
            currentExercise.completedWorkSetCount >= currentExercise.activeWorkSetCount,
        isLastExercise: nextExercise == null,
        nextExerciseName: nextExercise?.name,
      );
    }
    return WorkoutExecutionState(
      sessionId: sessionId,
      dayPlanId: session.readNullable<String>('workout_day_plan_id') ?? '',
      statusCode: session.read<String>('status_code'),
      startedAt: DateTime.parse(session.read<String>('started_at')),
      endedAt: _parseNullable(session.readNullable<String>('ended_at')),
      recordDate: DateTime.parse(session.read<String>('record_date')),
      focus: session.readNullable<String>('session_focus_snapshot') ?? 'トレーニング',
      locationName: session.read<String>('location_name'),
      currentSessionExerciseId: currentId,
      currentSetNumber: currentNumber,
      exercises: exercises,
      currentInput: input,
      rest: rest,
      completionReasonCode:
          session.readNullable<String>('completion_reason_code'),
    );
  }

  @override
  Future<void> saveCurrentInput({
    required String sessionId,
    required WorkoutSetInput input,
  }) async {
    final now = DateTime.now().toUtc().toIso8601String();
    await _database.customStatement(
      '''
      UPDATE workout_session
      SET current_input_draft_json = ?, last_local_saved_at = ?,
          last_interaction_at = ?, updated_at = ?, row_version = row_version + 1,
          sync_status = 'LOCAL_ONLY'
      WHERE id = ? AND status_code = 'IN_PROGRESS' AND deleted_at IS NULL
      ''',
      <Object?>[input.toJsonText(), now, now, now, sessionId],
    );
  }

  @override
  Future<WorkoutExecutionState> completeCurrentSet({
    required String sessionId,
    required WorkoutSetInput input,
  }) async {
    final state = await loadSession(sessionId);
    if (state.statusCode != 'IN_PROGRESS' || state.isResting) {
      throw StateError('The current set cannot be completed now.');
    }
    final exercise = state.currentExercise;
    final target = state.currentTarget;
    if (exercise == null || target == null) {
      throw StateError('Current exercise or set is missing.');
    }
    _validateSetInput(exercise.recordingMethodCode, input);
    final now = DateTime.now().toUtc();
    final nowText = now.toIso8601String();
    final userId = await _sessionValue(sessionId, 'user_id');
    final recordId = _idGenerator.next();
    await _database.transaction(() async {
      await _database.customStatement(
        '''
        INSERT INTO work_set_record (
          id, user_id, created_at, updated_at, sync_status,
          session_exercise_id, planned_set_id, set_number, side_code,
          is_warmup, actual_weight_kg, input_weight_value,
          input_weight_unit_code, actual_reps, actual_duration_sec,
          assistance_value, variation_code, equipment_mode_code, completed_at
        ) VALUES (?, ?, ?, ?, 'LOCAL_ONLY', ?, ?, ?, 'BOTH', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''',
        <Object?>[
          recordId,
          userId,
          nowText,
          nowText,
          exercise.sessionExerciseId,
          target.plannedSetId,
          target.setNumber,
          target.isWarmup ? 1 : 0,
          _weightKg(input.weightValue, input.weightUnitCode),
          input.weightValue,
          input.weightUnitCode,
          input.reps,
          input.durationSec,
          input.assistanceValue,
          input.variationCode,
          input.equipmentModeCode,
          nowText,
        ],
      );
      await _database.customStatement(
        '''
        UPDATE workout_session
        SET rest_started_at = ?, rest_duration_sec = ?,
            current_input_draft_json = '{}', last_local_saved_at = ?,
            last_interaction_at = ?, updated_at = ?, row_version = row_version + 1,
            sync_status = 'LOCAL_ONLY'
        WHERE id = ?
        ''',
        <Object?>[
          nowText,
          target.restSec,
          nowText,
          nowText,
          nowText,
          sessionId,
        ],
      );
      await _insertEvent(
        userId: userId,
        sessionId: sessionId,
        sessionExerciseId: exercise.sessionExerciseId,
        eventType: 'SET_COMPLETED',
        payload: <String, Object?>{
          'recordId': recordId,
          'setNumber': target.setNumber,
          'weightValue': input.weightValue,
          'weightUnitCode': input.weightUnitCode,
          'reps': input.reps,
          'durationSec': input.durationSec,
          'assistanceValue': input.assistanceValue,
          'variationCode': input.variationCode,
          'equipmentModeCode': input.equipmentModeCode,
        },
        occurredAt: nowText,
      );
    });
    return loadSession(sessionId);
  }

  @override
  Future<WorkoutExecutionState> updateLastCompletedSet({
    required String sessionId,
    required WorkoutSetInput input,
  }) async {
    final state = await loadSession(sessionId);
    final exercise = state.currentExercise;
    final previous = exercise?.lastActiveRecord;
    if (exercise == null || previous == null) {
      throw StateError('There is no completed set to edit.');
    }
    _validateSetInput(exercise.recordingMethodCode, input);
    final now = DateTime.now().toUtc().toIso8601String();
    final userId = await _sessionValue(sessionId, 'user_id');
    final replacementId = _idGenerator.next();
    await _database.transaction(() async {
      await _database.customStatement(
        '''
        UPDATE work_set_record
        SET voided_at = ?, updated_at = ?, correction_reason_code = 'USER_EDIT'
        WHERE id = ? AND voided_at IS NULL
        ''',
        <Object?>[now, now, previous.id],
      );
      await _database.customStatement(
        '''
        INSERT INTO work_set_record (
          id, user_id, created_at, updated_at, supersedes_id, sync_status,
          session_exercise_id, planned_set_id, set_number, side_code,
          is_warmup, actual_weight_kg, input_weight_value,
          input_weight_unit_code, actual_reps, actual_duration_sec,
          assistance_value, variation_code, equipment_mode_code,
          rest_duration_sec, correction_reason_code, completed_at
        ) SELECT ?, ?, ?, ?, id, 'LOCAL_ONLY', session_exercise_id,
                 planned_set_id, set_number, side_code, is_warmup,
                 ?, ?, ?, ?, ?, ?, ?, ?, rest_duration_sec, 'USER_EDIT', completed_at
          FROM work_set_record WHERE id = ?
        ''',
        <Object?>[
          replacementId,
          userId,
          now,
          now,
          _weightKg(input.weightValue, input.weightUnitCode),
          input.weightValue,
          input.weightUnitCode,
          input.reps,
          input.durationSec,
          input.assistanceValue,
          input.variationCode,
          input.equipmentModeCode,
          previous.id,
        ],
      );
      await _touchSession(sessionId, now);
      await _insertEvent(
        userId: userId,
        sessionId: sessionId,
        sessionExerciseId: exercise.sessionExerciseId,
        eventType: 'SET_CORRECTED',
        payload: <String, Object?>{
          'voidedRecordId': previous.id,
          'replacementRecordId': replacementId,
        },
        occurredAt: now,
      );
    });
    return loadSession(sessionId);
  }

  @override
  Future<WorkoutExecutionState> changeRestDuration({
    required String sessionId,
    required int deltaSeconds,
  }) async {
    final state = await loadSession(sessionId);
    final rest = state.rest;
    if (rest == null) throw StateError('Rest timer is not active.');
    final next = math.max(0, rest.durationSec + deltaSeconds);
    final now = DateTime.now().toUtc().toIso8601String();
    await _database.customStatement(
      '''
      UPDATE workout_session
      SET rest_duration_sec = ?, last_local_saved_at = ?,
          last_interaction_at = ?, updated_at = ?, row_version = row_version + 1,
          sync_status = 'LOCAL_ONLY'
      WHERE id = ?
      ''',
      <Object?>[next, now, now, now, sessionId],
    );
    return loadSession(sessionId);
  }

  @override
  Future<WorkoutExecutionState> finishRestAndAdvance(String sessionId) async {
    final state = await loadSession(sessionId);
    final exercise = state.currentExercise;
    final rest = state.rest;
    if (exercise == null || rest == null) {
      throw StateError('Rest timer is not active.');
    }
    final now = DateTime.now().toUtc();
    final nowText = now.toIso8601String();
    final actualRest = math.max(0, now.difference(rest.startedAt.toUtc()).inSeconds);
    final lastRecord = exercise.lastActiveRecord;
    final userId = await _sessionValue(sessionId, 'user_id');
    await _database.transaction(() async {
      if (lastRecord != null) {
        await _database.customStatement(
          '''
          UPDATE work_set_record
          SET rest_duration_sec = ?, updated_at = ?
          WHERE id = ? AND voided_at IS NULL
          ''',
          <Object?>[actualRest, nowText, lastRecord.id],
        );
      }
      if (exercise.completedWorkSetCount < exercise.activeWorkSetCount) {
        final nextNumber = _nextUncompletedTargetNumber(exercise);
        await _database.customStatement(
          '''
          UPDATE workout_session
          SET current_set_number = ?, rest_started_at = NULL,
              rest_duration_sec = NULL, current_input_draft_json = '{}',
              last_local_saved_at = ?, last_interaction_at = ?, updated_at = ?,
              row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
          WHERE id = ?
          ''',
          <Object?>[nextNumber, nowText, nowText, nowText, sessionId],
        );
      } else {
        await _database.customStatement(
          '''
          UPDATE session_exercise
          SET status_code = 'COMPLETED', ended_at = ?, updated_at = ?,
              row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
          WHERE id = ?
          ''',
          <Object?>[nowText, nowText, exercise.sessionExerciseId],
        );
        final next = _nextActiveExercise(state.exercises, exercise.orderIndex);
        if (next == null) {
          await _database.customStatement(
            '''
            UPDATE workout_session
            SET status_code = 'AWAITING_ASSESSMENT', ended_at = ?,
                current_session_exercise_id = NULL, current_set_number = NULL,
                rest_started_at = NULL, rest_duration_sec = NULL,
                current_input_draft_json = '{}', last_local_saved_at = ?,
                last_interaction_at = ?, updated_at = ?,
                row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
            WHERE id = ?
            ''',
            <Object?>[nowText, nowText, nowText, nowText, sessionId],
          );
        } else {
          await _database.customStatement(
            '''
            UPDATE session_exercise
            SET status_code = 'IN_PROGRESS', started_at = COALESCE(started_at, ?),
                updated_at = ?, row_version = row_version + 1,
                sync_status = 'LOCAL_ONLY'
            WHERE id = ?
            ''',
            <Object?>[nowText, nowText, next.sessionExerciseId],
          );
          final firstTarget = next.targets
              .where((value) => value.deletedAt == null)
              .map((value) => value.setNumber)
              .fold<int?>(null, (int? a, int b) => a == null || b < a ? b : a);
          await _database.customStatement(
            '''
            UPDATE workout_session
            SET current_session_exercise_id = ?, current_set_number = ?,
                rest_started_at = NULL, rest_duration_sec = NULL,
                current_input_draft_json = '{}', last_local_saved_at = ?,
                last_interaction_at = ?, updated_at = ?,
                row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
            WHERE id = ?
            ''',
            <Object?>[
              next.sessionExerciseId,
              firstTarget ?? 1,
              nowText,
              nowText,
              nowText,
              sessionId,
            ],
          );
        }
      }
      await _insertEvent(
        userId: userId,
        sessionId: sessionId,
        sessionExerciseId: exercise.sessionExerciseId,
        eventType: 'REST_FINISHED',
        payload: <String, Object?>{'actualRestSec': actualRest},
        occurredAt: nowText,
      );
    });
    final loaded = await loadSession(sessionId);
    if (!loaded.isAwaitingAssessment) {
      final nextExercise = loaded.currentExercise;
      final previousRecord = nextExercise?.lastActiveRecord;
      final nextInput = WorkoutSetInput.fromTarget(loaded.currentTarget).copyWith(
        variationCode: previousRecord?.variationCode,
        equipmentModeCode: previousRecord?.equipmentModeCode,
      );
      await saveCurrentInput(sessionId: sessionId, input: nextInput);
    }
    return loadSession(sessionId);
  }

  @override
  Future<WorkoutExecutionState> changeCurrentSetCount({
    required String sessionId,
    required int targetSetCount,
  }) async {
    final state = await loadSession(sessionId);
    final exercise = state.currentExercise;
    if (exercise == null || state.isResting) {
      throw StateError('Set count cannot be changed now.');
    }
    final completed = exercise.completedWorkSetCount;
    final bounded = targetSetCount.clamp(math.max(1, completed + 1), 10) as int;
    final activeWorkTargets = exercise.targets
        .where((value) => !value.isWarmup && value.deletedAt == null)
        .toList(growable: false)
      ..sort((a, b) => a.setNumber.compareTo(b.setNumber));
    final now = DateTime.now().toUtc().toIso8601String();
    final userId = await _sessionValue(sessionId, 'user_id');
    final ruleVersionId = await _sessionValue(sessionId, 'rule_version_id');
    await _database.transaction(() async {
      if (bounded < activeWorkTargets.length) {
        for (final target in activeWorkTargets.skip(bounded)) {
          await _database.customStatement(
            '''
            UPDATE session_set_target
            SET deleted_at = ?, updated_at = ?, row_version = row_version + 1
            WHERE id = ?
            ''',
            <Object?>[now, now, target.id],
          );
        }
      } else if (bounded > activeWorkTargets.length) {
        final template = activeWorkTargets.isNotEmpty
            ? activeWorkTargets.last
            : exercise.targets.last;
        var nextNumber = exercise.targets
                .map((value) => value.setNumber)
                .fold<int>(0, math.max) +
            1;
        for (var i = activeWorkTargets.length; i < bounded; i += 1) {
          await _insertSessionTarget(
            userId: userId,
            ruleVersionId: ruleVersionId,
            sessionExerciseId: exercise.sessionExerciseId,
            target: _StartSetSeed.fromSessionTarget(
              template,
              id: _idGenerator.next(),
              setNumber: nextNumber,
              sourceCode: 'USER_ADDED',
            ),
            nowText: now,
          );
          nextNumber += 1;
        }
      }
      await _database.customStatement(
        '''
        UPDATE session_exercise
        SET target_set_count = ?, updated_at = ?, row_version = row_version + 1,
            sync_status = 'LOCAL_ONLY'
        WHERE id = ?
        ''',
        <Object?>[bounded, now, exercise.sessionExerciseId],
      );
      await _touchSession(sessionId, now);
      await _insertEvent(
        userId: userId,
        sessionId: sessionId,
        sessionExerciseId: exercise.sessionExerciseId,
        eventType: 'SET_COUNT_CHANGED',
        payload: <String, Object?>{
          'from': exercise.activeWorkSetCount,
          'to': bounded,
        },
        occurredAt: now,
      );
    });
    return loadSession(sessionId);
  }

  @override
  Future<WorkoutExecutionState> moveCurrentExerciseLater(String sessionId) async {
    final state = await loadSession(sessionId);
    final current = state.currentExercise;
    if (current == null || current.completedWorkSetCount > 0 || state.isResting) {
      throw StateError('This exercise can no longer be moved.');
    }
    final maxOrder = state.exercises
        .map((value) => value.orderIndex)
        .fold<int>(0, math.max);
    final candidates = state.exercises
        .where(
          (value) => value.orderIndex > current.orderIndex &&
              value.statusCode != 'SKIPPED' &&
              value.statusCode != 'COMPLETED',
        )
        .toList()
      ..sort((a, b) => a.orderIndex.compareTo(b.orderIndex));
    if (current.orderIndex == maxOrder || candidates.isEmpty) return state;
    final now = DateTime.now().toUtc().toIso8601String();
    final userId = await _sessionValue(sessionId, 'user_id');
    final next = candidates.first;
    await _database.transaction(() async {
      await _database.customStatement(
        'UPDATE session_exercise SET order_index = -1 WHERE id = ?',
        <Object?>[current.sessionExerciseId],
      );
      await _database.customStatement(
        '''
        UPDATE session_exercise
        SET order_index = order_index - 1, updated_at = ?,
            row_version = row_version + 1
        WHERE workout_session_id = ? AND order_index > ?
        ''',
        <Object?>[now, sessionId, current.orderIndex],
      );
      await _database.customStatement(
        '''
        UPDATE session_exercise
        SET order_index = ?, status_code = 'PLANNED', updated_at = ?,
            row_version = row_version + 1
        WHERE id = ?
        ''',
        <Object?>[maxOrder, now, current.sessionExerciseId],
      );
      await _database.customStatement(
        '''
        UPDATE session_exercise
        SET status_code = 'IN_PROGRESS', started_at = COALESCE(started_at, ?),
            updated_at = ?, row_version = row_version + 1
        WHERE id = ?
        ''',
        <Object?>[now, now, next.sessionExerciseId],
      );
      final firstTarget = next.targets
          .where((value) => value.deletedAt == null)
          .map((value) => value.setNumber)
          .fold<int?>(null, (a, b) => a == null || b < a ? b : a);
      await _database.customStatement(
        '''
        UPDATE workout_session
        SET current_session_exercise_id = ?, current_set_number = ?,
            current_input_draft_json = '{}', last_local_saved_at = ?,
            last_interaction_at = ?, updated_at = ?, row_version = row_version + 1,
            sync_status = 'LOCAL_ONLY'
        WHERE id = ?
        ''',
        <Object?>[
          next.sessionExerciseId,
          firstTarget ?? 1,
          now,
          now,
          now,
          sessionId,
        ],
      );
      await _insertEvent(
        userId: userId,
        sessionId: sessionId,
        sessionExerciseId: current.sessionExerciseId,
        eventType: 'EXERCISE_MOVED_LATER',
        payload: <String, Object?>{'from': current.orderIndex, 'to': maxOrder},
        occurredAt: now,
      );
    });
    final loaded = await loadSession(sessionId);
    await saveCurrentInput(
      sessionId: sessionId,
      input: WorkoutSetInput.fromTarget(loaded.currentTarget),
    );
    return loadSession(sessionId);
  }

  @override
  Future<WorkoutExecutionState> skipCurrentExercise({
    required String sessionId,
    required String reasonCode,
  }) async {
    final state = await loadSession(sessionId);
    final current = state.currentExercise;
    if (current == null || state.isResting) {
      throw StateError('The exercise cannot be skipped now.');
    }
    final now = DateTime.now().toUtc().toIso8601String();
    final userId = await _sessionValue(sessionId, 'user_id');
    await _database.transaction(() async {
      await _database.customStatement(
        '''
        UPDATE session_exercise
        SET status_code = ?, skip_reason_code = ?, ended_at = ?,
            updated_at = ?, row_version = row_version + 1,
            sync_status = 'LOCAL_ONLY'
        WHERE id = ?
        ''',
        <Object?>[
          current.completedWorkSetCount > 0 ? 'PARTIAL' : 'SKIPPED',
          reasonCode,
          now,
          now,
          current.sessionExerciseId,
        ],
      );
      await _advanceFromRemovedExercise(state, current, now);
      await _insertEvent(
        userId: userId,
        sessionId: sessionId,
        sessionExerciseId: current.sessionExerciseId,
        eventType: 'EXERCISE_SKIPPED',
        payload: <String, Object?>{'reasonCode': reasonCode},
        occurredAt: now,
      );
    });
    final loaded = await loadSession(sessionId);
    if (!loaded.isAwaitingAssessment) {
      await saveCurrentInput(
        sessionId: sessionId,
        input: WorkoutSetInput.fromTarget(loaded.currentTarget),
      );
    }
    return loadSession(sessionId);
  }

  @override
  Future<List<double>> loadAvailableWeights(String sessionId) async {
    final state = await loadSession(sessionId);
    final exercise = state.currentExercise;
    if (exercise == null) return const <double>[];
    final locationId = await _sessionNullableValue(sessionId, 'training_location_id');
    if (locationId == null) return const <double>[];
    final exactRows = await _database.customSelect(
      '''
      SELECT DISTINCT ewo.weight_value
      FROM exercise_equipment_option eo
      JOIN exercise_equipment ee ON ee.equipment_option_id = eo.id
      JOIN location_equipment le
        ON le.equipment_id = ee.equipment_id
       AND le.training_location_id = ?
       AND le.is_available = 1
       AND le.deleted_at IS NULL
      JOIN equipment_weight_option ewo
        ON ewo.location_equipment_id = le.id
       AND ewo.deleted_at IS NULL
      WHERE eo.exercise_id = ?
      ORDER BY ewo.weight_value
      ''',
      variables: <Variable<Object>>[
        Variable.withString(locationId),
        Variable.withString(exercise.exerciseId),
      ],
    ).get();
    final values = <double>{
      for (final row in exactRows) row.read<double>('weight_value'),
    };
    final rangeRows = await _database.customSelect(
      '''
      SELECT le.min_weight, le.max_weight, le.increment_weight,
             lbd.shaft_weight_kg, lbd.max_total_weight_kg, lbd.min_increment_kg
      FROM exercise_equipment_option eo
      JOIN exercise_equipment ee ON ee.equipment_option_id = eo.id
      JOIN location_equipment le
        ON le.equipment_id = ee.equipment_id
       AND le.training_location_id = ?
       AND le.is_available = 1
       AND le.deleted_at IS NULL
      LEFT JOIN location_barbell_detail lbd
        ON lbd.location_equipment_id = le.id AND lbd.deleted_at IS NULL
      WHERE eo.exercise_id = ?
      ''',
      variables: <Variable<Object>>[
        Variable.withString(locationId),
        Variable.withString(exercise.exerciseId),
      ],
    ).get();
    for (final row in rangeRows) {
      final barStart = row.readNullable<double>('shaft_weight_kg');
      final barEnd = row.readNullable<double>('max_total_weight_kg');
      final barStep = row.readNullable<double>('min_increment_kg');
      final start = barStart ?? row.readNullable<double>('min_weight');
      final end = barEnd ?? row.readNullable<double>('max_weight');
      final step = barStep ?? row.readNullable<double>('increment_weight');
      if (start == null || end == null || step == null || step <= 0) continue;
      var current = start;
      var guard = 0;
      while (current <= end + 0.0001 && guard < 500) {
        values.add(double.parse(current.toStringAsFixed(3)));
        current += step;
        guard += 1;
      }
    }
    final currentValue = state.currentInput.weightValue;
    if (currentValue != null) values.add(currentValue);
    final sorted = values.toList()..sort();
    return sorted;
  }

  @override
  Future<List<WorkoutAlternativeChoice>> loadAlternatives({
    required String sessionId,
    required String reasonCode,
  }) async {
    final state = await loadSession(sessionId);
    final current = state.currentExercise;
    if (current == null) return const <WorkoutAlternativeChoice>[];
    final locationId = await _sessionNullableValue(sessionId, 'training_location_id');
    final rows = await _database.customSelect(
      '''
      SELECT em.id, em.name_ja, em.recording_method_code,
             ea.reason_code, ea.priority
      FROM exercise_alternative ea
      JOIN exercise_master em ON em.id = ea.alternative_exercise_id
      WHERE ea.exercise_id = ?
        AND em.is_active = 1
        AND NOT EXISTS (
          SELECT 1 FROM user_restriction ur
          WHERE ur.user_id = (SELECT user_id FROM workout_session WHERE id = ?)
            AND ur.exercise_id = em.id
            AND ur.deleted_at IS NULL
            AND (ur.effective_to IS NULL OR ur.effective_to >= date('now'))
            AND ur.default_action_code IN ('EXCLUDE', 'AVOID')
        )
      ORDER BY CASE WHEN ea.reason_code = ? THEN 0 ELSE 1 END,
               ea.priority, em.name_ja
      ''',
      variables: <Variable<Object>>[
        Variable.withString(current.exerciseId),
        Variable.withString(sessionId),
        Variable.withString(reasonCode),
      ],
    ).get();
    final result = <WorkoutAlternativeChoice>[];
    for (final row in rows) {
      final exerciseId = row.read<String>('id');
      if (locationId != null &&
          !await _isExerciseAvailableAtLocation(exerciseId, locationId)) {
        continue;
      }
      result.add(
        WorkoutAlternativeChoice(
          exerciseId: exerciseId,
          name: row.read<String>('name_ja'),
          recordingMethodCode: row.read<String>('recording_method_code'),
          reason: _alternativeReasonText(reasonCode),
        ),
      );
      if (result.length == 3) break;
    }
    return result;
  }

  @override
  Future<WorkoutExecutionState> substituteCurrentExercise({
    required String sessionId,
    required WorkoutAlternativeChoice alternative,
    required String reasonCode,
  }) async {
    final state = await loadSession(sessionId);
    final current = state.currentExercise;
    if (current == null || current.completedWorkSetCount > 0 || state.isResting) {
      throw StateError('The exercise cannot be changed after a set is completed.');
    }
    final now = DateTime.now().toUtc().toIso8601String();
    final userId = await _sessionValue(sessionId, 'user_id');
    await _database.transaction(() async {
      await _database.customStatement(
        '''
        UPDATE session_exercise
        SET exercise_id = ?, exercise_name_snapshot = ?,
            recording_method_snapshot = ?, performance_series_key = ?,
            substitution_reason_code = ?, updated_at = ?,
            row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
        WHERE id = ?
        ''',
        <Object?>[
          alternative.exerciseId,
          alternative.name,
          alternative.recordingMethodCode,
          alternative.exerciseId,
          reasonCode,
          now,
          current.sessionExerciseId,
        ],
      );
      await _database.customStatement(
        '''
        UPDATE session_set_target
        SET target_weight_kg = NULL, input_weight_value = NULL,
            input_weight_unit_code = NULL, source_code = 'SUBSTITUTED',
            updated_at = ?, row_version = row_version + 1
        WHERE session_exercise_id = ? AND deleted_at IS NULL
        ''',
        <Object?>[now, current.sessionExerciseId],
      );
      await _database.customStatement(
        '''
        UPDATE workout_session
        SET current_input_draft_json = '{}', last_local_saved_at = ?,
            last_interaction_at = ?, updated_at = ?, row_version = row_version + 1
        WHERE id = ?
        ''',
        <Object?>[now, now, now, sessionId],
      );
      await _insertEvent(
        userId: userId,
        sessionId: sessionId,
        sessionExerciseId: current.sessionExerciseId,
        eventType: 'EXERCISE_SUBSTITUTED',
        payload: <String, Object?>{
          'fromExerciseId': current.exerciseId,
          'toExerciseId': alternative.exerciseId,
          'reasonCode': reasonCode,
        },
        occurredAt: now,
      );
    });
    final loaded = await loadSession(sessionId);
    await saveCurrentInput(
      sessionId: sessionId,
      input: WorkoutSetInput.fromTarget(loaded.currentTarget),
    );
    return loadSession(sessionId);
  }

  @override
  Future<void> recordPain({
    required String sessionId,
    required String? sessionExerciseId,
    required String bodyPartId,
    required String actionCode,
    required String timingCode,
    required bool worsened,
  }) async {
    final userId = await _sessionValue(sessionId, 'user_id');
    final now = DateTime.now().toUtc().toIso8601String();
    await _database.customStatement(
      '''
      INSERT INTO session_pain_entry (
        id, user_id, created_at, updated_at, sync_status,
        workout_session_id, session_exercise_id, body_part_id,
        action_code, timing_code, worsened
      ) VALUES (?, ?, ?, ?, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?)
      ''',
      <Object?>[
        _idGenerator.next(),
        userId,
        now,
        now,
        sessionId,
        sessionExerciseId,
        bodyPartId,
        actionCode,
        timingCode,
        worsened ? 1 : 0,
      ],
    );
    await _touchSession(sessionId, now);
  }

  @override
  Future<WorkoutExecutionState> stopEarly(String sessionId) async {
    final state = await loadSession(sessionId);
    if (state.isFinished || state.isAwaitingAssessment) return state;
    final now = DateTime.now().toUtc().toIso8601String();
    final userId = await _sessionValue(sessionId, 'user_id');
    await _database.transaction(() async {
      await _database.customStatement(
        '''
        UPDATE workout_session
        SET status_code = 'AWAITING_ASSESSMENT', ended_at = ?,
            completion_reason_code = 'EARLY_STOP', rest_started_at = NULL,
            rest_duration_sec = NULL, current_input_draft_json = '{}',
            last_local_saved_at = ?, last_interaction_at = ?, updated_at = ?,
            row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
        WHERE id = ?
        ''',
        <Object?>[now, now, now, now, sessionId],
      );
      await _database.customStatement(
        '''
        UPDATE session_exercise
        SET status_code = CASE WHEN status_code = 'IN_PROGRESS' THEN 'PARTIAL'
                               ELSE status_code END,
            ended_at = CASE WHEN status_code = 'IN_PROGRESS' THEN ? ELSE ended_at END,
            updated_at = ?, row_version = row_version + 1
        WHERE workout_session_id = ? AND deleted_at IS NULL
        ''',
        <Object?>[now, now, sessionId],
      );
      await _insertEvent(
        userId: userId,
        sessionId: sessionId,
        eventType: 'SESSION_STOPPED_EARLY',
        payload: const <String, Object?>{},
        occurredAt: now,
      );
    });
    return loadSession(sessionId);
  }

  @override
  Future<void> finishSession({
    required String sessionId,
    required WorkoutAssessmentDraft assessment,
  }) async {
    final state = await loadSession(sessionId);
    if (!state.isAwaitingAssessment) {
      throw StateError('The workout is not ready for final assessment.');
    }
    if (assessment.difficultyScore < 1 || assessment.difficultyScore > 5) {
      throw ArgumentError.value(assessment.difficultyScore, 'difficultyScore');
    }
    if (state.hasIncompleteWork && assessment.incompleteReasonCode == null) {
      throw StateError('Select why the workout was not completed.');
    }
    if (assessment.hadPain && assessment.painBodyPartId == null) {
      throw StateError('Select the body part where pain was felt.');
    }
    final userId = await _sessionValue(sessionId, 'user_id');
    final ruleVersionId = await _sessionValue(sessionId, 'rule_version_id');
    final now = DateTime.now().toUtc();
    final nowText = now.toIso8601String();
    final effectiveEnd = (state.endedAt ?? now).toUtc();
    final duration = math.max(0, effectiveEnd.difference(state.startedAt.toUtc()).inSeconds);
    final finalStatus = state.hasIncompleteWork ? 'PARTIAL' : 'COMPLETED';
    await _database.transaction(() async {
      await _database.customStatement(
        '''
        INSERT INTO post_workout_assessment (
          id, user_id, rule_version_id, workout_session_id,
          overall_difficulty_score, had_pain, incomplete_reason_code,
          completed_exercise_count, completed_work_set_count,
          actual_duration_sec, next_proposal_response_code,
          created_at, updated_at, sync_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'LOCAL_ONLY')
        ''',
        <Object?>[
          _idGenerator.next(),
          userId,
          ruleVersionId,
          sessionId,
          assessment.difficultyScore,
          assessment.hadPain ? 1 : 0,
          assessment.incompleteReasonCode,
          state.completedExerciseCount,
          state.completedWorkSetCount,
          duration,
          assessment.proposalResponseCode,
          nowText,
          nowText,
        ],
      );
      if (assessment.hadPain && assessment.painBodyPartId != null) {
        await _database.customStatement(
          '''
          INSERT INTO session_pain_entry (
            id, user_id, created_at, updated_at, sync_status,
            workout_session_id, session_exercise_id, body_part_id,
            action_code, timing_code, worsened
          ) VALUES (?, ?, ?, ?, 'LOCAL_ONLY', ?, ?, ?, 'RECORDED_AFTER', 'AFTER', 0)
          ''',
          <Object?>[
            _idGenerator.next(),
            userId,
            nowText,
            nowText,
            sessionId,
            assessment.painSessionExerciseId,
            assessment.painBodyPartId,
          ],
        );
      }
      await _database.customStatement(
        '''
        UPDATE workout_session
        SET status_code = ?, ended_at = COALESCE(ended_at, ?),
            completion_reason_code = COALESCE(completion_reason_code, 'NORMAL'),
            last_local_saved_at = ?, last_interaction_at = ?, updated_at = ?,
            row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
        WHERE id = ?
        ''',
        <Object?>[finalStatus, nowText, nowText, nowText, nowText, sessionId],
      );
      if (state.dayPlanId.isNotEmpty) {
        await _database.customStatement(
          '''
          UPDATE workout_day_plan
          SET status_code = ?, updated_at = ?, row_version = row_version + 1,
              sync_status = 'LOCAL_ONLY'
          WHERE id = ?
          ''',
          <Object?>[finalStatus, nowText, state.dayPlanId],
        );
      }
      await _insertEvent(
        userId: userId,
        sessionId: sessionId,
        eventType: 'SESSION_FINALIZED',
        payload: <String, Object?>{
          'statusCode': finalStatus,
          'difficultyScore': assessment.difficultyScore,
          'completedWorkSetCount': state.completedWorkSetCount,
          'plannedWorkSetCount': state.plannedWorkSetCount,
        },
        occurredAt: nowText,
      );
    });
  }

  @override
  Future<List<WorkoutBodyPartChoice>> loadBodyParts() async {
    final rows = await _database.customSelect(
      '''
      SELECT id, name_ja FROM body_part_master
      WHERE is_active = 1
      ORDER BY display_order, name_ja
      ''',
    ).get();
    return rows
        .map(
          (QueryRow row) => WorkoutBodyPartChoice(
            id: row.read<String>('id'),
            name: row.read<String>('name_ja'),
          ),
        )
        .toList(growable: false);
  }

  Future<List<_StartExerciseSeed>> _loadStartExerciseSeeds(String dayPlanId) async {
    final rows = await _database.customSelect(
      '''
      SELECT pe.id, pe.exercise_id, pe.order_index,
             pe.exercise_name_snapshot, pe.recording_method_snapshot
      FROM planned_exercise pe
      WHERE pe.workout_day_plan_id = ?
        AND pe.deleted_at IS NULL AND pe.status_code <> 'SKIPPED'
      ORDER BY pe.order_index
      ''',
      variables: <Variable<Object>>[Variable.withString(dayPlanId)],
    ).get();
    final seeds = <_StartExerciseSeed>[];
    for (final row in rows) {
      final plannedExerciseId = row.read<String>('id');
      final targetRows = await _database.customSelect(
        '''
        SELECT * FROM planned_set
        WHERE planned_exercise_id = ? AND deleted_at IS NULL
        ORDER BY set_number
        ''',
        variables: <Variable<Object>>[
          Variable.withString(plannedExerciseId),
        ],
      ).get();
      final targets = targetRows
          .map(
            (QueryRow target) => _StartSetSeed(
              id: _idGenerator.next(),
              plannedSetId: target.read<String>('id'),
              setNumber: target.read<int>('set_number'),
              isWarmup: target.read<int>('is_warmup') == 1,
              targetWeightKg: target.readNullable<double>('target_weight_kg'),
              inputWeightValue: target.readNullable<double>('input_weight_value'),
              inputWeightUnitCode:
                  target.readNullable<String>('input_weight_unit_code'),
              targetRepsLower: target.readNullable<int>('target_reps_lower'),
              targetRepsUpper: target.readNullable<int>('target_reps_upper'),
              targetDurationSec: target.readNullable<int>('target_duration_sec'),
              targetAssistanceValue:
                  target.readNullable<double>('target_assistance_value'),
              restSec: target.read<int>('rest_sec'),
              sourceCode: 'PLANNED',
            ),
          )
          .toList();
      seeds.add(
        _StartExerciseSeed(
          sessionExerciseId: _idGenerator.next(),
          plannedExerciseId: plannedExerciseId,
          exerciseId: row.read<String>('exercise_id'),
          orderIndex: row.read<int>('order_index'),
          originalOrderIndex: row.read<int>('order_index'),
          name: row.read<String>('exercise_name_snapshot'),
          recordingMethodCode: row.read<String>('recording_method_snapshot'),
          performanceSeriesKey: row.read<String>('exercise_id'),
          originalSetCount: targets.where((value) => !value.isWarmup).length,
          targets: targets,
        ),
      );
    }
    return seeds;
  }

  Future<void> _applyStartAdjustments(
    List<_StartExerciseSeed> seeds, {
    required WorkoutLaunchSummary summary,
    required WorkoutStartAdjustment? adjustment,
    required String? locationId,
  }) async {
    if (adjustment == null) return;
    if (locationId != null && locationId != summary.locationId) {
      for (final seed in seeds) {
        if (await _isExerciseAvailableAtLocation(seed.exerciseId, locationId)) {
          continue;
        }
        final alternative = await _findStartAlternative(seed.exerciseId, locationId);
        if (alternative == null) {
          seed.skipped = true;
          seed.skipReasonCode = 'EQUIPMENT';
        } else {
          seed.exerciseId = alternative.exerciseId;
          seed.name = alternative.name;
          seed.recordingMethodCode = alternative.recordingMethodCode;
          seed.performanceSeriesKey = alternative.exerciseId;
          seed.substitutionReasonCode = 'EQUIPMENT_UNAVAILABLE';
          for (final target in seed.targets) {
            target.targetWeightKg = null;
            target.inputWeightValue = null;
            target.inputWeightUnitCode = null;
            target.sourceCode = 'LOCATION_SUBSTITUTION';
          }
        }
      }
    }
    for (final pain in adjustment.painEntries) {
      for (final seed in seeds) {
        if (!await _exerciseUsesBodyPart(seed.exerciseId, pain.bodyPartId)) continue;
        switch (pain.actionCode) {
          case 'EXCLUDE':
            seed.skipped = true;
            seed.skipReasonCode = 'PAIN';
            break;
          case 'REDUCE_LOAD':
            for (final target in seed.targets) {
              target.targetWeightKg = _scaled(target.targetWeightKg, 0.9);
              target.inputWeightValue = _scaled(target.inputWeightValue, 0.9);
              target.sourceCode = 'PAIN_REDUCED';
            }
            break;
          case 'MOVE_LATER':
            seed.orderIndex += 100;
            break;
          case 'LOW_IMPACT_ALTERNATIVE':
            final alternative = locationId == null
                ? null
                : await _findStartAlternative(seed.exerciseId, locationId);
            if (alternative == null) {
              seed.skipped = true;
              seed.skipReasonCode = 'PAIN';
            } else {
              seed.exerciseId = alternative.exerciseId;
              seed.name = alternative.name;
              seed.recordingMethodCode = alternative.recordingMethodCode;
              seed.performanceSeriesKey = alternative.exerciseId;
              seed.substitutionReasonCode = 'PAIN';
              for (final target in seed.targets) {
                target.targetWeightKg = null;
                target.inputWeightValue = null;
                target.inputWeightUnitCode = null;
                target.sourceCode = 'PAIN_SUBSTITUTION';
              }
            }
            break;
          case 'AS_PLANNED':
          default:
            break;
        }
      }
    }
    seeds.sort((a, b) => a.orderIndex.compareTo(b.orderIndex));
    for (var i = 0; i < seeds.length; i += 1) seeds[i].orderIndex = i + 1;

    final fatigue = adjustment.fatigueScore;
    if (fatigue >= 4) {
      final factor = fatigue >= 5 ? 0.9 : 0.95;
      for (final seed in seeds.where((value) => !value.skipped)) {
        for (final target in seed.targets) {
          target.targetWeightKg = _scaled(target.targetWeightKg, factor);
          target.inputWeightValue = _scaled(target.inputWeightValue, factor);
          if (target.sourceCode == 'PLANNED') target.sourceCode = 'FATIGUE_ADJUSTED';
        }
      }
      final active = seeds.where((value) => !value.skipped).toList();
      if (active.isNotEmpty) _removeLastWorkSet(active.last);
      if (fatigue >= 5 && active.length > 2) {
        active.last.skipped = true;
        active.last.skipReasonCode = 'FATIGUE';
      }
    }

    final planned = math.max(1, summary.plannedDurationMin);
    if (adjustment.availableDurationMin < planned) {
      final active = seeds.where((value) => !value.skipped).toList();
      final total = active.fold<int>(0, (sum, value) => sum + value.workSetCount);
      final budget = math.max(
        1,
        (total * adjustment.availableDurationMin / planned).floor(),
      );
      var current = total;
      for (final seed in active.reversed) {
        while (current > budget && seed.workSetCount > (seed == active.first ? 1 : 0)) {
          _removeLastWorkSet(seed);
          current -= 1;
        }
        if (seed.workSetCount == 0 && seed != active.first) {
          seed.skipped = true;
          seed.skipReasonCode = 'TIME';
        }
      }
    }

    // A pre-start adjustment redefines the executable session plan. The
    // original targets remain in planned_set for audit, while skipped session
    // exercises carry zero active targets so they do not make a fully executed
    // adjusted session appear incomplete.
    for (final seed in seeds.where((value) => value.skipped)) {
      seed.targets.clear();
    }
  }

  void _removeLastWorkSet(_StartExerciseSeed seed) {
    for (var i = seed.targets.length - 1; i >= 0; i -= 1) {
      if (!seed.targets[i].isWarmup) {
        seed.targets.removeAt(i);
        return;
      }
    }
  }

  Future<void> _insertSessionTarget({
    required String userId,
    required String ruleVersionId,
    required String sessionExerciseId,
    required _StartSetSeed target,
    required String nowText,
  }) async {
    await _database.customStatement(
      '''
      INSERT INTO session_set_target (
        id, user_id, rule_version_id, session_exercise_id,
        planned_set_id, set_number, is_warmup, target_weight_kg,
        input_weight_value, input_weight_unit_code, target_reps_lower,
        target_reps_upper, target_duration_sec, target_assistance_value,
        rest_sec, source_code, created_at, updated_at, sync_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'LOCAL_ONLY')
      ''',
      <Object?>[
        target.id,
        userId,
        ruleVersionId,
        sessionExerciseId,
        target.plannedSetId,
        target.setNumber,
        target.isWarmup ? 1 : 0,
        target.targetWeightKg,
        target.inputWeightValue,
        target.inputWeightUnitCode,
        target.targetRepsLower,
        target.targetRepsUpper,
        target.targetDurationSec,
        target.targetAssistanceValue,
        target.restSec,
        target.sourceCode,
        nowText,
        nowText,
      ],
    );
  }

  Future<List<WorkoutSessionSetTarget>> _loadTargets(String sessionExerciseId) async {
    final rows = await _database.customSelect(
      '''
      SELECT * FROM session_set_target
      WHERE session_exercise_id = ?
      ORDER BY set_number
      ''',
      variables: <Variable<Object>>[Variable.withString(sessionExerciseId)],
    ).get();
    return rows
        .map(
          (QueryRow row) => WorkoutSessionSetTarget(
            id: row.read<String>('id'),
            plannedSetId: row.readNullable<String>('planned_set_id'),
            setNumber: row.read<int>('set_number'),
            isWarmup: row.read<int>('is_warmup') == 1,
            targetWeightKg: row.readNullable<double>('target_weight_kg'),
            inputWeightValue: row.readNullable<double>('input_weight_value'),
            inputWeightUnitCode:
                row.readNullable<String>('input_weight_unit_code'),
            targetRepsLower: row.readNullable<int>('target_reps_lower'),
            targetRepsUpper: row.readNullable<int>('target_reps_upper'),
            targetDurationSec: row.readNullable<int>('target_duration_sec'),
            targetAssistanceValue:
                row.readNullable<double>('target_assistance_value'),
            restSec: row.read<int>('rest_sec'),
            sourceCode: row.read<String>('source_code'),
            deletedAt: _parseNullable(row.readNullable<String>('deleted_at')),
          ),
        )
        .toList(growable: false);
  }

  Future<List<WorkoutCompletedSet>> _loadRecords(String sessionExerciseId) async {
    final rows = await _database.customSelect(
      '''
      SELECT * FROM work_set_record
      WHERE session_exercise_id = ?
      ORDER BY completed_at, created_at
      ''',
      variables: <Variable<Object>>[Variable.withString(sessionExerciseId)],
    ).get();
    return rows
        .map(
          (QueryRow row) => WorkoutCompletedSet(
            id: row.read<String>('id'),
            setNumber: row.read<int>('set_number'),
            isWarmup: row.read<int>('is_warmup') == 1,
            completedAt: DateTime.parse(row.read<String>('completed_at')),
            isVoided: row.readNullable<String>('voided_at') != null,
            weightKg: row.readNullable<double>('actual_weight_kg'),
            inputWeightValue: row.readNullable<double>('input_weight_value'),
            inputWeightUnitCode:
                row.readNullable<String>('input_weight_unit_code'),
            reps: row.readNullable<int>('actual_reps'),
            durationSec: row.readNullable<int>('actual_duration_sec'),
            assistanceValue: row.readNullable<double>('assistance_value'),
            variationCode: row.readNullable<String>('variation_code'),
            equipmentModeCode: row.readNullable<String>('equipment_mode_code'),
            restDurationSec: row.readNullable<int>('rest_duration_sec'),
            supersedesId: row.readNullable<String>('supersedes_id'),
          ),
        )
        .toList(growable: false);
  }

  Future<String> _loadPreviousPerformance({
    required String userId,
    required String exerciseId,
    required String excludeSessionId,
  }) async {
    final rows = await _database.customSelect(
      '''
      SELECT wsr.input_weight_value, wsr.input_weight_unit_code,
             wsr.actual_reps, wsr.actual_duration_sec,
             wsr.assistance_value, wsr.variation_code,
             wsr.equipment_mode_code
      FROM session_exercise se
      JOIN workout_session ws ON ws.id = se.workout_session_id
      JOIN work_set_record wsr ON wsr.session_exercise_id = se.id
      WHERE ws.user_id = ?
        AND se.exercise_id = ?
        AND ws.id <> ?
        AND ws.status_code IN ('COMPLETED', 'PARTIAL')
        AND wsr.voided_at IS NULL
      ORDER BY ws.started_at DESC, wsr.set_number
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(exerciseId),
        Variable.withString(excludeSessionId),
      ],
    ).get();
    if (rows.isEmpty) return '前回記録なし';
    final row = rows.first;
    final parts = <String>[];
    final equipmentMode = row.readNullable<String>('equipment_mode_code');
    if (equipmentMode?.isNotEmpty ?? false) parts.add(equipmentMode!);
    final variation = row.readNullable<String>('variation_code');
    if (variation?.isNotEmpty ?? false) parts.add(variation!);
    final weight = row.readNullable<double>('input_weight_value');
    if (weight != null) {
      parts.add('${_trim(weight)}${row.readNullable<String>('input_weight_unit_code')?.toUpperCase() == 'LB' ? 'lb' : 'kg'}');
    }
    final reps = row.readNullable<int>('actual_reps');
    if (reps != null) parts.add('$reps回');
    final duration = row.readNullable<int>('actual_duration_sec');
    if (duration != null) parts.add('$duration秒');
    final assistance = row.readNullable<double>('assistance_value');
    if (assistance != null) parts.add('補助設定${_trim(assistance)}');
    return parts.isEmpty ? '前回記録あり' : '前回 ${parts.join(' × ')}';
  }

  Future<void> _advanceFromRemovedExercise(
    WorkoutExecutionState state,
    WorkoutSessionExercise current,
    String now,
  ) async {
    final next = _nextActiveExercise(state.exercises, current.orderIndex);
    if (next == null) {
      await _database.customStatement(
        '''
        UPDATE workout_session
        SET status_code = 'AWAITING_ASSESSMENT', ended_at = ?,
            current_session_exercise_id = NULL, current_set_number = NULL,
            current_input_draft_json = '{}', last_local_saved_at = ?,
            last_interaction_at = ?, updated_at = ?, row_version = row_version + 1
        WHERE id = ?
        ''',
        <Object?>[now, now, now, now, state.sessionId],
      );
      return;
    }
    await _database.customStatement(
      '''
      UPDATE session_exercise
      SET status_code = 'IN_PROGRESS', started_at = COALESCE(started_at, ?),
          updated_at = ?, row_version = row_version + 1
      WHERE id = ?
      ''',
      <Object?>[now, now, next.sessionExerciseId],
    );
    final first = next.targets
        .where((value) => value.deletedAt == null)
        .map((value) => value.setNumber)
        .fold<int?>(null, (a, b) => a == null || b < a ? b : a);
    await _database.customStatement(
      '''
      UPDATE workout_session
      SET current_session_exercise_id = ?, current_set_number = ?,
          rest_started_at = NULL, rest_duration_sec = NULL,
          current_input_draft_json = '{}', last_local_saved_at = ?,
          last_interaction_at = ?, updated_at = ?, row_version = row_version + 1
      WHERE id = ?
      ''',
      <Object?>[next.sessionExerciseId, first ?? 1, now, now, now, state.sessionId],
    );
  }

  WorkoutSessionExercise? _nextActiveExercise(
    List<WorkoutSessionExercise> values,
    int currentOrder,
  ) {
    final candidates = values
        .where(
          (value) => value.orderIndex > currentOrder &&
              value.statusCode != 'SKIPPED' &&
              value.statusCode != 'COMPLETED',
        )
        .toList()
      ..sort((a, b) => a.orderIndex.compareTo(b.orderIndex));
    return candidates.isEmpty ? null : candidates.first;
  }

  int _nextUncompletedTargetNumber(WorkoutSessionExercise exercise) {
    final completed = exercise.records
        .where((value) => !value.isVoided)
        .map((value) => value.setNumber)
        .toSet();
    final candidates = exercise.targets
        .where((value) => value.deletedAt == null && !completed.contains(value.setNumber))
        .map((value) => value.setNumber)
        .toList()
      ..sort();
    if (candidates.isEmpty) throw StateError('No remaining set target.');
    return candidates.first;
  }

  Future<bool> _isExerciseAvailableAtLocation(
    String exerciseId,
    String locationId,
  ) async {
    final optionCount = await _database.customSelect(
      'SELECT COUNT(*) AS count_value FROM exercise_equipment_option '
      'WHERE exercise_id = ?',
      variables: <Variable<Object>>[Variable.withString(exerciseId)],
    ).getSingle();
    if (optionCount.read<int>('count_value') == 0) return true;
    final rows = await _database.customSelect(
      '''
      SELECT 1 AS available
      FROM exercise_equipment_option eo
      WHERE eo.exercise_id = ?
        AND NOT EXISTS (
          SELECT 1
          FROM exercise_equipment ee
          WHERE ee.equipment_option_id = eo.id
            AND ee.requirement_type = 'REQUIRED'
            AND NOT EXISTS (
              SELECT 1 FROM location_equipment le
              WHERE le.training_location_id = ?
                AND le.equipment_id = ee.equipment_id
                AND le.is_available = 1
                AND le.deleted_at IS NULL
            )
        )
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(exerciseId),
        Variable.withString(locationId),
      ],
    ).get();
    return rows.isNotEmpty;
  }

  Future<WorkoutAlternativeChoice?> _findStartAlternative(
    String exerciseId,
    String locationId,
  ) async {
    final rows = await _database.customSelect(
      '''
      SELECT em.id, em.name_ja, em.recording_method_code
      FROM exercise_alternative ea
      JOIN exercise_master em ON em.id = ea.alternative_exercise_id
      WHERE ea.exercise_id = ? AND em.is_active = 1
      ORDER BY ea.priority, em.name_ja
      ''',
      variables: <Variable<Object>>[Variable.withString(exerciseId)],
    ).get();
    for (final row in rows) {
      final candidate = row.read<String>('id');
      if (await _isExerciseAvailableAtLocation(candidate, locationId)) {
        return WorkoutAlternativeChoice(
          exerciseId: candidate,
          name: row.read<String>('name_ja'),
          recordingMethodCode: row.read<String>('recording_method_code'),
          reason: '変更後の場所で実施できます。',
        );
      }
    }
    return null;
  }

  Future<bool> _exerciseUsesBodyPart(String exerciseId, String bodyPartId) async {
    final rows = await _database.customSelect(
      '''
      SELECT 1 AS found FROM exercise_body_part
      WHERE exercise_id = ? AND body_part_id = ? LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(exerciseId),
        Variable.withString(bodyPartId),
      ],
    ).get();
    return rows.isNotEmpty;
  }

  void _validateSetInput(String method, WorkoutSetInput input) {
    if (method == 'DURATION') {
      if (input.durationSec == null || input.durationSec! < 0) {
        throw StateError('Enter the completed duration.');
      }
    } else if (input.reps == null || input.reps! < 0) {
      throw StateError('Enter the completed repetitions.');
    }
    if (input.weightValue != null && input.weightValue! < 0) {
      throw StateError('Weight cannot be negative.');
    }
    if (method == 'ASSISTANCE_REVERSE' &&
        (input.assistanceValue == null || input.assistanceValue! < 0)) {
      throw StateError('Enter the assistance setting.');
    }
    if (<String>{'VARIATION_FIRST', 'BAND_STEPS'}.contains(method) &&
        (input.variationCode?.trim().isEmpty ?? true)) {
      throw StateError('Enter the variation or band setting.');
    }
    if (method == 'MULTI_MODE' &&
        (input.equipmentModeCode?.trim().isEmpty ?? true)) {
      throw StateError('Enter the equipment or execution mode.');
    }
  }

  Future<String> _sessionValue(String sessionId, String column) async {
    final row = await _database.customSelect(
      'SELECT $column FROM workout_session WHERE id = ? LIMIT 1',
      variables: <Variable<Object>>[Variable.withString(sessionId)],
    ).getSingle();
    return row.read<String>(column);
  }

  Future<String?> _sessionNullableValue(String sessionId, String column) async {
    final row = await _database.customSelect(
      'SELECT $column FROM workout_session WHERE id = ? LIMIT 1',
      variables: <Variable<Object>>[Variable.withString(sessionId)],
    ).getSingle();
    return row.readNullable<String>(column);
  }

  Future<void> _touchSession(String sessionId, String now) async {
    await _database.customStatement(
      '''
      UPDATE workout_session
      SET last_local_saved_at = ?, last_interaction_at = ?, updated_at = ?,
          row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
      WHERE id = ?
      ''',
      <Object?>[now, now, now, sessionId],
    );
  }

  Future<void> _insertEvent({
    required String userId,
    required String sessionId,
    required String eventType,
    required Map<String, Object?> payload,
    required String occurredAt,
    String? sessionExerciseId,
  }) async {
    await _database.customStatement(
      '''
      INSERT INTO workout_session_event (
        id, user_id, workout_session_id, session_exercise_id,
        event_type_code, payload_json, occurred_at, sync_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'LOCAL_ONLY')
      ''',
      <Object?>[
        _idGenerator.next(),
        userId,
        sessionId,
        sessionExerciseId,
        eventType,
        jsonEncode(payload),
        occurredAt,
      ],
    );
  }
}

final class _StartExerciseSeed {
  _StartExerciseSeed({
    required this.sessionExerciseId,
    required this.plannedExerciseId,
    required this.exerciseId,
    required this.orderIndex,
    required this.originalOrderIndex,
    required this.name,
    required this.recordingMethodCode,
    required this.performanceSeriesKey,
    required this.originalSetCount,
    required this.targets,
    this.skipped = false,
    this.substitutionReasonCode,
    this.skipReasonCode,
  });

  final String sessionExerciseId;
  final String plannedExerciseId;
  String exerciseId;
  int orderIndex;
  final int originalOrderIndex;
  String name;
  String recordingMethodCode;
  String performanceSeriesKey;
  final int originalSetCount;
  final List<_StartSetSeed> targets;
  bool skipped;
  String? substitutionReasonCode;
  String? skipReasonCode;

  int get workSetCount => targets.where((value) => !value.isWarmup).length;
}

final class _StartSetSeed {
  _StartSetSeed({
    required this.id,
    required this.setNumber,
    required this.isWarmup,
    required this.restSec,
    required this.sourceCode,
    this.plannedSetId,
    this.targetWeightKg,
    this.inputWeightValue,
    this.inputWeightUnitCode,
    this.targetRepsLower,
    this.targetRepsUpper,
    this.targetDurationSec,
    this.targetAssistanceValue,
  });

  factory _StartSetSeed.fromSessionTarget(
    WorkoutSessionSetTarget target, {
    required String id,
    required int setNumber,
    required String sourceCode,
  }) {
    return _StartSetSeed(
      id: id,
      setNumber: setNumber,
      isWarmup: target.isWarmup,
      restSec: target.restSec,
      sourceCode: sourceCode,
      targetWeightKg: target.targetWeightKg,
      inputWeightValue: target.inputWeightValue,
      inputWeightUnitCode: target.inputWeightUnitCode,
      targetRepsLower: target.targetRepsLower,
      targetRepsUpper: target.targetRepsUpper,
      targetDurationSec: target.targetDurationSec,
      targetAssistanceValue: target.targetAssistanceValue,
    );
  }

  final String id;
  final String? plannedSetId;
  final int setNumber;
  final bool isWarmup;
  double? targetWeightKg;
  double? inputWeightValue;
  String? inputWeightUnitCode;
  final int? targetRepsLower;
  final int? targetRepsUpper;
  final int? targetDurationSec;
  final double? targetAssistanceValue;
  final int restSec;
  String sourceCode;
}

DateTime? _parseNullable(String? value) => value == null ? null : DateTime.parse(value);

String _dateOnly(DateTime value) =>
    DateTime(value.year, value.month, value.day).toIso8601String().substring(0, 10);

double? _scaled(double? value, double factor) {
  if (value == null) return null;
  return (value * factor * 2).floorToDouble() / 2;
}

double? _weightKg(double? value, String unitCode) {
  if (value == null) return null;
  return unitCode.toUpperCase() == 'LB' ? value * 0.45359237 : value;
}

String _alternativeReasonText(String reasonCode) => switch (reasonCode) {
      'PAIN' => '同じ狙いで、より負担の低い候補です。',
      'EQUIPMENT_UNAVAILABLE' => '現在の器具で実施できる候補です。',
      'WEIGHT_UNAVAILABLE' => '利用できる重量に合わせやすい候補です。',
      'TOO_DIFFICULT' => '動作を安定させやすい候補です。',
      _ => '同じ部位を狙える代替候補です。',
    };

String _trim(double value) => value
    .toStringAsFixed(2)
    .replaceFirst(RegExp(r'\.?0+$'), '');
