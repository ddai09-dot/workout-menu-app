import 'dart:convert';

final class WorkoutLaunchSummary {
  const WorkoutLaunchSummary({
    required this.dayPlanId,
    required this.planDate,
    required this.focus,
    required this.locationId,
    required this.locationName,
    required this.plannedDurationMin,
    required this.exercises,
    required this.availableLocations,
  });

  final String dayPlanId;
  final DateTime planDate;
  final String focus;
  final String? locationId;
  final String locationName;
  final int plannedDurationMin;
  final List<WorkoutLaunchExercise> exercises;
  final List<WorkoutLocationChoice> availableLocations;

  int get exerciseCount => exercises.length;
  int get workSetCount => exercises.fold<int>(
        0,
        (int total, WorkoutLaunchExercise value) => total + value.workSetCount,
      );
}

final class WorkoutLaunchExercise {
  const WorkoutLaunchExercise({
    required this.plannedExerciseId,
    required this.exerciseId,
    required this.name,
    required this.targetPart,
    required this.workSetCount,
    required this.reason,
  });

  final String plannedExerciseId;
  final String exerciseId;
  final String name;
  final String targetPart;
  final int workSetCount;
  final String reason;
}

final class WorkoutLocationChoice {
  const WorkoutLocationChoice({
    required this.id,
    required this.name,
    required this.typeCode,
  });

  final String id;
  final String name;
  final String typeCode;
}

final class WorkoutStartAdjustment {
  const WorkoutStartAdjustment({
    required this.availableDurationMin,
    required this.fatigueScore,
    this.locationId,
    this.painEntries = const <WorkoutPainAdjustment>[],
  });

  final int availableDurationMin;
  final int fatigueScore;
  final String? locationId;
  final List<WorkoutPainAdjustment> painEntries;

  Map<String, Object?> toJson() => <String, Object?>{
        'availableDurationMin': availableDurationMin,
        'fatigueScore': fatigueScore,
        'locationId': locationId,
        'painEntries': painEntries
            .map((WorkoutPainAdjustment value) => value.toJson())
            .toList(growable: false),
      };
}

final class WorkoutPainAdjustment {
  const WorkoutPainAdjustment({
    required this.bodyPartId,
    required this.bodyPartName,
    required this.actionCode,
  });

  final String bodyPartId;
  final String bodyPartName;
  final String actionCode;

  Map<String, Object?> toJson() => <String, Object?>{
        'bodyPartId': bodyPartId,
        'bodyPartName': bodyPartName,
        'actionCode': actionCode,
      };
}

final class WorkoutExecutionState {
  const WorkoutExecutionState({
    required this.sessionId,
    required this.dayPlanId,
    required this.statusCode,
    required this.startedAt,
    required this.recordDate,
    required this.focus,
    required this.locationName,
    required this.currentSessionExerciseId,
    required this.currentSetNumber,
    required this.exercises,
    required this.currentInput,
    this.endedAt,
    this.rest,
    this.completionReasonCode,
  });

  final String sessionId;
  final String dayPlanId;
  final String statusCode;
  final DateTime startedAt;
  final DateTime? endedAt;
  final DateTime recordDate;
  final String focus;
  final String locationName;
  final String? currentSessionExerciseId;
  final int? currentSetNumber;
  final List<WorkoutSessionExercise> exercises;
  final WorkoutSetInput currentInput;
  final WorkoutRestState? rest;
  final String? completionReasonCode;

  WorkoutSessionExercise? get currentExercise {
    final id = currentSessionExerciseId;
    if (id == null) return null;
    for (final value in exercises) {
      if (value.sessionExerciseId == id) return value;
    }
    return null;
  }

  WorkoutSessionSetTarget? get currentTarget {
    final exercise = currentExercise;
    final number = currentSetNumber;
    if (exercise == null || number == null) return null;
    for (final value in exercise.targets) {
      if (value.setNumber == number && value.deletedAt == null) return value;
    }
    return null;
  }

  int get completedWorkSetCount => exercises.fold<int>(
        0,
        (int total, WorkoutSessionExercise exercise) =>
            total + exercise.completedWorkSetCount,
      );

  int get plannedWorkSetCount => exercises.fold<int>(
        0,
        (int total, WorkoutSessionExercise exercise) =>
            total + exercise.activeWorkSetCount,
      );

  int get completedExerciseCount => exercises
      .where((WorkoutSessionExercise value) => value.statusCode == 'COMPLETED')
      .length;

  bool get isAwaitingAssessment => statusCode == 'AWAITING_ASSESSMENT';
  bool get isFinished => statusCode == 'COMPLETED' || statusCode == 'PARTIAL';
  bool get isResting => rest != null;
  bool get hasIncompleteWork => completedWorkSetCount < plannedWorkSetCount;

  WorkoutExecutionState copyWith({
    String? statusCode,
    DateTime? endedAt,
    Object? currentSessionExerciseId = _unset,
    Object? currentSetNumber = _unset,
    List<WorkoutSessionExercise>? exercises,
    WorkoutSetInput? currentInput,
    Object? rest = _unset,
    Object? completionReasonCode = _unset,
  }) {
    return WorkoutExecutionState(
      sessionId: sessionId,
      dayPlanId: dayPlanId,
      statusCode: statusCode ?? this.statusCode,
      startedAt: startedAt,
      endedAt: endedAt ?? this.endedAt,
      recordDate: recordDate,
      focus: focus,
      locationName: locationName,
      currentSessionExerciseId: identical(currentSessionExerciseId, _unset)
          ? this.currentSessionExerciseId
          : currentSessionExerciseId as String?,
      currentSetNumber: identical(currentSetNumber, _unset)
          ? this.currentSetNumber
          : currentSetNumber as int?,
      exercises: exercises ?? this.exercises,
      currentInput: currentInput ?? this.currentInput,
      rest: identical(rest, _unset) ? this.rest : rest as WorkoutRestState?,
      completionReasonCode: identical(completionReasonCode, _unset)
          ? this.completionReasonCode
          : completionReasonCode as String?,
    );
  }
}

const Object _unset = Object();

final class WorkoutSessionExercise {
  const WorkoutSessionExercise({
    required this.sessionExerciseId,
    required this.plannedExerciseId,
    required this.exerciseId,
    required this.name,
    required this.recordingMethodCode,
    required this.performanceSeriesKey,
    required this.targetPart,
    required this.orderIndex,
    required this.originalOrderIndex,
    required this.originalSetCount,
    required this.targetSetCount,
    required this.statusCode,
    required this.targets,
    required this.records,
    required this.previousPerformanceText,
    this.substitutionReasonCode,
    this.skipReasonCode,
  });

  final String sessionExerciseId;
  final String? plannedExerciseId;
  final String exerciseId;
  final String name;
  final String recordingMethodCode;
  final String performanceSeriesKey;
  final String targetPart;
  final int orderIndex;
  final int originalOrderIndex;
  final int originalSetCount;
  final int targetSetCount;
  final String statusCode;
  final String? substitutionReasonCode;
  final String? skipReasonCode;
  final List<WorkoutSessionSetTarget> targets;
  final List<WorkoutCompletedSet> records;
  final String previousPerformanceText;

  int get completedWorkSetCount => records
      .where((WorkoutCompletedSet value) => !value.isWarmup && !value.isVoided)
      .length;

  int get activeWorkSetCount => targets
      .where((WorkoutSessionSetTarget value) => !value.isWarmup && value.deletedAt == null)
      .length;

  WorkoutCompletedSet? get lastActiveRecord {
    final active = records
        .where((WorkoutCompletedSet value) => !value.isVoided)
        .toList(growable: false);
    if (active.isEmpty) return null;
    return active.last;
  }

  bool get recordsDuration => recordingMethodCode == 'DURATION';

  bool get recordsRepetitions => !recordsDuration;

  bool get supportsWeight => <String>{
        'WEIGHT_REPS',
        'REPS_LOADABLE',
        'MULTI_MODE',
      }.contains(recordingMethodCode);

  bool get requiresAssistance => recordingMethodCode == 'ASSISTANCE_REVERSE';

  bool get requiresVariation => <String>{
        'VARIATION_FIRST',
        'BAND_STEPS',
      }.contains(recordingMethodCode);

  bool get requiresEquipmentMode => recordingMethodCode == 'MULTI_MODE';
}

final class WorkoutSessionSetTarget {
  const WorkoutSessionSetTarget({
    required this.id,
    required this.setNumber,
    required this.isWarmup,
    required this.restSec,
    required this.sourceCode,
    this.plannedSetId,
    this.targetWeightKg,
    this.inputWeightValue,
    this.inputWeightUnitCode,
    this.targetRepsLower,
    this.targetRepsUpper,
    this.targetDurationSec,
    this.targetAssistanceValue,
    this.deletedAt,
  });

  final String id;
  final String? plannedSetId;
  final int setNumber;
  final bool isWarmup;
  final int restSec;
  final String sourceCode;
  final double? targetWeightKg;
  final double? inputWeightValue;
  final String? inputWeightUnitCode;
  final int? targetRepsLower;
  final int? targetRepsUpper;
  final int? targetDurationSec;
  final double? targetAssistanceValue;
  final DateTime? deletedAt;

  String get targetText {
    if (targetDurationSec != null) return '${targetDurationSec}秒';
    if (targetRepsLower != null && targetRepsUpper != null) {
      if (targetRepsLower == targetRepsUpper) return '$targetRepsLower回';
      return '$targetRepsLower〜$targetRepsUpper回';
    }
    return '回数を記録';
  }
}

final class WorkoutCompletedSet {
  const WorkoutCompletedSet({
    required this.id,
    required this.setNumber,
    required this.isWarmup,
    required this.completedAt,
    required this.isVoided,
    this.weightKg,
    this.inputWeightValue,
    this.inputWeightUnitCode,
    this.reps,
    this.durationSec,
    this.assistanceValue,
    this.variationCode,
    this.equipmentModeCode,
    this.restDurationSec,
    this.supersedesId,
  });

  final String id;
  final int setNumber;
  final bool isWarmup;
  final DateTime completedAt;
  final bool isVoided;
  final double? weightKg;
  final double? inputWeightValue;
  final String? inputWeightUnitCode;
  final int? reps;
  final int? durationSec;
  final double? assistanceValue;
  final String? variationCode;
  final String? equipmentModeCode;
  final int? restDurationSec;
  final String? supersedesId;

  String get summaryText {
    final parts = <String>[];
    if (equipmentModeCode?.trim().isNotEmpty ?? false) {
      parts.add(equipmentModeCode!.trim());
    }
    if (variationCode?.trim().isNotEmpty ?? false) {
      parts.add(variationCode!.trim());
    }
    if (inputWeightValue != null) {
      parts.add('${_trim(inputWeightValue!)}${inputWeightUnitCode?.toUpperCase() == 'LB' ? 'lb' : 'kg'}');
    } else if (weightKg != null) {
      parts.add('${_trim(weightKg!)}kg');
    }
    if (reps != null) parts.add('${reps}回');
    if (durationSec != null) parts.add('${durationSec}秒');
    if (assistanceValue != null) {
      parts.add('補助設定${_trim(assistanceValue!)}');
    }
    return parts.isEmpty ? '記録済み' : parts.join(' × ');
  }
}

final class WorkoutSetInput {
  const WorkoutSetInput({
    this.weightValue,
    this.weightUnitCode = 'KG',
    this.reps,
    this.durationSec,
    this.assistanceValue,
    this.variationCode,
    this.equipmentModeCode,
  });

  final double? weightValue;
  final String weightUnitCode;
  final int? reps;
  final int? durationSec;
  final double? assistanceValue;
  final String? variationCode;
  final String? equipmentModeCode;

  factory WorkoutSetInput.fromTarget(WorkoutSessionSetTarget? target) {
    return WorkoutSetInput(
      weightValue: target?.inputWeightValue ?? target?.targetWeightKg,
      weightUnitCode: target?.inputWeightUnitCode ?? 'KG',
      reps: target?.targetRepsLower,
      durationSec: target?.targetDurationSec,
      assistanceValue: target?.targetAssistanceValue,
    );
  }

  factory WorkoutSetInput.fromJsonText(String value) {
    if (value.isEmpty || value == '{}') return const WorkoutSetInput();
    final decoded = jsonDecode(value);
    if (decoded is! Map) return const WorkoutSetInput();
    final map = Map<String, Object?>.from(decoded);
    return WorkoutSetInput(
      weightValue: (map['weightValue'] as num?)?.toDouble(),
      weightUnitCode: map['weightUnitCode'] as String? ?? 'KG',
      reps: (map['reps'] as num?)?.toInt(),
      durationSec: (map['durationSec'] as num?)?.toInt(),
      assistanceValue: (map['assistanceValue'] as num?)?.toDouble(),
      variationCode: map['variationCode'] as String?,
      equipmentModeCode: map['equipmentModeCode'] as String?,
    );
  }

  String toJsonText() => jsonEncode(<String, Object?>{
        'weightValue': weightValue,
        'weightUnitCode': weightUnitCode,
        'reps': reps,
        'durationSec': durationSec,
        'assistanceValue': assistanceValue,
        'variationCode': variationCode,
        'equipmentModeCode': equipmentModeCode,
      });

  WorkoutSetInput copyWith({
    Object? weightValue = _unset,
    String? weightUnitCode,
    Object? reps = _unset,
    Object? durationSec = _unset,
    Object? assistanceValue = _unset,
    Object? variationCode = _unset,
    Object? equipmentModeCode = _unset,
  }) {
    return WorkoutSetInput(
      weightValue: identical(weightValue, _unset)
          ? this.weightValue
          : weightValue as double?,
      weightUnitCode: weightUnitCode ?? this.weightUnitCode,
      reps: identical(reps, _unset) ? this.reps : reps as int?,
      durationSec: identical(durationSec, _unset)
          ? this.durationSec
          : durationSec as int?,
      assistanceValue: identical(assistanceValue, _unset)
          ? this.assistanceValue
          : assistanceValue as double?,
      variationCode: identical(variationCode, _unset)
          ? this.variationCode
          : variationCode as String?,
      equipmentModeCode: identical(equipmentModeCode, _unset)
          ? this.equipmentModeCode
          : equipmentModeCode as String?,
    );
  }
}

final class WorkoutRestState {
  const WorkoutRestState({
    required this.startedAt,
    required this.durationSec,
    required this.completedSetSummary,
    required this.isLastSetOfExercise,
    required this.isLastExercise,
    this.nextExerciseName,
  });

  final DateTime startedAt;
  final int durationSec;
  final String completedSetSummary;
  final bool isLastSetOfExercise;
  final bool isLastExercise;
  final String? nextExerciseName;

  int remainingSecondsAt(DateTime now) {
    final elapsed = now.difference(startedAt).inSeconds;
    final remaining = durationSec - elapsed;
    return remaining < 0 ? 0 : remaining;
  }

  bool isCompleteAt(DateTime now) => remainingSecondsAt(now) == 0;
}

final class WorkoutAlternativeChoice {
  const WorkoutAlternativeChoice({
    required this.exerciseId,
    required this.name,
    required this.recordingMethodCode,
    required this.reason,
  });

  final String exerciseId;
  final String name;
  final String recordingMethodCode;
  final String reason;
}

final class WorkoutBodyPartChoice {
  const WorkoutBodyPartChoice({required this.id, required this.name});
  final String id;
  final String name;
}

final class WorkoutAssessmentDraft {
  const WorkoutAssessmentDraft({
    required this.difficultyScore,
    required this.hadPain,
    this.painBodyPartId,
    this.painSessionExerciseId,
    this.incompleteReasonCode,
    this.proposalResponseCode,
  });

  final int difficultyScore;
  final bool hadPain;
  final String? painBodyPartId;
  final String? painSessionExerciseId;
  final String? incompleteReasonCode;
  final String? proposalResponseCode;
}

String _trim(double value) {
  final text = value.toStringAsFixed(2);
  return text.replaceFirst(RegExp(r'\.?0+$'), '');
}
