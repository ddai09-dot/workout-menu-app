import 'package:workout_menu_app/features/workout/domain/workout_models.dart';

abstract interface class WorkoutRepository {
  Future<WorkoutLaunchSummary> loadLaunchSummary(String dayPlanId);

  Future<WorkoutExecutionState?> loadOpenSession();

  Future<WorkoutExecutionState> loadSession(String sessionId);

  Future<WorkoutExecutionState> startSession({
    required String dayPlanId,
    WorkoutStartAdjustment? adjustment,
  });

  Future<void> saveCurrentInput({
    required String sessionId,
    required WorkoutSetInput input,
  });

  Future<WorkoutExecutionState> completeCurrentSet({
    required String sessionId,
    required WorkoutSetInput input,
  });

  Future<WorkoutExecutionState> updateLastCompletedSet({
    required String sessionId,
    required WorkoutSetInput input,
  });

  Future<WorkoutExecutionState> changeRestDuration({
    required String sessionId,
    required int deltaSeconds,
  });

  Future<WorkoutExecutionState> finishRestAndAdvance(String sessionId);

  Future<WorkoutExecutionState> changeCurrentSetCount({
    required String sessionId,
    required int targetSetCount,
  });

  Future<WorkoutExecutionState> moveCurrentExerciseLater(String sessionId);

  Future<WorkoutExecutionState> skipCurrentExercise({
    required String sessionId,
    required String reasonCode,
  });

  Future<List<double>> loadAvailableWeights(String sessionId);

  Future<List<WorkoutAlternativeChoice>> loadAlternatives({
    required String sessionId,
    required String reasonCode,
  });

  Future<WorkoutExecutionState> substituteCurrentExercise({
    required String sessionId,
    required WorkoutAlternativeChoice alternative,
    required String reasonCode,
  });

  Future<void> recordPain({
    required String sessionId,
    required String? sessionExerciseId,
    required String bodyPartId,
    required String actionCode,
    required String timingCode,
    required bool worsened,
  });

  Future<WorkoutExecutionState> stopEarly(String sessionId);

  Future<void> finishSession({
    required String sessionId,
    required WorkoutAssessmentDraft assessment,
  });

  Future<List<WorkoutBodyPartChoice>> loadBodyParts();
}
