import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

Future<T?> showWorkoutNumberPicker<T>({
  required BuildContext context,
  required String title,
  required List<T> values,
  required T? initialValue,
  required String Function(T value) labelBuilder,
}) {
  if (values.isEmpty) return Future<T?>.value(null);
  var index = initialValue == null ? 0 : values.indexOf(initialValue);
  if (index < 0) index = 0;
  return showModalBottomSheet<T>(
    context: context,
    useSafeArea: true,
    isScrollControlled: true,
    builder: (BuildContext context) {
      var selectedIndex = index;
      return StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return SizedBox(
            height: 360,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(title, style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  Expanded(
                    child: CupertinoPicker(
                      itemExtent: 48,
                      scrollController: FixedExtentScrollController(
                        initialItem: selectedIndex,
                      ),
                      onSelectedItemChanged: (int value) {
                        setState(() => selectedIndex = value);
                      },
                      children: values
                          .map(
                            (T value) => Center(child: Text(labelBuilder(value))),
                          )
                          .toList(growable: false),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: () => Navigator.of(context).pop(values[selectedIndex]),
                    child: const Text('この数値を使う'),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}
