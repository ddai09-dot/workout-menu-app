import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/database/providers/database_providers.dart';
import 'package:workout_menu_app/features/settings/data/local_training_settings_repository.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_repository.dart';

final trainingSettingsRepositoryProvider =
    Provider<TrainingSettingsRepository>((ref) {
  return LocalTrainingSettingsRepository(ref.watch(appDatabaseProvider));
});

final trainingSettingsSnapshotProvider =
    FutureProvider<TrainingSettingsSnapshot>((ref) {
  return ref.watch(trainingSettingsRepositoryProvider).load();
});
