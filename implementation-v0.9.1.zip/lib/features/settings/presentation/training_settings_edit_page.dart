import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/core/widgets/primary_action_button.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/onboarding/presentation/steps/onboarding_steps.dart';
import 'package:workout_menu_app/features/onboarding/presentation/widgets/onboarding_section.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_repository.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_section.dart';
import 'package:workout_menu_app/features/settings/presentation/training_settings_providers.dart';

final class TrainingSettingsEditPage extends ConsumerWidget {
  const TrainingSettingsEditPage({
    required this.section,
    super.key,
  });

  final TrainingSettingsSection section;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final snapshot = ref.watch(trainingSettingsSnapshotProvider);
    return snapshot.when(
      data: (TrainingSettingsSnapshot value) => _TrainingSettingsEditor(
        key: ValueKey<String>('${value.draft.userId}-${section.pathSegment}'),
        section: section,
        snapshot: value,
      ),
      loading: () => Scaffold(
        appBar: AppBar(title: Text(section.title)),
        body: const Center(child: CircularProgressIndicator()),
      ),
      error: (Object error, StackTrace stackTrace) => Scaffold(
        appBar: AppBar(title: Text(section.title)),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const Text('設定を読み込めませんでした。端末内の登録データを確認してください。'),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () => ref.invalidate(trainingSettingsSnapshotProvider),
                  child: const Text('もう一度読み込む'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

final class _TrainingSettingsEditor extends ConsumerStatefulWidget {
  const _TrainingSettingsEditor({
    required this.section,
    required this.snapshot,
    super.key,
  });

  final TrainingSettingsSection section;
  final TrainingSettingsSnapshot snapshot;

  @override
  ConsumerState<_TrainingSettingsEditor> createState() =>
      _TrainingSettingsEditorState();
}

final class _TrainingSettingsEditorState
    extends ConsumerState<_TrainingSettingsEditor> {
  late OnboardingDraft _original;
  late OnboardingDraft _draft;
  bool _isSaving = false;
  bool _allowPop = false;
  String? _message;

  TrainingSettingsSection get section => widget.section;

  bool get _hasChanges =>
      section.fingerprint(_original) != section.fingerprint(_draft);

  @override
  void initState() {
    super.initState();
    _original = widget.snapshot.draft;
    _draft = widget.snapshot.draft;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _allowPop || !_hasChanges,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) {
          _confirmDiscard();
        }
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          leading: IconButton(
            tooltip: '戻る',
            onPressed: _isSaving ? null : _requestPop,
            icon: const Icon(Icons.arrow_back),
          ),
          title: Text(section.title),
          actions: <Widget>[
            if (_isSaving)
              const Padding(
                padding: EdgeInsets.only(right: 16),
                child: Center(child: Text('保存中…')),
              ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: SingleChildScrollView(
                  keyboardDismissBehavior:
                      ScrollViewKeyboardDismissBehavior.onDrag,
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Text(
                        section.description,
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                      const SizedBox(height: 12),
                      _ImpactNotice(section: section),
                      for (final warning in widget.snapshot.warnings) ...<Widget>[
                        const SizedBox(height: 12),
                        _MessageCard(
                          message: warning,
                          isError: false,
                        ),
                      ],
                      if (_message != null) ...<Widget>[
                        const SizedBox(height: 12),
                        _MessageCard(message: _message!, isError: true),
                      ],
                      const SizedBox(height: 24),
                      _buildSectionBody(),
                    ],
                  ),
                ),
              ),
              DecoratedBox(
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  boxShadow: const <BoxShadow>[
                    BoxShadow(
                      blurRadius: 12,
                      offset: Offset(0, -2),
                      color: Color(0x14000000),
                    ),
                  ],
                ),
                child: SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
                    child: PrimaryActionButton(
                      label: _isSaving ? '保存しています…' : '変更を保存する',
                      onPressed: _isSaving || !_hasChanges ? null : _save,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionBody() {
    void update(OnboardingDraft value) {
      setState(() {
        _draft = value;
        _message = null;
      });
    }

    return switch (section) {
      TrainingSettingsSection.goals => Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            OnboardingSection(
              title: '一番の目的',
              child: PrimaryGoalStep(draft: _draft, onChanged: update),
            ),
            const SizedBox(height: 24),
            OnboardingSection(
              title: '副目的',
              description: '一番の目的以外から複数選択できます。',
              child: SecondaryGoalsStep(draft: _draft, onChanged: update),
            ),
          ],
        ),
      TrainingSettingsSection.experience => Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            ExperienceHistoryStep(draft: _draft, onChanged: update),
            const SizedBox(height: 32),
            ExperienceCurrentStep(draft: _draft, onChanged: update),
          ],
        ),
      TrainingSettingsSection.environment => Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            LocationStep(draft: _draft, onChanged: update),
            const SizedBox(height: 32),
            EquipmentStep(draft: _draft, onChanged: update),
            if (_draft.locationModeCode == 'BOTH' &&
                _draft.bothUsageModeCode == 'BY_WEEKDAY') ...<Widget>[
              const SizedBox(height: 32),
              _EnvironmentScheduleLocationStep(
                draft: _draft,
                onChanged: update,
              ),
            ],
          ],
        ),
      TrainingSettingsSection.schedule =>
        ScheduleStep(draft: _draft, onChanged: update),
      TrainingSettingsSection.split =>
        SplitStep(draft: _draft, onChanged: update),
      TrainingSettingsSection.priorities =>
        PrioritiesStep(draft: _draft, onChanged: update),
      TrainingSettingsSection.restrictions =>
        RestrictionsStep(draft: _draft, onChanged: update),
    };
  }

  Future<void> _save() async {
    final validation = section.validationMessage(_draft);
    if (validation != null) {
      setState(() => _message = validation);
      return;
    }
    setState(() {
      _isSaving = true;
      _message = null;
    });
    try {
      final result = await ref
          .read(trainingSettingsRepositoryProvider)
          .saveSection(
            section: section,
            original: _original,
            updated: _draft,
          );
      if (!mounted) {
        return;
      }
      setState(() {
        _original = _draft;
        _isSaving = false;
      });
      ref.invalidate(trainingSettingsSnapshotProvider);
      if (result.impact.currentWeekReviewRecommended) {
        await _showCurrentWeekReview(result);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result.impact.message)),
        );
        _allowPop = true;
        context.pop();
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _isSaving = false;
          _message = '変更を保存できませんでした。入力内容は画面に残っています。もう一度お試しください。';
        });
      }
    }
  }

  Future<void> _showCurrentWeekReview(
    TrainingSettingsSaveResult result,
  ) async {
    final review = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('今週のメニューも確認しますか？'),
          content: Text(
            '${result.impact.message}\n\n設定は保存しました。作成済みメニューは自動変更していません。',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('今は変更しない'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('今週のメニューを確認'),
            ),
          ],
        );
      },
    );
    if (!mounted) {
      return;
    }
    _allowPop = true;
    if (review == true) {
      context.go('/menu/weekly-planner');
    } else {
      context.pop();
    }
  }

  void _requestPop() {
    if (_hasChanges) {
      _confirmDiscard();
    } else {
      _allowPop = true;
      context.pop();
    }
  }

  Future<void> _confirmDiscard() async {
    if (_isSaving) {
      return;
    }
    final discard = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('変更を破棄しますか？'),
          content: const Text('保存していない変更があります。'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('編集を続ける'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('破棄する'),
            ),
          ],
        );
      },
    );
    if (discard == true && mounted) {
      setState(() => _allowPop = true);
      context.pop();
    }
  }
}

final class _EnvironmentScheduleLocationStep extends StatelessWidget {
  const _EnvironmentScheduleLocationStep({
    required this.draft,
    required this.onChanged,
  });

  final OnboardingDraft draft;
  final ValueChanged<OnboardingDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    final entries = ScheduleStep.weekdays.entries
        .where(
          (MapEntry<String, String> entry) =>
              draft.availableWeekdayCodes.contains(entry.key),
        )
        .toList(growable: false);
    return OnboardingSection(
      title: '曜日ごとの利用場所',
      description: '「曜日によって使い分ける」を選んだ場合だけ設定します。通常の曜日や時間自体は「通常の予定」で変更できます。',
      child: entries.isEmpty
          ? const Text('先に「通常の予定」で実施しやすい曜日を設定してください。')
          : Column(
              children: entries
                  .map(
                    (MapEntry<String, String> entry) => Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          children: <Widget>[
                            Expanded(child: Text(entry.value)),
                            DropdownButton<String>(
                              value: draft.scheduleLocationByWeekday[entry.key],
                              hint: const Text('場所を選択'),
                              underline: const SizedBox.shrink(),
                              items: const <DropdownMenuItem<String>>[
                                DropdownMenuItem<String>(
                                  value: 'HOME',
                                  child: Text('自宅'),
                                ),
                                DropdownMenuItem<String>(
                                  value: 'GYM',
                                  child: Text('ジム'),
                                ),
                              ],
                              onChanged: (String? value) {
                                if (value == null) {
                                  return;
                                }
                                onChanged(
                                  draft.copyWith(
                                    scheduleLocationByWeekday: <String, String>{
                                      ...draft.scheduleLocationByWeekday,
                                      entry.key: value,
                                    },
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                  .toList(growable: false),
            ),
    );
  }
}

final class _ImpactNotice extends StatelessWidget {
  const _ImpactNotice({required this.section});

  final TrainingSettingsSection section;

  @override
  Widget build(BuildContext context) {
    final immediateReview = section == TrainingSettingsSection.environment ||
        section == TrainingSettingsSection.restrictions;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Icon(Icons.info_outline),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                immediateReview
                    ? '設定は保存後のメニュー生成に使用します。器具の削除や痛み・制限の追加がある場合だけ、今週のメニュー確認を案内します。本人の確認なしに作成済みメニューは変更しません。'
                    : '変更は次回のメニュー作成から反映します。作成済みメニューと過去記録は変更しません。',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final class _MessageCard extends StatelessWidget {
  const _MessageCard({
    required this.message,
    required this.isError,
  });

  final String message;
  final bool isError;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Material(
      color: isError ? colors.errorContainer : colors.secondaryContainer,
      borderRadius: BorderRadius.circular(10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Text(
          message,
          style: TextStyle(
            color: isError ? colors.onErrorContainer : colors.onSecondaryContainer,
          ),
        ),
      ),
    );
  }
}
