import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/onboarding/data/local_onboarding_repository.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_option.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_step.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_repository.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_section.dart';

final class LocalTrainingSettingsRepository
    implements TrainingSettingsRepository {
  LocalTrainingSettingsRepository(
    this._database, {
    IdGenerator idGenerator = const UuidV7Generator(),
  }) : _writer = LocalOnboardingRepository(
          _database,
          idGenerator: idGenerator,
        );

  final AppDatabase _database;
  final LocalOnboardingRepository _writer;

  @override
  Future<TrainingSettingsSnapshot> load() async {
    final warnings = <String>[];
    final profileRows = await _database.customSelect('''
      SELECT user_id, nickname, age_years, sex_code, height_cm
      FROM user_profile
      WHERE deleted_at IS NULL
        AND onboarding_completed_at IS NOT NULL
      ORDER BY updated_at DESC
      LIMIT 1
    ''').get();
    if (profileRows.isEmpty) {
      throw StateError('Completed user profile was not found.');
    }
    final profile = profileRows.first;
    final userId = profile.read<String>('user_id');

    final settingRows = await _database.customSelect(
      '''
      SELECT desired_days_per_week, usual_duration_min,
             location_mode_code, both_usage_mode_code,
             split_preference_code, ab_goal_code
      FROM user_training_setting
      WHERE user_id = ? AND deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    final experienceRows = await _database.customSelect(
      '''
      SELECT cumulative_experience_code, continuity_code, hiatus_code,
             current_frequency, adjustment_habit_code, logging_habit_code
      FROM user_experience_profile
      WHERE user_id = ? AND deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    if (settingRows.isEmpty || experienceRows.isEmpty) {
      throw StateError('Normalized training settings are incomplete.');
    }
    final setting = settingRows.first;
    final experience = experienceRows.first;

    final measurementRows = await _database.customSelect(
      '''
      SELECT weight_kg, body_fat_percent
      FROM body_measurement
      WHERE user_id = ? AND voided_at IS NULL
      ORDER BY measured_at DESC, created_at DESC
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    final measurement = measurementRows.isEmpty ? null : measurementRows.first;

    final goalRows = await _database.customSelect(
      '''
      SELECT goal_code, goal_type
      FROM user_goal
      WHERE user_id = ? AND deleted_at IS NULL
      ORDER BY display_order, created_at
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    String? primaryGoal;
    final secondaryGoals = <String>{};
    for (final row in goalRows) {
      final code = row.read<String>('goal_code');
      if (row.read<String>('goal_type') == 'PRIMARY') {
        if (primaryGoal != null) {
          warnings.add('主目的が複数保存されているため、先頭の値を表示しています。');
          continue;
        }
        primaryGoal = code;
      } else {
        secondaryGoals.add(code);
      }
    }
    if (secondaryGoals.isEmpty) {
      secondaryGoals.add('NONE');
    }

    final locations = await _loadLocations(userId);
    final equipment = await _loadEquipment(userId, locations.idToType);
    final schedule = await _loadSchedule(userId, locations.idToType);
    final priorities = await _loadPriorities(userId, warnings);
    final restrictions = await _loadRestrictions(userId, warnings);

    final bodyFat = measurement?.readNullable<double>('body_fat_percent');
    final draft = OnboardingDraft(
      id: 'settings-$userId',
      userId: userId,
      currentStep: OnboardingStep.review,
      nickname: profile.read<String>('nickname'),
      ageYears: profile.read<int>('age_years'),
      sexCode: profile.readNullable<String>('sex_code'),
      heightCm: profile.readNullable<double>('height_cm'),
      weightKg: measurement?.readNullable<double>('weight_kg'),
      knowsBodyFat: bodyFat != null,
      bodyFatPercent: bodyFat,
      primaryGoalCode: primaryGoal,
      secondaryGoalCodes: secondaryGoals,
      cumulativeExperienceCode:
          experience.read<String>('cumulative_experience_code'),
      continuityCode: experience.read<String>('continuity_code'),
      hiatusCode: experience.readNullable<String>('hiatus_code'),
      currentFrequency: experience.read<int>('current_frequency'),
      adjustmentHabitCode:
          experience.read<String>('adjustment_habit_code'),
      loggingHabitCode: experience.read<String>('logging_habit_code'),
      locationModeCode: setting.read<String>('location_mode_code'),
      bothUsageModeCode:
          setting.readNullable<String>('both_usage_mode_code'),
      gymProfileCode: locations.gymProfileCode,
      homeEquipmentCodes: equipment.homeCodes,
      limitedGymEquipmentCodes: equipment.gymCodes,
      fixedDumbbells: equipment.fixedDumbbells,
      adjustableDumbbells: equipment.adjustableDumbbells,
      barbellSetup: equipment.barbell,
      desiredDaysPerWeek: setting.read<int>('desired_days_per_week'),
      availableWeekdayCodes: schedule.availableWeekdays,
      scheduleLocationByWeekday: schedule.locationByWeekday,
      usualDurationMin: setting.read<int>('usual_duration_min'),
      splitPreferenceCode: setting.read<String>('split_preference_code'),
      primaryPriorityCode: priorities.primary,
      secondaryPriorityCodes: priorities.secondary,
      appearancePriorityCodes: priorities.appearance,
      abGoalCode: setting.read<String>('ab_goal_code'),
      painActionsByArea: restrictions.painActions,
      avoidBodyPartCodes: restrictions.bodyParts,
      avoidMovementGroupCodes: restrictions.movementGroups,
      avoidExerciseCodes: restrictions.exercises,
    );
    return TrainingSettingsSnapshot(
      draft: draft,
      warnings: List<String>.unmodifiable(warnings),
    );
  }

  @override
  Future<TrainingSettingsSaveResult> saveSection({
    required TrainingSettingsSection section,
    required OnboardingDraft original,
    required OnboardingDraft updated,
  }) async {
    await _writer.saveTrainingSettingsSection(
      section: section,
      draft: updated,
    );
    return TrainingSettingsSaveResult(
      section: section,
      impact: section.changeImpact(original, updated),
    );
  }

  Future<_LocationState> _loadLocations(String userId) async {
    final rows = await _database.customSelect(
      '''
      SELECT id, location_type_code, gym_profile_code
      FROM training_location
      WHERE user_id = ? AND deleted_at IS NULL
      ORDER BY is_primary DESC, created_at
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    final idToType = <String, String>{};
    String? gymProfileCode;
    for (final row in rows) {
      final type = row.read<String>('location_type_code');
      idToType[row.read<String>('id')] = type;
      if (type == 'GYM') {
        gymProfileCode ??= row.readNullable<String>('gym_profile_code');
      }
    }
    return _LocationState(
      idToType: idToType,
      gymProfileCode: gymProfileCode,
    );
  }

  Future<_EquipmentState> _loadEquipment(
    String userId,
    Map<String, String> locationTypes,
  ) async {
    final optionRows = await _database.customSelect(
      '''
      SELECT location_equipment_id, weight_value, quantity
      FROM equipment_weight_option
      WHERE user_id = ? AND deleted_at IS NULL
      ORDER BY weight_value
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    final optionsByEquipment = <String, List<WeightOptionDraft>>{};
    for (final row in optionRows) {
      optionsByEquipment
          .putIfAbsent(
            row.read<String>('location_equipment_id'),
            () => <WeightOptionDraft>[],
          )
          .add(
            WeightOptionDraft(
              weightKg: row.read<double>('weight_value'),
              quantity: row.read<int>('quantity'),
            ),
          );
    }

    final rows = await _database.customSelect(
      '''
      SELECT le.id AS location_equipment_id,
             le.training_location_id,
             em.code AS equipment_code,
             le.quantity, le.min_weight, le.max_weight, le.increment_weight,
             le.has_rack, le.has_safety,
             dd.setup_type_code, dd.unit_count,
             bd.shaft_weight_kg, bd.max_total_weight_kg,
             bd.min_increment_kg, bd.has_rack AS barbell_has_rack,
             bd.has_safety AS barbell_has_safety
      FROM location_equipment le
      JOIN equipment_master em ON em.id = le.equipment_id
      LEFT JOIN location_dumbbell_detail dd
        ON dd.location_equipment_id = le.id AND dd.deleted_at IS NULL
      LEFT JOIN location_barbell_detail bd
        ON bd.location_equipment_id = le.id AND bd.deleted_at IS NULL
      WHERE le.user_id = ?
        AND le.deleted_at IS NULL
        AND le.is_available = 1
      ORDER BY le.created_at
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();

    final homeCodes = <String>{};
    final gymCodes = <String>{};
    DumbbellSetupDraft? fixedDumbbells;
    DumbbellSetupDraft? adjustableDumbbells;
    BarbellSetupDraft? barbell;
    for (final row in rows) {
      final locationType = locationTypes[
          row.read<String>('training_location_id')];
      if (locationType == null) {
        continue;
      }
      final equipmentCode = row.read<String>('equipment_code');
      final equipmentId = row.read<String>('location_equipment_id');
      if (locationType == 'GYM') {
        gymCodes.add(equipmentCode);
        continue;
      }
      if (equipmentCode == 'DUMBBELL') {
        final setupType = row.readNullable<String>('setup_type_code');
        final setup = DumbbellSetupDraft(
          setupTypeCode: setupType ?? 'ADJUSTABLE',
          unitCount: row.readNullable<int>('unit_count') ??
              row.read<int>('quantity'),
          minWeightKg: row.readNullable<double>('min_weight'),
          maxWeightKg: row.readNullable<double>('max_weight'),
          incrementWeightKg: row.readNullable<double>('increment_weight'),
          weightOptions: List<WeightOptionDraft>.unmodifiable(
            optionsByEquipment[equipmentId] ?? const <WeightOptionDraft>[],
          ),
        );
        if (setup.setupTypeCode == 'FIXED') {
          homeCodes.add('FIXED_DUMBBELL');
          fixedDumbbells = setup;
        } else {
          homeCodes.add('ADJUSTABLE_DUMBBELL');
          adjustableDumbbells = setup;
        }
      } else if (equipmentCode == 'BARBELL') {
        homeCodes.add('BARBELL');
        barbell = BarbellSetupDraft(
          shaftWeightKg:
              row.readNullable<double>('shaft_weight_kg') ??
                  row.readNullable<double>('min_weight') ??
                  20,
          maxTotalWeightKg:
              row.readNullable<double>('max_total_weight_kg') ??
                  row.readNullable<double>('max_weight') ??
                  100,
          minIncrementKg:
              row.readNullable<double>('min_increment_kg') ??
                  row.readNullable<double>('increment_weight') ??
                  2.5,
          hasRack: (row.readNullable<int>('barbell_has_rack') ??
                  row.read<int>('has_rack')) ==
              1,
          hasSafety: (row.readNullable<int>('barbell_has_safety') ??
                  row.read<int>('has_safety')) ==
              1,
          plateOptions: List<WeightOptionDraft>.unmodifiable(
            optionsByEquipment[equipmentId] ?? const <WeightOptionDraft>[],
          ),
        );
      } else {
        homeCodes.add(equipmentCode);
      }
    }
    if (homeCodes.isEmpty && locationTypes.values.contains('HOME')) {
      homeCodes.add('NONE');
    }
    return _EquipmentState(
      homeCodes: homeCodes,
      gymCodes: gymCodes,
      fixedDumbbells: fixedDumbbells,
      adjustableDumbbells: adjustableDumbbells,
      barbell: barbell,
    );
  }

  Future<_ScheduleState> _loadSchedule(
    String userId,
    Map<String, String> locationTypes,
  ) async {
    final rows = await _database.customSelect(
      '''
      SELECT weekday_code, is_available, training_location_id
      FROM standard_schedule_day
      WHERE user_id = ? AND deleted_at IS NULL
      ORDER BY CASE weekday_code
        WHEN 'MON' THEN 1 WHEN 'TUE' THEN 2 WHEN 'WED' THEN 3
        WHEN 'THU' THEN 4 WHEN 'FRI' THEN 5 WHEN 'SAT' THEN 6
        WHEN 'SUN' THEN 7 ELSE 99 END
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    final available = <String>{};
    final locations = <String, String>{};
    for (final row in rows) {
      if (row.read<int>('is_available') != 1) {
        continue;
      }
      final weekday = row.read<String>('weekday_code');
      available.add(weekday);
      final locationId = row.readNullable<String>('training_location_id');
      final locationType = locationId == null ? null : locationTypes[locationId];
      if (locationType != null) {
        locations[weekday] = locationType;
      }
    }
    return _ScheduleState(
      availableWeekdays: available,
      locationByWeekday: locations,
    );
  }

  Future<_PriorityState> _loadPriorities(
    String userId,
    List<String> warnings,
  ) async {
    final rows = await _database.customSelect(
      '''
      SELECT upp.context_code, upp.priority_type,
             bpm.code AS body_part_code, upp.appearance_code
      FROM user_priority_part upp
      LEFT JOIN body_part_master bpm ON bpm.id = upp.body_part_id
      WHERE upp.user_id = ? AND upp.deleted_at IS NULL
      ORDER BY upp.created_at
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    String? primary;
    final secondary = <String>{};
    final appearance = <String>{};
    for (final row in rows) {
      final context = row.read<String>('context_code');
      final type = row.read<String>('priority_type');
      final code = row.readNullable<String>('body_part_code') ??
          row.readNullable<String>('appearance_code');
      if (code == null) {
        continue;
      }
      if (context == 'APPEARANCE') {
        appearance.add(code);
      } else if (context == 'TRAINING' && type == 'MAIN') {
        if (primary != null) {
          warnings.add('最優先部位が複数保存されているため、先頭の値を表示しています。');
        } else {
          primary = code;
        }
      } else if (context == 'TRAINING') {
        secondary.add(code);
      }
    }
    if (secondary.isEmpty) {
      secondary.add('NONE');
    }
    if (appearance.isEmpty) {
      appearance.add('NONE');
    }
    return _PriorityState(
      primary: primary,
      secondary: secondary,
      appearance: appearance,
    );
  }

  Future<_RestrictionState> _loadRestrictions(
    String userId,
    List<String> warnings,
  ) async {
    final rows = await _database.customSelect(
      '''
      SELECT ur.restriction_type_code, ur.default_action_code,
             bpm.code AS body_part_code, jm.code AS joint_code,
             mm.code AS movement_code, em.code AS exercise_code
      FROM user_restriction ur
      LEFT JOIN body_part_master bpm ON bpm.id = ur.body_part_id
      LEFT JOIN joint_master jm ON jm.id = ur.joint_id
      LEFT JOIN movement_master mm ON mm.id = ur.movement_id
      LEFT JOIN exercise_master em ON em.id = ur.exercise_id
      WHERE ur.user_id = ?
        AND ur.deleted_at IS NULL
        AND (ur.effective_to IS NULL OR ur.effective_to >= date('now'))
      ORDER BY ur.created_at
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    final painActions = <String, String>{};
    final bodyParts = <String>{};
    final movementCounts = <String, int>{};
    final exercises = <String>{};
    for (final row in rows) {
      switch (row.read<String>('restriction_type_code')) {
        case 'PAIN_AREA':
          final joint = row.readNullable<String>('joint_code');
          final body = row.readNullable<String>('body_part_code');
          final key = joint != null ? 'JOINT:$joint' : body != null ? 'BODY:$body' : null;
          if (key != null) {
            painActions[key] = row.read<String>('default_action_code');
          }
          break;
        case 'AVOID_BODY_PART':
          final code = row.readNullable<String>('body_part_code');
          if (code != null) {
            bodyParts.add(code);
          }
          break;
        case 'AVOID_MOVEMENT':
          final code = row.readNullable<String>('movement_code');
          if (code != null) {
            movementCounts[code] = (movementCounts[code] ?? 0) + 1;
          }
          break;
        case 'AVOID_EXERCISE':
          final code = row.readNullable<String>('exercise_code');
          if (code != null) {
            exercises.add(code);
          }
          break;
      }
    }
    final movementGroups = _decodeMovementGroups(movementCounts);
    if (movementGroups == null) {
      warnings.add('避ける動作の保存内容を選択肢へ戻せなかったため、自動推測せず未選択で表示しています。');
    }
    return _RestrictionState(
      painActions: painActions,
      bodyParts: bodyParts,
      movementGroups: movementGroups ?? <String>{},
      exercises: exercises,
    );
  }

  Set<String>? _decodeMovementGroups(Map<String, int> expected) {
    if (expected.isEmpty) {
      return <String>{};
    }
    final groups = OnboardingOptions.avoidMovementCodesByGroup.entries.toList();
    Set<String>? best;
    for (var mask = 0; mask < (1 << groups.length); mask++) {
      final actual = <String, int>{};
      final selected = <String>{};
      for (var index = 0; index < groups.length; index++) {
        if ((mask & (1 << index)) == 0) {
          continue;
        }
        final group = groups[index];
        selected.add(group.key);
        for (final code in group.value) {
          actual[code] = (actual[code] ?? 0) + 1;
        }
      }
      if (_sameCounts(actual, expected) &&
          (best == null || selected.length < best.length)) {
        best = selected;
      }
    }
    return best;
  }

  bool _sameCounts(Map<String, int> left, Map<String, int> right) {
    if (left.length != right.length) {
      return false;
    }
    for (final entry in left.entries) {
      if (right[entry.key] != entry.value) {
        return false;
      }
    }
    return true;
  }
}

final class _LocationState {
  const _LocationState({
    required this.idToType,
    required this.gymProfileCode,
  });

  final Map<String, String> idToType;
  final String? gymProfileCode;
}

final class _EquipmentState {
  const _EquipmentState({
    required this.homeCodes,
    required this.gymCodes,
    required this.fixedDumbbells,
    required this.adjustableDumbbells,
    required this.barbell,
  });

  final Set<String> homeCodes;
  final Set<String> gymCodes;
  final DumbbellSetupDraft? fixedDumbbells;
  final DumbbellSetupDraft? adjustableDumbbells;
  final BarbellSetupDraft? barbell;
}

final class _ScheduleState {
  const _ScheduleState({
    required this.availableWeekdays,
    required this.locationByWeekday,
  });

  final Set<String> availableWeekdays;
  final Map<String, String> locationByWeekday;
}

final class _PriorityState {
  const _PriorityState({
    required this.primary,
    required this.secondary,
    required this.appearance,
  });

  final String? primary;
  final Set<String> secondary;
  final Set<String> appearance;
}

final class _RestrictionState {
  const _RestrictionState({
    required this.painActions,
    required this.bodyParts,
    required this.movementGroups,
    required this.exercises,
  });

  final Map<String, String> painActions;
  final Set<String> bodyParts;
  final Set<String> movementGroups;
  final Set<String> exercises;
}
