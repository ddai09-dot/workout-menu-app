import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_section.dart';

final class TrainingSettingsSnapshot {
  const TrainingSettingsSnapshot({
    required this.draft,
    this.warnings = const <String>[],
  });

  final OnboardingDraft draft;
  final List<String> warnings;
}

final class TrainingSettingsSaveResult {
  const TrainingSettingsSaveResult({
    required this.section,
    required this.impact,
  });

  final TrainingSettingsSection section;
  final TrainingSettingsChangeImpact impact;
}

abstract interface class TrainingSettingsRepository {
  Future<TrainingSettingsSnapshot> load();

  Future<TrainingSettingsSaveResult> saveSection({
    required TrainingSettingsSection section,
    required OnboardingDraft original,
    required OnboardingDraft updated,
  });
}
