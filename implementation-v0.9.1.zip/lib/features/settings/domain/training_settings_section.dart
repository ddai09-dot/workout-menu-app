import 'dart:convert';

import 'package:workout_menu_app/features/onboarding/domain/onboarding_draft.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_option.dart';
import 'package:workout_menu_app/features/onboarding/domain/onboarding_step.dart';

enum TrainingSettingsSection {
  goals,
  experience,
  environment,
  schedule,
  split,
  priorities,
  restrictions,
}

final class TrainingSettingsChangeImpact {
  const TrainingSettingsChangeImpact({
    required this.currentWeekReviewRecommended,
    required this.message,
  });

  final bool currentWeekReviewRecommended;
  final String message;
}

extension TrainingSettingsSectionDefinition on TrainingSettingsSection {
  String get pathSegment => switch (this) {
        TrainingSettingsSection.goals => 'goals',
        TrainingSettingsSection.experience => 'experience',
        TrainingSettingsSection.environment => 'environment',
        TrainingSettingsSection.schedule => 'schedule',
        TrainingSettingsSection.split => 'split',
        TrainingSettingsSection.priorities => 'priorities',
        TrainingSettingsSection.restrictions => 'restrictions',
      };

  String get title => switch (this) {
        TrainingSettingsSection.goals => 'トレーニング目的',
        TrainingSettingsSection.experience => '経験・継続状況',
        TrainingSettingsSection.environment => '環境・器具',
        TrainingSettingsSection.schedule => '通常の予定',
        TrainingSettingsSection.split => 'メニューの分け方',
        TrainingSettingsSection.priorities => '優先部位',
        TrainingSettingsSection.restrictions => '痛み・身体上の制限',
      };

  String get description => switch (this) {
        TrainingSettingsSection.goals => '主目的と副目的を変更します。',
        TrainingSettingsSection.experience => '経験期間、現在の頻度、記録習慣を変更します。',
        TrainingSettingsSection.environment => '利用場所と、実際に使用できる器具を変更します。',
        TrainingSettingsSection.schedule => '通常の日数、曜日、時間、場所を変更します。',
        TrainingSettingsSection.split => '動作別、部位別、アプリおすすめから選びます。',
        TrainingSettingsSection.priorities => '優先部位、見た目の希望、腹筋の目的を変更します。',
        TrainingSettingsSection.restrictions => '痛みの扱いと、避ける部位・動作・種目を変更します。',
      };

  static TrainingSettingsSection? fromPath(String value) {
    for (final section in TrainingSettingsSection.values) {
      if (section.pathSegment == value) {
        return section;
      }
    }
    return null;
  }

  String? validationMessage(OnboardingDraft draft) {
    final steps = switch (this) {
      TrainingSettingsSection.goals => const <OnboardingStep>[
          OnboardingStep.primaryGoal,
          OnboardingStep.secondaryGoals,
        ],
      TrainingSettingsSection.experience => const <OnboardingStep>[
          OnboardingStep.experienceHistory,
          OnboardingStep.experienceCurrent,
        ],
      TrainingSettingsSection.environment => const <OnboardingStep>[
          OnboardingStep.location,
          OnboardingStep.equipment,
          // Location IDs are rebuilt in the same transaction, so the saved
          // standard schedule must remain resolvable as well.
          OnboardingStep.schedule,
        ],
      TrainingSettingsSection.schedule => const <OnboardingStep>[
          OnboardingStep.schedule,
        ],
      TrainingSettingsSection.split => const <OnboardingStep>[
          OnboardingStep.split,
        ],
      TrainingSettingsSection.priorities => const <OnboardingStep>[
          OnboardingStep.priorities,
        ],
      TrainingSettingsSection.restrictions => const <OnboardingStep>[
          OnboardingStep.restrictions,
        ],
    };
    for (final step in steps) {
      final message = draft.validationMessage(step);
      if (message != null) {
        return message;
      }
    }
    return null;
  }

  String fingerprint(OnboardingDraft draft) {
    final value = switch (this) {
      TrainingSettingsSection.goals => <String, Object?>{
          'primary': draft.primaryGoalCode,
          'secondary': _sorted(draft.secondaryGoalCodes),
        },
      TrainingSettingsSection.experience => <String, Object?>{
          'cumulative': draft.cumulativeExperienceCode,
          'continuity': draft.continuityCode,
          'hiatus': draft.hiatusCode,
          'frequency': draft.currentFrequency,
          'adjustment': draft.adjustmentHabitCode,
          'logging': draft.loggingHabitCode,
        },
      TrainingSettingsSection.environment => <String, Object?>{
          'location': draft.locationModeCode,
          'bothUsage': draft.bothUsageModeCode,
          'gymProfile': draft.gymProfileCode,
          'homeEquipment': _sorted(draft.homeEquipmentCodes),
          'gymEquipment': _sorted(draft.limitedGymEquipmentCodes),
          'fixedDumbbells': draft.fixedDumbbells?.toJson(),
          'adjustableDumbbells': draft.adjustableDumbbells?.toJson(),
          'barbell': draft.barbellSetup?.toJson(),
          'scheduleLocations': _sortedMap(draft.scheduleLocationByWeekday),
        },
      TrainingSettingsSection.schedule => <String, Object?>{
          'days': draft.desiredDaysPerWeek,
          'weekdays': _sorted(draft.availableWeekdayCodes),
          'locations': _sortedMap(draft.scheduleLocationByWeekday),
          'duration': draft.usualDurationMin,
        },
      TrainingSettingsSection.split => <String, Object?>{
          'split': draft.splitPreferenceCode,
        },
      TrainingSettingsSection.priorities => <String, Object?>{
          'primary': draft.primaryPriorityCode,
          'secondary': _sorted(draft.secondaryPriorityCodes),
          'appearance': _sorted(draft.appearancePriorityCodes),
          'abGoal': draft.abGoalCode,
        },
      TrainingSettingsSection.restrictions => <String, Object?>{
          'pain': _sortedMap(draft.painActionsByArea),
          'bodyParts': _sorted(draft.avoidBodyPartCodes),
          'movements': _sorted(draft.avoidMovementGroupCodes),
          'exercises': _sorted(draft.avoidExerciseCodes),
        },
    };
    return jsonEncode(value);
  }

  String summary(OnboardingDraft draft) {
    return switch (this) {
      TrainingSettingsSection.goals => _goalsSummary(draft),
      TrainingSettingsSection.experience =>
        '${_label(OnboardingOptions.cumulativeExperience, draft.cumulativeExperienceCode)}／'
            '${_label(OnboardingOptions.continuity, draft.continuityCode)}',
      TrainingSettingsSection.environment => _environmentSummary(draft),
      TrainingSettingsSection.schedule => _scheduleSummary(draft),
      TrainingSettingsSection.split =>
        _label(OnboardingOptions.splitPreferences, draft.splitPreferenceCode),
      TrainingSettingsSection.priorities =>
        _label(OnboardingOptions.priorityParts, draft.primaryPriorityCode),
      TrainingSettingsSection.restrictions => _restrictionSummary(draft),
    };
  }

  TrainingSettingsChangeImpact changeImpact(
    OnboardingDraft original,
    OnboardingDraft updated,
  ) {
    if (this == TrainingSettingsSection.environment &&
        _environmentReduction(original, updated)) {
      return const TrainingSettingsChangeImpact(
        currentWeekReviewRecommended: true,
        message: '利用場所または使用できる器具が減ったため、今週の該当メニューも確認してください。',
      );
    }
    if (this == TrainingSettingsSection.restrictions &&
        _restrictionIncrease(original, updated)) {
      return const TrainingSettingsChangeImpact(
        currentWeekReviewRecommended: true,
        message: '痛み・制限が追加または強化されたため、今週の該当メニューも確認してください。',
      );
    }
    return const TrainingSettingsChangeImpact(
      currentWeekReviewRecommended: false,
      message: '変更は次回のメニュー作成から反映されます。作成済みのメニューと記録は変更していません。',
    );
  }
}

List<String> _sorted(Set<String> values) => values.toList()..sort();

Map<String, String> _sortedMap(Map<String, String> values) {
  final keys = values.keys.toList()..sort();
  return <String, String>{for (final key in keys) key: values[key]!};
}

String _label(List<OnboardingOption> options, String? code) {
  if (code == null) {
    return '未設定';
  }
  for (final option in options) {
    if (option.code == code) {
      return option.label;
    }
  }
  return '設定済み';
}

String _goalsSummary(OnboardingDraft draft) {
  final primary = _label(OnboardingOptions.goals, draft.primaryGoalCode);
  final secondaryCount = draft.secondaryGoalCodes.where((value) => value != 'NONE').length;
  return secondaryCount == 0 ? primary : '$primary／副目的$secondaryCount件';
}

String _environmentSummary(OnboardingDraft draft) {
  final location = _label(OnboardingOptions.locationModes, draft.locationModeCode);
  final equipmentCount = draft.homeEquipmentCodes.where((value) => value != 'NONE').length +
      draft.limitedGymEquipmentCodes.length;
  return equipmentCount == 0 ? location : '$location／器具$equipmentCount件';
}

String _scheduleSummary(OnboardingDraft draft) {
  const weekdayLabels = <String, String>{
    'MON': '月',
    'TUE': '火',
    'WED': '水',
    'THU': '木',
    'FRI': '金',
    'SAT': '土',
    'SUN': '日',
  };
  final days = const <String>['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN']
      .where(draft.availableWeekdayCodes.contains)
      .map((code) => weekdayLabels[code]!)
      .join('・');
  final frequency = draft.desiredDaysPerWeek == null ? '未設定' : '週${draft.desiredDaysPerWeek}日';
  final duration = draft.usualDurationMin == null ? '' : '／${draft.usualDurationMin}分';
  return days.isEmpty ? '$frequency$duration' : '$frequency／$days$duration';
}

String _restrictionSummary(OnboardingDraft draft) {
  final count = draft.painActionsByArea.length +
      draft.avoidBodyPartCodes.length +
      draft.avoidMovementGroupCodes.length +
      draft.avoidExerciseCodes.length;
  return count == 0 ? '特になし' : '$count件設定';
}

bool _environmentReduction(OnboardingDraft before, OnboardingDraft after) {
  if (before.usesHome && !after.usesHome || before.usesGym && !after.usesGym) {
    return true;
  }
  if (before.homeEquipmentCodes.difference(after.homeEquipmentCodes).isNotEmpty ||
      before.limitedGymEquipmentCodes.difference(after.limitedGymEquipmentCodes).isNotEmpty) {
    return true;
  }
  if (before.gymProfileCode != 'LIMITED' && after.gymProfileCode == 'LIMITED') {
    return true;
  }
  if (_dumbbellCapacityReduced(before.fixedDumbbells, after.fixedDumbbells) ||
      _dumbbellCapacityReduced(before.adjustableDumbbells, after.adjustableDumbbells) ||
      _barbellCapacityReduced(before.barbellSetup, after.barbellSetup)) {
    return true;
  }
  return false;
}

bool _dumbbellCapacityReduced(DumbbellSetupDraft? before, DumbbellSetupDraft? after) {
  if (before == null) {
    return false;
  }
  if (after == null || after.unitCount < before.unitCount) {
    return true;
  }
  if (before.minWeightKg != null && after.minWeightKg != null && after.minWeightKg! > before.minWeightKg!) {
    return true;
  }
  if (before.maxWeightKg != null && after.maxWeightKg != null && after.maxWeightKg! < before.maxWeightKg!) {
    return true;
  }
  return _weightOptionsReduced(before.weightOptions, after.weightOptions);
}

bool _barbellCapacityReduced(BarbellSetupDraft? before, BarbellSetupDraft? after) {
  if (before == null) {
    return false;
  }
  if (after == null ||
      after.maxTotalWeightKg < before.maxTotalWeightKg ||
      after.minIncrementKg > before.minIncrementKg ||
      before.hasRack && !after.hasRack ||
      before.hasSafety && !after.hasSafety) {
    return true;
  }
  return _weightOptionsReduced(before.plateOptions, after.plateOptions);
}

bool _weightOptionsReduced(
  List<WeightOptionDraft> before,
  List<WeightOptionDraft> after,
) {
  final afterByWeight = <double, int>{
    for (final option in after) option.weightKg: option.quantity,
  };
  for (final option in before) {
    if ((afterByWeight[option.weightKg] ?? 0) < option.quantity) {
      return true;
    }
  }
  return false;
}

bool _restrictionIncrease(OnboardingDraft before, OnboardingDraft after) {
  const severity = <String, int>{
    'AS_PLANNED': 0,
    'MOVE_LATER': 1,
    'REDUCE_LOAD': 2,
    'SUBSTITUTE': 3,
    'EXCLUDE': 4,
  };
  for (final entry in after.painActionsByArea.entries) {
    final oldAction = before.painActionsByArea[entry.key];
    if (oldAction == null ||
        (severity[entry.value] ?? 99) > (severity[oldAction] ?? 99)) {
      return true;
    }
  }
  return after.avoidBodyPartCodes.difference(before.avoidBodyPartCodes).isNotEmpty ||
      after.avoidMovementGroupCodes.difference(before.avoidMovementGroupCodes).isNotEmpty ||
      after.avoidExerciseCodes.difference(before.avoidExerciseCodes).isNotEmpty;
}
