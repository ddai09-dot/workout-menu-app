import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_menu_plan.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_draft.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_step.dart';
import 'package:workout_menu_app/features/weekly_planner/presentation/weekly_planner_notifier.dart';

final class MenuPage extends ConsumerWidget {
  const MenuPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final value = ref.watch(weeklyPlannerProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('メニュー')),
      body: SafeArea(
        child: value.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (Object error, StackTrace stackTrace) => Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const Text('今週のメニューを読み込めませんでした。'),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () => ref.invalidate(weeklyPlannerProvider),
                    child: const Text('もう一度試す'),
                  ),
                ],
              ),
            ),
          ),
          data: (WeeklyPlannerState state) {
            final plan = state.plan;
            if (plan == null) {
              return _EmptyMenu(
                hasProgress: state.draft.currentStep != WeeklyPlannerStep.start,
              );
            }
            if (plan.isRestWeek) {
              return _RestWeekView(plan: plan);
            }
            return _WeeklyMenuView(plan: plan);
          },
        ),
      ),
      floatingActionButton: value.maybeWhen(
        data: (WeeklyPlannerState state) => state.plan == null
            ? null
            : FloatingActionButton.extended(
                onPressed: () {
                  if (state.draft.finalized) {
                    ref.invalidate(weeklyPlannerProvider);
                  }
                  context.go('/menu/weekly-planner');
                },
                icon: const Icon(Icons.tune),
                label: const Text('今週を調整'),
              ),
        orElse: () => null,
      ),
    );
  }
}

final class _EmptyMenu extends StatelessWidget {
  const _EmptyMenu({required this.hasProgress});

  final bool hasProgress;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Icon(Icons.calendar_month_outlined, size: 56),
            const SizedBox(height: 16),
            Text(
              hasProgress ? '週間メニューの作成途中です' : '今週のメニューは未作成です',
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              hasProgress
                  ? '入力内容は保存されています。前回の続きから再開できます。'
                  : '今週の予定・体調・前週の結果を確認して、実施できるメニューを作成します。',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: () => context.go('/menu/weekly-planner'),
              child: Text(hasProgress ? '作成の続きをする' : '今週のメニューを作成する'),
            ),
          ],
        ),
      ),
    );
  }
}

final class _RestWeekView extends StatelessWidget {
  const _RestWeekView({required this.plan});

  final WeeklyMenuPlan plan;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: <Widget>[
        Text(
          '${_shortDate(plan.weekStartDate)}〜${_shortDate(plan.weekEndDate)}',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: <Widget>[
                const Icon(Icons.hotel_outlined, size: 52),
                const SizedBox(height: 12),
                Text('完全休養週', style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 8),
                const Text(
                  '今週のトレーニングメニューはありません。ウォーキングやストレッチへの自動置換もしていません。',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

final class _WeeklyMenuView extends StatelessWidget {
  const _WeeklyMenuView({required this.plan});

  final WeeklyMenuPlan plan;

  @override
  Widget build(BuildContext context) {
    final byWeekday = <String, WeeklyDayPlan>{
      for (final day in plan.days) day.weekdayCode: day,
    };
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 96),
      children: <Widget>[
        Text(
          '${_shortDate(plan.weekStartDate)}〜${_shortDate(plan.weekEndDate)}',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 4),
        Text(
          plan.splitName,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w700,
              ),
        ),
        const SizedBox(height: 4),
        Text('${plan.days.length}日・約${plan.estimatedTotalMin}分'),
        const SizedBox(height: 20),
        for (final code in WeekdayCodes.ordered) ...<Widget>[
          _MenuDayRow(weekdayCode: code, day: byWeekday[code]),
          const SizedBox(height: 10),
        ],
      ],
    );
  }
}

final class _MenuDayRow extends StatelessWidget {
  const _MenuDayRow({required this.weekdayCode, required this.day});

  final String weekdayCode;
  final WeeklyDayPlan? day;

  @override
  Widget build(BuildContext context) {
    final plan = day;
    final status = switch (plan?.statusCode) {
      'COMPLETED' => '完了',
      'PARTIAL' => '一部実施',
      'SKIPPED' => 'スキップ',
      _ => plan == null ? '休み' : '予定',
    };
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            SizedBox(
              width: 42,
              child: Text(
                WeekdayCodes.label(weekdayCode),
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
              ),
            ),
            Expanded(
              child: plan == null
                  ? const Padding(
                      padding: EdgeInsets.only(top: 4),
                      child: Text('休み'),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          plan.focus,
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 4),
                        Text('${plan.locationName}・約${plan.estimatedDurationMin}分'),
                        const SizedBox(height: 6),
                        Text(
                          plan.exercises
                              .map((PlannedExercisePlan value) => value.exerciseName)
                              .join(' / '),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: <Widget>[
                Text(status, style: Theme.of(context).textTheme.labelLarge),
                if (plan != null && plan.statusCode == 'PLANNED')
                  TextButton(
                    onPressed: () => context.go('/workout/start/${plan.id}'),
                    child: const Text('開始'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

String _shortDate(DateTime value) => '${value.month}/${value.day}';
