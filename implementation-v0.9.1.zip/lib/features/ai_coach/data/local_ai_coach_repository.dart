import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:drift/drift.dart';
import 'package:uuid/uuid.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/features/ai_coach/data/edge_ai_coach_gateway.dart';
import 'package:workout_menu_app/features/ai_coach/domain/ai_coach_repository.dart';
import 'package:workout_menu_app/features/ai_coach/domain/ai_models.dart';
import 'package:workout_menu_app/features/ai_coach/domain/ai_context_builder.dart';

final class LocalAiCoachRepository implements AiCoachRepository {
  LocalAiCoachRepository({required AppDatabase database, required EdgeAiCoachGateway gateway, required String userId})
      : _database = database, _gateway = gateway, _userId = userId;
  final AppDatabase _database;
  final EdgeAiCoachGateway _gateway;
  final String _userId;
  final _ids = const Uuid();
  final _contextBuilder = const AiContextBuilder();

  @override
  Future<AiCoachResponse> ask(AiCoachRequest request) async {
    final sanitized = _contextBuilder.sanitize(request.context);
    final requestHash = sha256.convert(utf8.encode('${request.scope.name}:${request.userText.trim()}')).toString();
    final contextHash = sha256.convert(utf8.encode(jsonEncode(sanitized))).toString();
    final cached = await _database.customSelect(
      'SELECT response_text, safety_code FROM ai_response_cache WHERE user_id = ? AND request_hash = ? AND context_hash = ? AND expires_at > CURRENT_TIMESTAMP LIMIT 1',
      variables: <Variable<Object>>[Variable<String>(_userId), Variable<String>(requestHash), Variable<String>(contextHash)],
    ).getSingleOrNull();
    if (cached != null) {
      return AiCoachResponse(text: cached.read<String>('response_text'), safetyCode: _safety(cached.read<String>('safety_code')), fromCache: true, createdAt: DateTime.now());
    }
    final response = await _gateway.ask(AiCoachRequest(userText: request.userText, scope: request.scope, context: sanitized, exerciseId: request.exerciseId));
    if (response.safetyCode != AiSafetyCode.blocked) {
      await _database.customStatement(
        'INSERT OR REPLACE INTO ai_response_cache (id,user_id,request_hash,context_hash,response_text,safety_code,created_at,expires_at) VALUES (?,?,?,?,?,?,CURRENT_TIMESTAMP,datetime(CURRENT_TIMESTAMP,\'+24 hours\'))',
        <Object?>[_ids.v4(), _userId, requestHash, contextHash, response.text, response.safetyCode.name.toUpperCase()],
      );
    }
    return response;
  }

  @override
  Future<List<AiChatEntry>> loadHistory({String? sessionId}) async {
    final rows = await _database.customSelect(
      sessionId == null
        ? 'SELECT id,role_code,content_text,safety_code,created_at FROM ai_chat_message WHERE user_id = ? AND deleted_at IS NULL ORDER BY created_at DESC LIMIT 100'
        : 'SELECT id,role_code,content_text,safety_code,created_at FROM ai_chat_message WHERE user_id = ? AND chat_session_id = ? AND deleted_at IS NULL ORDER BY created_at',
      variables: <Variable<Object>>[Variable<String>(_userId), if (sessionId != null) Variable<String>(sessionId)],
    ).get();
    return rows.map((row) => AiChatEntry(id: row.read<String>('id'), roleCode: row.read<String>('role_code'), text: row.read<String>('content_text'), safetyCode: _safety(row.read<String>('safety_code')), createdAt: DateTime.parse(row.read<String>('created_at')))).toList();
  }

  @override
  Future<void> saveFeedback({required String messageId, required bool helpful}) => _database.customStatement(
    'INSERT OR REPLACE INTO ai_feedback (id,user_id,message_id,rating_code,created_at) VALUES (?,?,?,?,CURRENT_TIMESTAMP)',
    <Object?>[_ids.v4(), _userId, messageId, helpful ? 'HELPFUL' : 'NOT_HELPFUL'],
  );

  @override
  Future<List<Map<String, String>>> searchFaq(String query) async {
    final rows = await _database.customSelect('SELECT question_text,answer_text FROM ai_faq WHERE is_active = 1 AND (question_text LIKE ? OR answer_text LIKE ?) ORDER BY sort_order LIMIT 30', variables: <Variable<Object>>[Variable<String>('%$query%'), Variable<String>('%$query%')]).get();
    return rows.map((r) => <String,String>{'question':r.read<String>('question_text'),'answer':r.read<String>('answer_text')}).toList();
  }

  @override
  Future<List<Map<String, String>>> searchDictionary(String query) async {
    final rows = await _database.customSelect('SELECT display_term,definition_text FROM ai_dictionary WHERE is_active = 1 AND (display_term LIKE ? OR definition_text LIKE ?) ORDER BY sort_order LIMIT 30', variables: <Variable<Object>>[Variable<String>('%$query%'), Variable<String>('%$query%')]).get();
    return rows.map((r) => <String,String>{'term':r.read<String>('display_term'),'definition':r.read<String>('definition_text')}).toList();
  }

  AiSafetyCode _safety(String value) => switch (value) { 'MEDICAL_ESCALATION' => AiSafetyCode.medicalEscalation, 'BLOCKED' => AiSafetyCode.blocked, _ => AiSafetyCode.ok };
}
