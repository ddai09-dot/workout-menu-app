import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:workout_menu_app/features/ai_coach/domain/ai_models.dart';

final class EdgeAiCoachGateway {
  EdgeAiCoachGateway(this._client);
  final SupabaseClient? _client;

  Future<AiCoachResponse> ask(AiCoachRequest request) async {
    final client = _client;
    if (client == null) {
      return AiCoachResponse(
        text: 'AI相談は現在利用できません。基本メニューと進行判断は、引き続きルールベースで利用できます。',
        safetyCode: AiSafetyCode.blocked,
        fromCache: false,
        createdAt: DateTime.now(),
      );
    }
    final response = await client.functions.invoke('ai-coach', body: <String, Object?>{
      'message': request.userText,
      'scope': request.scope.name,
      'exerciseId': request.exerciseId,
      'context': request.context,
    });
    final data = response.data;
    if (data is! Map) throw StateError('Invalid AI response');
    final code = switch (data['safetyCode']) {
      'MEDICAL_ESCALATION' => AiSafetyCode.medicalEscalation,
      'BLOCKED' => AiSafetyCode.blocked,
      _ => AiSafetyCode.ok,
    };
    return AiCoachResponse(
      text: data['text']?.toString() ?? '回答を取得できませんでした。',
      safetyCode: code,
      fromCache: data['fromCache'] == true,
      createdAt: DateTime.now(),
    );
  }
}
