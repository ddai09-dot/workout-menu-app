abstract interface class AiExplanationGateway {
  Future<AiExplanation> explain(AiExplanationRequest request);
}

final class AiExplanationRequest {
  const AiExplanationRequest({
    required this.topicCode,
    required this.structuredContext,
  });

  final String topicCode;
  final Map<String, Object?> structuredContext;
}

final class AiExplanation {
  const AiExplanation({
    required this.text,
    required this.createdAt,
  });

  final String text;
  final DateTime createdAt;
}
