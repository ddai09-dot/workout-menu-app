import 'package:workout_menu_app/features/ai_coach/domain/ai_models.dart';

abstract interface class AiCoachRepository {
  Future<List<AiChatEntry>> loadHistory({String? sessionId});
  Future<AiCoachResponse> ask(AiCoachRequest request);
  Future<void> saveFeedback({required String messageId, required bool helpful});
  Future<List<Map<String, String>>> searchFaq(String query);
  Future<List<Map<String, String>>> searchDictionary(String query);
}
