final class AiContextBuilder {
  const AiContextBuilder();

  Map<String, Object?> sanitize(Map<String, Object?> source) {
    const denied = <String>{'name', 'email', 'phone', 'address', 'authSubject', 'freeTextNote'};
    final output = <String, Object?>{};
    source.forEach((String key, Object? value) {
      if (!denied.contains(key)) output[key] = value;
    });
    return output;
  }
}
