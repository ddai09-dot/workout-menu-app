enum AiAdviceScope { general, exerciseForm, todayMenu, stagnation, pain }

enum AiSafetyCode { ok, medicalEscalation, blocked }

final class AiChatEntry {
  const AiChatEntry({required this.id, required this.roleCode, required this.text, required this.createdAt, this.safetyCode = AiSafetyCode.ok});
  final String id;
  final String roleCode;
  final String text;
  final DateTime createdAt;
  final AiSafetyCode safetyCode;
}

final class AiCoachRequest {
  const AiCoachRequest({required this.userText, required this.scope, required this.context, this.exerciseId});
  final String userText;
  final AiAdviceScope scope;
  final Map<String, Object?> context;
  final String? exerciseId;
}

final class AiCoachResponse {
  const AiCoachResponse({required this.text, required this.safetyCode, required this.fromCache, required this.createdAt});
  final String text;
  final AiSafetyCode safetyCode;
  final bool fromCache;
  final DateTime createdAt;
}
