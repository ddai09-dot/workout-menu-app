import 'package:flutter/material.dart';
final class AiKnowledgePage extends StatelessWidget { const AiKnowledgePage({super.key});
@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('用語・FAQ')),body:ListView(padding:const EdgeInsets.all(16),children:const [
  ExpansionTile(title:Text('RPE'),children:[ListTile(title:Text('主観的運動強度。あと何回できそうかを含めて、きつさを評価する考え方です。'))]),
  ExpansionTile(title:Text('ダブルプログレッション'),children:[ListTile(title:Text('同じ重量で回数を伸ばし、上限を安定して達成した後に重量を上げる進行方法です。'))]),
  ExpansionTile(title:Text('痛みがある場合は？'),children:[ListTile(title:Text('痛みを我慢して続けず、該当種目を中止してください。強い痛みや継続する痛みは医療機関へ相談してください。'))]),
]));}
