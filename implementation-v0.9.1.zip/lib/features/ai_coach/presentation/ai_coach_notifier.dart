import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/features/ai_coach/domain/ai_models.dart';

final aiCoachProvider = NotifierProvider<AiCoachNotifier, AsyncValue<List<AiChatEntry>>>(AiCoachNotifier.new);

final class AiCoachNotifier extends Notifier<AsyncValue<List<AiChatEntry>>> {
  @override
  AsyncValue<List<AiChatEntry>> build() => const AsyncData(<AiChatEntry>[]);

  Future<void> submit(String text, {AiAdviceScope scope = AiAdviceScope.general, String? exerciseId}) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty || trimmed.length > 500) return;
    final current = state.value ?? const <AiChatEntry>[];
    final now = DateTime.now();
    state = AsyncData(<AiChatEntry>[...current, AiChatEntry(id: 'local-${now.microsecondsSinceEpoch}', roleCode: 'USER', text: trimmed, createdAt: now)]);
    state = const AsyncLoading();
    // Repository wiring is intentionally done in bootstrap after Supabase and the active user are available.
    final fallback = AiChatEntry(
      id: 'assistant-${DateTime.now().microsecondsSinceEpoch}', roleCode: 'ASSISTANT',
      text: 'AI接続設定後に回答を表示します。メニュー生成・重量・進行判断はAIではなく、既存のルールエンジンが決定します。',
      createdAt: DateTime.now(), safetyCode: AiSafetyCode.blocked,
    );
    state = AsyncData(<AiChatEntry>[...current, AiChatEntry(id: 'local-${now.microsecondsSinceEpoch}', roleCode: 'USER', text: trimmed, createdAt: now), fallback]);
  }
}
