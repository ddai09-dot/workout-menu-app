import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/features/ai_coach/presentation/ai_coach_notifier.dart';

final class AiCoachPage extends ConsumerStatefulWidget { const AiCoachPage({super.key}); @override ConsumerState<AiCoachPage> createState()=>_State(); }
final class _State extends ConsumerState<AiCoachPage> {
  final controller=TextEditingController();
  @override void dispose(){controller.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    final state=ref.watch(aiCoachProvider);
    return Scaffold(appBar:AppBar(title:const Text('AI相談')),
      body:SafeArea(child:Column(children:[
        const MaterialBanner(content:Text('AIは説明・相談専用です。メニュー、重量、セット数、進行判断は変更しません。'),actions:[SizedBox.shrink()]),
        Expanded(child:state.when(
          loading:()=>const Center(child:CircularProgressIndicator()),
          error:(e,_)=>Center(child:Text('回答を取得できませんでした: $e')),
          data:(items)=>items.isEmpty?const _Empty():ListView.builder(padding:const EdgeInsets.all(16),itemCount:items.length,itemBuilder:(context,i){final m=items[i];return Align(alignment:m.roleCode=='USER'?Alignment.centerRight:Alignment.centerLeft,child:Card(child:Padding(padding:const EdgeInsets.all(12),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:320),child:Text(m.text)))));}),
        )),
        Padding(padding:const EdgeInsets.all(12),child:Row(children:[Expanded(child:TextField(controller:controller,maxLength:500,maxLines:3,minLines:1,decoration:const InputDecoration(labelText:'相談内容',hintText:'例：胸に効かない原因を知りたい',border:OutlineInputBorder()))),const SizedBox(width:8),IconButton.filled(onPressed:(){final t=controller.text;controller.clear();ref.read(aiCoachProvider.notifier).submit(t);},icon:const Icon(Icons.send),tooltip:'送信')]))
      ])));
  }
}
final class _Empty extends StatelessWidget{const _Empty();@override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(24),children:const [Icon(Icons.psychology_alt_outlined,size:56),SizedBox(height:16),Text('トレーニングの理由やフォームについて相談できます。',textAlign:TextAlign.center),SizedBox(height:8),Text('痛みについては診断せず、運動中止や医療機関への相談を案内します。',textAlign:TextAlign.center)]);}
