import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/settings/domain/training_settings_section.dart';
import 'package:workout_menu_app/features/settings/presentation/training_settings_providers.dart';

final class MyPage extends ConsumerWidget {
  const MyPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(trainingSettingsSnapshotProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('マイページ')),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            ref.invalidate(trainingSettingsSnapshotProvider);
            await ref.read(trainingSettingsSnapshotProvider.future);
          },
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            children: <Widget>[
              Text(
                'トレーニング設定',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 8),
              Text(
                '登録内容を項目ごとに変更できます。作成済みのメニューと記録は自動で書き換えません。',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 12),
              settings.when(
                data: (snapshot) => Column(
                  children: <Widget>[
                    for (final section in TrainingSettingsSection.values)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Card(
                          clipBehavior: Clip.antiAlias,
                          child: ListTile(
                            minVerticalPadding: 16,
                            leading: Icon(_iconFor(section)),
                            title: Text(section.title),
                            subtitle: Text(section.summary(snapshot.draft)),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () => context.go(
                              '/my-page/settings/${section.pathSegment}',
                            ),
                          ),
                        ),
                      ),
                    for (final warning in snapshot.warnings)
                      Padding(
                        padding: const EdgeInsets.only(top: 4, bottom: 8),
                        child: Card(
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                const Icon(Icons.info_outline),
                                const SizedBox(width: 12),
                                Expanded(child: Text(warning)),
                              ],
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                loading: () => const Card(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(child: CircularProgressIndicator()),
                  ),
                ),
                error: (Object error, StackTrace stackTrace) => Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        const Text('トレーニング設定を読み込めませんでした。'),
                        const SizedBox(height: 12),
                        OutlinedButton(
                          onPressed: () =>
                              ref.invalidate(trainingSettingsSnapshotProvider),
                          child: const Text('もう一度読み込む'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'アプリ',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 8),
              Card(
                clipBehavior: Clip.antiAlias,
                child: ListTile(
                  leading: const Icon(Icons.menu_book_outlined),
                  title: const Text('用語・FAQ'),
                  subtitle: const Text('トレーニング用語と基本的な使い方'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => context.push('/ai-knowledge'),
                ),
              ),
              const SizedBox(height: 8),
              Card(
                clipBehavior: Clip.antiAlias,
                child: ListTile(
                  leading: const Icon(Icons.delete_outline),
                  title: const Text('端末内データ'),
                  subtitle: const Text('登録内容と記録を削除して最初から始める'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => context.push('/my-page/data'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  IconData _iconFor(TrainingSettingsSection section) {
    return switch (section) {
      TrainingSettingsSection.goals => Icons.flag_outlined,
      TrainingSettingsSection.experience => Icons.timeline_outlined,
      TrainingSettingsSection.environment => Icons.fitness_center_outlined,
      TrainingSettingsSection.schedule => Icons.calendar_month_outlined,
      TrainingSettingsSection.split => Icons.account_tree_outlined,
      TrainingSettingsSection.priorities => Icons.star_outline,
      TrainingSettingsSection.restrictions => Icons.health_and_safety_outlined,
    };
  }
}
