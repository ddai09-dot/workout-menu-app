import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/home/presentation/today_action_notifier.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_draft.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_step.dart';
import 'package:workout_menu_app/features/weekly_planner/presentation/steps/weekly_planner_steps.dart';
import 'package:workout_menu_app/features/weekly_planner/presentation/weekly_planner_notifier.dart';

final class WeeklyPlannerFlowPage extends ConsumerWidget {
  const WeeklyPlannerFlowPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final value = ref.watch(weeklyPlannerProvider);
    return value.when(
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (Object error, StackTrace stackTrace) => Scaffold(
        appBar: AppBar(title: const Text('今週のメニュー')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                const Text('週間メニューの情報を読み込めませんでした。'),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () => ref.invalidate(weeklyPlannerProvider),
                  child: const Text('もう一度試す'),
                ),
              ],
            ),
          ),
        ),
      ),
      data: (WeeklyPlannerState plannerState) {
        final notifier = ref.read(weeklyPlannerProvider.notifier);
        final draft = plannerState.draft;
        return Scaffold(
          appBar: AppBar(
            title: Text(draft.currentStep.title),
            leading: draft.currentStep == WeeklyPlannerStep.start
                ? IconButton(
                    onPressed: () => context.go('/menu'),
                    icon: const Icon(Icons.close),
                  )
                : IconButton(
                    onPressed: plannerState.isBusy
                        ? null
                        : () => unawaited(notifier.back()),
                    icon: const Icon(Icons.arrow_back),
                  ),
          ),
          body: SafeArea(
            child: Column(
              children: <Widget>[
                if (draft.currentStep != WeeklyPlannerStep.start)
                  LinearProgressIndicator(
                    value: draft.currentStep.progressIndex / 5,
                  ),
                if (plannerState.isSaving)
                  const LinearProgressIndicator(minHeight: 2),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 132),
                    children: <Widget>[
                      if (_subtitle(draft.currentStep) case final subtitle?) ...<Widget>[
                        Text(subtitle, style: Theme.of(context).textTheme.bodyLarge),
                        const SizedBox(height: 20),
                      ],
                      _stepBody(
                        state: plannerState,
                        onChanged: (WeeklyPlannerDraft next) {
                          unawaited(
                            notifier.updateDraft((WeeklyPlannerDraft _) => next),
                          );
                        },
                        onRestWeek: () => unawaited(
                          _confirmRestWeek(context, notifier, ref),
                        ),
                      ),
                      if (plannerState.message != null) ...<Widget>[
                        const SizedBox(height: 16),
                        Text(
                          plannerState.message!,
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.error,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                      if (draft.currentStep != WeeklyPlannerStep.start) ...<Widget>[
                        const SizedBox(height: 24),
                        TextButton(
                          onPressed: plannerState.isBusy
                              ? null
                              : () => unawaited(_confirmReset(context, notifier)),
                          child: const Text('最初からやり直す'),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
          bottomNavigationBar: SafeArea(
            minimum: const EdgeInsets.fromLTRB(20, 12, 20, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                if (draft.currentStep == WeeklyPlannerStep.review) ...<Widget>[
                  OutlinedButton(
                    onPressed: plannerState.isBusy
                        ? null
                        : () => unawaited(notifier.reviseConditions()),
                    child: const Text('条件を修正して作り直す'),
                  ),
                  const SizedBox(height: 8),
                ],
                FilledButton(
                  onPressed: plannerState.isBusy
                      ? null
                      : () => unawaited(
                            _onPrimary(
                              context,
                              ref,
                              plannerState,
                              notifier,
                            ),
                          ),
                  child: plannerState.isGenerating || plannerState.isFinalizing
                      ? const SizedBox.square(
                          dimension: 22,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : Text(_primaryLabel(draft.currentStep)),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _stepBody({
    required WeeklyPlannerState state,
    required ValueChanged<WeeklyPlannerDraft> onChanged,
    required VoidCallback onRestWeek,
  }) {
    final draft = state.draft;
    return switch (draft.currentStep) {
      WeeklyPlannerStep.start =>
        WeeklyStartStep(draft: draft, onRestWeek: onRestWeek),
      WeeklyPlannerStep.schedule => WeeklyScheduleStep(
          draft: draft,
          locations: state.locations,
          onChanged: onChanged,
        ),
      WeeklyPlannerStep.condition =>
        WeeklyConditionStep(draft: draft, onChanged: onChanged),
      WeeklyPlannerStep.previousWeek => WeeklyPreviousStep(
          draft: draft,
          previousExercises: state.previousExercises,
          onChanged: onChanged,
        ),
      WeeklyPlannerStep.adjustment =>
        WeeklyAdjustmentStep(draft: draft, onChanged: onChanged),
      WeeklyPlannerStep.review => state.plan == null
          ? const Center(child: CircularProgressIndicator())
          : WeeklyReviewStep(plan: state.plan!),
    };
  }

  Future<void> _onPrimary(
    BuildContext context,
    WidgetRef ref,
    WeeklyPlannerState state,
    WeeklyPlannerNotifier notifier,
  ) async {
    if (state.draft.currentStep == WeeklyPlannerStep.review) {
      final completed = await notifier.finalize();
      if (completed && context.mounted) {
        ref.invalidate(todayActionProvider);
        context.go('/menu');
      }
      return;
    }
    await notifier.next();
  }

  Future<void> _confirmRestWeek(
    BuildContext context,
    WeeklyPlannerNotifier notifier,
    WidgetRef ref,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('今週を完全休養にしますか？'),
        content: const Text(
          '今週のトレーニングメニューは作成しません。ウォーキングやストレッチへの自動変更も行いません。',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('キャンセル'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('完全休養にする'),
          ),
        ],
      ),
    );
    if (confirmed ?? false) {
      final completed = await notifier.createRestWeek();
      if (completed && context.mounted) {
        ref.invalidate(todayActionProvider);
        context.go('/menu');
      }
    }
  }

  Future<void> _confirmReset(
    BuildContext context,
    WeeklyPlannerNotifier notifier,
  ) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('最初からやり直しますか？'),
        content: const Text('今週の入力内容と未確定メニューを破棄します。確定済みの過去履歴は削除しません。'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('キャンセル'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('やり直す'),
          ),
        ],
      ),
    );
    if (confirmed ?? false) {
      await notifier.reset();
    }
  }

  String _primaryLabel(WeeklyPlannerStep step) => switch (step) {
        WeeklyPlannerStep.start => '今週の予定を入力する',
        WeeklyPlannerStep.schedule => '体調の確認へ',
        WeeklyPlannerStep.condition => '次へ',
        WeeklyPlannerStep.previousWeek => '調整方針へ',
        WeeklyPlannerStep.adjustment => 'メニューを作成する',
        WeeklyPlannerStep.review => 'この内容で確定',
      };

  String? _subtitle(WeeklyPlannerStep step) => switch (step) {
        WeeklyPlannerStep.start => null,
        WeeklyPlannerStep.schedule => '実際にトレーニングできる日だけを選んでください。',
        WeeklyPlannerStep.condition => '今日の気分ではなく、今週全体の状態で回答してください。',
        WeeklyPlannerStep.previousWeek => '前週の記録を基に、今週の負荷を調整します。',
        WeeklyPlannerStep.adjustment => '迷う項目は「アプリに任せる」で問題ありません。',
        WeeklyPlannerStep.review => '曜日・種目・セット数を確認し、問題なければ確定してください。',
      };
}
