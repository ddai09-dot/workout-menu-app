import 'package:flutter/material.dart';
import 'package:workout_menu_app/features/onboarding/presentation/widgets/choice_card.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_menu_plan.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_draft.dart';

const Map<String, String> weeklyBodyPartLabels = <String, String>{
  'CHEST': '胸',
  'BACK': '背中',
  'SHOULDERS': '肩',
  'ARMS': '腕',
  'GLUTES': 'お尻',
  'LEGS': '脚',
  'CORE': '腹筋・体幹',
};

final class WeeklyStartStep extends StatelessWidget {
  const WeeklyStartStep({
    required this.draft,
    required this.onRestWeek,
    super.key,
  });

  final WeeklyPlannerDraft draft;
  final VoidCallback onRestWeek;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          '${_shortDate(draft.weekStartDate)}〜${_shortDate(draft.weekEndDate)}',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
              ),
        ),
        const SizedBox(height: 16),
        const _InfoCard(
          icon: Icons.calendar_month_outlined,
          title: '今週だけの予定を確認',
          body: 'トレーニングできる曜日・時間・場所を選びます。前週または通常予定を初期値にしています。',
        ),
        const SizedBox(height: 12),
        const _InfoCard(
          icon: Icons.monitor_heart_outlined,
          title: '体調と前週の結果を反映',
          body: '睡眠、モチベーション、痛み、前週の負荷を使って無理のない構成へ調整します。',
        ),
        const SizedBox(height: 12),
        const _InfoCard(
          icon: Icons.tune,
          title: 'ルールでメニューを作成',
          body: '登録済みの経験・器具・優先部位を基に、AIを使わず再現可能なルールで作成します。',
        ),
        const SizedBox(height: 24),
        OutlinedButton.icon(
          onPressed: onRestWeek,
          icon: const Icon(Icons.hotel_outlined),
          label: const Text('今週は完全休養にする'),
        ),
        const SizedBox(height: 8),
        Text(
          '完全休養を選んだ場合、ウォーキングやストレッチへ自動置換しません。',
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
}

final class WeeklyScheduleStep extends StatelessWidget {
  const WeeklyScheduleStep({
    required this.draft,
    required this.locations,
    required this.onChanged,
    super.key,
  });

  final WeeklyPlannerDraft draft;
  final List<PlannerLocationChoice> locations;
  final ValueChanged<WeeklyPlannerDraft> onChanged;

  static const durations = <int>[15, 30, 45, 60, 90, 120];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          draft.scheduleSourceCode == 'LAST_WEEK'
              ? '前週の曜日・時間・場所をコピーしました。'
              : '通常の予定を初期値にしています。',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 16),
        for (final day in draft.days) ...<Widget>[
          _ScheduleDayCard(
            day: day,
            locations: locations,
            onAvailabilityChanged: (bool selected) {
              onChanged(
                draft.updateDay(
                  day.weekdayCode,
                  (WeeklyDayDraft value) => value.copyWith(
                    isAvailable: selected,
                    durationMin: selected ? value.durationMin ?? 45 : null,
                    locationId: selected
                        ? value.locationId ??
                            (locations.isEmpty ? null : locations.first.id)
                        : null,
                    locationName: selected
                        ? value.locationName ??
                            (locations.isEmpty ? null : locations.first.name)
                        : null,
                  ),
                ),
              );
            },
            onDurationChanged: (int? duration) {
              onChanged(
                draft.updateDay(
                  day.weekdayCode,
                  (WeeklyDayDraft value) => value.copyWith(
                    durationMin: duration,
                  ),
                ),
              );
            },
            onLocationChanged: (String? id) {
              final location = locations
                  .where((PlannerLocationChoice value) => value.id == id)
                  .firstOrNull;
              onChanged(
                draft.updateDay(
                  day.weekdayCode,
                  (WeeklyDayDraft value) => value.copyWith(
                    locationId: id,
                    locationName: location?.name,
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 12),
        ],
      ],
    );
  }
}

final class WeeklyConditionStep extends StatelessWidget {
  const WeeklyConditionStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final WeeklyPlannerDraft draft;
  final ValueChanged<WeeklyPlannerDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        _ScoreSelector(
          title: '睡眠状態',
          value: draft.sleepScore,
          labels: const <String>['かなり悪い', '悪い', '普通', '良い', 'かなり良い'],
          onChanged: (int value) => onChanged(draft.copyWith(sleepScore: value)),
        ),
        const SizedBox(height: 24),
        _ScoreSelector(
          title: 'モチベーション',
          value: draft.motivationScore,
          labels: const <String>['かなり低い', '低い', '普通', '高い', 'かなり高い'],
          onChanged: (int value) =>
              onChanged(draft.copyWith(motivationScore: value)),
        ),
        const SizedBox(height: 8),
        Text(
          'モチベーションだけを理由に重量やセット数を増やすことはありません。',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 24),
        Text('痛み・違和感', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        Text(
          '該当する部位だけ選択し、今週の対応を指定してください。',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 12),
        for (final entry in weeklyBodyPartLabels.entries) ...<Widget>[
          _PainPartCard(
            code: entry.key,
            name: entry.value,
            value: draft.painEntries
                .where((WeeklyPainDraft pain) => pain.bodyPartCode == entry.key)
                .firstOrNull,
            onChanged: (WeeklyPainDraft? pain) {
              final next = draft.painEntries
                  .where(
                    (WeeklyPainDraft value) => value.bodyPartCode != entry.key,
                  )
                  .toList();
              if (pain != null) {
                next.add(pain);
              }
              onChanged(draft.copyWith(painEntries: next));
            },
          ),
          const SizedBox(height: 8),
        ],
      ],
    );
  }
}

final class WeeklyPreviousStep extends StatelessWidget {
  const WeeklyPreviousStep({
    required this.draft,
    required this.previousExercises,
    required this.onChanged,
    super.key,
  });

  final WeeklyPlannerDraft draft;
  final List<PreviousExerciseChoice> previousExercises;
  final ValueChanged<WeeklyPlannerDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        _ScoreSelector(
          title: '前週の全体負荷',
          value: draft.previousLoadScore ?? 3,
          labels: const <String>['軽すぎた', 'やや軽い', '適切', 'やや重い', '重すぎた'],
          onChanged: (int value) =>
              onChanged(draft.copyWith(previousLoadScore: value)),
        ),
        const SizedBox(height: 24),
        _ScoreSelector(
          title: '目標回数の達成状況',
          value: draft.achievementScore ?? 3,
          labels: const <String>['ほぼ未達', '未達が多い', '半分程度', 'ほぼ達成', 'すべて達成'],
          onChanged: (int value) =>
              onChanged(draft.copyWith(achievementScore: value)),
        ),
        const SizedBox(height: 24),
        Text('停滞を感じた種目', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        if (previousExercises.isEmpty)
          const Text('前週に実施した種目がないため、この項目はありません。')
        else
          for (final exercise in previousExercises) ...<Widget>[
            _StallExerciseCard(
              exercise: exercise,
              value: draft.stalledExercises
                  .where(
                    (WeeklyStallDraft value) => value.exerciseId == exercise.id,
                  )
                  .firstOrNull,
              onChanged: (WeeklyStallDraft? stall) {
                final next = draft.stalledExercises
                    .where(
                      (WeeklyStallDraft value) =>
                          value.exerciseId != exercise.id,
                    )
                    .toList();
                if (stall != null) {
                  next.add(stall);
                }
                onChanged(draft.copyWith(stalledExercises: next));
              },
            ),
            const SizedBox(height: 8),
          ],
      ],
    );
  }
}

final class WeeklyAdjustmentStep extends StatelessWidget {
  const WeeklyAdjustmentStep({
    required this.draft,
    required this.onChanged,
    super.key,
  });

  final WeeklyPlannerDraft draft;
  final ValueChanged<WeeklyPlannerDraft> onChanged;

  @override
  Widget build(BuildContext context) {
    const loadOptions = <String, (String, String)>{
      'APP': ('アプリに任せる', '睡眠・前週結果・経験から判定します。'),
      'UP': ('負荷を上げたい', '安全条件を満たす範囲で増やします。'),
      'MAINTAIN': ('維持したい', '前週と同程度を目安にします。'),
      'DOWN': ('負荷を下げたい', 'セット数または重量を抑えます。'),
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('今週の全体負荷', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        for (final option in loadOptions.entries) ...<Widget>[
          ChoiceCard(
            label: option.value.$1,
            description: option.value.$2,
            selected: draft.loadDirectionCode == option.key,
            onTap: () => onChanged(
              draft.copyWith(
                loadDirectionCode: option.key,
                increaseMethodCode: option.key == 'UP'
                    ? draft.increaseMethodCode
                    : null,
              ),
            ),
          ),
          const SizedBox(height: 8),
        ],
        if (draft.loadDirectionCode == 'UP') ...<Widget>[
          const SizedBox(height: 16),
          Text('上げる方法', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: draft.increaseMethodCode,
            decoration: const InputDecoration(
              labelText: '方法を選択',
              border: OutlineInputBorder(),
            ),
            items: const <DropdownMenuItem<String>>[
              DropdownMenuItem(value: 'APP', child: Text('アプリに任せる')),
              DropdownMenuItem(value: 'WEIGHT', child: Text('重量を上げる')),
              DropdownMenuItem(value: 'SETS', child: Text('セット数を増やす')),
              DropdownMenuItem(value: 'EXERCISE', child: Text('種目を増やす')),
              DropdownMenuItem(value: 'SHORTER_REST', child: Text('休憩を短くする')),
            ],
            onChanged: (String? value) =>
                onChanged(draft.copyWith(increaseMethodCode: value)),
          ),
        ],
        const SizedBox(height: 24),
        Text('優先部位', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        for (final option in const <(String, String, String)>[
          ('DEFAULT', '通常設定を使う', '初期登録で選んだ優先部位を使います。'),
          ('CUSTOM', '今週だけ変更する', '今週の最優先部位を選択します。'),
          ('BALANCED', '全身を均等にする', '優先部位を設定せず均等に配分します。'),
        ]) ...<Widget>[
          ChoiceCard(
            label: option.$2,
            description: option.$3,
            selected: draft.priorityModeCode == option.$1,
            onTap: () => onChanged(
              draft.copyWith(
                priorityModeCode: option.$1,
                primaryPriorityCode:
                    option.$1 == 'CUSTOM' ? draft.primaryPriorityCode : null,
                secondaryPriorityCodes: option.$1 == 'CUSTOM'
                    ? draft.secondaryPriorityCodes
                    : const <String>{},
              ),
            ),
          ),
          const SizedBox(height: 8),
        ],
        if (draft.priorityModeCode == 'CUSTOM') ...<Widget>[
          const SizedBox(height: 12),
          Text('最優先部位', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: weeklyBodyPartLabels.entries.map((entry) {
              return ChoiceChip(
                label: Text(entry.value),
                selected: draft.primaryPriorityCode == entry.key,
                onSelected: (_) => onChanged(
                  draft.copyWith(primaryPriorityCode: entry.key),
                ),
              );
            }).toList(growable: false),
          ),
          const SizedBox(height: 16),
          Text('補助優先部位（任意）', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: weeklyBodyPartLabels.entries.map((entry) {
              final selected = draft.secondaryPriorityCodes.contains(entry.key);
              final enabled = draft.primaryPriorityCode != entry.key;
              return FilterChip(
                label: Text(entry.value),
                selected: selected,
                onSelected: enabled
                    ? (bool nextSelected) {
                        final next = <String>{...draft.secondaryPriorityCodes};
                        nextSelected ? next.add(entry.key) : next.remove(entry.key);
                        onChanged(draft.copyWith(secondaryPriorityCodes: next));
                      }
                    : null,
              );
            }).toList(growable: false),
          ),
        ],
        const SizedBox(height: 24),
        DropdownButtonFormField<String>(
          value: draft.splitOverrideCode ?? 'DEFAULT',
          decoration: const InputDecoration(
            labelText: '今週だけ分け方を変更（任意）',
            border: OutlineInputBorder(),
          ),
          items: const <DropdownMenuItem<String>>[
            DropdownMenuItem(value: 'DEFAULT', child: Text('通常設定を使う')),
            DropdownMenuItem(value: 'APP', child: Text('アプリに任せる')),
            DropdownMenuItem(value: 'MOVEMENT', child: Text('動作別')),
            DropdownMenuItem(value: 'BODY_PART', child: Text('部位別')),
          ],
          onChanged: (String? value) => onChanged(
            draft.copyWith(
              splitOverrideCode: value == 'DEFAULT' ? null : value,
            ),
          ),
        ),
      ],
    );
  }
}

final class WeeklyReviewStep extends StatelessWidget {
  const WeeklyReviewStep({required this.plan, super.key});

  final WeeklyMenuPlan plan;

  @override
  Widget build(BuildContext context) {
    if (plan.isRestWeek) {
      return const _InfoCard(
        icon: Icons.hotel_outlined,
        title: '完全休養週',
        body: '今週はトレーニングメニューを作成しません。',
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(plan.splitName, style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 8),
                Text('${plan.days.length}日・${plan.exerciseCount}種目・約${plan.estimatedTotalMin}分'),
                const SizedBox(height: 12),
                for (final reason in plan.summaryReasons)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        const Icon(Icons.check_circle_outline, size: 18),
                        const SizedBox(width: 8),
                        Expanded(child: Text(reason)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
        if (plan.validationMessages.isNotEmpty) ...<Widget>[
          const SizedBox(height: 12),
          Card(
            color: Theme.of(context).colorScheme.errorContainer,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  const Text('確認が必要です', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  for (final message in plan.validationMessages) Text('・$message'),
                ],
              ),
            ),
          ),
        ],
        const SizedBox(height: 16),
        for (final day in plan.days) ...<Widget>[
          _DayPlanCard(day: day),
          const SizedBox(height: 12),
        ],
      ],
    );
  }
}

final class _ScheduleDayCard extends StatelessWidget {
  const _ScheduleDayCard({
    required this.day,
    required this.locations,
    required this.onAvailabilityChanged,
    required this.onDurationChanged,
    required this.onLocationChanged,
  });

  final WeeklyDayDraft day;
  final List<PlannerLocationChoice> locations;
  final ValueChanged<bool> onAvailabilityChanged;
  final ValueChanged<int?> onDurationChanged;
  final ValueChanged<String?> onLocationChanged;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: <Widget>[
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('${WeekdayCodes.label(day.weekdayCode)}曜日  ${_shortDate(day.planDate)}'),
              subtitle: Text(day.isAvailable ? 'トレーニングする' : '休み'),
              value: day.isAvailable,
              onChanged: onAvailabilityChanged,
            ),
            if (day.isAvailable) ...<Widget>[
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  Expanded(
                    child: DropdownButtonFormField<int>(
                      value: day.durationMin,
                      decoration: const InputDecoration(
                        labelText: '時間',
                        border: OutlineInputBorder(),
                      ),
                      items: WeeklyScheduleStep.durations
                          .map(
                            (int value) => DropdownMenuItem<int>(
                              value: value,
                              child: Text(value == 120 ? '90分以上' : '$value分'),
                            ),
                          )
                          .toList(growable: false),
                      onChanged: onDurationChanged,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: locations.any((value) => value.id == day.locationId)
                          ? day.locationId
                          : null,
                      decoration: const InputDecoration(
                        labelText: '場所',
                        border: OutlineInputBorder(),
                      ),
                      items: locations
                          .map(
                            (PlannerLocationChoice value) => DropdownMenuItem<String>(
                              value: value.id,
                              child: Text(value.name, overflow: TextOverflow.ellipsis),
                            ),
                          )
                          .toList(growable: false),
                      onChanged: onLocationChanged,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}

final class _ScoreSelector extends StatelessWidget {
  const _ScoreSelector({
    required this.title,
    required this.value,
    required this.labels,
    required this.onChanged,
  });

  final String title;
  final int value;
  final List<String> labels;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(title, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        SegmentedButton<int>(
          segments: List<ButtonSegment<int>>.generate(
            5,
            (int index) => ButtonSegment<int>(
              value: index + 1,
              label: Text('${index + 1}'),
            ),
          ),
          selected: <int>{value},
          onSelectionChanged: (Set<int> selected) => onChanged(selected.first),
          showSelectedIcon: false,
        ),
        const SizedBox(height: 8),
        Text(labels[value - 1], style: Theme.of(context).textTheme.bodyMedium),
      ],
    );
  }
}

final class _PainPartCard extends StatelessWidget {
  const _PainPartCard({
    required this.code,
    required this.name,
    required this.value,
    required this.onChanged,
  });

  final String code;
  final String name;
  final WeeklyPainDraft? value;
  final ValueChanged<WeeklyPainDraft?> onChanged;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Column(
          children: <Widget>[
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(name),
              value: value != null,
              onChanged: (bool? selected) {
                onChanged(
                  selected ?? false
                      ? WeeklyPainDraft(
                          bodyPartCode: code,
                          bodyPartName: name,
                          actionCode: 'REDUCE_LOAD',
                        )
                      : null,
                );
              },
            ),
            if (value != null)
              DropdownButtonFormField<String>(
                value: value!.actionCode,
                decoration: const InputDecoration(
                  labelText: '今週の対応',
                  border: OutlineInputBorder(),
                ),
                items: const <DropdownMenuItem<String>>[
                  DropdownMenuItem(value: 'REDUCE_LOAD', child: Text('負荷を下げる')),
                  DropdownMenuItem(value: 'SUBSTITUTE', child: Text('別の種目へ変更')),
                  DropdownMenuItem(value: 'EXCLUDE', child: Text('この部位を外す')),
                  DropdownMenuItem(value: 'AS_PLANNED', child: Text('予定どおり行う')),
                ],
                onChanged: (String? action) {
                  if (action != null) {
                    onChanged(
                      WeeklyPainDraft(
                        bodyPartCode: code,
                        bodyPartName: name,
                        actionCode: action,
                      ),
                    );
                  }
                },
              ),
          ],
        ),
      ),
    );
  }
}

final class _StallExerciseCard extends StatelessWidget {
  const _StallExerciseCard({
    required this.exercise,
    required this.value,
    required this.onChanged,
  });

  final PreviousExerciseChoice exercise;
  final WeeklyStallDraft? value;
  final ValueChanged<WeeklyStallDraft?> onChanged;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Column(
          children: <Widget>[
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(exercise.name),
              value: value != null,
              onChanged: (bool? selected) {
                onChanged(
                  selected ?? false
                      ? WeeklyStallDraft(
                          exerciseId: exercise.id,
                          exerciseCode: exercise.code,
                          exerciseName: exercise.name,
                          adjustmentCode: exercise.recommendedAdjustmentCode ?? 'MAINTAIN',
                          recommendedAdjustmentCode: exercise.recommendedAdjustmentCode,
                        )
                      : null,
                );
              },
            ),
            if (value != null)
              DropdownButtonFormField<String>(
                value: value!.adjustmentCode,
                decoration: const InputDecoration(
                  labelText: '今週の調整',
                  border: OutlineInputBorder(),
                ),
                items: const <DropdownMenuItem<String>>[
                  DropdownMenuItem(value: 'MAINTAIN', child: Text('同じ条件で続ける')),
                  DropdownMenuItem(value: 'REDUCE_WEIGHT', child: Text('重量を下げる')),
                  DropdownMenuItem(value: 'CHANGE_REP_RANGE', child: Text('回数帯を変える')),
                  DropdownMenuItem(value: 'SUBSTITUTE', child: Text('種目を変更する')),
                ],
                onChanged: (String? adjustment) {
                  if (adjustment != null) {
                    onChanged(
                      WeeklyStallDraft(
                        exerciseId: exercise.id,
                        exerciseCode: exercise.code,
                        exerciseName: exercise.name,
                        adjustmentCode: adjustment,
                        recommendedAdjustmentCode: exercise.recommendedAdjustmentCode,
                      ),
                    );
                  }
                },
              ),
          ],
        ),
      ),
    );
  }
}

final class _DayPlanCard extends StatelessWidget {
  const _DayPlanCard({required this.day});

  final WeeklyDayPlan day;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(
                    '${WeekdayCodes.label(day.weekdayCode)}曜日  ${day.focus}',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                        ),
                  ),
                ),
                if (day.isLocked) const Chip(label: Text('実施済み固定')),
              ],
            ),
            Text('${day.locationName}・約${day.estimatedDurationMin}分・${day.workSetCount}セット'),
            const SizedBox(height: 6),
            Text(day.reason, style: Theme.of(context).textTheme.bodySmall),
            const Divider(height: 24),
            for (final exercise in day.exercises) ...<Widget>[
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(width: 28, child: Text('${exercise.orderIndex}.')),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(exercise.exerciseName, style: const TextStyle(fontWeight: FontWeight.w600)),
                        Text(_setSummary(exercise.sets)),
                        Text(exercise.reason, style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
            ],
          ],
        ),
      ),
    );
  }
}

final class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.title, required this.body});

  final IconData icon;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Icon(icon),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(body),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

String _shortDate(DateTime value) => '${value.month}/${value.day}';

String _setSummary(List<PlannedSetPlan> sets) {
  final work = sets.where((PlannedSetPlan set) => !set.isWarmup).toList();
  if (work.isEmpty) {
    return 'セット指定なし';
  }
  final first = work.first;
  if (first.targetDurationSec != null) {
    return '${work.length}セット × ${first.targetDurationSec}秒';
  }
  if (first.targetRepsLower != null) {
    final reps = first.targetRepsUpper == first.targetRepsLower
        ? '${first.targetRepsLower}回'
        : '${first.targetRepsLower}〜${first.targetRepsUpper}回';
    return '${work.length}セット × $reps';
  }
  return '${work.length}セット';
}

extension _FirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
