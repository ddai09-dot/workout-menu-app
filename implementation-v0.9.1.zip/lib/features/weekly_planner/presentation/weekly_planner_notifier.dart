import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/database/providers/database_providers.dart';
import 'package:workout_menu_app/features/weekly_planner/data/local_weekly_planner_repository.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_menu_plan.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_draft.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_repository.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_step.dart';

final weeklyPlannerRepositoryProvider = Provider<WeeklyPlannerRepository>((ref) {
  return LocalWeeklyPlannerRepository(ref.watch(appDatabaseProvider));
});

final weeklyPlannerProvider =
    AsyncNotifierProvider<WeeklyPlannerNotifier, WeeklyPlannerState>(
  WeeklyPlannerNotifier.new,
);

final class WeeklyPlannerState {
  const WeeklyPlannerState({
    required this.draft,
    required this.locations,
    required this.previousExercises,
    this.plan,
    this.isSaving = false,
    this.isGenerating = false,
    this.isFinalizing = false,
    this.message,
  });

  final WeeklyPlannerDraft draft;
  final List<PlannerLocationChoice> locations;
  final List<PreviousExerciseChoice> previousExercises;
  final WeeklyMenuPlan? plan;
  final bool isSaving;
  final bool isGenerating;
  final bool isFinalizing;
  final String? message;

  bool get isBusy => isGenerating || isFinalizing;

  WeeklyPlannerState copyWith({
    WeeklyPlannerDraft? draft,
    List<PlannerLocationChoice>? locations,
    List<PreviousExerciseChoice>? previousExercises,
    Object? plan = _unset,
    bool? isSaving,
    bool? isGenerating,
    bool? isFinalizing,
    Object? message = _unset,
  }) {
    return WeeklyPlannerState(
      draft: draft ?? this.draft,
      locations: locations ?? this.locations,
      previousExercises: previousExercises ?? this.previousExercises,
      plan: identical(plan, _unset) ? this.plan : plan as WeeklyMenuPlan?,
      isSaving: isSaving ?? this.isSaving,
      isGenerating: isGenerating ?? this.isGenerating,
      isFinalizing: isFinalizing ?? this.isFinalizing,
      message: identical(message, _unset) ? this.message : message as String?,
    );
  }
}

const Object _unset = Object();

final class WeeklyPlannerNotifier extends AsyncNotifier<WeeklyPlannerState> {
  Future<void> _saveQueue = Future<void>.value();
  int _saveRevision = 0;

  @override
  Future<WeeklyPlannerState> build() async {
    final repository = ref.watch(weeklyPlannerRepositoryProvider);
    final draft = await repository.loadOrCreateCurrentWeekDraft();
    final results = await Future.wait<Object?>(<Future<Object?>>[
      repository.loadLocations(),
      repository.loadPreviousExerciseChoices(draft.weekStartDate),
      repository.loadActivePlan(draft.weekStartDate),
    ]);
    return WeeklyPlannerState(
      draft: draft,
      locations: results[0] as List<PlannerLocationChoice>,
      previousExercises: results[1] as List<PreviousExerciseChoice>,
      plan: results[2] as WeeklyMenuPlan?,
    );
  }

  WeeklyPlannerState? get _current => state.when(
        data: (WeeklyPlannerState value) => value,
        loading: () => null,
        error: (Object error, StackTrace stackTrace) => null,
      );

  Future<void> updateDraft(
    WeeklyPlannerDraft Function(WeeklyPlannerDraft draft) update, {
    bool persist = true,
  }) async {
    final current = _current;
    if (current == null || current.isBusy) {
      return;
    }
    final nextDraft = update(current.draft);
    state = AsyncData<WeeklyPlannerState>(
      current.copyWith(
        draft: nextDraft,
        isSaving: persist,
        message: null,
      ),
    );
    if (!persist) {
      return;
    }
    final revision = ++_saveRevision;
    final previous = _saveQueue;
    final currentSave = () async {
      try {
        await previous;
      } catch (_) {
        // A failed older save must not prevent the latest answer being saved.
      }
      await ref.read(weeklyPlannerRepositoryProvider).saveDraft(nextDraft);
    }();
    _saveQueue = currentSave;
    try {
      await currentSave;
      final latest = _current;
      if (latest != null && revision == _saveRevision) {
        state = AsyncData<WeeklyPlannerState>(
          latest.copyWith(isSaving: false),
        );
      }
    } catch (_) {
      final latest = _current;
      if (latest != null && revision == _saveRevision) {
        state = AsyncData<WeeklyPlannerState>(
          latest.copyWith(
            isSaving: false,
            message: '端末への保存に失敗しました。もう一度操作してください。',
          ),
        );
      }
    }
  }

  Future<void> next() async {
    final current = _current;
    if (current == null) {
      return;
    }
    final message = current.draft.validationMessage(current.draft.currentStep);
    if (message != null) {
      state = AsyncData<WeeklyPlannerState>(current.copyWith(message: message));
      return;
    }
    var next = _nextStep(current.draft.currentStep);
    if (next == WeeklyPlannerStep.previousWeek &&
        !current.draft.hasPreviousWeek) {
      next = WeeklyPlannerStep.adjustment;
    }
    if (next == WeeklyPlannerStep.review) {
      await generate();
      return;
    }
    if (next != null) {
      await updateDraft(
        (WeeklyPlannerDraft draft) => draft.copyWith(
          currentStep: next,
          previousLoadScore: next == WeeklyPlannerStep.previousWeek &&
                  draft.previousLoadScore == null
              ? 3
              : draft.previousLoadScore,
          achievementScore: next == WeeklyPlannerStep.previousWeek &&
                  draft.achievementScore == null
              ? 3
              : draft.achievementScore,
        ),
      );
    }
  }

  Future<void> back() async {
    final current = _current;
    if (current == null) {
      return;
    }
    var previous = _previousStep(current.draft.currentStep);
    if (previous == WeeklyPlannerStep.previousWeek &&
        !current.draft.hasPreviousWeek) {
      previous = WeeklyPlannerStep.condition;
    }
    if (previous != null) {
      await updateDraft(
        (WeeklyPlannerDraft draft) => draft.copyWith(currentStep: previous),
      );
    }
  }

  Future<bool> generate() async {
    final current = _current;
    if (current == null || current.isBusy) {
      return false;
    }
    final invalid = current.draft.firstInvalidStep;
    if (invalid != null) {
      await updateDraft(
        (WeeklyPlannerDraft draft) => draft.copyWith(currentStep: invalid),
      );
      final latest = _current;
      if (latest != null) {
        state = AsyncData<WeeklyPlannerState>(
          latest.copyWith(message: '未入力の項目があります。内容を確認してください。'),
        );
      }
      return false;
    }
    state = AsyncData<WeeklyPlannerState>(
      current.copyWith(isGenerating: true, message: null),
    );
    try {
      await _saveQueue;
      final plan = await ref
          .read(weeklyPlannerRepositoryProvider)
          .generateAndSave(current.draft);
      final nextDraft = current.draft.copyWith(
        currentStep: WeeklyPlannerStep.review,
        generatedMenuId: plan.id,
      );
      await ref.read(weeklyPlannerRepositoryProvider).saveDraft(nextDraft);
      state = AsyncData<WeeklyPlannerState>(
        current.copyWith(
          draft: nextDraft,
          plan: plan,
          isGenerating: false,
        ),
      );
      return true;
    } catch (_) {
      final latest = _current ?? current;
      state = AsyncData<WeeklyPlannerState>(
        latest.copyWith(
          isGenerating: false,
          message: 'メニューを作成できませんでした。予定や器具を確認してください。',
        ),
      );
      return false;
    }
  }

  Future<bool> finalize() async {
    final current = _current;
    final plan = current?.plan;
    if (current == null || plan == null || current.isBusy) {
      return false;
    }
    if (plan.validationMessages.isNotEmpty) {
      state = AsyncData<WeeklyPlannerState>(
        current.copyWith(message: '確認が必要な項目があります。条件を修正して再生成してください。'),
      );
      return false;
    }
    state = AsyncData<WeeklyPlannerState>(
      current.copyWith(isFinalizing: true, message: null),
    );
    try {
      await _saveQueue;
      await ref
          .read(weeklyPlannerRepositoryProvider)
          .finalizePlan(current.draft, plan);
      state = AsyncData<WeeklyPlannerState>(
        current.copyWith(
          draft: current.draft.copyWith(finalized: true),
          plan: plan,
          isFinalizing: false,
        ),
      );
      return true;
    } catch (_) {
      state = AsyncData<WeeklyPlannerState>(
        current.copyWith(
          isFinalizing: false,
          message: 'メニューを確定できませんでした。もう一度試してください。',
        ),
      );
      return false;
    }
  }

  Future<bool> createRestWeek() async {
    final current = _current;
    if (current == null || current.isBusy) {
      return false;
    }
    state = AsyncData<WeeklyPlannerState>(
      current.copyWith(isGenerating: true, message: null),
    );
    try {
      final plan = await ref
          .read(weeklyPlannerRepositoryProvider)
          .createRestWeek(current.draft);
      state = AsyncData<WeeklyPlannerState>(
        current.copyWith(
          draft: current.draft.copyWith(
            restWeek: true,
            generatedMenuId: plan.id,
            finalized: true,
          ),
          plan: plan,
          isGenerating: false,
        ),
      );
      return true;
    } catch (_) {
      state = AsyncData<WeeklyPlannerState>(
        current.copyWith(
          isGenerating: false,
          message: '休養週を保存できませんでした。もう一度試してください。',
        ),
      );
      return false;
    }
  }

  Future<void> reviseConditions() async {
    final current = _current;
    if (current == null) {
      return;
    }
    await updateDraft(
      (WeeklyPlannerDraft draft) => draft.copyWith(
        currentStep: WeeklyPlannerStep.schedule,
        generatedMenuId: null,
        finalized: false,
      ),
    );
  }

  Future<void> reset() async {
    final current = _current;
    if (current == null || current.isBusy) {
      return;
    }
    final repository = ref.read(weeklyPlannerRepositoryProvider);
    final fresh = await repository.resetDraft(current.draft);
    final plan = await repository.loadActivePlan(fresh.weekStartDate);
    state = AsyncData<WeeklyPlannerState>(
      current.copyWith(
        draft: fresh,
        plan: plan,
        isSaving: false,
        message: null,
      ),
    );
  }

  WeeklyPlannerStep? _nextStep(WeeklyPlannerStep step) => switch (step) {
        WeeklyPlannerStep.start => WeeklyPlannerStep.schedule,
        WeeklyPlannerStep.schedule => WeeklyPlannerStep.condition,
        WeeklyPlannerStep.condition => WeeklyPlannerStep.previousWeek,
        WeeklyPlannerStep.previousWeek => WeeklyPlannerStep.adjustment,
        WeeklyPlannerStep.adjustment => WeeklyPlannerStep.review,
        WeeklyPlannerStep.review => null,
      };

  WeeklyPlannerStep? _previousStep(WeeklyPlannerStep step) => switch (step) {
        WeeklyPlannerStep.start => null,
        WeeklyPlannerStep.schedule => WeeklyPlannerStep.start,
        WeeklyPlannerStep.condition => WeeklyPlannerStep.schedule,
        WeeklyPlannerStep.previousWeek => WeeklyPlannerStep.condition,
        WeeklyPlannerStep.adjustment => WeeklyPlannerStep.previousWeek,
        WeeklyPlannerStep.review => WeeklyPlannerStep.adjustment,
      };
}
