import 'dart:convert';

import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/progression/domain/progression_models.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/rule_based_weekly_menu_generator.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_generation_models.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_menu_plan.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_draft.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_repository.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_step.dart';

final class LocalWeeklyPlannerRepository implements WeeklyPlannerRepository {
  const LocalWeeklyPlannerRepository(
    this._database, {
    IdGenerator idGenerator = const UuidV7Generator(),
    RuleBasedWeeklyMenuGenerator generator = const RuleBasedWeeklyMenuGenerator(),
  })  : _idGenerator = idGenerator,
        _generator = generator;

  final AppDatabase _database;
  final IdGenerator _idGenerator;
  final RuleBasedWeeklyMenuGenerator _generator;

  @override
  Future<WeeklyPlannerDraft> loadOrCreateCurrentWeekDraft() async {
    final userId = await _requiredUserId();
    final ruleVersionId = await _requiredId(
      table: 'rule_version',
      code: 'MENU_RULE_V1_1',
    );
    final weekStart = _mondayOf(DateTime.now());
    final weekStartText = _dateOnly(weekStart);
    final existing = await _database.customSelect(
      '''
      SELECT draft_json
      FROM weekly_planner_draft
      WHERE user_id = ?
        AND week_start_date = ?
        AND status_code = 'IN_PROGRESS'
        AND deleted_at IS NULL
      ORDER BY updated_at DESC
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(weekStartText),
      ],
    ).get();
    if (existing.isNotEmpty) {
      final decoded = jsonDecode(existing.first.read<String>('draft_json'));
      return WeeklyPlannerDraft.fromJson(
        Map<String, Object?>.from(decoded! as Map<Object?, Object?>),
      );
    }

    final hasPrevious = await _hasPreviousWeekRecord(userId, weekStart);
    final savedWeek = await _loadSavedWeekDraft(
      userId: userId,
      ruleVersionId: ruleVersionId,
      weekStart: weekStart,
      hasPreviousWeek: hasPrevious,
    );
    final defaults = savedWeek == null
        ? await _loadDefaultDays(userId, weekStart)
        : null;
    final draft = savedWeek ??
        WeeklyPlannerDraft(
          id: _idGenerator.next(),
          userId: userId,
          ruleVersionId: ruleVersionId,
          weekStartDate: weekStart,
          days: defaults!.days,
          scheduleSourceCode: defaults.sourceCode,
          hasPreviousWeek: hasPrevious,
        );
    await _insertDraft(draft);
    return draft;
  }

  Future<void> _insertDraft(WeeklyPlannerDraft draft) async {
    final now = DateTime.now().toUtc().toIso8601String();
    await _database.customStatement(
      '''
      INSERT INTO weekly_planner_draft (
        id, user_id, rule_version_id, week_start_date,
        current_step_code, draft_json, status_code,
        created_at, updated_at, row_version, sync_status
      ) VALUES (?, ?, ?, ?, ?, ?, 'IN_PROGRESS', ?, ?, 1, 'LOCAL_ONLY')
      ''',
      <Object?>[
        draft.id,
        draft.userId,
        draft.ruleVersionId,
        _dateOnly(draft.weekStartDate),
        draft.currentStep.code,
        jsonEncode(draft.toJson()),
        now,
        now,
      ],
    );
  }

  @override
  Future<void> saveDraft(WeeklyPlannerDraft draft) async {
    await _database.customStatement(
      '''
      UPDATE weekly_planner_draft
      SET current_step_code = ?,
          draft_json = ?,
          updated_at = ?,
          row_version = row_version + 1,
          sync_status = 'LOCAL_ONLY'
      WHERE id = ?
        AND status_code = 'IN_PROGRESS'
        AND deleted_at IS NULL
      ''',
      <Object?>[
        draft.currentStep.code,
        jsonEncode(draft.toJson()),
        DateTime.now().toUtc().toIso8601String(),
        draft.id,
      ],
    );
  }

  @override
  Future<WeeklyPlannerDraft> resetDraft(WeeklyPlannerDraft draft) async {
    final now = DateTime.now().toUtc().toIso8601String();
    await _database.transaction(() async {
      await _database.customStatement(
        '''
        UPDATE weekly_planner_draft
        SET status_code = 'RESET',
            deleted_at = ?,
            updated_at = ?,
            row_version = row_version + 1
        WHERE id = ?
        ''',
        <Object?>[now, now, draft.id],
      );
      await _database.customStatement(
        '''
        UPDATE weekly_menu
        SET is_active = 0,
            deleted_at = ?,
            updated_at = ?,
            row_version = row_version + 1
        WHERE status_code = 'PROVISIONAL'
          AND is_active = 1
          AND training_week_id IN (
            SELECT id FROM training_week
            WHERE user_id = ? AND week_start_date = ? AND deleted_at IS NULL
          )
        ''',
        <Object?>[
          now,
          now,
          draft.userId,
          _dateOnly(draft.weekStartDate),
        ],
      );
    });
    final defaults = await _loadDefaultDays(draft.userId, draft.weekStartDate);
    final fresh = WeeklyPlannerDraft(
      id: _idGenerator.next(),
      userId: draft.userId,
      ruleVersionId: draft.ruleVersionId,
      weekStartDate: draft.weekStartDate,
      days: defaults.days,
      scheduleSourceCode: defaults.sourceCode,
      hasPreviousWeek: await _hasPreviousWeekRecord(
        draft.userId,
        draft.weekStartDate,
      ),
    );
    await _insertDraft(fresh);
    return fresh;
  }

  @override
  Future<List<PlannerLocationChoice>> loadLocations() async {
    final userId = await _requiredUserId();
    final rows = await _database.customSelect(
      '''
      SELECT id, display_name, location_type_code
      FROM training_location
      WHERE user_id = ?
        AND deleted_at IS NULL
      ORDER BY is_primary DESC, location_type_code, display_name
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    return rows
        .map(
          (QueryRow row) => PlannerLocationChoice(
            id: row.read<String>('id'),
            name: row.read<String>('display_name'),
            typeCode: row.read<String>('location_type_code'),
          ),
        )
        .toList(growable: false);
  }

  @override
  Future<List<PreviousExerciseChoice>> loadPreviousExerciseChoices(
    DateTime weekStartDate,
  ) async {
    final userId = await _requiredUserId();
    final previousStart = weekStartDate.subtract(const Duration(days: 7));
    final previousEnd = previousStart.add(const Duration(days: 6));
    final rows = await _database.customSelect(
      '''
      SELECT DISTINCT em.id, em.code, em.name_ja
      FROM workout_session ws
      JOIN session_exercise se ON se.workout_session_id = ws.id
      JOIN exercise_master em ON em.id = se.exercise_id
      WHERE ws.user_id = ?
        AND ws.record_date BETWEEN ? AND ?
        AND ws.deleted_at IS NULL
        AND se.deleted_at IS NULL
      ORDER BY em.code
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(_dateOnly(previousStart)),
        Variable.withString(_dateOnly(previousEnd)),
      ],
    ).get();
    return rows
        .map(
          (QueryRow row) => PreviousExerciseChoice(
            id: row.read<String>('id'),
            code: row.read<String>('code'),
            name: row.read<String>('name_ja'),
          ),
        )
        .toList(growable: false);
  }

  @override
  Future<WeeklyMenuPlan?> loadActivePlan(DateTime weekStartDate) async {
    final userId = await _requiredUserId();
    final rows = await _database.customSelect(
      '''
      SELECT wm.id
      FROM weekly_menu wm
      JOIN training_week tw ON tw.id = wm.training_week_id
      WHERE tw.user_id = ?
        AND tw.week_start_date = ?
        AND wm.is_active = 1
        AND wm.deleted_at IS NULL
        AND tw.deleted_at IS NULL
      ORDER BY wm.menu_version DESC
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(_dateOnly(weekStartDate)),
      ],
    ).get();
    if (rows.isEmpty) {
      return null;
    }
    return _loadPlanByMenuId(rows.first.read<String>('id'));
  }

  @override
  Future<WeeklyMenuPlan> generateAndSave(WeeklyPlannerDraft draft) async {
    final invalid = draft.firstInvalidStep;
    if (invalid != null) {
      throw StateError('Weekly planner is incomplete at ${invalid.code}.');
    }
    final input = await _loadGenerationInput(draft);
    final plan = _generator.generate(input);
    await _persistPlan(draft, plan);
    return plan;
  }

  @override
  Future<WeeklyMenuPlan> createRestWeek(WeeklyPlannerDraft draft) async {
    final restDraft = draft.copyWith(restWeek: true);
    final input = await _loadGenerationInput(restDraft);
    final plan = _generator.generate(input);
    await _persistPlan(restDraft, plan, finalizeImmediately: true);
    await _completeDraft(restDraft.copyWith(
      generatedMenuId: plan.id,
      finalized: true,
    ));
    return plan;
  }

  @override
  Future<void> finalizePlan(
    WeeklyPlannerDraft draft,
    WeeklyMenuPlan plan,
  ) async {
    final now = DateTime.now().toUtc().toIso8601String();
    await _database.transaction(() async {
      await _database.customStatement(
        '''
        UPDATE weekly_menu
        SET status_code = 'FINALIZED',
            finalized_at = ?,
            updated_at = ?,
            row_version = row_version + 1,
            sync_status = 'LOCAL_ONLY'
        WHERE id = ?
          AND is_active = 1
          AND deleted_at IS NULL
        ''',
        <Object?>[now, now, plan.id],
      );
      await _database.customStatement(
        '''
        UPDATE training_week
        SET status_code = 'ACTIVE',
            updated_at = ?,
            row_version = row_version + 1,
            sync_status = 'LOCAL_ONLY'
        WHERE id = (
          SELECT training_week_id FROM weekly_menu WHERE id = ?
        )
        ''',
        <Object?>[now, plan.id],
      );
      await _completeDraft(
        draft.copyWith(
          generatedMenuId: plan.id,
          finalized: true,
        ),
      );
    });
  }

  Future<WeeklyPlannerDraft?> _loadSavedWeekDraft({
    required String userId,
    required String ruleVersionId,
    required DateTime weekStart,
    required bool hasPreviousWeek,
  }) async {
    final weekRows = await _database.customSelect(
      '''
      SELECT tw.id AS training_week_id,
             wi.sleep_score, wi.motivation_score, wi.previous_load_score,
             wi.goal_rep_achievement_rate, wi.weekly_load_direction_code,
             wi.increase_method_code, wi.split_override_code,
             wi.priority_mode_code
      FROM training_week tw
      LEFT JOIN weekly_input wi ON wi.training_week_id = tw.id
        AND wi.deleted_at IS NULL
      WHERE tw.user_id = ?
        AND tw.week_start_date = ?
        AND tw.deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(_dateOnly(weekStart)),
      ],
    ).get();
    if (weekRows.isEmpty) {
      return null;
    }
    final week = weekRows.first;
    final trainingWeekId = week.read<String>('training_week_id');
    final dayRows = await _database.customSelect(
      '''
      SELECT wad.weekday_code, wad.is_available, wad.duration_min,
             wad.training_location_id, tl.display_name
      FROM weekly_available_day wad
      LEFT JOIN training_location tl ON tl.id = wad.training_location_id
      WHERE wad.training_week_id = ?
        AND wad.deleted_at IS NULL
      ORDER BY CASE wad.weekday_code
        WHEN 'MON' THEN 1 WHEN 'TUE' THEN 2 WHEN 'WED' THEN 3
        WHEN 'THU' THEN 4 WHEN 'FRI' THEN 5 WHEN 'SAT' THEN 6 ELSE 7 END
      ''',
      variables: <Variable<Object>>[Variable.withString(trainingWeekId)],
    ).get();
    if (dayRows.isEmpty) {
      return null;
    }

    final priorityRows = await _database.customSelect(
      '''
      SELECT wpp.priority_type, bpm.code
      FROM weekly_priority_part wpp
      JOIN body_part_master bpm ON bpm.id = wpp.body_part_id
      WHERE wpp.training_week_id = ?
        AND wpp.deleted_at IS NULL
      ORDER BY CASE wpp.priority_type WHEN 'MAIN' THEN 0 ELSE 1 END,
               bpm.display_order
      ''',
      variables: <Variable<Object>>[Variable.withString(trainingWeekId)],
    ).get();
    String? primaryPriorityCode;
    final secondaryPriorityCodes = <String>{};
    for (final row in priorityRows) {
      if (row.read<String>('priority_type') == 'MAIN') {
        primaryPriorityCode = row.read<String>('code');
      } else {
        secondaryPriorityCodes.add(row.read<String>('code'));
      }
    }

    final painRows = await _database.customSelect(
      '''
      SELECT bpm.code, bpm.name_ja, wpe.action_code
      FROM weekly_pain_entry wpe
      JOIN body_part_master bpm ON bpm.id = wpe.body_part_id
      WHERE wpe.training_week_id = ?
        AND wpe.deleted_at IS NULL
      ORDER BY bpm.display_order
      ''',
      variables: <Variable<Object>>[Variable.withString(trainingWeekId)],
    ).get();
    final stallRows = await _database.customSelect(
      '''
      SELECT wse.exercise_id, em.code, em.name_ja,
             wse.adjustment_code, wse.recommended_adjustment_code,
             wse.detected_by_code
      FROM weekly_stalled_exercise wse
      JOIN exercise_master em ON em.id = wse.exercise_id
      WHERE wse.training_week_id = ?
        AND wse.deleted_at IS NULL
      ORDER BY em.code
      ''',
      variables: <Variable<Object>>[Variable.withString(trainingWeekId)],
    ).get();

    final achievementRate = week.readNullable<double>(
      'goal_rep_achievement_rate',
    );
    return WeeklyPlannerDraft(
      id: _idGenerator.next(),
      userId: userId,
      ruleVersionId: ruleVersionId,
      weekStartDate: weekStart,
      days: _rowsToDays(dayRows, weekStart),
      scheduleSourceCode: 'CURRENT_WEEK',
      sleepScore: week.readNullable<int>('sleep_score') ?? 3,
      motivationScore: week.readNullable<int>('motivation_score') ?? 3,
      painEntries: painRows
          .map(
            (QueryRow row) => WeeklyPainDraft(
              bodyPartCode: row.read<String>('code'),
              bodyPartName: row.read<String>('name_ja'),
              actionCode: row.read<String>('action_code'),
            ),
          )
          .toList(growable: false),
      hasPreviousWeek: hasPreviousWeek,
      previousLoadScore: week.readNullable<int>('previous_load_score'),
      achievementScore: achievementRate == null
          ? null
          : (achievementRate * 5).round().clamp(1, 5).toInt(),
      stalledExercises: stallRows
          .map(
            (QueryRow row) => WeeklyStallDraft(
              exerciseId: row.read<String>('exercise_id'),
              exerciseCode: row.read<String>('code'),
              exerciseName: row.read<String>('name_ja'),
              adjustmentCode: row.read<String>('adjustment_code'),
              recommendedAdjustmentCode:
                  row.readNullable<String>('recommended_adjustment_code'),
              detectedByCode: row.read<String>('detected_by_code'),
            ),
          )
          .toList(growable: false),
      loadDirectionCode:
          week.readNullable<String>('weekly_load_direction_code') ?? 'APP',
      increaseMethodCode:
          week.readNullable<String>('increase_method_code'),
      priorityModeCode:
          week.readNullable<String>('priority_mode_code') ?? 'DEFAULT',
      primaryPriorityCode: primaryPriorityCode,
      secondaryPriorityCodes: secondaryPriorityCodes,
      splitOverrideCode: week.readNullable<String>('split_override_code'),
    );
  }

  Future<_DefaultDays> _loadDefaultDays(
    String userId,
    DateTime weekStart,
  ) async {
    final previousStart = weekStart.subtract(const Duration(days: 7));
    final previousRows = await _database.customSelect(
      '''
      SELECT wad.weekday_code, wad.is_available, wad.duration_min,
             wad.training_location_id, tl.display_name
      FROM weekly_available_day wad
      JOIN training_week tw ON tw.id = wad.training_week_id
      LEFT JOIN training_location tl ON tl.id = wad.training_location_id
      WHERE tw.user_id = ?
        AND tw.week_start_date = ?
        AND wad.deleted_at IS NULL
        AND tw.deleted_at IS NULL
      ORDER BY CASE wad.weekday_code
        WHEN 'MON' THEN 1 WHEN 'TUE' THEN 2 WHEN 'WED' THEN 3
        WHEN 'THU' THEN 4 WHEN 'FRI' THEN 5 WHEN 'SAT' THEN 6 ELSE 7 END
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(_dateOnly(previousStart)),
      ],
    ).get();
    if (previousRows.isNotEmpty) {
      return _DefaultDays(
        sourceCode: 'LAST_WEEK',
        days: _rowsToDays(previousRows, weekStart),
      );
    }

    final standardRows = await _database.customSelect(
      '''
      SELECT ssd.weekday_code, ssd.is_available, ssd.duration_min,
             ssd.training_location_id, tl.display_name
      FROM standard_schedule_day ssd
      LEFT JOIN training_location tl ON tl.id = ssd.training_location_id
      WHERE ssd.user_id = ?
        AND ssd.deleted_at IS NULL
      ORDER BY CASE ssd.weekday_code
        WHEN 'MON' THEN 1 WHEN 'TUE' THEN 2 WHEN 'WED' THEN 3
        WHEN 'THU' THEN 4 WHEN 'FRI' THEN 5 WHEN 'SAT' THEN 6 ELSE 7 END
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    return _DefaultDays(
      sourceCode: 'STANDARD',
      days: _rowsToDays(standardRows, weekStart),
    );
  }

  List<WeeklyDayDraft> _rowsToDays(
    List<QueryRow> rows,
    DateTime weekStart,
  ) {
    final byCode = <String, QueryRow>{
      for (final row in rows) row.read<String>('weekday_code'): row,
    };
    return List<WeeklyDayDraft>.generate(7, (int index) {
      final code = WeekdayCodes.ordered[index];
      final row = byCode[code];
      return WeeklyDayDraft(
        weekdayCode: code,
        planDate: weekStart.add(Duration(days: index)),
        isAvailable: row?.read<int>('is_available') == 1,
        durationMin: row?.readNullable<int>('duration_min'),
        locationId: row?.readNullable<String>('training_location_id'),
        locationName: row?.readNullable<String>('display_name'),
      );
    });
  }

  Future<bool> _hasPreviousWeekRecord(
    String userId,
    DateTime weekStart,
  ) async {
    final previousStart = weekStart.subtract(const Duration(days: 7));
    final previousEnd = previousStart.add(const Duration(days: 6));
    final rows = await _database.customSelect(
      '''
      SELECT 1 AS found
      FROM workout_session
      WHERE user_id = ?
        AND record_date BETWEEN ? AND ?
        AND deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(_dateOnly(previousStart)),
        Variable.withString(_dateOnly(previousEnd)),
      ],
    ).get();
    return rows.isNotEmpty;
  }

  Future<WeeklyGenerationInput> _loadGenerationInput(
    WeeklyPlannerDraft draft,
  ) async {
    final settings = await _database.customSelect(
      '''
      SELECT uts.desired_days_per_week, uts.split_preference_code,
             uts.ab_goal_code, uep.calculated_level_code,
             uep.start_volume_factor,
             (SELECT goal_code FROM user_goal ug
              WHERE ug.user_id = uts.user_id
                AND ug.goal_type = 'PRIMARY'
                AND ug.deleted_at IS NULL
              ORDER BY ug.display_order LIMIT 1) AS primary_goal_code
      FROM user_training_setting uts
      JOIN user_experience_profile uep ON uep.user_id = uts.user_id
      WHERE uts.user_id = ?
        AND uts.deleted_at IS NULL
        AND uep.deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(draft.userId)],
    ).getSingle();

    final priorities = await _database.customSelect(
      '''
      SELECT upp.priority_type, bpm.code
      FROM user_priority_part upp
      JOIN body_part_master bpm ON bpm.id = upp.body_part_id
      WHERE upp.user_id = ?
        AND upp.context_code = 'TRAINING'
        AND upp.deleted_at IS NULL
      ORDER BY CASE upp.priority_type WHEN 'MAIN' THEN 0 ELSE 1 END, bpm.display_order
      ''',
      variables: <Variable<Object>>[Variable.withString(draft.userId)],
    ).get();
    String? defaultPrimary;
    final defaultSecondary = <String>{};
    for (final row in priorities) {
      if (row.read<String>('priority_type') == 'MAIN') {
        defaultPrimary = row.read<String>('code');
      } else {
        defaultSecondary.add(row.read<String>('code'));
      }
    }

    final locations = await _loadGenerationLocations(draft.userId);
    final restrictions = await _loadRestrictions(draft.userId, draft.weekStartDate);
    final goalCode = settings.readNullable<String>('primary_goal_code') ?? 'HEALTH';
    final exercises = await _loadExercises(
      primaryGoalCode: goalCode,
    );
    final previousIds = await _loadPreviousExerciseIds(
      draft.userId,
      draft.weekStartDate,
    );
    final activePlan = await loadActivePlan(draft.weekStartDate);
    final lockedDays = activePlan?.days
            .where(
              (WeeklyDayPlan day) =>
                  day.statusCode == 'IN_PROGRESS' ||
                  day.statusCode == 'COMPLETED' ||
                  day.statusCode == 'PARTIAL',
            )
            .map(
              (WeeklyDayPlan day) => WeeklyDayPlan(
                id: day.id,
                planDate: day.planDate,
                weekdayCode: day.weekdayCode,
                locationId: day.locationId,
                locationName: day.locationName,
                durationMin: day.durationMin,
                estimatedDurationMin: day.estimatedDurationMin,
                focus: day.focus,
                reason: day.reason,
                exercises: day.exercises,
                statusCode: day.statusCode,
                isLocked: true,
              ),
            )
            .toList(growable: false) ??
        const <WeeklyDayPlan>[];

    return WeeklyGenerationInput(
      draft: draft,
      primaryGoalCode: goalCode,
      experienceLevelCode: settings.read<String>('calculated_level_code'),
      startVolumeFactor: settings.read<double>('start_volume_factor'),
      desiredDaysPerWeek: settings.read<int>('desired_days_per_week'),
      defaultSplitPreferenceCode:
          settings.read<String>('split_preference_code'),
      abGoalCode: settings.read<String>('ab_goal_code'),
      defaultPrimaryPriorityCode: defaultPrimary,
      defaultSecondaryPriorityCodes: defaultSecondary,
      locations: locations,
      restrictions: restrictions,
      exercises: exercises,
      previousExerciseIds: previousIds,
      lockedDays: lockedDays,
    );
  }

  Future<Map<String, GenerationLocation>> _loadGenerationLocations(
    String userId,
  ) async {
    final locationRows = await _database.customSelect(
      '''
      SELECT id, display_name, location_type_code, gym_profile_code
      FROM training_location
      WHERE user_id = ? AND deleted_at IS NULL
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    final equipmentRows = await _database.customSelect(
      '''
      SELECT le.training_location_id, em.code
      FROM location_equipment le
      JOIN equipment_master em ON em.id = le.equipment_id
      WHERE le.user_id = ?
        AND le.is_available = 1
        AND le.deleted_at IS NULL
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    final explicit = <String, Set<String>>{};
    for (final row in equipmentRows) {
      explicit
          .putIfAbsent(
            row.read<String>('training_location_id'),
            () => <String>{},
          )
          .add(row.read<String>('code'));
    }
    final allEquipmentRows = await _database.customSelect(
      'SELECT code, equipment_category_code FROM equipment_master WHERE is_active = 1',
    ).get();

    final result = <String, GenerationLocation>{};
    for (final row in locationRows) {
      final id = row.read<String>('id');
      final type = row.read<String>('location_type_code');
      final profile = row.readNullable<String>('gym_profile_code');
      final codes = <String>{...?explicit[id]};
      if (type == 'GYM' && profile != 'LIMITED') {
        for (final equipment in allEquipmentRows) {
          final code = equipment.read<String>('code');
          final category = equipment.read<String>('equipment_category_code');
          if (profile == 'FULL' ||
              profile == 'UNKNOWN' ||
              (profile == 'MACHINE_HEAVY' &&
                  <String>{'MACHINE', 'MACHINE_GROUP', 'ATTACHMENT', 'BENCH'}
                      .contains(category)) ||
              (profile == 'FREE_WEIGHT_HEAVY' &&
                  <String>{'FREE_WEIGHT', 'BENCH', 'RACK', 'STATION', 'ACCESSORY'}
                      .contains(category))) {
            codes.add(code);
          }
        }
        codes.addAll(const <String>{'NONE', 'DUMBBELL', 'BENCH'});
      }
      codes.add('NONE');
      result[id] = GenerationLocation(
        id: id,
        name: row.read<String>('display_name'),
        typeCode: type,
        gymProfileCode: profile,
        equipmentCodes: codes,
      );
    }
    return result;
  }

  Future<GenerationRestrictions> _loadRestrictions(
    String userId,
    DateTime weekStart,
  ) async {
    final rows = await _database.customSelect(
      '''
      SELECT ur.body_part_id, ur.joint_id, ur.movement_id, ur.exercise_id,
             bpm.code AS body_part_code, jm.code AS joint_code,
             mm.movement_group_code, ur.default_action_code
      FROM user_restriction ur
      LEFT JOIN body_part_master bpm ON bpm.id = ur.body_part_id
      LEFT JOIN joint_master jm ON jm.id = ur.joint_id
      LEFT JOIN movement_master mm ON mm.id = ur.movement_id
      WHERE ur.user_id = ?
        AND ur.deleted_at IS NULL
        AND ur.effective_from <= ?
        AND (ur.effective_to IS NULL OR ur.effective_to >= ?)
        AND ur.default_action_code IN ('EXCLUDE', 'SUBSTITUTE')
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(_dateOnly(weekStart.add(const Duration(days: 6)))),
        Variable.withString(_dateOnly(weekStart)),
      ],
    ).get();
    return GenerationRestrictions(
      bodyPartCodes: rows
          .map((QueryRow row) => row.readNullable<String>('body_part_code'))
          .whereType<String>()
          .toSet(),
      jointCodes: rows
          .map((QueryRow row) => row.readNullable<String>('joint_code'))
          .whereType<String>()
          .toSet(),
      movementGroupCodes: rows
          .map((QueryRow row) => row.readNullable<String>('movement_group_code'))
          .whereType<String>()
          .toSet(),
      exerciseIds: rows
          .map((QueryRow row) => row.readNullable<String>('exercise_id'))
          .whereType<String>()
          .toSet(),
    );
  }

  Future<List<GenerationExercise>> _loadExercises({
    required String primaryGoalCode,
  }) async {
    final goalCode = <String>{'HYPERTROPHY', 'STRENGTH', 'HEALTH'}
            .contains(primaryGoalCode)
        ? primaryGoalCode
        : 'HEALTH';
    final baseRows = await _database.customSelect(
      '''
      SELECT em.*, epp.target_mode_code, epp.rep_lower, epp.rep_upper,
             epp.duration_lower_sec, epp.duration_upper_sec,
             epp.set_lower, epp.set_upper, epp.rest_sec
      FROM exercise_master em
      JOIN exercise_progression_profile epp ON epp.exercise_id = em.id
      WHERE em.is_active = 1
        AND epp.is_active = 1
        AND epp.goal_code = ?
      ORDER BY em.code
      ''',
      variables: <Variable<Object>>[Variable.withString(goalCode)],
    ).get();
    final bodyRows = await _database.customSelect(
      '''
      SELECT ebp.exercise_id, ebp.relation_type, bpm.code
      FROM exercise_body_part ebp
      JOIN body_part_master bpm ON bpm.id = ebp.body_part_id
      ''',
    ).get();
    final movementRows = await _database.customSelect(
      '''
      SELECT emv.exercise_id, mm.movement_group_code
      FROM exercise_movement emv
      JOIN movement_master mm ON mm.id = emv.movement_id
      ''',
    ).get();
    final jointRows = await _database.customSelect(
      '''
      SELECT ej.exercise_id, jm.code
      FROM exercise_joint ej
      JOIN joint_master jm ON jm.id = ej.joint_id
      ''',
    ).get();
    final equipmentRows = await _database.customSelect(
      '''
      SELECT eoo.exercise_id, eoo.id AS option_id, eoo.option_code,
             eqm.code AS equipment_code, ee.minimum_quantity
      FROM exercise_equipment_option eoo
      LEFT JOIN exercise_equipment ee ON ee.equipment_option_id = eoo.id
      LEFT JOIN equipment_master eqm ON eqm.id = ee.equipment_id
      WHERE eoo.is_active = 1
      ORDER BY eoo.exercise_id, eoo.display_order, eqm.code
      ''',
    ).get();

    final primaryParts = <String, Set<String>>{};
    final secondaryParts = <String, Set<String>>{};
    for (final row in bodyRows) {
      final target = row.read<String>('relation_type') == 'PRIMARY'
          ? primaryParts
          : secondaryParts;
      target
          .putIfAbsent(row.read<String>('exercise_id'), () => <String>{})
          .add(row.read<String>('code'));
    }
    final movements = <String, Set<String>>{};
    for (final row in movementRows) {
      movements
          .putIfAbsent(row.read<String>('exercise_id'), () => <String>{})
          .add(row.read<String>('movement_group_code'));
    }
    final joints = <String, Set<String>>{};
    for (final row in jointRows) {
      joints
          .putIfAbsent(row.read<String>('exercise_id'), () => <String>{})
          .add(row.read<String>('code'));
    }
    final optionMaps = <String, Map<String, Map<String, int>>>{};
    for (final row in equipmentRows) {
      final exerciseId = row.read<String>('exercise_id');
      final optionCode = row.read<String>('option_code');
      final requirementMap = optionMaps
          .putIfAbsent(exerciseId, () => <String, Map<String, int>>{})
          .putIfAbsent(optionCode, () => <String, int>{});
      final equipmentCode = row.readNullable<String>('equipment_code');
      if (equipmentCode != null) {
        requirementMap[equipmentCode] = row.read<int>('minimum_quantity');
      }
    }

    return baseRows.map((QueryRow row) {
      final id = row.read<String>('id');
      final options = optionMaps[id]?.entries
              .map(
                (MapEntry<String, Map<String, int>> entry) =>
                    EquipmentRequirementOption(
                  code: entry.key,
                  requirements: entry.value,
                ),
              )
              .toList(growable: false) ??
          const <EquipmentRequirementOption>[];
      return GenerationExercise(
        id: id,
        code: row.read<String>('code'),
        name: row.read<String>('name_ja'),
        roleCode: row.read<String>('role_code'),
        exerciseClassCode: row.read<String>('exercise_class_code'),
        technicalDifficultyCode:
            row.read<String>('technical_difficulty_code'),
        recordingMethodCode: row.read<String>('recording_method_code'),
        availabilityByLevel: <String, String>{
          'BEGINNER': row.read<String>('beginner_availability'),
          'INTERMEDIATE': row.read<String>('intermediate_availability'),
          'ADVANCED': row.read<String>('advanced_availability'),
        },
        defaultPriorityCode: row.read<String>('default_priority_code'),
        primaryBodyPartCodes: primaryParts[id] ?? const <String>{},
        secondaryBodyPartCodes: secondaryParts[id] ?? const <String>{},
        movementGroupCodes: movements[id] ?? const <String>{},
        jointCodes: joints[id] ?? const <String>{},
        equipmentOptions: options,
        progression: ExerciseProgression(
          targetModeCode: row.read<String>('target_mode_code'),
          repLower: row.readNullable<int>('rep_lower'),
          repUpper: row.readNullable<int>('rep_upper'),
          durationLowerSec: row.readNullable<int>('duration_lower_sec'),
          durationUpperSec: row.readNullable<int>('duration_upper_sec'),
          setLower: row.read<int>('set_lower'),
          setUpper: row.read<int>('set_upper'),
          restSec: row.read<int>('rest_sec'),
        ),
      );
    }).toList(growable: false);
  }

  Future<Set<String>> _loadPreviousExerciseIds(
    String userId,
    DateTime weekStart,
  ) async {
    final from = weekStart.subtract(const Duration(days: 56));
    final rows = await _database.customSelect(
      '''
      SELECT DISTINCT se.exercise_id
      FROM workout_session ws
      JOIN session_exercise se ON se.workout_session_id = ws.id
      WHERE ws.user_id = ?
        AND ws.record_date BETWEEN ? AND ?
        AND ws.deleted_at IS NULL
        AND se.deleted_at IS NULL
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(_dateOnly(from)),
        Variable.withString(_dateOnly(weekStart.subtract(const Duration(days: 1)))),
      ],
    ).get();
    return rows.map((QueryRow row) => row.read<String>('exercise_id')).toSet();
  }

  Future<void> _persistPlan(
    WeeklyPlannerDraft draft,
    WeeklyMenuPlan plan, {
    bool finalizeImmediately = false,
  }) async {
    final now = DateTime.now().toUtc().toIso8601String();
    await _database.transaction(() async {
      final trainingWeekId = await _ensureTrainingWeek(draft, now);
      await _saveWeeklyInputs(draft, trainingWeekId, now);
      final version = await _nextMenuVersion(trainingWeekId);
      await _database.customStatement(
        '''
        UPDATE weekly_menu
        SET is_active = 0,
            updated_at = ?,
            row_version = row_version + 1
        WHERE training_week_id = ?
          AND is_active = 1
          AND deleted_at IS NULL
        ''',
        <Object?>[now, trainingWeekId],
      );
      final status = finalizeImmediately
          ? plan.isRestWeek
              ? 'REST_WEEK'
              : 'FINALIZED'
          : plan.statusCode;
      await _database.customStatement(
        '''
        INSERT INTO weekly_menu (
          id, user_id, rule_version_id, created_at, updated_at,
          row_version, sync_status, training_week_id, menu_version,
          status_code, split_code, generated_at, finalized_at, is_active,
          generation_input_snapshot_json, generation_trace_json,
          estimated_total_min
        ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
        ''',
        <Object?>[
          plan.id,
          draft.userId,
          draft.ruleVersionId,
          now,
          now,
          trainingWeekId,
          version,
          status,
          plan.splitCode,
          now,
          finalizeImmediately ? now : null,
          jsonEncode(draft.toJson()),
          jsonEncode(<String, Object?>{
            ...plan.generationTrace,
            'splitName': plan.splitName,
            'summaryReasons': plan.summaryReasons,
            'validationMessages': plan.validationMessages,
          }),
          plan.estimatedTotalMin,
        ],
      );
      for (final day in plan.days) {
        final dayId = _idGenerator.next();
        await _database.customStatement(
          '''
          INSERT INTO workout_day_plan (
            id, user_id, rule_version_id, created_at, updated_at,
            row_version, sync_status, weekly_menu_id, plan_date,
            weekday_code, training_location_id, duration_min, status_code,
            session_focus_snapshot, reason_text_snapshot,
            estimated_duration_min
          ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?, ?, ?, ?)
          ''',
          <Object?>[
            dayId,
            draft.userId,
            draft.ruleVersionId,
            now,
            now,
            plan.id,
            _dateOnly(day.planDate),
            day.weekdayCode,
            day.locationId,
            day.durationMin,
            day.statusCode,
            day.focus,
            day.reason,
            day.estimatedDurationMin,
          ],
        );
        for (final exercise in day.exercises) {
          final exerciseId = _idGenerator.next();
          await _database.customStatement(
            '''
            INSERT INTO planned_exercise (
              id, user_id, rule_version_id, created_at, updated_at,
              row_version, sync_status, workout_day_plan_id, exercise_id,
              order_index, exercise_name_snapshot, role_code_snapshot,
              recording_method_snapshot, target_part_snapshot,
              reason_text_snapshot, progression_profile_snapshot_json,
              selection_score, selection_reason_ids_json, status_code
            ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PLANNED')
            ''',
            <Object?>[
              exerciseId,
              draft.userId,
              draft.ruleVersionId,
              now,
              now,
              dayId,
              exercise.exerciseId,
              exercise.orderIndex,
              exercise.exerciseName,
              exercise.roleCode,
              exercise.recordingMethodCode,
              exercise.targetPart,
              exercise.reason,
              jsonEncode(exercise.progressionSnapshot),
              exercise.selectionScore,
              jsonEncode(exercise.reasonIds),
            ],
          );
          for (final set in exercise.sets) {
            await _database.customStatement(
              '''
              INSERT INTO planned_set (
                id, user_id, rule_version_id, created_at, updated_at,
                row_version, sync_status, planned_exercise_id, set_number,
                is_warmup, target_weight_kg, input_weight_value,
                input_weight_unit_code, target_reps_lower, target_reps_upper,
                target_duration_sec, target_assistance_value, rest_sec
              ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
              ''',
              <Object?>[
                _idGenerator.next(),
                draft.userId,
                draft.ruleVersionId,
                now,
                now,
                exerciseId,
                set.setNumber,
                set.isWarmup ? 1 : 0,
                set.targetWeightKg,
                set.inputWeightValue,
                set.inputWeightUnitCode,
                set.targetRepsLower,
                set.targetRepsUpper,
                set.targetDurationSec,
                set.targetAssistanceValue,
                set.restSec,
              ],
            );
          }
          await _applyQueuedProgressionAdjustment(
            userId: draft.userId,
            exerciseId: exercise.exerciseId,
            plannedExerciseId: exerciseId,
            now: now,
          );
        }
      }
      await _database.customStatement(
        '''
        UPDATE training_week
        SET status_code = ?, updated_at = ?, row_version = row_version + 1
        WHERE id = ?
        ''',
        <Object?>[
          plan.isRestWeek
              ? 'REST_WEEK'
              : finalizeImmediately
                  ? 'ACTIVE'
                  : 'PROVISIONAL',
          now,
          trainingWeekId,
        ],
      );
    });
  }

  Future<void> _applyQueuedProgressionAdjustment({
    required String userId,
    required String exerciseId,
    required String plannedExerciseId,
    required String now,
  }) async {
    final rows = await _database.customSelect(
      '''
      SELECT id, adjustment_type_code, payload_json
      FROM accepted_progression_adjustment
      WHERE user_id = ?
        AND exercise_id = ?
        AND status_code = 'QUEUED'
        AND deleted_at IS NULL
      ORDER BY queued_at ASC
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(exerciseId),
      ],
    ).get();
    if (rows.isEmpty) return;
    final row = rows.first;
    final typeCode = row.read<String>('adjustment_type_code');
    final payload = Map<String, Object?>.from(
      jsonDecode(row.read<String>('payload_json'))! as Map<Object?, Object?>,
    );
    var applied = true;
    if (typeCode == ProgressionProposalTypes.increaseWeight ||
        typeCode == ProgressionProposalTypes.reduceWeight) {
      final value = (payload['weightKg'] as num?)?.toDouble();
      if (value == null) {
        applied = false;
      } else {
        await _database.customStatement(
          '''
          UPDATE planned_set
          SET target_weight_kg = ?, input_weight_value = ?,
              input_weight_unit_code = 'KG', updated_at = ?,
              row_version = row_version + 1
          WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
          ''',
          <Object?>[value, value, now, plannedExerciseId],
        );
      }
    } else if (typeCode == ProgressionProposalTypes.extendReps) {
      final value = (payload['targetRepsUpper'] as num?)?.toInt();
      if (value == null) {
        applied = false;
      } else {
        await _database.customStatement(
          '''
          UPDATE planned_set
          SET target_reps_upper = ?, updated_at = ?, row_version = row_version + 1
          WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
          ''',
          <Object?>[value, now, plannedExerciseId],
        );
      }
    } else if (typeCode == ProgressionProposalTypes.increaseDuration) {
      final value = (payload['targetDurationSec'] as num?)?.toInt();
      if (value == null) {
        applied = false;
      } else {
        await _database.customStatement(
          '''
          UPDATE planned_set
          SET target_duration_sec = ?, updated_at = ?, row_version = row_version + 1
          WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
          ''',
          <Object?>[value, now, plannedExerciseId],
        );
      }
    } else if (typeCode == ProgressionProposalTypes.reduceAssistance) {
      final value = (payload['assistanceValue'] as num?)?.toDouble();
      if (value == null) {
        applied = false;
      } else {
        await _database.customStatement(
          '''
          UPDATE planned_set
          SET target_assistance_value = ?, updated_at = ?, row_version = row_version + 1
          WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
          ''',
          <Object?>[value, now, plannedExerciseId],
        );
      }
    } else if (typeCode == ProgressionProposalTypes.addSet) {
      final lastRows = await _database.customSelect(
        '''
        SELECT * FROM planned_set
        WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
        ORDER BY set_number DESC LIMIT 1
        ''',
        variables: <Variable<Object>>[Variable.withString(plannedExerciseId)],
      ).get();
      if (lastRows.isEmpty) {
        applied = false;
      } else {
        final last = lastRows.first;
        await _database.customStatement(
          '''
          INSERT INTO planned_set (
            id, user_id, rule_version_id, created_at, updated_at,
            row_version, sync_status, planned_exercise_id, set_number,
            is_warmup, target_weight_kg, input_weight_value,
            input_weight_unit_code, target_reps_lower, target_reps_upper,
            target_duration_sec, target_assistance_value, rest_sec
          ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?)
          ''',
          <Object?>[
            _idGenerator.next(),
            userId,
            last.read<String>('rule_version_id'),
            now,
            now,
            plannedExerciseId,
            last.read<int>('set_number') + 1,
            last.readNullable<double>('target_weight_kg'),
            last.readNullable<double>('input_weight_value'),
            last.readNullable<String>('input_weight_unit_code'),
            last.readNullable<int>('target_reps_lower'),
            last.readNullable<int>('target_reps_upper'),
            last.readNullable<int>('target_duration_sec'),
            last.readNullable<double>('target_assistance_value'),
            last.read<int>('rest_sec'),
          ],
        );
      }
    } else if (typeCode == ProgressionProposalTypes.reduceSet) {
      await _database.customStatement(
        '''
        UPDATE planned_set
        SET deleted_at = ?, updated_at = ?, row_version = row_version + 1
        WHERE id = (
          SELECT id FROM planned_set
          WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
          ORDER BY set_number DESC LIMIT 1
        )
        ''',
        <Object?>[now, now, plannedExerciseId],
      );
    } else {
      applied = false;
    }
    if (!applied) return;
    await _database.customStatement(
      '''
      UPDATE accepted_progression_adjustment
      SET status_code = 'APPLIED', target_planned_exercise_id = ?,
          applied_at = ?, consumed_at = ?, updated_at = ?,
          row_version = row_version + 1
      WHERE id = ?
      ''',
      <Object?>[
        plannedExerciseId,
        now,
        now,
        now,
        row.read<String>('id'),
      ],
    );
  }

  Future<String> _ensureTrainingWeek(
    WeeklyPlannerDraft draft,
    String now,
  ) async {
    final existing = await _database.customSelect(
      '''
      SELECT id FROM training_week
      WHERE user_id = ? AND week_start_date = ? AND deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(draft.userId),
        Variable.withString(_dateOnly(draft.weekStartDate)),
      ],
    ).get();
    if (existing.isNotEmpty) {
      return existing.first.read<String>('id');
    }
    final id = _idGenerator.next();
    await _database.customStatement(
      '''
      INSERT INTO training_week (
        id, user_id, rule_version_id, created_at, updated_at,
        row_version, sync_status, week_start_date, week_end_date, status_code
      ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, 'PLANNING')
      ''',
      <Object?>[
        id,
        draft.userId,
        draft.ruleVersionId,
        now,
        now,
        _dateOnly(draft.weekStartDate),
        _dateOnly(draft.weekEndDate),
      ],
    );
    return id;
  }

  Future<void> _saveWeeklyInputs(
    WeeklyPlannerDraft draft,
    String trainingWeekId,
    String now,
  ) async {
    final existingInput = await _database.customSelect(
      'SELECT id FROM weekly_input WHERE training_week_id = ? LIMIT 1',
      variables: <Variable<Object>>[Variable.withString(trainingWeekId)],
    ).get();
    final inputId = existingInput.isEmpty
        ? _idGenerator.next()
        : existingInput.first.read<String>('id');
    await _database.customStatement(
      '''
      INSERT INTO weekly_input (
        id, user_id, rule_version_id, created_at, updated_at,
        row_version, sync_status, training_week_id, same_as_last_week,
        sleep_score, motivation_score, previous_load_score,
        goal_rep_achievement_rate, weekly_load_direction_code,
        increase_method_code, split_override_code, priority_mode_code,
        rest_week
      ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        updated_at = excluded.updated_at,
        row_version = weekly_input.row_version + 1,
        sync_status = 'LOCAL_ONLY',
        same_as_last_week = excluded.same_as_last_week,
        sleep_score = excluded.sleep_score,
        motivation_score = excluded.motivation_score,
        previous_load_score = excluded.previous_load_score,
        goal_rep_achievement_rate = excluded.goal_rep_achievement_rate,
        weekly_load_direction_code = excluded.weekly_load_direction_code,
        increase_method_code = excluded.increase_method_code,
        split_override_code = excluded.split_override_code,
        priority_mode_code = excluded.priority_mode_code,
        rest_week = excluded.rest_week,
        deleted_at = NULL
      ''',
      <Object?>[
        inputId,
        draft.userId,
        draft.ruleVersionId,
        now,
        now,
        trainingWeekId,
        draft.scheduleSourceCode == 'LAST_WEEK' ? 1 : 0,
        draft.sleepScore,
        draft.motivationScore,
        draft.previousLoadScore,
        draft.achievementRate,
        draft.loadDirectionCode,
        draft.increaseMethodCode,
        draft.splitOverrideCode,
        draft.priorityModeCode,
        draft.restWeek ? 1 : 0,
      ],
    );
    for (final table in <String>[
      'weekly_available_day',
      'weekly_priority_part',
      'weekly_pain_entry',
      'weekly_stalled_exercise',
    ]) {
      await _database.customStatement(
        'UPDATE $table SET deleted_at = ?, updated_at = ?, row_version = row_version + 1 '
        'WHERE training_week_id = ? AND deleted_at IS NULL',
        <Object?>[now, now, trainingWeekId],
      );
    }
    for (final day in draft.days) {
      await _database.customStatement(
        '''
        INSERT INTO weekly_available_day (
          id, user_id, rule_version_id, created_at, updated_at,
          row_version, sync_status, training_week_id, weekday_code,
          plan_date, is_available, duration_min, training_location_id
        ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?, ?)
        ''',
        <Object?>[
          _idGenerator.next(),
          draft.userId,
          draft.ruleVersionId,
          now,
          now,
          trainingWeekId,
          day.weekdayCode,
          _dateOnly(day.planDate),
          day.isAvailable ? 1 : 0,
          day.durationMin,
          day.locationId,
        ],
      );
    }
    if (draft.priorityModeCode == 'CUSTOM' &&
        draft.primaryPriorityCode != null) {
      await _insertWeeklyPriority(
        draft,
        trainingWeekId,
        draft.primaryPriorityCode!,
        'MAIN',
        now,
      );
      for (final code in draft.secondaryPriorityCodes) {
        await _insertWeeklyPriority(
          draft,
          trainingWeekId,
          code,
          'SECONDARY',
          now,
        );
      }
    }
    for (final pain in draft.painEntries) {
      final bodyPartId = await _requiredId(
        table: 'body_part_master',
        code: pain.bodyPartCode,
      );
      await _database.customStatement(
        '''
        INSERT INTO weekly_pain_entry (
          id, user_id, rule_version_id, created_at, updated_at,
          row_version, sync_status, training_week_id, body_part_id,
          action_code, status_code
        ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, 'NOTICEABLE_CONTINUE')
        ''',
        <Object?>[
          _idGenerator.next(),
          draft.userId,
          draft.ruleVersionId,
          now,
          now,
          trainingWeekId,
          bodyPartId,
          pain.actionCode,
        ],
      );
    }
    for (final stall in draft.stalledExercises) {
      await _database.customStatement(
        '''
        INSERT INTO weekly_stalled_exercise (
          id, user_id, rule_version_id, created_at, updated_at,
          row_version, sync_status, training_week_id, exercise_id,
          detected_by_code, adjustment_code, recommended_adjustment_code
        ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?, ?, ?)
        ''',
        <Object?>[
          _idGenerator.next(),
          draft.userId,
          draft.ruleVersionId,
          now,
          now,
          trainingWeekId,
          stall.exerciseId,
          stall.detectedByCode,
          stall.adjustmentCode,
          stall.recommendedAdjustmentCode,
        ],
      );
    }
  }

  Future<void> _insertWeeklyPriority(
    WeeklyPlannerDraft draft,
    String trainingWeekId,
    String bodyPartCode,
    String priorityType,
    String now,
  ) async {
    final bodyPartId = await _requiredId(
      table: 'body_part_master',
      code: bodyPartCode,
    );
    await _database.customStatement(
      '''
      INSERT INTO weekly_priority_part (
        id, user_id, rule_version_id, created_at, updated_at,
        row_version, sync_status, training_week_id, body_part_id,
        priority_type
      ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, ?)
      ''',
      <Object?>[
        _idGenerator.next(),
        draft.userId,
        draft.ruleVersionId,
        now,
        now,
        trainingWeekId,
        bodyPartId,
        priorityType,
      ],
    );
  }

  Future<int> _nextMenuVersion(String trainingWeekId) async {
    final row = await _database.customSelect(
      '''
      SELECT COALESCE(MAX(menu_version), 0) + 1 AS next_version
      FROM weekly_menu
      WHERE training_week_id = ?
      ''',
      variables: <Variable<Object>>[Variable.withString(trainingWeekId)],
    ).getSingle();
    return row.read<int>('next_version');
  }

  Future<WeeklyMenuPlan> _loadPlanByMenuId(String menuId) async {
    final menu = await _database.customSelect(
      '''
      SELECT wm.*, tw.week_start_date, tw.week_end_date
      FROM weekly_menu wm
      JOIN training_week tw ON tw.id = wm.training_week_id
      WHERE wm.id = ?
      ''',
      variables: <Variable<Object>>[Variable.withString(menuId)],
    ).getSingle();
    final traceObject = jsonDecode(menu.read<String>('generation_trace_json'));
    final trace = Map<String, Object?>.from(
      (traceObject ?? const <String, Object?>{}) as Map<Object?, Object?>,
    );
    final dayRows = await _database.customSelect(
      '''
      SELECT wdp.*, tl.display_name
      FROM workout_day_plan wdp
      LEFT JOIN training_location tl ON tl.id = wdp.training_location_id
      WHERE wdp.weekly_menu_id = ? AND wdp.deleted_at IS NULL
      ORDER BY wdp.plan_date
      ''',
      variables: <Variable<Object>>[Variable.withString(menuId)],
    ).get();
    final days = <WeeklyDayPlan>[];
    for (final dayRow in dayRows) {
      final dayId = dayRow.read<String>('id');
      final exerciseRows = await _database.customSelect(
        '''
        SELECT pe.*, em.code AS exercise_code
        FROM planned_exercise pe
        JOIN exercise_master em ON em.id = pe.exercise_id
        WHERE pe.workout_day_plan_id = ? AND pe.deleted_at IS NULL
        ORDER BY pe.order_index
        ''',
        variables: <Variable<Object>>[Variable.withString(dayId)],
      ).get();
      final exercises = <PlannedExercisePlan>[];
      for (final exerciseRow in exerciseRows) {
        final plannedExerciseId = exerciseRow.read<String>('id');
        final setRows = await _database.customSelect(
          '''
          SELECT * FROM planned_set
          WHERE planned_exercise_id = ? AND deleted_at IS NULL
          ORDER BY set_number
          ''',
          variables: <Variable<Object>>[
            Variable.withString(plannedExerciseId),
          ],
        ).get();
        final snapshotObject = jsonDecode(
          exerciseRow.read<String>('progression_profile_snapshot_json'),
        );
        final reasonObject = jsonDecode(
          exerciseRow.read<String>('selection_reason_ids_json'),
        );
        exercises.add(
          PlannedExercisePlan(
            id: plannedExerciseId,
            exerciseId: exerciseRow.read<String>('exercise_id'),
            exerciseCode: exerciseRow.read<String>('exercise_code'),
            exerciseName:
                exerciseRow.read<String>('exercise_name_snapshot'),
            orderIndex: exerciseRow.read<int>('order_index'),
            roleCode: exerciseRow.read<String>('role_code_snapshot'),
            recordingMethodCode:
                exerciseRow.read<String>('recording_method_snapshot'),
            targetPart:
                exerciseRow.read<String>('target_part_snapshot'),
            reason: exerciseRow.read<String>('reason_text_snapshot'),
            selectionScore: exerciseRow.read<int>('selection_score'),
            reasonIds: (reasonObject as List<Object?>).cast<String>(),
            progressionSnapshot: Map<String, Object?>.from(
              snapshotObject! as Map<Object?, Object?>,
            ),
            sets: setRows
                .map(
                  (QueryRow setRow) => PlannedSetPlan(
                    id: setRow.read<String>('id'),
                    setNumber: setRow.read<int>('set_number'),
                    isWarmup: setRow.read<int>('is_warmup') == 1,
                    restSec: setRow.read<int>('rest_sec'),
                    targetWeightKg:
                        setRow.readNullable<double>('target_weight_kg'),
                    inputWeightValue:
                        setRow.readNullable<double>('input_weight_value'),
                    inputWeightUnitCode:
                        setRow.readNullable<String>('input_weight_unit_code'),
                    targetRepsLower:
                        setRow.readNullable<int>('target_reps_lower'),
                    targetRepsUpper:
                        setRow.readNullable<int>('target_reps_upper'),
                    targetDurationSec:
                        setRow.readNullable<int>('target_duration_sec'),
                    targetAssistanceValue:
                        setRow.readNullable<double>('target_assistance_value'),
                  ),
                )
                .toList(growable: false),
          ),
        );
      }
      days.add(
        WeeklyDayPlan(
          id: dayId,
          planDate: DateTime.parse(dayRow.read<String>('plan_date')),
          weekdayCode: dayRow.read<String>('weekday_code'),
          locationId:
              dayRow.readNullable<String>('training_location_id'),
          locationName:
              dayRow.readNullable<String>('display_name') ?? '場所未設定',
          durationMin: dayRow.read<int>('duration_min'),
          estimatedDurationMin:
              dayRow.read<int>('estimated_duration_min'),
          focus: dayRow.read<String>('session_focus_snapshot'),
          reason: dayRow.read<String>('reason_text_snapshot'),
          exercises: exercises,
          statusCode: dayRow.read<String>('status_code'),
        ),
      );
    }
    return WeeklyMenuPlan(
      id: menuId,
      weekStartDate: DateTime.parse(menu.read<String>('week_start_date')),
      weekEndDate: DateTime.parse(menu.read<String>('week_end_date')),
      splitCode: menu.readNullable<String>('split_code'),
      splitName: trace['splitName'] as String? ??
          (menu.read<String>('status_code') == 'REST_WEEK'
              ? '完全休養週'
              : '週間メニュー'),
      statusCode: menu.read<String>('status_code'),
      estimatedTotalMin: menu.read<int>('estimated_total_min'),
      summaryReasons:
          ((trace['summaryReasons'] as List<Object?>?) ?? const <Object?>[])
              .cast<String>(),
      validationMessages:
          ((trace['validationMessages'] as List<Object?>?) ?? const <Object?>[])
              .cast<String>(),
      days: days,
      isRestWeek: menu.read<String>('status_code') == 'REST_WEEK',
      generationTrace: trace,
    );
  }

  Future<void> _completeDraft(WeeklyPlannerDraft draft) async {
    final now = DateTime.now().toUtc().toIso8601String();
    await _database.customStatement(
      '''
      UPDATE weekly_planner_draft
      SET status_code = 'COMPLETED',
          current_step_code = 'REVIEW',
          draft_json = ?,
          updated_at = ?,
          deleted_at = ?,
          row_version = row_version + 1,
          sync_status = 'LOCAL_ONLY'
      WHERE id = ?
      ''',
      <Object?>[
        jsonEncode(draft.toJson()),
        now,
        now,
        draft.id,
      ],
    );
  }

  Future<String> _requiredUserId() async {
    final rows = await _database.customSelect(
      '''
      SELECT ua.id
      FROM user_account ua
      JOIN user_profile up ON up.user_id = ua.id
      WHERE ua.deleted_at IS NULL
        AND up.deleted_at IS NULL
        AND up.onboarding_completed_at IS NOT NULL
      ORDER BY ua.created_at
      LIMIT 1
      ''',
    ).get();
    if (rows.isEmpty) {
      throw StateError('Complete onboarding before creating a weekly menu.');
    }
    return rows.first.read<String>('id');
  }

  Future<String> _requiredId({
    required String table,
    required String code,
  }) async {
    final rows = await _database.customSelect(
      'SELECT id FROM $table WHERE code = ? AND is_active = 1 LIMIT 1',
      variables: <Variable<Object>>[Variable.withString(code)],
    ).get();
    if (rows.isEmpty) {
      throw StateError('$table code $code is missing.');
    }
    return rows.first.read<String>('id');
  }
}

final class _DefaultDays {
  const _DefaultDays({
    required this.sourceCode,
    required this.days,
  });

  final String sourceCode;
  final List<WeeklyDayDraft> days;
}

DateTime _mondayOf(DateTime value) {
  final local = DateTime(value.year, value.month, value.day);
  return local.subtract(Duration(days: local.weekday - DateTime.monday));
}

String _dateOnly(DateTime value) =>
    DateTime(value.year, value.month, value.day).toIso8601String().substring(0, 10);
