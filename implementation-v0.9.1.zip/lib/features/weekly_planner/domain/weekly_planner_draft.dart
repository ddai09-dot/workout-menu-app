import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_step.dart';

const Object _unset = Object();

abstract final class WeekdayCodes {
  static const ordered = <String>['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];

  static String label(String code) => switch (code) {
        'MON' => '月',
        'TUE' => '火',
        'WED' => '水',
        'THU' => '木',
        'FRI' => '金',
        'SAT' => '土',
        'SUN' => '日',
        _ => code,
      };

  static int indexOf(String code) => ordered.indexOf(code);
}

final class WeeklyDayDraft {
  const WeeklyDayDraft({
    required this.weekdayCode,
    required this.planDate,
    required this.isAvailable,
    required this.durationMin,
    required this.locationId,
    required this.locationName,
  });

  final String weekdayCode;
  final DateTime planDate;
  final bool isAvailable;
  final int? durationMin;
  final String? locationId;
  final String? locationName;

  WeeklyDayDraft copyWith({
    bool? isAvailable,
    Object? durationMin = _unset,
    Object? locationId = _unset,
    Object? locationName = _unset,
  }) {
    return WeeklyDayDraft(
      weekdayCode: weekdayCode,
      planDate: planDate,
      isAvailable: isAvailable ?? this.isAvailable,
      durationMin: identical(durationMin, _unset)
          ? this.durationMin
          : durationMin as int?,
      locationId: identical(locationId, _unset)
          ? this.locationId
          : locationId as String?,
      locationName: identical(locationName, _unset)
          ? this.locationName
          : locationName as String?,
    );
  }

  Map<String, Object?> toJson() => <String, Object?>{
        'weekdayCode': weekdayCode,
        'planDate': _dateOnly(planDate),
        'isAvailable': isAvailable,
        'durationMin': durationMin,
        'locationId': locationId,
        'locationName': locationName,
      };

  factory WeeklyDayDraft.fromJson(Map<String, Object?> json) {
    return WeeklyDayDraft(
      weekdayCode: json['weekdayCode']! as String,
      planDate: DateTime.parse(json['planDate']! as String),
      isAvailable: json['isAvailable'] as bool? ?? false,
      durationMin: (json['durationMin'] as num?)?.toInt(),
      locationId: json['locationId'] as String?,
      locationName: json['locationName'] as String?,
    );
  }
}

final class WeeklyPainDraft {
  const WeeklyPainDraft({
    required this.bodyPartCode,
    required this.bodyPartName,
    required this.actionCode,
  });

  final String bodyPartCode;
  final String bodyPartName;
  final String actionCode;

  Map<String, Object> toJson() => <String, Object>{
        'bodyPartCode': bodyPartCode,
        'bodyPartName': bodyPartName,
        'actionCode': actionCode,
      };

  factory WeeklyPainDraft.fromJson(Map<String, Object?> json) {
    return WeeklyPainDraft(
      bodyPartCode: json['bodyPartCode']! as String,
      bodyPartName: json['bodyPartName']! as String,
      actionCode: json['actionCode']! as String,
    );
  }
}

final class WeeklyStallDraft {
  const WeeklyStallDraft({
    required this.exerciseId,
    required this.exerciseCode,
    required this.exerciseName,
    required this.adjustmentCode,
    this.recommendedAdjustmentCode,
    this.detectedByCode = 'USER',
  });

  final String exerciseId;
  final String exerciseCode;
  final String exerciseName;
  final String adjustmentCode;
  final String? recommendedAdjustmentCode;
  final String detectedByCode;

  Map<String, Object?> toJson() => <String, Object?>{
        'exerciseId': exerciseId,
        'exerciseCode': exerciseCode,
        'exerciseName': exerciseName,
        'adjustmentCode': adjustmentCode,
        'recommendedAdjustmentCode': recommendedAdjustmentCode,
        'detectedByCode': detectedByCode,
      };

  factory WeeklyStallDraft.fromJson(Map<String, Object?> json) {
    return WeeklyStallDraft(
      exerciseId: json['exerciseId']! as String,
      exerciseCode: json['exerciseCode']! as String,
      exerciseName: json['exerciseName']! as String,
      adjustmentCode: json['adjustmentCode']! as String,
      recommendedAdjustmentCode: json['recommendedAdjustmentCode'] as String?,
      detectedByCode: json['detectedByCode'] as String? ?? 'USER',
    );
  }
}

final class WeeklyPlannerDraft {
  const WeeklyPlannerDraft({
    required this.id,
    required this.userId,
    required this.ruleVersionId,
    required this.weekStartDate,
    required this.days,
    this.currentStep = WeeklyPlannerStep.start,
    this.scheduleSourceCode = 'STANDARD',
    this.sleepScore = 3,
    this.motivationScore = 3,
    this.painEntries = const <WeeklyPainDraft>[],
    this.hasPreviousWeek = false,
    this.previousLoadScore,
    this.achievementScore,
    this.stalledExercises = const <WeeklyStallDraft>[],
    this.loadDirectionCode = 'APP',
    this.increaseMethodCode,
    this.priorityModeCode = 'DEFAULT',
    this.primaryPriorityCode,
    this.secondaryPriorityCodes = const <String>{},
    this.splitOverrideCode,
    this.restWeek = false,
    this.generatedMenuId,
    this.finalized = false,
  });

  final String id;
  final String userId;
  final String ruleVersionId;
  final DateTime weekStartDate;
  final WeeklyPlannerStep currentStep;
  final String scheduleSourceCode;
  final List<WeeklyDayDraft> days;
  final int sleepScore;
  final int motivationScore;
  final List<WeeklyPainDraft> painEntries;
  final bool hasPreviousWeek;
  final int? previousLoadScore;
  final int? achievementScore;
  final List<WeeklyStallDraft> stalledExercises;
  final String loadDirectionCode;
  final String? increaseMethodCode;
  final String priorityModeCode;
  final String? primaryPriorityCode;
  final Set<String> secondaryPriorityCodes;
  final String? splitOverrideCode;
  final bool restWeek;
  final String? generatedMenuId;
  final bool finalized;

  DateTime get weekEndDate => weekStartDate.add(const Duration(days: 6));
  List<WeeklyDayDraft> get availableDays => days
      .where((WeeklyDayDraft value) => value.isAvailable)
      .toList(growable: false);

  WeeklyPlannerDraft copyWith({
    WeeklyPlannerStep? currentStep,
    String? scheduleSourceCode,
    List<WeeklyDayDraft>? days,
    int? sleepScore,
    int? motivationScore,
    List<WeeklyPainDraft>? painEntries,
    bool? hasPreviousWeek,
    Object? previousLoadScore = _unset,
    Object? achievementScore = _unset,
    List<WeeklyStallDraft>? stalledExercises,
    String? loadDirectionCode,
    Object? increaseMethodCode = _unset,
    String? priorityModeCode,
    Object? primaryPriorityCode = _unset,
    Set<String>? secondaryPriorityCodes,
    Object? splitOverrideCode = _unset,
    bool? restWeek,
    Object? generatedMenuId = _unset,
    bool? finalized,
  }) {
    return WeeklyPlannerDraft(
      id: id,
      userId: userId,
      ruleVersionId: ruleVersionId,
      weekStartDate: weekStartDate,
      currentStep: currentStep ?? this.currentStep,
      scheduleSourceCode: scheduleSourceCode ?? this.scheduleSourceCode,
      days: days ?? this.days,
      sleepScore: sleepScore ?? this.sleepScore,
      motivationScore: motivationScore ?? this.motivationScore,
      painEntries: painEntries ?? this.painEntries,
      hasPreviousWeek: hasPreviousWeek ?? this.hasPreviousWeek,
      previousLoadScore: identical(previousLoadScore, _unset)
          ? this.previousLoadScore
          : previousLoadScore as int?,
      achievementScore: identical(achievementScore, _unset)
          ? this.achievementScore
          : achievementScore as int?,
      stalledExercises: stalledExercises ?? this.stalledExercises,
      loadDirectionCode: loadDirectionCode ?? this.loadDirectionCode,
      increaseMethodCode: identical(increaseMethodCode, _unset)
          ? this.increaseMethodCode
          : increaseMethodCode as String?,
      priorityModeCode: priorityModeCode ?? this.priorityModeCode,
      primaryPriorityCode: identical(primaryPriorityCode, _unset)
          ? this.primaryPriorityCode
          : primaryPriorityCode as String?,
      secondaryPriorityCodes:
          secondaryPriorityCodes ?? this.secondaryPriorityCodes,
      splitOverrideCode: identical(splitOverrideCode, _unset)
          ? this.splitOverrideCode
          : splitOverrideCode as String?,
      restWeek: restWeek ?? this.restWeek,
      generatedMenuId: identical(generatedMenuId, _unset)
          ? this.generatedMenuId
          : generatedMenuId as String?,
      finalized: finalized ?? this.finalized,
    );
  }

  WeeklyPlannerDraft updateDay(
    String weekdayCode,
    WeeklyDayDraft Function(WeeklyDayDraft day) update,
  ) {
    return copyWith(
      days: days
          .map(
            (WeeklyDayDraft day) =>
                day.weekdayCode == weekdayCode ? update(day) : day,
          )
          .toList(growable: false),
    );
  }

  String? validationMessage(WeeklyPlannerStep step) {
    if (restWeek) {
      return null;
    }
    return switch (step) {
      WeeklyPlannerStep.start => null,
      WeeklyPlannerStep.schedule => _scheduleValidationMessage(),
      WeeklyPlannerStep.condition => _conditionValidationMessage(),
      WeeklyPlannerStep.previousWeek => _previousValidationMessage(),
      WeeklyPlannerStep.adjustment => _adjustmentValidationMessage(),
      WeeklyPlannerStep.review => generatedMenuId == null
          ? 'メニューを生成してください。'
          : null,
    };
  }

  WeeklyPlannerStep? get firstInvalidStep {
    for (final step in WeeklyPlannerStep.values) {
      if (step == WeeklyPlannerStep.review) {
        continue;
      }
      if (validationMessage(step) != null) {
        return step;
      }
    }
    return null;
  }

  String? _scheduleValidationMessage() {
    if (availableDays.isEmpty) {
      return 'トレーニングできる曜日を1日以上選択してください。';
    }
    for (final day in availableDays) {
      if (day.durationMin == null) {
        return '${WeekdayCodes.label(day.weekdayCode)}曜日の時間を選択してください。';
      }
      if (day.locationId == null) {
        return '${WeekdayCodes.label(day.weekdayCode)}曜日の場所を選択してください。';
      }
    }
    return null;
  }

  String? _conditionValidationMessage() {
    if (sleepScore < 1 || sleepScore > 5) {
      return '睡眠状態を1〜5から選択してください。';
    }
    if (motivationScore < 1 || motivationScore > 5) {
      return 'モチベーションを1〜5から選択してください。';
    }
    return null;
  }

  String? _previousValidationMessage() {
    if (!hasPreviousWeek) {
      return null;
    }
    if (previousLoadScore == null) {
      return '前週の全体負荷を選択してください。';
    }
    if (achievementScore == null) {
      return '目標回数の達成状況を選択してください。';
    }
    return null;
  }

  String? _adjustmentValidationMessage() {
    const allowed = <String>{'APP', 'UP', 'MAINTAIN', 'DOWN'};
    if (!allowed.contains(loadDirectionCode)) {
      return '今週の全体負荷を選択してください。';
    }
    if (loadDirectionCode == 'UP' && increaseMethodCode == null) {
      return '負荷を上げる方法を選択してください。';
    }
    if (priorityModeCode == 'CUSTOM' && primaryPriorityCode == null) {
      return '今週の最優先部位を選択してください。';
    }
    return null;
  }

  double? get achievementRate => switch (achievementScore) {
        1 => 0.2,
        2 => 0.4,
        3 => 0.6,
        4 => 0.8,
        5 => 1.0,
        _ => null,
      };

  Map<String, Object?> toJson() => <String, Object?>{
        'id': id,
        'userId': userId,
        'ruleVersionId': ruleVersionId,
        'weekStartDate': _dateOnly(weekStartDate),
        'currentStepCode': currentStep.code,
        'scheduleSourceCode': scheduleSourceCode,
        'days': days.map((WeeklyDayDraft value) => value.toJson()).toList(),
        'sleepScore': sleepScore,
        'motivationScore': motivationScore,
        'painEntries': painEntries
            .map((WeeklyPainDraft value) => value.toJson())
            .toList(),
        'hasPreviousWeek': hasPreviousWeek,
        'previousLoadScore': previousLoadScore,
        'achievementScore': achievementScore,
        'stalledExercises': stalledExercises
            .map((WeeklyStallDraft value) => value.toJson())
            .toList(),
        'loadDirectionCode': loadDirectionCode,
        'increaseMethodCode': increaseMethodCode,
        'priorityModeCode': priorityModeCode,
        'primaryPriorityCode': primaryPriorityCode,
        'secondaryPriorityCodes': secondaryPriorityCodes.toList()..sort(),
        'splitOverrideCode': splitOverrideCode,
        'restWeek': restWeek,
        'generatedMenuId': generatedMenuId,
        'finalized': finalized,
      };

  factory WeeklyPlannerDraft.fromJson(Map<String, Object?> json) {
    return WeeklyPlannerDraft(
      id: json['id']! as String,
      userId: json['userId']! as String,
      ruleVersionId: json['ruleVersionId']! as String,
      weekStartDate: DateTime.parse(json['weekStartDate']! as String),
      currentStep: WeeklyPlannerStepX.fromCode(
        json['currentStepCode'] as String? ?? 'START',
      ),
      scheduleSourceCode:
          json['scheduleSourceCode'] as String? ?? 'STANDARD',
      days: ((json['days'] as List<Object?>?) ?? const <Object?>[])
          .map(
            (Object? value) => WeeklyDayDraft.fromJson(
              Map<String, Object?>.from(value! as Map<Object?, Object?>),
            ),
          )
          .toList(growable: false),
      sleepScore: (json['sleepScore'] as num?)?.toInt() ?? 3,
      motivationScore: (json['motivationScore'] as num?)?.toInt() ?? 3,
      painEntries:
          ((json['painEntries'] as List<Object?>?) ?? const <Object?>[])
              .map(
                (Object? value) => WeeklyPainDraft.fromJson(
                  Map<String, Object?>.from(value! as Map<Object?, Object?>),
                ),
              )
              .toList(growable: false),
      hasPreviousWeek: json['hasPreviousWeek'] as bool? ?? false,
      previousLoadScore: (json['previousLoadScore'] as num?)?.toInt(),
      achievementScore: (json['achievementScore'] as num?)?.toInt(),
      stalledExercises:
          ((json['stalledExercises'] as List<Object?>?) ?? const <Object?>[])
              .map(
                (Object? value) => WeeklyStallDraft.fromJson(
                  Map<String, Object?>.from(value! as Map<Object?, Object?>),
                ),
              )
              .toList(growable: false),
      loadDirectionCode: json['loadDirectionCode'] as String? ?? 'APP',
      increaseMethodCode: json['increaseMethodCode'] as String?,
      priorityModeCode: json['priorityModeCode'] as String? ?? 'DEFAULT',
      primaryPriorityCode: json['primaryPriorityCode'] as String?,
      secondaryPriorityCodes:
          ((json['secondaryPriorityCodes'] as List<Object?>?) ??
                  const <Object?>[])
              .cast<String>()
              .toSet(),
      splitOverrideCode: json['splitOverrideCode'] as String?,
      restWeek: json['restWeek'] as bool? ?? false,
      generatedMenuId: json['generatedMenuId'] as String?,
      finalized: json['finalized'] as bool? ?? false,
    );
  }
}

String _dateOnly(DateTime value) =>
    DateTime(value.year, value.month, value.day).toIso8601String().substring(0, 10);
