import 'dart:math' as math;

import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_generation_models.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_menu_plan.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_draft.dart';

final class RuleBasedWeeklyMenuGenerator {
  const RuleBasedWeeklyMenuGenerator({
    IdGenerator idGenerator = const UuidV7Generator(),
  }) : _idGenerator = idGenerator;

  final IdGenerator _idGenerator;

  WeeklyMenuPlan generate(WeeklyGenerationInput input) {
    if (input.draft.restWeek) {
      return WeeklyMenuPlan(
        id: _idGenerator.next(),
        weekStartDate: input.draft.weekStartDate,
        weekEndDate: input.draft.weekEndDate,
        splitCode: null,
        splitName: '完全休養週',
        statusCode: 'REST_WEEK',
        estimatedTotalMin: 0,
        summaryReasons: const <String>[
          '今週は完全休養として保存します。ウォーキングやストレッチへ自動置換しません。',
        ],
        days: const <WeeklyDayPlan>[],
        validationMessages: const <String>[],
        isRestWeek: true,
        generationTrace: const <String, Object?>{
          'specVersion': '1.1',
          'implementationVersion': '0.8.6',
          'steps': <Map<String, Object?>>[
            <String, Object?>{'step': 1, 'code': 'INPUT_NORMALIZATION', 'status': 'PASSED'},
            <String, Object?>{'step': 2, 'code': 'REST_WEEK_CHECK', 'status': 'TERMINATED_REST_WEEK'},
          ],
        },
      );
    }

    final available = input.draft.availableDays.toList()
      ..sort(
        (WeeklyDayDraft a, WeeklyDayDraft b) =>
            a.planDate.compareTo(b.planDate),
      );
    if (available.isEmpty) {
      throw StateError('No available day was selected.');
    }

    final desired = math.min(
      math.min(input.desiredDaysPerWeek, available.length),
      6,
    );
    final selectedDays = _selectSpreadDays(available, desired);
    final split = _chooseSplit(input, selectedDays);
    final dayTemplates = _placeTemplates(split, selectedDays);
    final primaryPriority = input.effectivePrimaryPriorityCode;

    final generatedDays = <WeeklyDayPlan>[];
    final validationMessages = <String>[];
    final traceReasons = <String>[
      '経験・週回数・曜日間隔・器具を評価し、${split.name}を選びました。',
    ];
    final traceSteps = <Map<String, Object?>>[
      <String, Object?>{'step': 1, 'code': 'INPUT_NORMALIZATION', 'status': 'PASSED'},
      <String, Object?>{'step': 2, 'code': 'REST_WEEK_CHECK', 'status': 'CONTINUE'},
      <String, Object?>{'step': 3, 'code': 'TRAINING_DAY_COUNT', 'status': 'PASSED', 'selectedDays': desired},
      <String, Object?>{'step': 4, 'code': 'SPLIT_CANDIDATES', 'status': 'PASSED', 'candidateCount': _SplitCatalog.forDays(selectedDays.length).length},
      <String, Object?>{'step': 5, 'code': 'SPLIT_SCORING', 'status': 'PASSED', 'selectedSplit': split.code},
      <String, Object?>{'step': 6, 'code': 'CALENDAR_PLACEMENT', 'status': 'PASSED', 'dates': selectedDays.map((WeeklyDayDraft value) => value.planDate.toIso8601String().substring(0, 10)).toList(growable: false)},
    ];

    for (var index = 0; index < selectedDays.length; index++) {
      final day = selectedDays[index];
      final location = input.locations[day.locationId];
      if (location == null) {
        validationMessages.add(
          '${WeekdayCodes.label(day.weekdayCode)}曜日の場所が見つからないため、メニューを作成できません。',
        );
        continue;
      }
      final template = dayTemplates[index];
      final result = _composeDay(
        input: input,
        day: day,
        location: location,
        template: template,
        primaryPriority: primaryPriority,
      );
      generatedDays.add(result.day);
      validationMessages.addAll(result.validationMessages);
    }

    final mergedDays = <WeeklyDayPlan>[
      ...input.lockedDays,
      ...generatedDays.where(
        (WeeklyDayPlan day) => !input.lockedDays.any(
          (WeeklyDayPlan locked) => _dateOnly(locked.planDate) == _dateOnly(day.planDate),
        ),
      ),
    ]..sort((WeeklyDayPlan a, WeeklyDayPlan b) => a.planDate.compareTo(b.planDate));

    if (primaryPriority != null) {
      traceReasons.add(
        '${_partLabel(<String>{primaryPriority})}を今週の最優先部位として、可能な範囲で複数日に分散しています。',
      );
    }
    if (input.draft.sleepScore <= 2) {
      traceReasons.add(
        '睡眠不足を考慮し、セット数を減らして重量増加を見送る構成です。',
      );
    }
    if (input.startVolumeFactor < 1) {
      traceReasons.add(
        '復帰期の開始量として、通常の約${(input.startVolumeFactor * 100).round()}%を上限にしています。',
      );
    }
    if (input.draft.loadDirectionCode == 'UP' &&
        input.draft.increaseMethodCode == 'WEIGHT') {
      traceReasons.add(
        '重量増加は直近実績を参照できる種目だけに限定し、セット数は自動で増やしていません。',
      );
    }
    if (input.draft.painEntries.isNotEmpty) {
      traceReasons.add(
        '痛み・違和感の指定を種目除外と負荷調整へ反映しています。',
      );
    }

    final totalMin = mergedDays.fold<int>(
      0,
      (int total, WeeklyDayPlan day) => total + day.estimatedDurationMin,
    );
    traceSteps.addAll(<Map<String, Object?>>[
      <String, Object?>{'step': 7, 'code': 'WEEKLY_VOLUME', 'status': 'IMPLEMENTED_SESSION_TARGET', 'workSets': mergedDays.fold<int>(0, (int total, WeeklyDayPlan day) => total + day.workSetCount)},
      <String, Object?>{'step': 8, 'code': 'EXERCISE_HARD_FILTER', 'status': 'PASSED'},
      <String, Object?>{'step': 9, 'code': 'EXERCISE_SCORING', 'status': 'PASSED', 'exerciseCount': mergedDays.fold<int>(0, (int total, WeeklyDayPlan day) => total + day.exercises.length)},
      <String, Object?>{'step': 10, 'code': 'TIME_FIT', 'status': validationMessages.isEmpty ? 'PASSED' : 'PASSED_WITH_MESSAGES', 'estimatedTotalMin': totalMin},
      <String, Object?>{'step': 11, 'code': 'LOAD_REP_CONFIGURATION', 'status': 'PROFILE_SNAPSHOT_ONLY'},
      <String, Object?>{'step': 12, 'code': 'FINAL_VALIDATION', 'status': validationMessages.isEmpty ? 'PASSED' : 'WARNING', 'messageCount': validationMessages.length},
      <String, Object?>{'step': 13, 'code': 'REASON_RENDERING', 'status': 'PASSED', 'reasonCount': traceReasons.length},
    ]);

    return WeeklyMenuPlan(
      id: _idGenerator.next(),
      weekStartDate: input.draft.weekStartDate,
      weekEndDate: input.draft.weekEndDate,
      splitCode: split.code,
      splitName: split.name,
      statusCode: 'PROVISIONAL',
      estimatedTotalMin: totalMin,
      summaryReasons: traceReasons,
      days: mergedDays,
      validationMessages: validationMessages,
      generationTrace: <String, Object?>{
        'specVersion': '1.1',
        'implementationVersion': '0.8.6',
        'ruleVersionId': input.draft.ruleVersionId,
        'splitScorePolicy': 'score_desc_complexity_asc_code_asc',
        'steps': traceSteps,
      },
    );
  }

  List<WeeklyDayDraft> _selectSpreadDays(
    List<WeeklyDayDraft> available,
    int count,
  ) {
    if (available.length <= count) {
      return List<WeeklyDayDraft>.unmodifiable(available);
    }
    List<WeeklyDayDraft>? best;
    var bestScore = -1 << 30;

    void search(int start, List<WeeklyDayDraft> current) {
      if (current.length == count) {
        var score = 0;
        for (var i = 1; i < current.length; i++) {
          final gap = current[i].planDate.difference(current[i - 1].planDate).inDays;
          score += math.min(gap, 3) * 20;
          if (gap == 1) {
            score -= 25;
          }
        }
        score += current.fold<int>(0, (int total, WeeklyDayDraft day) {
          return total + (day.durationMin ?? 0);
        });
        if (score > bestScore) {
          bestScore = score;
          best = List<WeeklyDayDraft>.of(current);
        }
        return;
      }
      for (var i = start; i <= available.length - (count - current.length); i++) {
        current.add(available[i]);
        search(i + 1, current);
        current.removeLast();
      }
    }

    search(0, <WeeklyDayDraft>[]);
    return List<WeeklyDayDraft>.unmodifiable(best ?? available.take(count));
  }

  _SplitTemplate _chooseSplit(
    WeeklyGenerationInput input,
    List<WeeklyDayDraft> selectedDays,
  ) {
    final candidates = _SplitCatalog.forDays(selectedDays.length);
    final preference = input.effectiveSplitPreferenceCode;
    final level = input.experienceLevelCode;
    final consecutive = _hasConsecutiveDays(selectedDays);
    final priority = input.effectivePrimaryPriorityCode;

    final scored = candidates.map((_SplitTemplate candidate) {
      var score = 30;
      if (candidate.preferenceCode == preference) {
        score += 20;
      }
      if (preference == 'APP' && candidate.appRecommended) {
        score += 18;
      }
      if (candidate.levels.contains(level)) {
        score += 15;
      }
      if (candidate.simple && level == 'BEGINNER') {
        score += 8;
      }
      if (candidate.priorityFrequency(priority) >= 2) {
        score += 10;
      }
      if (consecutive && candidate.code.startsWith('FULL_BODY')) {
        score -= 35;
      }
      if (consecutive && candidate.code == 'UPPER_LOWER_2') {
        score += 25;
      }
      if (level == 'BEGINNER' && candidate.complexity >= 4) {
        score -= 20;
      }
      if (preference != 'APP' && candidate.preferenceCode != preference) {
        score -= 12;
      }
      return _ScoredSplit(candidate, score);
    }).toList()
      ..sort((_ScoredSplit a, _ScoredSplit b) {
        final byScore = b.score.compareTo(a.score);
        if (byScore != 0) {
          return byScore;
        }
        final byComplexity = a.value.complexity.compareTo(b.value.complexity);
        if (byComplexity != 0) {
          return byComplexity;
        }
        return a.value.code.compareTo(b.value.code);
      });
    return scored.first.value;
  }

  List<_SessionTemplate> _placeTemplates(
    _SplitTemplate split,
    List<WeeklyDayDraft> selectedDays,
  ) {
    final templates = List<_SessionTemplate>.of(split.sessions);
    if (templates.length != selectedDays.length) {
      throw StateError('Split session count does not match selected days.');
    }
    return templates;
  }

  _ComposedDay _composeDay({
    required WeeklyGenerationInput input,
    required WeeklyDayDraft day,
    required GenerationLocation location,
    required _SessionTemplate template,
    required String? primaryPriority,
  }) {
    final duration = day.durationMin ?? 30;
    final maxExercises = _maxExerciseCount(
      duration,
      input.experienceLevelCode,
      loadDirectionCode: input.draft.loadDirectionCode,
      increaseMethodCode: input.draft.increaseMethodCode,
    );
    final workSetTarget = _targetWorkSets(
      duration: duration,
      sleepScore: input.draft.sleepScore,
      previousLoadScore: input.draft.previousLoadScore,
      loadDirectionCode: input.draft.loadDirectionCode,
      increaseMethodCode: input.draft.increaseMethodCode,
      startVolumeFactor: input.startVolumeFactor,
    );
    final excludedParts = <String>{...input.restrictions.bodyPartCodes};
    final reduceLoadParts = <String>{};
    for (final pain in input.draft.painEntries) {
      if (pain.actionCode == 'EXCLUDE' || pain.actionCode == 'SUBSTITUTE') {
        excludedParts.add(pain.bodyPartCode);
      } else if (pain.actionCode == 'REDUCE_LOAD') {
        reduceLoadParts.add(pain.bodyPartCode);
      }
    }

    final slots = template.slots.take(maxExercises).toList();
    final stallsByExerciseId = <String, WeeklyStallDraft>{
      for (final stall in input.draft.stalledExercises)
        stall.exerciseId: stall,
    };
    final chosen = <_ScoredExercise>[];
    final validation = <String>[];
    final usedMovementGroups = <String>{};
    final usedExerciseIds = <String>{};

    for (var slotIndex = 0; slotIndex < slots.length; slotIndex++) {
      final slot = slots[slotIndex];
      final candidates = <_ScoredExercise>[];
      for (final exercise in input.exercises) {
        if (usedExerciseIds.contains(exercise.id)) {
          continue;
        }
        final stall = stallsByExerciseId[exercise.id];
        if (stall?.adjustmentCode == 'SUBSTITUTE') {
          continue;
        }
        if (!_matchesSlot(exercise, slot)) {
          continue;
        }
        if (!exercise.isAvailableForLevel(input.experienceLevelCode)) {
          continue;
        }
        if (!exercise.canUseAt(location)) {
          continue;
        }
        if (input.restrictions.exerciseIds.contains(exercise.id) ||
            exercise.primaryBodyPartCodes.any(excludedParts.contains) ||
            exercise.jointCodes.any(input.restrictions.jointCodes.contains) ||
            exercise.movementGroupCodes
                .any(input.restrictions.movementGroupCodes.contains)) {
          continue;
        }

        var score = 0;
        final reasonIds = <String>[];
        if (slotIndex <= 1 && exercise.isMajor) {
          score += 20;
          reasonIds.add('EX_MAIN_ROLE');
        }
        if (exercise.defaultPriorityCode == 'STANDARD') {
          score += 12;
          reasonIds.add('EX_BASIC');
        }
        if (input.previousExerciseIds.contains(exercise.id)) {
          score += 15;
          reasonIds.add('EX_HISTORY');
        }
        if (primaryPriority != null &&
            exercise.primaryBodyPartCodes.contains(primaryPriority)) {
          score += 12;
          reasonIds.add('EX_PRIORITY');
        }
        if (input.effectiveSecondaryPriorityCodes
            .any(exercise.primaryBodyPartCodes.contains)) {
          score += 4;
          reasonIds.add('EX_SECONDARY_PRIORITY');
        }
        if (exercise.movementGroupCodes.any(
          (String code) => !usedMovementGroups.contains(code),
        )) {
          score += 10;
          reasonIds.add('EX_MOVEMENT_GAP');
        }
        if (exercise.isCompound && duration <= 45) {
          score += 6;
          reasonIds.add('EX_TIME_EFFICIENT');
        }
        if (_technicalMatch(
          exercise.technicalDifficultyCode,
          input.experienceLevelCode,
        )) {
          score += 6;
          reasonIds.add('EX_TECH_MATCH');
        }
        if (exercise.movementGroupCodes.any(usedMovementGroups.contains)) {
          score -= 10;
        }
        if (exercise.primaryBodyPartCodes.any(reduceLoadParts.contains)) {
          score -= 8;
          reasonIds.add('PAIN_REDUCE');
        }
        if (stall != null) {
          switch (stall.adjustmentCode) {
            case 'MAINTAIN':
              score += 5;
              reasonIds.add('STALL_MAINTAIN');
              break;
            case 'REDUCE_WEIGHT':
              score += 4;
              reasonIds.add('STALL_REDUCE_WEIGHT');
              break;
            case 'CHANGE_REP_RANGE':
              score += 4;
              reasonIds.add('STALL_CHANGE_REP_RANGE');
              break;
            default:
              break;
          }
        }
        candidates.add(_ScoredExercise(exercise, score, reasonIds));
      }
      candidates.sort((_ScoredExercise a, _ScoredExercise b) {
        final score = b.score.compareTo(a.score);
        if (score != 0) {
          return score;
        }
        return a.exercise.code.compareTo(b.exercise.code);
      });
      if (candidates.isEmpty) {
        continue;
      }
      final selected = candidates.first;
      chosen.add(selected);
      usedExerciseIds.add(selected.exercise.id);
      usedMovementGroups.addAll(selected.exercise.movementGroupCodes);
    }

    if (chosen.length < 2) {
      throw StateError(
        '${WeekdayCodes.label(day.weekdayCode)}曜日に実施可能な種目が不足しています。',
      );
    }

    final setCounts = _allocateSetCounts(
      chosen: chosen,
      targetWorkSets: workSetTarget,
      primaryPriority: primaryPriority,
      reduceLoadParts: reduceLoadParts,
    );

    final exercises = <PlannedExercisePlan>[];
    var estimatedSec = 5 * 60;
    for (var i = 0; i < chosen.length; i++) {
      final scored = chosen[i];
      final progression = scored.exercise.progression;
      final stall = stallsByExerciseId[scored.exercise.id];
      final adjustedProgression = _adjustProgression(progression, stall);
      final count = setCounts[i];
      if (count <= 0) {
        continue;
      }
      final sets = <PlannedSetPlan>[];
      for (var setIndex = 1; setIndex <= count; setIndex++) {
        sets.add(
          PlannedSetPlan(
            id: _idGenerator.next(),
            setNumber: setIndex,
            isWarmup: false,
            restSec: _adjustRestSeconds(
              adjustedProgression.restSec,
              loadDirectionCode: input.draft.loadDirectionCode,
              increaseMethodCode: input.draft.increaseMethodCode,
              sleepScore: input.draft.sleepScore,
            ),
            targetRepsLower: adjustedProgression.repLower,
            targetRepsUpper: adjustedProgression.repUpper,
            targetDurationSec: adjustedProgression.durationUpperSec,
          ),
        );
      }
      estimatedSec += _exerciseSeconds(scored.exercise, count);
      final part = _partLabel(scored.exercise.primaryBodyPartCodes);
      exercises.add(
        PlannedExercisePlan(
          id: _idGenerator.next(),
          exerciseId: scored.exercise.id,
          exerciseCode: scored.exercise.code,
          exerciseName: scored.exercise.name,
          orderIndex: exercises.length + 1,
          roleCode: scored.exercise.roleCode,
          recordingMethodCode: scored.exercise.recordingMethodCode,
          targetPart: part,
          reason: _exerciseReason(scored, part),
          selectionScore: scored.score,
          reasonIds: scored.reasonIds,
          progressionSnapshot: <String, Object?>{
            ...adjustedProgression.toJson(),
            if (stall != null) 'stallAdjustmentCode': stall.adjustmentCode,
            if (input.draft.loadDirectionCode == 'UP')
              'weeklyIncreaseMethodCode': input.draft.increaseMethodCode,
          },
          sets: sets,
        ),
      );
    }

    while (estimatedSec > (duration * 60 * 1.05).round() &&
        exercises.length > 2) {
      final removed = exercises.removeLast();
      estimatedSec -= _exerciseSeconds(
        chosen.firstWhere(
          (_ScoredExercise value) => value.exercise.id == removed.exerciseId,
        ).exercise,
        removed.sets.length,
      );
      // The resulting plan is valid. Trimming is reflected by the persisted
      // exercise list rather than treated as a blocking validation error.
    }

    final estimatedMin = (estimatedSec / 60).ceil();
    final focus = template.name;
    final reason = _dayReason(
      template: template,
      location: location,
      primaryPriority: primaryPriority,
      sleepScore: input.draft.sleepScore,
    );

    return _ComposedDay(
      day: WeeklyDayPlan(
        id: _idGenerator.next(),
        planDate: day.planDate,
        weekdayCode: day.weekdayCode,
        locationId: day.locationId,
        locationName: location.name,
        durationMin: duration,
        estimatedDurationMin: estimatedMin,
        focus: focus,
        reason: reason,
        exercises: exercises,
      ),
      validationMessages: validation,
    );
  }

  bool _matchesSlot(GenerationExercise exercise, _ExerciseSlot slot) {
    final partMatch = slot.bodyPartCodes.isEmpty ||
        exercise.primaryBodyPartCodes.any(slot.bodyPartCodes.contains);
    final movementMatch = slot.movementGroupCodes.isEmpty ||
        exercise.movementGroupCodes.any(slot.movementGroupCodes.contains);
    return partMatch && movementMatch;
  }

  List<int> _allocateSetCounts({
    required List<_ScoredExercise> chosen,
    required int targetWorkSets,
    required String? primaryPriority,
    required Set<String> reduceLoadParts,
  }) {
    final values = chosen
        .map((_ScoredExercise value) => value.exercise.progression.setLower)
        .toList();
    for (var i = 0; i < values.length; i++) {
      if (chosen[i].exercise.primaryBodyPartCodes.any(reduceLoadParts.contains)) {
        values[i] = math.max(1, values[i] - 1);
      }
    }
    var total = values.fold<int>(0, (int a, int b) => a + b);
    while (total < targetWorkSets) {
      var changed = false;
      final order = List<int>.generate(values.length, (int index) => index)
        ..sort((int a, int b) {
          final aPriority = primaryPriority != null &&
              chosen[a].exercise.primaryBodyPartCodes.contains(primaryPriority);
          final bPriority = primaryPriority != null &&
              chosen[b].exercise.primaryBodyPartCodes.contains(primaryPriority);
          if (aPriority != bPriority) {
            return bPriority ? 1 : -1;
          }
          return chosen[b].score.compareTo(chosen[a].score);
        });
      for (final index in order) {
        final maxSets = chosen[index].exercise.progression.setUpper;
        if (values[index] < maxSets) {
          values[index]++;
          total++;
          changed = true;
          if (total >= targetWorkSets) {
            break;
          }
        }
      }
      if (!changed) {
        break;
      }
    }
    while (total > targetWorkSets && values.length > 2) {
      var changed = false;
      for (var i = values.length - 1; i >= 0; i--) {
        if (values[i] > 1) {
          values[i]--;
          total--;
          changed = true;
          if (total <= targetWorkSets) {
            break;
          }
        }
      }
      if (!changed) {
        break;
      }
    }
    return values;
  }

  int _targetWorkSets({
    required int duration,
    required int sleepScore,
    required int? previousLoadScore,
    required String loadDirectionCode,
    required String? increaseMethodCode,
    required double startVolumeFactor,
  }) {
    var target = switch (duration) {
      <= 15 => 7,
      <= 30 => 10,
      <= 45 => 14,
      <= 60 => 17,
      <= 90 => 22,
      _ => 26,
    };
    final factor = switch (sleepScore) {
      1 => 0.75,
      2 => 0.85,
      3 => 0.95,
      _ => 1.0,
    };
    target = math.max(4, (target * factor * startVolumeFactor).round());
    if (previousLoadScore == 5) {
      target = math.max(4, (target * 0.85).round());
    } else if (previousLoadScore == 4) {
      target = math.max(4, target - 1);
    }
    if (loadDirectionCode == 'DOWN') {
      target = math.max(4, target - 2);
    } else if (loadDirectionCode == 'UP' &&
        sleepScore >= 3 &&
        <String?>{'APP', 'SETS'}.contains(increaseMethodCode)) {
      target += 1;
    }
    return target;
  }

  int _maxExerciseCount(
    int duration,
    String level, {
    required String loadDirectionCode,
    required String? increaseMethodCode,
  }) {
    final standard = switch (duration) {
      <= 15 => 3,
      <= 30 => 4,
      <= 45 => 5,
      <= 60 => 6,
      <= 90 => 8,
      _ => 9,
    };
    final cap = switch (level) {
      'BEGINNER' => 5,
      'INTERMEDIATE' => duration <= 45 ? 5 : 7,
      _ => standard,
    };
    final base = math.min(standard, cap);
    if (loadDirectionCode == 'UP' && increaseMethodCode == 'EXERCISE') {
      return math.min(standard, base + 1);
    }
    return base;
  }

  ExerciseProgression _adjustProgression(
    ExerciseProgression progression,
    WeeklyStallDraft? stall,
  ) {
    if (stall?.adjustmentCode != 'CHANGE_REP_RANGE' ||
        progression.repLower == null ||
        progression.repUpper == null) {
      return progression;
    }
    return ExerciseProgression(
      targetModeCode: progression.targetModeCode,
      repLower: progression.repLower! + 2,
      repUpper: progression.repUpper! + 2,
      durationLowerSec: progression.durationLowerSec,
      durationUpperSec: progression.durationUpperSec,
      setLower: progression.setLower,
      setUpper: progression.setUpper,
      restSec: progression.restSec,
    );
  }

  int _adjustRestSeconds(
    int restSec, {
    required String loadDirectionCode,
    required String? increaseMethodCode,
    required int sleepScore,
  }) {
    if (loadDirectionCode == 'UP' &&
        increaseMethodCode == 'SHORTER_REST' &&
        sleepScore >= 3) {
      return math.max(30, (restSec * 0.9).round());
    }
    return restSec;
  }

  int _exerciseSeconds(GenerationExercise exercise, int sets) {
    final setup = exercise.isMajor ? 75 : 40;
    final work = exercise.isCompound ? 40 : 30;
    return setup + sets * work + math.max(0, sets - 1) * exercise.progression.restSec;
  }

  bool _technicalMatch(String difficulty, String level) {
    return switch (level) {
      'BEGINNER' => difficulty == 'LOW' || difficulty == 'MEDIUM',
      'INTERMEDIATE' => difficulty != 'VERY_HIGH',
      _ => true,
    };
  }

  bool _hasConsecutiveDays(List<WeeklyDayDraft> days) {
    for (var i = 1; i < days.length; i++) {
      if (days[i].planDate.difference(days[i - 1].planDate).inDays == 1) {
        return true;
      }
    }
    return false;
  }

  String _exerciseReason(_ScoredExercise scored, String part) {
    if (scored.reasonIds.contains('STALL_REDUCE_WEIGHT')) {
      return '停滞への対応として、種目は維持しつつ重量を下げる方針で採用しています。';
    }
    if (scored.reasonIds.contains('STALL_CHANGE_REP_RANGE')) {
      return '停滞への対応として、重量を追わず回数帯を変更する方針で採用しています。';
    }
    if (scored.reasonIds.contains('STALL_MAINTAIN')) {
      return '停滞を確認しつつ、今回は条件を変えずに継続するため採用しています。';
    }
    if (scored.reasonIds.contains('EX_HISTORY')) {
      return '前回記録があり、重量と回数の進歩を確認しやすいため採用しています。';
    }
    if (scored.reasonIds.contains('EX_PRIORITY')) {
      return '$partを今週の優先部位として反映するため採用しています。';
    }
    if (scored.reasonIds.contains('EX_TIME_EFFICIENT')) {
      return '限られた時間で複数の部位を鍛えられるため採用しています。';
    }
    return '$partを狙い、当日の器具で安全に実施できるため採用しています。';
  }

  String _dayReason({
    required _SessionTemplate template,
    required GenerationLocation location,
    required String? primaryPriority,
    required int sleepScore,
  }) {
    final parts = <String>[
      '${location.name}で実施できる${template.name}です。',
    ];
    if (primaryPriority != null && template.containsPart(primaryPriority)) {
      parts.add('優先部位を前半へ配置しています。');
    }
    if (sleepScore <= 2) {
      parts.add('睡眠状態を考慮して量を抑えています。');
    }
    return parts.join();
  }

  String _partLabel(Set<String> codes) {
    const labels = <String, String>{
      'CHEST': '胸',
      'BACK': '背中',
      'SHOULDERS': '肩',
      'ARMS': '腕',
      'LEGS': '脚',
      'GLUTES': 'お尻',
      'CORE': '腹筋・体幹',
    };
    return codes.map((String code) => labels[code] ?? code).join('・');
  }
}

final class _ComposedDay {
  const _ComposedDay({
    required this.day,
    required this.validationMessages,
  });

  final WeeklyDayPlan day;
  final List<String> validationMessages;
}

final class _ScoredExercise {
  const _ScoredExercise(this.exercise, this.score, this.reasonIds);

  final GenerationExercise exercise;
  final int score;
  final List<String> reasonIds;
}

final class _ScoredSplit {
  const _ScoredSplit(this.value, this.score);

  final _SplitTemplate value;
  final int score;
}

final class _ExerciseSlot {
  const _ExerciseSlot({
    required this.label,
    this.bodyPartCodes = const <String>{},
    this.movementGroupCodes = const <String>{},
  });

  final String label;
  final Set<String> bodyPartCodes;
  final Set<String> movementGroupCodes;
}

final class _SessionTemplate {
  const _SessionTemplate({
    required this.code,
    required this.name,
    required this.slots,
  });

  final String code;
  final String name;
  final List<_ExerciseSlot> slots;

  bool containsPart(String part) =>
      slots.any((_ExerciseSlot slot) => slot.bodyPartCodes.contains(part));
}

final class _SplitTemplate {
  const _SplitTemplate({
    required this.code,
    required this.name,
    required this.preferenceCode,
    required this.sessions,
    required this.levels,
    required this.complexity,
    required this.simple,
    required this.appRecommended,
  });

  final String code;
  final String name;
  final String preferenceCode;
  final List<_SessionTemplate> sessions;
  final Set<String> levels;
  final int complexity;
  final bool simple;
  final bool appRecommended;

  int priorityFrequency(String? part) {
    if (part == null) {
      return 0;
    }
    return sessions.where((_SessionTemplate value) => value.containsPart(part)).length;
  }
}

abstract final class _SplitCatalog {
  static const allLevels = <String>{'BEGINNER', 'INTERMEDIATE', 'ADVANCED'};
  static const experienced = <String>{'INTERMEDIATE', 'ADVANCED'};

  static List<_SplitTemplate> forDays(int days) => switch (days) {
        1 => <_SplitTemplate>[_fullBody1],
        2 => <_SplitTemplate>[_fullBody2, _upperLower2],
        3 => <_SplitTemplate>[_fullBody3, _upperLowerFull3, _ppl3],
        4 => <_SplitTemplate>[_upperLower4, _bodyPart4, _pplFull4],
        5 => <_SplitTemplate>[_upperLowerPpl5, _bodyPart5],
        _ => <_SplitTemplate>[_ppl6, _upperLower6],
      };

  static const push = _ExerciseSlot(
    label: 'プッシュ',
    movementGroupCodes: <String>{'PUSH'},
  );
  static const pull = _ExerciseSlot(
    label: 'プル',
    movementGroupCodes: <String>{'PULL'},
  );
  static const legs = _ExerciseSlot(
    label: '脚',
    movementGroupCodes: <String>{'LEGS'},
  );
  static const chest = _ExerciseSlot(
    label: '胸',
    bodyPartCodes: <String>{'CHEST'},
  );
  static const back = _ExerciseSlot(
    label: '背中',
    bodyPartCodes: <String>{'BACK'},
  );
  static const shoulders = _ExerciseSlot(
    label: '肩',
    bodyPartCodes: <String>{'SHOULDERS'},
  );
  static const arms = _ExerciseSlot(
    label: '腕',
    bodyPartCodes: <String>{'ARMS'},
  );
  static const glutes = _ExerciseSlot(
    label: 'お尻',
    bodyPartCodes: <String>{'GLUTES'},
  );
  static const core = _ExerciseSlot(
    label: '腹筋・体幹',
    bodyPartCodes: <String>{'CORE'},
  );

  static const fullA = _SessionTemplate(
    code: 'FULL_A',
    name: '全身A',
    slots: <_ExerciseSlot>[push, pull, legs, shoulders, core],
  );
  static const fullB = _SessionTemplate(
    code: 'FULL_B',
    name: '全身B',
    slots: <_ExerciseSlot>[legs, pull, push, glutes, arms],
  );
  static const fullC = _SessionTemplate(
    code: 'FULL_C',
    name: '全身C',
    slots: <_ExerciseSlot>[pull, legs, push, shoulders, core],
  );
  static const upperA = _SessionTemplate(
    code: 'UPPER_A',
    name: '上半身A',
    slots: <_ExerciseSlot>[chest, back, shoulders, arms, core],
  );
  static const upperB = _SessionTemplate(
    code: 'UPPER_B',
    name: '上半身B',
    slots: <_ExerciseSlot>[back, chest, shoulders, arms, core],
  );
  static const lowerA = _SessionTemplate(
    code: 'LOWER_A',
    name: '下半身A',
    slots: <_ExerciseSlot>[legs, glutes, legs, core],
  );
  static const lowerB = _SessionTemplate(
    code: 'LOWER_B',
    name: '下半身B',
    slots: <_ExerciseSlot>[glutes, legs, legs, core],
  );
  static const pushDay = _SessionTemplate(
    code: 'PUSH',
    name: 'プッシュ',
    slots: <_ExerciseSlot>[chest, shoulders, push, arms, core],
  );
  static const pullDay = _SessionTemplate(
    code: 'PULL',
    name: 'プル',
    slots: <_ExerciseSlot>[back, pull, shoulders, arms, core],
  );
  static const legDay = _SessionTemplate(
    code: 'LEGS',
    name: '脚',
    slots: <_ExerciseSlot>[legs, glutes, legs, core],
  );
  static const chestArms = _SessionTemplate(
    code: 'CHEST_ARMS',
    name: '胸・三頭',
    slots: <_ExerciseSlot>[chest, chest, shoulders, arms, core],
  );
  static const backArms = _SessionTemplate(
    code: 'BACK_ARMS',
    name: '背中・二頭',
    slots: <_ExerciseSlot>[back, back, shoulders, arms, core],
  );
  static const shoulderArms = _SessionTemplate(
    code: 'SHOULDER_ARMS',
    name: '肩・腕',
    slots: <_ExerciseSlot>[shoulders, shoulders, arms, arms, core],
  );

  static const _fullBody1 = _SplitTemplate(
    code: 'FULL_BODY_1',
    name: '全身1日',
    preferenceCode: 'APP',
    sessions: <_SessionTemplate>[fullA],
    levels: allLevels,
    complexity: 1,
    simple: true,
    appRecommended: true,
  );
  static const _fullBody2 = _SplitTemplate(
    code: 'FULL_BODY_AB',
    name: '全身A／B',
    preferenceCode: 'APP',
    sessions: <_SessionTemplate>[fullA, fullB],
    levels: allLevels,
    complexity: 1,
    simple: true,
    appRecommended: true,
  );
  static const _upperLower2 = _SplitTemplate(
    code: 'UPPER_LOWER_2',
    name: '上半身／下半身',
    preferenceCode: 'BODY_PART',
    sessions: <_SessionTemplate>[upperA, lowerA],
    levels: allLevels,
    complexity: 2,
    simple: true,
    appRecommended: false,
  );
  static const _fullBody3 = _SplitTemplate(
    code: 'FULL_BODY_ABC',
    name: '全身A／B／C',
    preferenceCode: 'APP',
    sessions: <_SessionTemplate>[fullA, fullB, fullC],
    levels: allLevels,
    complexity: 1,
    simple: true,
    appRecommended: true,
  );
  static const _upperLowerFull3 = _SplitTemplate(
    code: 'UPPER_LOWER_FULL_3',
    name: '上半身／下半身／全身',
    preferenceCode: 'BODY_PART',
    sessions: <_SessionTemplate>[upperA, lowerA, fullB],
    levels: experienced,
    complexity: 2,
    simple: true,
    appRecommended: true,
  );
  static const _ppl3 = _SplitTemplate(
    code: 'PPL_3',
    name: 'プッシュ／プル／脚',
    preferenceCode: 'MOVEMENT',
    sessions: <_SessionTemplate>[pushDay, pullDay, legDay],
    levels: experienced,
    complexity: 3,
    simple: false,
    appRecommended: false,
  );
  static const _upperLower4 = _SplitTemplate(
    code: 'UPPER_LOWER_4',
    name: '上半身A／下半身A／上半身B／下半身B',
    preferenceCode: 'APP',
    sessions: <_SessionTemplate>[upperA, lowerA, upperB, lowerB],
    levels: allLevels,
    complexity: 2,
    simple: true,
    appRecommended: true,
  );
  static const _bodyPart4 = _SplitTemplate(
    code: 'BODY_PART_4',
    name: '胸・三頭／背中・二頭／脚／肩・腕',
    preferenceCode: 'BODY_PART',
    sessions: <_SessionTemplate>[chestArms, backArms, legDay, shoulderArms],
    levels: experienced,
    complexity: 3,
    simple: false,
    appRecommended: false,
  );
  static const _pplFull4 = _SplitTemplate(
    code: 'PPL_FULL_4',
    name: 'プッシュ／プル／脚／全身',
    preferenceCode: 'MOVEMENT',
    sessions: <_SessionTemplate>[pushDay, pullDay, legDay, fullA],
    levels: experienced,
    complexity: 3,
    simple: false,
    appRecommended: false,
  );
  static const _upperLowerPpl5 = _SplitTemplate(
    code: 'UPPER_LOWER_PPL_5',
    name: '上半身／下半身／プッシュ／プル／下半身',
    preferenceCode: 'APP',
    sessions: <_SessionTemplate>[upperA, lowerA, pushDay, pullDay, lowerB],
    levels: experienced,
    complexity: 3,
    simple: false,
    appRecommended: true,
  );
  static const _bodyPart5 = _SplitTemplate(
    code: 'BODY_PART_5',
    name: '胸／背中／肩／腕／脚',
    preferenceCode: 'BODY_PART',
    sessions: <_SessionTemplate>[chestArms, backArms, shoulderArms, fullA, legDay],
    levels: experienced,
    complexity: 4,
    simple: false,
    appRecommended: false,
  );
  static const _ppl6 = _SplitTemplate(
    code: 'PPL_X2',
    name: 'プッシュA／プルA／脚A／プッシュB／プルB／脚B',
    preferenceCode: 'MOVEMENT',
    sessions: <_SessionTemplate>[pushDay, pullDay, legDay, pushDay, pullDay, legDay],
    levels: experienced,
    complexity: 4,
    simple: false,
    appRecommended: true,
  );
  static const _upperLower6 = _SplitTemplate(
    code: 'UPPER_LOWER_X3',
    name: '上半身／下半身 × 3',
    preferenceCode: 'BODY_PART',
    sessions: <_SessionTemplate>[upperA, lowerA, upperB, lowerB, upperA, lowerA],
    levels: experienced,
    complexity: 3,
    simple: false,
    appRecommended: false,
  );
}

String _dateOnly(DateTime value) =>
    DateTime(value.year, value.month, value.day).toIso8601String().substring(0, 10);
