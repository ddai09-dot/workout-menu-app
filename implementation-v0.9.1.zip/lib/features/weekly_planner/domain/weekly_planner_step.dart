enum WeeklyPlannerStep {
  start,
  schedule,
  condition,
  previousWeek,
  adjustment,
  review,
}

extension WeeklyPlannerStepX on WeeklyPlannerStep {
  String get code => switch (this) {
        WeeklyPlannerStep.start => 'START',
        WeeklyPlannerStep.schedule => 'SCHEDULE',
        WeeklyPlannerStep.condition => 'CONDITION',
        WeeklyPlannerStep.previousWeek => 'PREVIOUS_WEEK',
        WeeklyPlannerStep.adjustment => 'ADJUSTMENT',
        WeeklyPlannerStep.review => 'REVIEW',
      };

  String get title => switch (this) {
        WeeklyPlannerStep.start => '今週のメニュー',
        WeeklyPlannerStep.schedule => '今週の予定',
        WeeklyPlannerStep.condition => '現在の状態',
        WeeklyPlannerStep.previousWeek => '前週の振り返り',
        WeeklyPlannerStep.adjustment => '今週の調整方針',
        WeeklyPlannerStep.review => 'メニューを確認',
      };

  int get progressIndex => switch (this) {
        WeeklyPlannerStep.start => 0,
        WeeklyPlannerStep.schedule => 1,
        WeeklyPlannerStep.condition => 2,
        WeeklyPlannerStep.previousWeek => 3,
        WeeklyPlannerStep.adjustment => 4,
        WeeklyPlannerStep.review => 5,
      };

  static WeeklyPlannerStep fromCode(String code) {
    return WeeklyPlannerStep.values.firstWhere(
      (WeeklyPlannerStep value) => value.code == code,
      orElse: () => WeeklyPlannerStep.start,
    );
  }
}
