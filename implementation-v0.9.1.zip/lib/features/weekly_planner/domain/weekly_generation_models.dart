import 'package:workout_menu_app/features/weekly_planner/domain/weekly_menu_plan.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_draft.dart';

final class WeeklyGenerationInput {
  const WeeklyGenerationInput({
    required this.draft,
    required this.primaryGoalCode,
    required this.experienceLevelCode,
    required this.startVolumeFactor,
    required this.desiredDaysPerWeek,
    required this.defaultSplitPreferenceCode,
    required this.abGoalCode,
    required this.defaultPrimaryPriorityCode,
    required this.defaultSecondaryPriorityCodes,
    required this.locations,
    required this.restrictions,
    required this.exercises,
    required this.previousExerciseIds,
    required this.lockedDays,
  });

  final WeeklyPlannerDraft draft;
  final String primaryGoalCode;
  final String experienceLevelCode;
  final double startVolumeFactor;
  final int desiredDaysPerWeek;
  final String defaultSplitPreferenceCode;
  final String abGoalCode;
  final String? defaultPrimaryPriorityCode;
  final Set<String> defaultSecondaryPriorityCodes;
  final Map<String, GenerationLocation> locations;
  final GenerationRestrictions restrictions;
  final List<GenerationExercise> exercises;
  final Set<String> previousExerciseIds;
  final List<WeeklyDayPlan> lockedDays;

  String get effectiveSplitPreferenceCode =>
      draft.splitOverrideCode ?? defaultSplitPreferenceCode;

  String? get effectivePrimaryPriorityCode => switch (draft.priorityModeCode) {
        'BALANCED' => null,
        'CUSTOM' => draft.primaryPriorityCode,
        _ => defaultPrimaryPriorityCode,
      };

  Set<String> get effectiveSecondaryPriorityCodes =>
      draft.priorityModeCode == 'CUSTOM'
          ? draft.secondaryPriorityCodes
          : draft.priorityModeCode == 'BALANCED'
              ? const <String>{}
              : defaultSecondaryPriorityCodes;
}

final class GenerationLocation {
  const GenerationLocation({
    required this.id,
    required this.name,
    required this.typeCode,
    required this.gymProfileCode,
    required this.equipmentCodes,
  });

  final String id;
  final String name;
  final String typeCode;
  final String? gymProfileCode;
  final Set<String> equipmentCodes;

  bool hasEquipment(String code) {
    if (code == 'NONE') {
      return true;
    }
    if (equipmentCodes.contains(code)) {
      return true;
    }
    if (equipmentCodes.contains('BENCH') &&
        <String>{'FLAT_BENCH', 'ADJUSTABLE_BENCH', 'STEP_PLATFORM'}
            .contains(code)) {
      return true;
    }
    if (equipmentCodes.contains('ADJUSTABLE_BENCH') &&
        <String>{'BENCH', 'FLAT_BENCH', 'STEP_PLATFORM'}.contains(code)) {
      return true;
    }
    if (equipmentCodes.contains('FLAT_BENCH') && code == 'BENCH') {
      return true;
    }
    if (equipmentCodes.contains('CABLE_MACHINE') &&
        <String>{'ROPE_ATTACHMENT', 'STRAIGHT_BAR_ATTACHMENT', 'ANKLE_STRAP'}
            .contains(code)) {
      return true;
    }
    if (equipmentCodes.contains('RACK') && code == 'SAFETY') {
      return true;
    }
    return false;
  }
}

final class GenerationRestrictions {
  const GenerationRestrictions({
    this.bodyPartCodes = const <String>{},
    this.jointCodes = const <String>{},
    this.movementGroupCodes = const <String>{},
    this.exerciseIds = const <String>{},
  });

  final Set<String> bodyPartCodes;
  final Set<String> jointCodes;
  final Set<String> movementGroupCodes;
  final Set<String> exerciseIds;
}

final class EquipmentRequirementOption {
  const EquipmentRequirementOption({
    required this.code,
    required this.requirements,
  });

  final String code;
  final Map<String, int> requirements;

  bool isSatisfiedBy(GenerationLocation location) {
    return requirements.entries.every(
      (MapEntry<String, int> requirement) =>
          location.hasEquipment(requirement.key),
    );
  }
}

final class ExerciseProgression {
  const ExerciseProgression({
    required this.targetModeCode,
    required this.setLower,
    required this.setUpper,
    required this.restSec,
    this.repLower,
    this.repUpper,
    this.durationLowerSec,
    this.durationUpperSec,
  });

  final String targetModeCode;
  final int? repLower;
  final int? repUpper;
  final int? durationLowerSec;
  final int? durationUpperSec;
  final int setLower;
  final int setUpper;
  final int restSec;

  Map<String, Object?> toJson() => <String, Object?>{
        'targetModeCode': targetModeCode,
        'repLower': repLower,
        'repUpper': repUpper,
        'durationLowerSec': durationLowerSec,
        'durationUpperSec': durationUpperSec,
        'setLower': setLower,
        'setUpper': setUpper,
        'restSec': restSec,
      };
}

final class GenerationExercise {
  const GenerationExercise({
    required this.id,
    required this.code,
    required this.name,
    required this.roleCode,
    required this.exerciseClassCode,
    required this.technicalDifficultyCode,
    required this.recordingMethodCode,
    required this.availabilityByLevel,
    required this.defaultPriorityCode,
    required this.primaryBodyPartCodes,
    required this.secondaryBodyPartCodes,
    required this.movementGroupCodes,
    required this.jointCodes,
    required this.equipmentOptions,
    required this.progression,
  });

  final String id;
  final String code;
  final String name;
  final String roleCode;
  final String exerciseClassCode;
  final String technicalDifficultyCode;
  final String recordingMethodCode;
  final Map<String, String> availabilityByLevel;
  final String defaultPriorityCode;
  final Set<String> primaryBodyPartCodes;
  final Set<String> secondaryBodyPartCodes;
  final Set<String> movementGroupCodes;
  final Set<String> jointCodes;
  final List<EquipmentRequirementOption> equipmentOptions;
  final ExerciseProgression progression;

  bool isAvailableForLevel(String levelCode) {
    final value = availabilityByLevel[levelCode] ?? 'UNAVAILABLE';
    return value == 'AVAILABLE' || value == 'CONDITIONAL';
  }

  bool canUseAt(GenerationLocation location) {
    if (equipmentOptions.isEmpty) {
      return true;
    }
    return equipmentOptions.any(
      (EquipmentRequirementOption option) => option.isSatisfiedBy(location),
    );
  }

  bool get isMajor => roleCode.startsWith('MAJOR');
  bool get isCompound => exerciseClassCode.startsWith('COMPOUND');
}
