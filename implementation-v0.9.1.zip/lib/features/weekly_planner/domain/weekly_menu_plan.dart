final class WeeklyMenuPlan {
  const WeeklyMenuPlan({
    required this.id,
    required this.weekStartDate,
    required this.weekEndDate,
    required this.splitCode,
    required this.splitName,
    required this.statusCode,
    required this.estimatedTotalMin,
    required this.summaryReasons,
    required this.days,
    required this.validationMessages,
    this.isRestWeek = false,
    this.generationTrace = const <String, Object?>{},
  });

  final String id;
  final DateTime weekStartDate;
  final DateTime weekEndDate;
  final String? splitCode;
  final String splitName;
  final String statusCode;
  final int estimatedTotalMin;
  final List<String> summaryReasons;
  final List<WeeklyDayPlan> days;
  final List<String> validationMessages;
  final bool isRestWeek;
  final Map<String, Object?> generationTrace;

  int get exerciseCount => days.fold<int>(
        0,
        (int total, WeeklyDayPlan day) => total + day.exercises.length,
      );
}

final class WeeklyDayPlan {
  const WeeklyDayPlan({
    required this.id,
    required this.planDate,
    required this.weekdayCode,
    required this.locationId,
    required this.locationName,
    required this.durationMin,
    required this.estimatedDurationMin,
    required this.focus,
    required this.reason,
    required this.exercises,
    this.statusCode = 'PLANNED',
    this.isLocked = false,
  });

  final String id;
  final DateTime planDate;
  final String weekdayCode;
  final String? locationId;
  final String locationName;
  final int durationMin;
  final int estimatedDurationMin;
  final String focus;
  final String reason;
  final List<PlannedExercisePlan> exercises;
  final String statusCode;
  final bool isLocked;

  int get workSetCount => exercises.fold<int>(
        0,
        (int total, PlannedExercisePlan exercise) =>
            total + exercise.sets.where((PlannedSetPlan set) => !set.isWarmup).length,
      );
}

final class PlannedExercisePlan {
  const PlannedExercisePlan({
    required this.id,
    required this.exerciseId,
    required this.exerciseCode,
    required this.exerciseName,
    required this.orderIndex,
    required this.roleCode,
    required this.recordingMethodCode,
    required this.targetPart,
    required this.reason,
    required this.selectionScore,
    required this.reasonIds,
    required this.progressionSnapshot,
    required this.sets,
  });

  final String id;
  final String exerciseId;
  final String exerciseCode;
  final String exerciseName;
  final int orderIndex;
  final String roleCode;
  final String recordingMethodCode;
  final String targetPart;
  final String reason;
  final int selectionScore;
  final List<String> reasonIds;
  final Map<String, Object?> progressionSnapshot;
  final List<PlannedSetPlan> sets;
}

final class PlannedSetPlan {
  const PlannedSetPlan({
    required this.id,
    required this.setNumber,
    required this.isWarmup,
    required this.restSec,
    this.targetWeightKg,
    this.inputWeightValue,
    this.inputWeightUnitCode,
    this.targetRepsLower,
    this.targetRepsUpper,
    this.targetDurationSec,
    this.targetAssistanceValue,
  });

  final String id;
  final int setNumber;
  final bool isWarmup;
  final int restSec;
  final double? targetWeightKg;
  final double? inputWeightValue;
  final String? inputWeightUnitCode;
  final int? targetRepsLower;
  final int? targetRepsUpper;
  final int? targetDurationSec;
  final double? targetAssistanceValue;
}

final class PreviousExerciseChoice {
  const PreviousExerciseChoice({
    required this.id,
    required this.code,
    required this.name,
    this.detectedAsStalled = false,
    this.recommendedAdjustmentCode,
  });

  final String id;
  final String code;
  final String name;
  final bool detectedAsStalled;
  final String? recommendedAdjustmentCode;
}

final class PlannerLocationChoice {
  const PlannerLocationChoice({
    required this.id,
    required this.name,
    required this.typeCode,
  });

  final String id;
  final String name;
  final String typeCode;
}
