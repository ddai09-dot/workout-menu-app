import 'package:workout_menu_app/features/weekly_planner/domain/weekly_menu_plan.dart';
import 'package:workout_menu_app/features/weekly_planner/domain/weekly_planner_draft.dart';

abstract interface class WeeklyPlannerRepository {
  Future<WeeklyPlannerDraft> loadOrCreateCurrentWeekDraft();

  Future<void> saveDraft(WeeklyPlannerDraft draft);

  Future<WeeklyPlannerDraft> resetDraft(WeeklyPlannerDraft draft);

  Future<List<PlannerLocationChoice>> loadLocations();

  Future<List<PreviousExerciseChoice>> loadPreviousExerciseChoices(
    DateTime weekStartDate,
  );

  Future<WeeklyMenuPlan?> loadActivePlan(DateTime weekStartDate);

  Future<WeeklyMenuPlan> generateAndSave(WeeklyPlannerDraft draft);

  Future<void> finalizePlan(WeeklyPlannerDraft draft, WeeklyMenuPlan plan);

  Future<WeeklyMenuPlan> createRestWeek(WeeklyPlannerDraft draft);
}
