import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_image_resolver.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_models.dart';

final class AssetBundleExerciseFormImageResolver
    implements ExerciseFormImageResolver {
  AssetBundleExerciseFormImageResolver(this._bundle);

  final AssetBundle _bundle;
  final Map<String, Uint8List> _successCache = <String, Uint8List>{};
  final Map<String, Future<ExerciseFormImageResolution>> _inFlight =
      <String, Future<ExerciseFormImageResolution>>{};

  static const Set<String> _displayableStatuses = <String>{
    'READY',
    'PUBLISHED',
  };

  @override
  Future<ExerciseFormImageResolution> resolve(
    ExerciseFormImageMetadata metadata,
  ) {
    final status = metadata.assetStatus?.trim().toUpperCase() ?? '';
    if (!_displayableStatuses.contains(status)) {
      return Future.value(
        const ExerciseFormImageResolution(
          availability: ExerciseFormImageAvailability.notReady,
        ),
      );
    }

    final uri = metadata.assetUri?.trim() ?? '';
    if (!uri.startsWith('assets/images/exercises/') || uri.contains('..')) {
      return Future.value(
        const ExerciseFormImageResolution(
          availability: ExerciseFormImageAvailability.invalidUri,
        ),
      );
    }

    final checksum = metadata.checksum?.trim().toLowerCase() ?? '';
    if (checksum.isEmpty || checksum == 'pending') {
      return Future.value(
        const ExerciseFormImageResolution(
          availability: ExerciseFormImageAvailability.checksumPending,
        ),
      );
    }
    if (!RegExp(r'^[0-9a-f]{64}$').hasMatch(checksum)) {
      return Future.value(
        const ExerciseFormImageResolution(
          availability: ExerciseFormImageAvailability.checksumMismatch,
        ),
      );
    }

    final cacheKey = '$uri|$checksum';
    final cached = _successCache[cacheKey];
    if (cached != null) {
      return Future.value(
        ExerciseFormImageResolution(
          availability: ExerciseFormImageAvailability.available,
          bytes: cached,
        ),
      );
    }
    return _inFlight.putIfAbsent(cacheKey, () => _load(uri, checksum, cacheKey));
  }

  Future<ExerciseFormImageResolution> _load(
    String uri,
    String checksum,
    String cacheKey,
  ) async {
    try {
      final data = await _bundle.load(uri);
      final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
      if (sha256.convert(bytes).toString() != checksum) {
        return const ExerciseFormImageResolution(
          availability: ExerciseFormImageAvailability.checksumMismatch,
        );
      }
      final immutableBytes = Uint8List.fromList(bytes);
      _successCache[cacheKey] = immutableBytes;
      return ExerciseFormImageResolution(
        availability: ExerciseFormImageAvailability.available,
        bytes: immutableBytes,
      );
    } catch (_) {
      return const ExerciseFormImageResolution(
        availability: ExerciseFormImageAvailability.missingAsset,
      );
    } finally {
      _inFlight.remove(cacheKey);
    }
  }

  @override
  void invalidate({String? assetUri}) {
    if (assetUri == null) {
      _successCache.clear();
      _inFlight.clear();
      return;
    }
    _successCache.removeWhere((key, value) => key.startsWith('$assetUri|'));
    _inFlight.removeWhere((key, value) => key.startsWith('$assetUri|'));
  }
}
