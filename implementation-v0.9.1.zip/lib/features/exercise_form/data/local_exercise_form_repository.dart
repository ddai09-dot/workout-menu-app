import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_models.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_repository.dart';

final class LocalExerciseFormRepository implements ExerciseFormRepository {
  const LocalExerciseFormRepository(this._database);

  final AppDatabase _database;

  @override
  Future<ExerciseFormContent?> loadByExerciseId(String exerciseId) async {
    final rows = await _database.customSelect(
      '''
      SELECT
        em.id AS exercise_id,
        em.name_ja AS exercise_name,
        efc.content_version AS copy_content_version,
        efc.image_1_label,
        efc.image_2_label,
        efc.movement_tip,
        efc.caution_text,
        efa.asset_position,
        efa.asset_uri,
        efa.checksum,
        efa.asset_status,
        efa.content_version AS asset_content_version
      FROM exercise_master em
      JOIN exercise_form_copy efc
        ON efc.exercise_id = em.id
       AND efc.is_active = 1
      LEFT JOIN exercise_form_asset efa
        ON efa.exercise_id = em.id
       AND efa.is_active = 1
      WHERE em.id = ?
        AND em.is_active = 1
      ORDER BY efa.asset_position ASC
      ''',
      variables: <Variable<Object>>[Variable.withString(exerciseId)],
    ).get();

    if (rows.isEmpty) return null;
    final first = rows.first;
    final labels = <int, String>{
      1: first.read<String>('image_1_label'),
      2: first.read<String>('image_2_label'),
    };
    final assetsByPosition = <int, QueryRow>{};
    for (final row in rows) {
      final position = row.readNullable<int>('asset_position');
      if (position == 1 || position == 2) {
        assetsByPosition[position!] = row;
      }
    }

    final images = <ExerciseFormImageMetadata>[
      for (final position in const <int>[1, 2])
        ExerciseFormImageMetadata(
          position: position,
          label: labels[position]!,
          assetUri: assetsByPosition[position]?.readNullable<String>('asset_uri'),
          checksum: assetsByPosition[position]?.readNullable<String>('checksum'),
          assetStatus: assetsByPosition[position]?.readNullable<String>('asset_status'),
          contentVersion:
              assetsByPosition[position]?.readNullable<int>('asset_content_version'),
        ),
    ];

    return ExerciseFormContent(
      exerciseId: first.read<String>('exercise_id'),
      exerciseName: first.read<String>('exercise_name'),
      movementTip: first.read<String>('movement_tip'),
      cautionText: first.read<String>('caution_text'),
      images: images,
      contentVersion: first.read<int>('copy_content_version'),
    );
  }
}
