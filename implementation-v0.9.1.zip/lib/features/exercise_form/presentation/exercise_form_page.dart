import 'package:flutter/material.dart';
import 'package:workout_menu_app/features/exercise_form/presentation/exercise_form_section.dart';

final class ExerciseFormPage extends StatelessWidget {
  const ExerciseFormPage({required this.exerciseId, super.key});

  final String exerciseId;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('フォームを確認')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
          children: <Widget>[
            ExerciseFormSection(exerciseId: exerciseId),
          ],
        ),
      ),
    );
  }
}
