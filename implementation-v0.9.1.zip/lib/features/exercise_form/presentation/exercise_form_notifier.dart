import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/database/providers/database_providers.dart';
import 'package:workout_menu_app/features/exercise_form/data/asset_bundle_exercise_form_image_resolver.dart';
import 'package:workout_menu_app/features/exercise_form/data/local_exercise_form_repository.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_image_resolver.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_models.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_repository.dart';
import 'package:workout_menu_app/features/exercise_form/domain/load_exercise_form_use_case.dart';

final exerciseFormRepositoryProvider = Provider<ExerciseFormRepository>((ref) {
  return LocalExerciseFormRepository(ref.watch(appDatabaseProvider));
});

final exerciseFormImageResolverProvider = Provider<ExerciseFormImageResolver>((ref) {
  return AssetBundleExerciseFormImageResolver(rootBundle);
});

final loadExerciseFormUseCaseProvider = Provider<LoadExerciseFormUseCase>((ref) {
  return LoadExerciseFormUseCase(
    ref.watch(exerciseFormRepositoryProvider),
    ref.watch(exerciseFormImageResolverProvider),
  );
});

final exerciseFormProvider =
    FutureProvider.family<ExerciseFormDisplay?, String>((ref, exerciseId) {
  return ref.watch(loadExerciseFormUseCaseProvider)(exerciseId);
});
