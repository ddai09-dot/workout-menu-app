import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_models.dart';
import 'package:workout_menu_app/features/exercise_form/presentation/exercise_form_notifier.dart';

final class ExerciseFormSection extends ConsumerWidget {
  const ExerciseFormSection({
    required this.exerciseId,
    this.showTitle = true,
    super.key,
  });

  final String exerciseId;
  final bool showTitle;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(exerciseFormProvider(exerciseId));
    return state.when(
      loading: () => const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: CircularProgressIndicator(),
        ),
      ),
      error: (error, stackTrace) => _LoadFailure(
        onRetry: () => _retry(ref),
      ),
      data: (form) {
        if (form == null) {
          return _EmptyForm(onRetry: () => _retry(ref));
        }
        return _FormContent(form: form, showTitle: showTitle);
      },
    );
  }

  void _retry(WidgetRef ref) {
    ref.read(loadExerciseFormUseCaseProvider).retryImages();
    ref.invalidate(exerciseFormProvider(exerciseId));
  }
}

final class _FormContent extends StatelessWidget {
  const _FormContent({required this.form, required this.showTitle});

  final ExerciseFormDisplay form;
  final bool showTitle;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        if (showTitle) ...<Widget>[
          Text(form.exerciseName, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 16),
        ],
        for (final image in form.images) ...<Widget>[
          _ImageSlot(image: image),
          const SizedBox(height: 12),
        ],
        _ExplanationCard(
          icon: Icons.directions_run_outlined,
          title: '動作のポイント',
          text: form.movementTip,
        ),
        const SizedBox(height: 12),
        _ExplanationCard(
          icon: Icons.health_and_safety_outlined,
          title: '注意点',
          text: form.cautionText,
        ),
      ],
    );
  }
}

final class _ImageSlot extends StatelessWidget {
  const _ImageSlot({required this.image});

  final ExerciseFormImageDisplay image;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: '位置${image.position} ${image.label}',
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
              child: Text(
                '位置${image.position}　${image.label}',
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ),
            AspectRatio(
              aspectRatio: 4 / 3,
              child: image.canDisplayImage
                  ? Image.memory(
                      image.bytes!,
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) =>
                          const _ImagePlaceholder(),
                    )
                  : const _ImagePlaceholder(),
            ),
          ],
        ),
      ),
    );
  }
}

final class _ImagePlaceholder extends StatelessWidget {
  const _ImagePlaceholder();

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return ColoredBox(
      color: colors.surfaceContainerHighest,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Icon(Icons.image_not_supported_outlined, color: colors.onSurfaceVariant),
              const SizedBox(height: 8),
              Text(
                '画像は準備中です',
                textAlign: TextAlign.center,
                style: TextStyle(color: colors.onSurfaceVariant),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

final class _ExplanationCard extends StatelessWidget {
  const _ExplanationCard({
    required this.icon,
    required this.title,
    required this.text,
  });

  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Icon(icon),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(title, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 6),
                  Text(text),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

final class _LoadFailure extends StatelessWidget {
  const _LoadFailure({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Text('フォーム説明を読み込めませんでした。'),
            const SizedBox(height: 12),
            FilledButton(onPressed: onRetry, child: const Text('もう一度試す')),
          ],
        ),
      ),
    );
  }
}

final class _EmptyForm extends StatelessWidget {
  const _EmptyForm({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Text('この種目のフォーム説明が見つかりません。'),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: onRetry, child: const Text('再読み込み')),
          ],
        ),
      ),
    );
  }
}
