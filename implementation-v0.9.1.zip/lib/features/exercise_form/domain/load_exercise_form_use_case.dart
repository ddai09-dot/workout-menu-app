import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_image_resolver.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_models.dart';
import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_repository.dart';

final class LoadExerciseFormUseCase {
  const LoadExerciseFormUseCase(this._repository, this._imageResolver);

  final ExerciseFormRepository _repository;
  final ExerciseFormImageResolver _imageResolver;

  Future<ExerciseFormDisplay?> call(String exerciseId) async {
    final content = await _repository.loadByExerciseId(exerciseId);
    if (content == null) return null;

    final images = await Future.wait(
      content.images.map((metadata) async {
        final result = await _imageResolver.resolve(metadata);
        return ExerciseFormImageDisplay(
          position: metadata.position,
          label: metadata.label,
          assetUri: metadata.assetUri,
          bytes: result.bytes,
          availability: result.availability,
        );
      }),
    );

    images.sort((a, b) => a.position.compareTo(b.position));
    return ExerciseFormDisplay(
      exerciseId: content.exerciseId,
      exerciseName: content.exerciseName,
      movementTip: content.movementTip,
      cautionText: content.cautionText,
      images: images,
      contentVersion: content.contentVersion,
    );
  }

  void retryImages() => _imageResolver.invalidate();
}
