import 'dart:typed_data';

import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_models.dart';

final class ExerciseFormImageResolution {
  const ExerciseFormImageResolution({required this.availability, this.bytes});

  final ExerciseFormImageAvailability availability;
  final Uint8List? bytes;
}

abstract interface class ExerciseFormImageResolver {
  Future<ExerciseFormImageResolution> resolve(ExerciseFormImageMetadata metadata);

  void invalidate({String? assetUri});
}
