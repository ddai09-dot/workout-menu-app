import 'package:workout_menu_app/features/exercise_form/domain/exercise_form_models.dart';

abstract interface class ExerciseFormRepository {
  Future<ExerciseFormContent?> loadByExerciseId(String exerciseId);
}
