import 'dart:typed_data';

enum ExerciseFormImageAvailability {
  available,
  notReady,
  invalidUri,
  checksumPending,
  checksumMismatch,
  missingAsset,
  unsupportedSource,
}

final class ExerciseFormImageMetadata {
  const ExerciseFormImageMetadata({
    required this.position,
    required this.label,
    required this.assetUri,
    required this.checksum,
    required this.assetStatus,
    required this.contentVersion,
  });

  final int position;
  final String label;
  final String? assetUri;
  final String? checksum;
  final String? assetStatus;
  final int? contentVersion;
}

final class ExerciseFormContent {
  const ExerciseFormContent({
    required this.exerciseId,
    required this.exerciseName,
    required this.movementTip,
    required this.cautionText,
    required this.images,
    required this.contentVersion,
  });

  final String exerciseId;
  final String exerciseName;
  final String movementTip;
  final String cautionText;
  final List<ExerciseFormImageMetadata> images;
  final int contentVersion;
}

final class ExerciseFormImageDisplay {
  const ExerciseFormImageDisplay({
    required this.position,
    required this.label,
    required this.availability,
    this.assetUri,
    this.bytes,
  });

  final int position;
  final String label;
  final String? assetUri;
  final Uint8List? bytes;
  final ExerciseFormImageAvailability availability;

  bool get canDisplayImage =>
      availability == ExerciseFormImageAvailability.available && bytes != null;
}

final class ExerciseFormDisplay {
  const ExerciseFormDisplay({
    required this.exerciseId,
    required this.exerciseName,
    required this.movementTip,
    required this.cautionText,
    required this.images,
    required this.contentVersion,
  });

  final String exerciseId;
  final String exerciseName;
  final String movementTip;
  final String cautionText;
  final List<ExerciseFormImageDisplay> images;
  final int contentVersion;

  Map<String, Object> toAiContext() => <String, Object>{
        'exerciseId': exerciseId,
        'exerciseName': exerciseName,
        'positionLabels': images.map((value) => value.label).toList(growable: false),
        'movementTip': movementTip,
        'cautionText': cautionText,
      };
}
