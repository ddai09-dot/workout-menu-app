import 'notification_models.dart';

abstract interface class NotificationRepository {
  Future<ReminderSettingsState> load();

  Future<bool> requestPermission();

  Future<void> save(ReminderPreference preference);

  Future<void> rescheduleAll();

  Future<void> cancelAll();
}

abstract interface class LocalNotificationGateway {
  Future<bool> isPermissionGranted();

  Future<bool> requestPermission();

  Future<void> schedule({
    required int id,
    required DateTime scheduledAt,
    required String title,
    required String body,
    String? routePath,
  });

  Future<void> cancel(int id);

  Future<void> cancelAll();
}
