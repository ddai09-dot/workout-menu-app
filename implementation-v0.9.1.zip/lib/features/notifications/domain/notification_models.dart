enum ReminderType {
  workoutPlan('WORKOUT_PLAN'),
  weeklyPlanning('WEEKLY_PLANNING'),
  inactivity('INACTIVITY'),
  restTimer('REST_TIMER');

  const ReminderType(this.code);

  final String code;

  static ReminderType fromCode(String code) {
    return ReminderType.values.firstWhere(
      (ReminderType value) => value.code == code,
      orElse: () => throw StateError('Unknown notification type: $code'),
    );
  }
}

final class ReminderPreference {
  const ReminderPreference({
    required this.type,
    required this.enabled,
    this.localTime,
    this.weekdayMask,
    this.advanceMinutes = 0,
    this.soundEnabled = true,
    this.vibrationEnabled = true,
    this.timezone = 'Asia/Tokyo',
  });

  final ReminderType type;
  final bool enabled;
  final String? localTime;
  final int? weekdayMask;
  final int advanceMinutes;
  final bool soundEnabled;
  final bool vibrationEnabled;
  final String timezone;

  ReminderPreference copyWith({
    bool? enabled,
    String? localTime,
    int? weekdayMask,
    int? advanceMinutes,
    bool? soundEnabled,
    bool? vibrationEnabled,
    String? timezone,
  }) {
    return ReminderPreference(
      type: type,
      enabled: enabled ?? this.enabled,
      localTime: localTime ?? this.localTime,
      weekdayMask: weekdayMask ?? this.weekdayMask,
      advanceMinutes: advanceMinutes ?? this.advanceMinutes,
      soundEnabled: soundEnabled ?? this.soundEnabled,
      vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
      timezone: timezone ?? this.timezone,
    );
  }
}

final class ReminderSettingsState {
  const ReminderSettingsState({
    required this.permissionGranted,
    required this.preferences,
  });

  final bool permissionGranted;
  final List<ReminderPreference> preferences;
}
