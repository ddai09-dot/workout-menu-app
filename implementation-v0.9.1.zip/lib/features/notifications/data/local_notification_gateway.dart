import 'package:workout_menu_app/features/notifications/domain/notification_repository.dart';

/// Native adapter boundary.
///
/// This remains a truthful stub until an Xcode-capable environment wires an
/// iOS local-notification plugin and verifies permission and scheduling.
final class LocalNotificationGatewayStub implements LocalNotificationGateway {
  @override
  Future<bool> isPermissionGranted() async => false;

  @override
  Future<bool> requestPermission() async => false;

  @override
  Future<void> schedule({
    required int id,
    required DateTime scheduledAt,
    required String title,
    required String body,
    String? routePath,
  }) async {}

  @override
  Future<void> cancel(int id) async {}

  @override
  Future<void> cancelAll() async {}
}
