import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/notifications/domain/notification_models.dart';
import 'package:workout_menu_app/features/notifications/domain/notification_repository.dart';

final class LocalNotificationRepository implements NotificationRepository {
  LocalNotificationRepository(
    this._database,
    this._gateway, {
    IdGenerator idGenerator = const UuidV7Generator(),
  }) : _ids = idGenerator;

  final AppDatabase _database;
  final LocalNotificationGateway _gateway;
  final IdGenerator _ids;

  static final RegExp _localTimePattern = RegExp(r'^(?:[01]\d|2[0-3]):[0-5]\d$');

  @override
  Future<ReminderSettingsState> load() async {
    final user = await _requiredUser();
    await _ensureDefaults(user);
    final rows = await _database.customSelect(
      '''
      SELECT notification_type_code, is_enabled, local_time, weekday_mask,
             advance_minutes, sound_enabled, vibration_enabled, timezone
      FROM notification_preference
      WHERE user_id = ? AND deleted_at IS NULL
      ORDER BY notification_type_code
      ''',
      variables: <Variable<Object>>[Variable.withString(user.id)],
    ).get();

    final byType = <ReminderType, ReminderPreference>{};
    for (final row in rows) {
      final type = ReminderType.fromCode(
        row.read<String>('notification_type_code'),
      );
      byType[type] = ReminderPreference(
        type: type,
        enabled: row.read<int>('is_enabled') == 1,
        localTime: row.readNullable<String>('local_time'),
        weekdayMask: row.readNullable<int>('weekday_mask'),
        advanceMinutes: row.read<int>('advance_minutes'),
        soundEnabled: row.read<int>('sound_enabled') == 1,
        vibrationEnabled: row.read<int>('vibration_enabled') == 1,
        timezone: row.read<String>('timezone'),
      );
    }

    return ReminderSettingsState(
      permissionGranted: await _gateway.isPermissionGranted(),
      preferences: <ReminderPreference>[
        for (final type in ReminderType.values) byType[type]!,
      ],
    );
  }

  @override
  Future<bool> requestPermission() => _gateway.requestPermission();

  @override
  Future<void> save(ReminderPreference preference) async {
    _validate(preference);
    final user = await _requiredUser();
    final now = DateTime.now().toUtc().toIso8601String();
    final rows = await _database.customSelect(
      '''
      SELECT id
      FROM notification_preference
      WHERE user_id = ?
        AND notification_type_code = ?
        AND deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(user.id),
        Variable.withString(preference.type.code),
      ],
    ).get();

    if (rows.isEmpty) {
      await _database.customStatement(
        '''
        INSERT INTO notification_preference(
          id, user_id, notification_type_code, is_enabled, local_time,
          weekday_mask, advance_minutes, sound_enabled, vibration_enabled,
          timezone, created_at, updated_at, row_version, sync_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'LOCAL_ONLY')
        ''',
        <Object?>[
          _ids.next(),
          user.id,
          preference.type.code,
          preference.enabled ? 1 : 0,
          preference.localTime,
          preference.weekdayMask,
          preference.advanceMinutes,
          preference.soundEnabled ? 1 : 0,
          preference.vibrationEnabled ? 1 : 0,
          preference.timezone,
          now,
          now,
        ],
      );
    } else {
      await _database.customStatement(
        '''
        UPDATE notification_preference
        SET is_enabled = ?, local_time = ?, weekday_mask = ?,
            advance_minutes = ?, sound_enabled = ?, vibration_enabled = ?,
            timezone = ?, updated_at = ?, row_version = row_version + 1,
            sync_status = 'LOCAL_ONLY'
        WHERE id = ?
        ''',
        <Object?>[
          preference.enabled ? 1 : 0,
          preference.localTime,
          preference.weekdayMask,
          preference.advanceMinutes,
          preference.soundEnabled ? 1 : 0,
          preference.vibrationEnabled ? 1 : 0,
          preference.timezone,
          now,
          rows.single.read<String>('id'),
        ],
      );
    }

    // A source-specific scheduler must create replacement rows. Existing rows
    // are cancelled when their preference is disabled or timing changes so an
    // old notification cannot fire under a new setting.
    await _cancelSchedulesForType(user.id, preference.type);
  }

  @override
  Future<void> rescheduleAll() async {
    final user = await _requiredUser();
    final preferences = await _loadPreferenceMap(user.id);
    final rows = await _database.customSelect(
      '''
      SELECT id, notification_type_code, scheduled_at, title_text, body_text,
             route_path, platform_notification_id
      FROM notification_schedule
      WHERE user_id = ?
        AND deleted_at IS NULL
        AND status_code = 'SCHEDULED'
      ORDER BY scheduled_at, platform_notification_id
      ''',
      variables: <Variable<Object>>[Variable.withString(user.id)],
    ).get();

    final permissionGranted = await _gateway.isPermissionGranted();
    for (final row in rows) {
      final type = ReminderType.fromCode(
        row.read<String>('notification_type_code'),
      );
      final preference = preferences[type];
      if (preference == null || !preference.enabled) {
        await _cancelScheduleRow(row);
        continue;
      }
      if (!permissionGranted) {
        continue;
      }
      final scheduledAt = DateTime.tryParse(row.read<String>('scheduled_at'));
      if (scheduledAt == null) {
        throw StateError('Invalid notification scheduled_at: ${row.read<String>('id')}');
      }
      await _gateway.schedule(
        id: row.read<int>('platform_notification_id'),
        scheduledAt: scheduledAt,
        title: row.read<String>('title_text'),
        body: row.read<String>('body_text'),
        routePath: row.readNullable<String>('route_path'),
      );
    }
  }

  @override
  Future<void> cancelAll() async {
    final user = await _requiredUser();
    await _gateway.cancelAll();
    final now = DateTime.now().toUtc().toIso8601String();
    await _database.customStatement(
      '''
      UPDATE notification_schedule
      SET status_code = 'CANCELLED', cancelled_at = ?, updated_at = ?,
          row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
      WHERE user_id = ?
        AND deleted_at IS NULL
        AND status_code = 'SCHEDULED'
      ''',
      <Object?>[now, now, user.id],
    );
  }

  Future<Map<ReminderType, ReminderPreference>> _loadPreferenceMap(
    String userId,
  ) async {
    final rows = await _database.customSelect(
      '''
      SELECT notification_type_code, is_enabled, local_time, weekday_mask,
             advance_minutes, sound_enabled, vibration_enabled, timezone
      FROM notification_preference
      WHERE user_id = ? AND deleted_at IS NULL
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    return <ReminderType, ReminderPreference>{
      for (final row in rows)
        ReminderType.fromCode(row.read<String>('notification_type_code')):
            ReminderPreference(
          type: ReminderType.fromCode(
            row.read<String>('notification_type_code'),
          ),
          enabled: row.read<int>('is_enabled') == 1,
          localTime: row.readNullable<String>('local_time'),
          weekdayMask: row.readNullable<int>('weekday_mask'),
          advanceMinutes: row.read<int>('advance_minutes'),
          soundEnabled: row.read<int>('sound_enabled') == 1,
          vibrationEnabled: row.read<int>('vibration_enabled') == 1,
          timezone: row.read<String>('timezone'),
        ),
    };
  }

  Future<void> _ensureDefaults(_NotificationUser user) async {
    final existingRows = await _database.customSelect(
      '''
      SELECT notification_type_code
      FROM notification_preference
      WHERE user_id = ? AND deleted_at IS NULL
      ''',
      variables: <Variable<Object>>[Variable.withString(user.id)],
    ).get();
    final existing = existingRows
        .map((row) => row.read<String>('notification_type_code'))
        .toSet();
    final now = DateTime.now().toUtc().toIso8601String();

    for (final preference in _defaultPreferences(user)) {
      if (existing.contains(preference.type.code)) {
        continue;
      }
      await _database.customStatement(
        '''
        INSERT INTO notification_preference(
          id, user_id, notification_type_code, is_enabled, local_time,
          weekday_mask, advance_minutes, sound_enabled, vibration_enabled,
          timezone, created_at, updated_at, row_version, sync_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'LOCAL_ONLY')
        ''',
        <Object?>[
          _ids.next(),
          user.id,
          preference.type.code,
          preference.enabled ? 1 : 0,
          preference.localTime,
          preference.weekdayMask,
          preference.advanceMinutes,
          preference.soundEnabled ? 1 : 0,
          preference.vibrationEnabled ? 1 : 0,
          preference.timezone,
          now,
          now,
        ],
      );
    }
  }

  List<ReminderPreference> _defaultPreferences(_NotificationUser user) {
    return <ReminderPreference>[
      ReminderPreference(
        type: ReminderType.workoutPlan,
        enabled: true,
        localTime: '18:00',
        advanceMinutes: 60,
        soundEnabled: user.soundEnabled,
        timezone: user.timezone,
      ),
      ReminderPreference(
        type: ReminderType.weeklyPlanning,
        enabled: true,
        localTime: '19:00',
        soundEnabled: user.soundEnabled,
        timezone: user.timezone,
      ),
      ReminderPreference(
        type: ReminderType.inactivity,
        enabled: false,
        localTime: '19:00',
        soundEnabled: user.soundEnabled,
        timezone: user.timezone,
      ),
      ReminderPreference(
        type: ReminderType.restTimer,
        enabled: true,
        soundEnabled: user.soundEnabled,
        timezone: user.timezone,
      ),
    ];
  }

  Future<void> _cancelSchedulesForType(
    String userId,
    ReminderType type,
  ) async {
    final rows = await _database.customSelect(
      '''
      SELECT id, platform_notification_id
      FROM notification_schedule
      WHERE user_id = ?
        AND notification_type_code = ?
        AND deleted_at IS NULL
        AND status_code = 'SCHEDULED'
      ORDER BY platform_notification_id
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(type.code),
      ],
    ).get();
    for (final row in rows) {
      await _cancelScheduleRow(row);
    }
  }

  Future<void> _cancelScheduleRow(QueryRow row) async {
    await _gateway.cancel(row.read<int>('platform_notification_id'));
    final now = DateTime.now().toUtc().toIso8601String();
    await _database.customStatement(
      '''
      UPDATE notification_schedule
      SET status_code = 'CANCELLED', cancelled_at = ?, updated_at = ?,
          row_version = row_version + 1, sync_status = 'LOCAL_ONLY'
      WHERE id = ? AND status_code = 'SCHEDULED'
      ''',
      <Object?>[now, now, row.read<String>('id')],
    );
  }

  Future<_NotificationUser> _requiredUser() async {
    final rows = await _database.customSelect(
      '''
      SELECT ua.id, ua.timezone,
             COALESCE(ap.sound_enabled, 1) AS sound_enabled
      FROM user_account ua
      LEFT JOIN app_preference ap
        ON ap.user_id = ua.id AND ap.deleted_at IS NULL
      WHERE ua.deleted_at IS NULL
        AND ua.account_status = 'ACTIVE'
      ORDER BY ua.created_at
      LIMIT 1
      ''',
    ).get();
    if (rows.isEmpty) {
      throw StateError('Active user not found.');
    }
    final row = rows.single;
    return _NotificationUser(
      id: row.read<String>('id'),
      timezone: row.read<String>('timezone'),
      soundEnabled: row.read<int>('sound_enabled') == 1,
    );
  }

  void _validate(ReminderPreference preference) {
    final localTime = preference.localTime;
    if (preference.type != ReminderType.restTimer &&
        (localTime == null || !_localTimePattern.hasMatch(localTime))) {
      throw ArgumentError.value(
        localTime,
        'localTime',
        'Use HH:mm for scheduled notification preferences.',
      );
    }
    final weekdayMask = preference.weekdayMask;
    if (weekdayMask != null && (weekdayMask < 0 || weekdayMask > 127)) {
      throw ArgumentError.value(weekdayMask, 'weekdayMask', 'Use 0 to 127.');
    }
    if (preference.advanceMinutes < 0 || preference.advanceMinutes > 1440) {
      throw ArgumentError.value(
        preference.advanceMinutes,
        'advanceMinutes',
        'Use 0 to 1440.',
      );
    }
    if (preference.timezone.trim().isEmpty) {
      throw ArgumentError.value(preference.timezone, 'timezone');
    }
  }
}

final class _NotificationUser {
  const _NotificationUser({
    required this.id,
    required this.timezone,
    required this.soundEnabled,
  });

  final String id;
  final String timezone;
  final bool soundEnabled;
}
