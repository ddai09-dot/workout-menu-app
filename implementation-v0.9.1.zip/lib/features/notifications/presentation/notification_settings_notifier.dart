import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/database/providers/database_providers.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/notifications/data/local_notification_gateway.dart';
import 'package:workout_menu_app/features/notifications/data/local_notification_repository.dart';
import 'package:workout_menu_app/features/notifications/domain/notification_models.dart';
import 'package:workout_menu_app/features/notifications/domain/notification_repository.dart';

final localNotificationGatewayProvider = Provider<LocalNotificationGateway>(
  (ref) => LocalNotificationGatewayStub(),
);

final notificationRepositoryProvider = Provider<NotificationRepository>((ref) {
  return LocalNotificationRepository(
    ref.watch(appDatabaseProvider),
    ref.watch(localNotificationGatewayProvider),
    idGenerator: const UuidV7Generator(),
  );
});

final notificationSettingsProvider = AsyncNotifierProvider<
    NotificationSettingsNotifier,
    ReminderSettingsState>(NotificationSettingsNotifier.new);

final class NotificationSettingsNotifier
    extends AsyncNotifier<ReminderSettingsState> {
  NotificationRepository get _repository =>
      ref.read(notificationRepositoryProvider);

  @override
  Future<ReminderSettingsState> build() => _repository.load();

  Future<void> requestPermission() async {
    await _repository.requestPermission();
    state = AsyncData(await _repository.load());
  }

  Future<void> setEnabled(ReminderPreference preference, bool value) {
    return _save(preference.copyWith(enabled: value));
  }

  Future<void> setLocalTime(ReminderPreference preference, String value) {
    return _save(preference.copyWith(localTime: value));
  }

  Future<void> setAdvanceMinutes(
    ReminderPreference preference,
    int value,
  ) {
    return _save(preference.copyWith(advanceMinutes: value));
  }

  Future<void> _save(ReminderPreference preference) async {
    await _repository.save(preference);
    await _repository.rescheduleAll();
    state = AsyncData(await _repository.load());
  }
}
