import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/features/notifications/domain/notification_models.dart';
import 'notification_settings_notifier.dart';

final class NotificationSettingsPage extends ConsumerWidget {
  const NotificationSettingsPage({super.key});

  String _title(ReminderType type) {
    return switch (type) {
      ReminderType.workoutPlan => 'トレーニング予定',
      ReminderType.weeklyPlanning => '週間メニューの確認',
      ReminderType.inactivity => '記録が空いたとき',
      ReminderType.restTimer => 'インターバル終了',
    };
  }

  String _description(ReminderType type) {
    return switch (type) {
      ReminderType.workoutPlan => '予定しているトレーニングを事前に知らせます。',
      ReminderType.weeklyPlanning => '週のメニューを確認するタイミングを知らせます。',
      ReminderType.inactivity => '一定期間、記録がない場合に知らせます。',
      ReminderType.restTimer => 'インターバル終了時に知らせます。',
    };
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(notificationSettingsProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('通知・リマインダー')),
      body: SafeArea(
        child: async.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (Object error, StackTrace stackTrace) => Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  const Text('設定を読み込めませんでした。'),
                  const SizedBox(height: 12),
                  OutlinedButton(
                    onPressed: () => ref.invalidate(
                      notificationSettingsProvider,
                    ),
                    child: const Text('もう一度読み込む'),
                  ),
                ],
              ),
            ),
          ),
          data: (ReminderSettingsState data) => ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            children: <Widget>[
              if (!data.permissionGranted)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: <Widget>[
                        const Text('通知は現在許可されていません。'),
                        const SizedBox(height: 8),
                        const Text(
                          '許可しなくても、メニュー作成やトレーニング記録は利用できます。',
                        ),
                        const SizedBox(height: 12),
                        FilledButton(
                          onPressed: () => ref
                              .read(notificationSettingsProvider.notifier)
                              .requestPermission(),
                          child: const Text('通知を許可する'),
                        ),
                      ],
                    ),
                  ),
                ),
              for (final preference in data.preferences)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: _PreferenceCard(
                    preference: preference,
                    title: _title(preference.type),
                    description: _description(preference.type),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

final class _PreferenceCard extends ConsumerWidget {
  const _PreferenceCard({
    required this.preference,
    required this.title,
    required this.description,
  });

  final ReminderPreference preference;
  final String title;
  final String description;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: <Widget>[
          SwitchListTile(
            title: Text(title),
            subtitle: Text(description),
            value: preference.enabled,
            onChanged: (bool value) => _run(
              context,
              () => ref
                  .read(notificationSettingsProvider.notifier)
                  .setEnabled(preference, value),
            ),
          ),
          if (preference.enabled &&
              preference.type != ReminderType.restTimer) ...<Widget>[
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.schedule_outlined),
              title: const Text('通知時刻'),
              subtitle: Text(preference.localTime ?? '時刻未設定'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _selectTime(context, ref),
            ),
          ],
          if (preference.enabled &&
              preference.type == ReminderType.workoutPlan) ...<Widget>[
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.notifications_active_outlined),
              title: const Text('予定より前に通知'),
              trailing: DropdownButton<int>(
                value: preference.advanceMinutes,
                underline: const SizedBox.shrink(),
                items: const <DropdownMenuItem<int>>[
                  DropdownMenuItem(value: 0, child: Text('予定時刻')),
                  DropdownMenuItem(value: 30, child: Text('30分前')),
                  DropdownMenuItem(value: 60, child: Text('1時間前')),
                  DropdownMenuItem(value: 120, child: Text('2時間前')),
                ],
                onChanged: (int? value) {
                  if (value == null || value == preference.advanceMinutes) {
                    return;
                  }
                  _run(
                    context,
                    () => ref
                        .read(notificationSettingsProvider.notifier)
                        .setAdvanceMinutes(preference, value),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _selectTime(BuildContext context, WidgetRef ref) async {
    final initial = _parseTime(preference.localTime);
    var selectedHour = initial.hour;
    var selectedMinute = initial.minute;
    final hourController = FixedExtentScrollController(
      initialItem: selectedHour,
    );
    final minuteController = FixedExtentScrollController(
      initialItem: selectedMinute,
    );
    final value = await showModalBottomSheet<String>(
      context: context,
      useSafeArea: true,
      isScrollControlled: true,
      builder: (BuildContext sheetContext) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Text(
                    '通知時刻',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 220,
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: CupertinoPicker.builder(
                            scrollController: hourController,
                            itemExtent: 44,
                            childCount: 24,
                            onSelectedItemChanged: (int index) {
                              setState(() => selectedHour = index);
                            },
                            itemBuilder: (BuildContext context, int index) {
                              return Center(
                                child: Text(
                                  index.toString().padLeft(2, '0'),
                                ),
                              );
                            },
                          ),
                        ),
                        Text(
                          ':',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        Expanded(
                          child: CupertinoPicker.builder(
                            scrollController: minuteController,
                            itemExtent: 44,
                            childCount: 60,
                            onSelectedItemChanged: (int index) {
                              setState(() => selectedMinute = index);
                            },
                            itemBuilder: (BuildContext context, int index) {
                              return Center(
                                child: Text(
                                  index.toString().padLeft(2, '0'),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton(
                    onPressed: () {
                      Navigator.of(sheetContext).pop(
                        '${selectedHour.toString().padLeft(2, '0')}:'
                        '${selectedMinute.toString().padLeft(2, '0')}',
                      );
                    },
                    child: const Text('この時刻を使う'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
    hourController.dispose();
    minuteController.dispose();
    if (value == null || !context.mounted) {
      return;
    }
    await _run(
      context,
      () => ref
          .read(notificationSettingsProvider.notifier)
          .setLocalTime(preference, value),
    );
  }

  TimeOfDay _parseTime(String? value) {
    final parts = value?.split(':');
    if (parts == null || parts.length != 2) {
      return const TimeOfDay(hour: 19, minute: 0);
    }
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null ||
        minute == null ||
        hour < 0 ||
        hour > 23 ||
        minute < 0 ||
        minute > 59) {
      return const TimeOfDay(hour: 19, minute: 0);
    }
    return TimeOfDay(hour: hour, minute: minute);
  }

  Future<void> _run(
    BuildContext context,
    Future<void> Function() action,
  ) async {
    try {
      await action();
    } catch (_) {
      if (!context.mounted) {
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('設定を保存できませんでした。')),
      );
    }
  }
}
