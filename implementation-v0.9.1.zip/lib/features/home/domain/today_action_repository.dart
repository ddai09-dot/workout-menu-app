import 'package:workout_menu_app/features/home/domain/today_action.dart';

abstract interface class TodayActionRepository {
  Future<TodayAction> loadTodayAction();
}
