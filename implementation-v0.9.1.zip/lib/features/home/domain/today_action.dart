final class TodayAction {
  const TodayAction({
    required this.title,
    required this.description,
    required this.primaryActionLabel,
    required this.routeLocation,
  });

  final String title;
  final String description;
  final String primaryActionLabel;
  final String routeLocation;
}
