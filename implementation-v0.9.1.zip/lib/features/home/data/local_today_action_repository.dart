import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/features/home/domain/today_action.dart';
import 'package:workout_menu_app/features/home/domain/today_action_repository.dart';

final class LocalTodayActionRepository implements TodayActionRepository {
  const LocalTodayActionRepository(this._database);

  final AppDatabase _database;

  @override
  Future<TodayAction> loadTodayAction() async {
    final row = await _database.customSelect(
      'SELECT COUNT(*) AS exercise_count '
      'FROM exercise_master WHERE is_active = 1',
    ).getSingle();

    final exerciseCount = row.read<int>('exercise_count');
    if (exerciseCount != 72) {
      throw StateError(
        'Exercise seed is incomplete: expected 72, got $exerciseCount.',
      );
    }

    final completed = await _database.customSelect('''
      SELECT 1 AS found
      FROM user_profile
      WHERE onboarding_completed_at IS NOT NULL
        AND deleted_at IS NULL
      LIMIT 1
    ''').get();
    if (completed.isEmpty) {
      final draft = await _database.customSelect('''
        SELECT current_step_code
        FROM onboarding_draft
        WHERE status_code = 'IN_PROGRESS'
          AND deleted_at IS NULL
        ORDER BY updated_at DESC
        LIMIT 1
      ''').get();
      final inProgress = draft.isNotEmpty &&
          draft.first.read<String>('current_step_code') != 'INTRO';
      return TodayAction(
        title: inProgress ? '初期登録の続きをしましょう' : '初期設定を始めましょう',
        description: inProgress
            ? '入力内容は端末に保存されています。前回の続きから再開できます。'
            : 'あなたの予定・経験・器具を登録すると、今週のメニューを作成できます。',
        primaryActionLabel: inProgress ? '登録の続きをする' : '初期設定を始める',
        routeLocation: '/onboarding',
      );
    }

    final openSession = await _database.customSelect(
      '''
      SELECT id, status_code
      FROM workout_session
      WHERE deleted_at IS NULL
        AND status_code IN ('IN_PROGRESS', 'AWAITING_ASSESSMENT')
      ORDER BY last_local_saved_at DESC
      LIMIT 1
      ''',
    ).get();
    if (openSession.isNotEmpty) {
      final sessionId = openSession.first.read<String>('id');
      final status = openSession.first.read<String>('status_code');
      return TodayAction(
        title: status == 'AWAITING_ASSESSMENT'
            ? '終了後の記録が残っています'
            : '未終了のトレーニングがあります',
        description: status == 'AWAITING_ASSESSMENT'
            ? '実施内容は端末に保存されています。きつさや未完了理由を記録して終了してください。'
            : '完了したセット、現在の種目、休憩タイマーは端末に保存されています。',
        primaryActionLabel: status == 'AWAITING_ASSESSMENT'
            ? '終了後の記録を続ける'
            : 'トレーニングを再開する',
        routeLocation: status == 'AWAITING_ASSESSMENT'
            ? '/workout/assessment/$sessionId'
            : '/workout/session/$sessionId',
      );
    }

    final now = DateTime.now();
    final weekStart = _mondayOf(now);
    final weekStartText = _dateOnly(weekStart);
    final todayText = _dateOnly(now);
    final activeMenu = await _database.customSelect(
      '''
      SELECT wm.id, wm.status_code
      FROM weekly_menu wm
      JOIN training_week tw ON tw.id = wm.training_week_id
      WHERE tw.week_start_date = ?
        AND wm.is_active = 1
        AND wm.deleted_at IS NULL
        AND tw.deleted_at IS NULL
      ORDER BY wm.menu_version DESC
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(weekStartText)],
    ).get();
    if (activeMenu.isNotEmpty) {
      final menuId = activeMenu.first.read<String>('id');
      final status = activeMenu.first.read<String>('status_code');
      if (status == 'REST_WEEK') {
        return const TodayAction(
          title: '今週は完全休養です',
          description: '今週はトレーニングメニューを作成しない設定です。',
          primaryActionLabel: '今週のメニューを見る',
          routeLocation: '/menu',
        );
      }
      if (status == 'FINALIZED') {
        final todayPlan = await _database.customSelect(
          '''
          SELECT wdp.id, wdp.session_focus_snapshot,
                 wdp.estimated_duration_min, wdp.duration_min,
                 COALESCE(tl.display_name, '場所未設定') AS location_name,
                 COUNT(pe.id) AS exercise_count
          FROM workout_day_plan wdp
          LEFT JOIN training_location tl ON tl.id = wdp.training_location_id
          LEFT JOIN planned_exercise pe
            ON pe.workout_day_plan_id = wdp.id AND pe.deleted_at IS NULL
          WHERE wdp.weekly_menu_id = ?
            AND wdp.plan_date = ?
            AND wdp.deleted_at IS NULL
            AND wdp.status_code IN ('PLANNED', 'IN_PROGRESS')
          GROUP BY wdp.id, wdp.session_focus_snapshot,
                   wdp.estimated_duration_min, wdp.duration_min, tl.display_name
          LIMIT 1
          ''',
          variables: <Variable<Object>>[
            Variable.withString(menuId),
            Variable.withString(todayText),
          ],
        ).get();
        if (todayPlan.isNotEmpty) {
          final plan = todayPlan.first;
          final duration = plan.read<int>('estimated_duration_min') == 0
              ? plan.read<int>('duration_min')
              : plan.read<int>('estimated_duration_min');
          return TodayAction(
            title: '今日は${plan.read<String>('session_focus_snapshot')}',
            description:
                '${plan.read<String>('location_name')}・約$duration分・${plan.read<int>('exercise_count')}種目',
            primaryActionLabel: 'トレーニングを始める',
            routeLocation: '/workout/start/${plan.read<String>('id')}',
          );
        }
        final nextPlan = await _database.customSelect(
          '''
          SELECT wdp.plan_date, wdp.session_focus_snapshot
          FROM workout_day_plan wdp
          WHERE wdp.weekly_menu_id = ?
            AND wdp.plan_date > ?
            AND wdp.status_code = 'PLANNED'
            AND wdp.deleted_at IS NULL
          ORDER BY wdp.plan_date
          LIMIT 1
          ''',
          variables: <Variable<Object>>[
            Variable.withString(menuId),
            Variable.withString(todayText),
          ],
        ).get();
        if (nextPlan.isNotEmpty) {
          final plan = nextPlan.first;
          final date = DateTime.parse(plan.read<String>('plan_date'));
          return TodayAction(
            title: '今日は休養日です',
            description:
                '次回は${date.month}/${date.day}の${plan.read<String>('session_focus_snapshot')}です。',
            primaryActionLabel: '今週のメニューを見る',
            routeLocation: '/menu',
          );
        }
        return const TodayAction(
          title: '今週の予定を確認しましょう',
          description: '今週のトレーニング予定と完了状況を確認できます。',
          primaryActionLabel: '今週のメニューを見る',
          routeLocation: '/menu',
        );
      }
    }

    final weeklyDraft = await _database.customSelect(
      '''
      SELECT current_step_code
      FROM weekly_planner_draft
      WHERE week_start_date = ?
        AND status_code = 'IN_PROGRESS'
        AND deleted_at IS NULL
      ORDER BY updated_at DESC
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(weekStartText)],
    ).get();
    final inProgress = weeklyDraft.isNotEmpty &&
        weeklyDraft.first.read<String>('current_step_code') != 'START';
    return TodayAction(
      title: inProgress ? '週間メニューの続きを作りましょう' : '今週のメニューを作成しましょう',
      description: inProgress
          ? '入力内容は保存されています。前回の続きから再開できます。'
          : '今週の予定と体調を確認して、実施できる曜日にメニューを作成します。',
      primaryActionLabel: inProgress ? '作成の続きをする' : '今週のメニューを作成する',
      routeLocation: '/menu/weekly-planner',
    );
  }
}

DateTime _mondayOf(DateTime value) {
  final local = DateTime(value.year, value.month, value.day);
  return local.subtract(Duration(days: local.weekday - DateTime.monday));
}

String _dateOnly(DateTime value) =>
    DateTime(value.year, value.month, value.day).toIso8601String().substring(0, 10);
