import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/database/providers/database_providers.dart';
import 'package:workout_menu_app/features/home/data/local_today_action_repository.dart';
import 'package:workout_menu_app/features/home/domain/today_action.dart';
import 'package:workout_menu_app/features/home/domain/today_action_repository.dart';

final todayActionRepositoryProvider = Provider<TodayActionRepository>((ref) {
  return LocalTodayActionRepository(ref.watch(appDatabaseProvider));
});

final todayActionProvider =
    AsyncNotifierProvider<TodayActionNotifier, TodayAction>(
  TodayActionNotifier.new,
);

final class TodayActionNotifier extends AsyncNotifier<TodayAction> {
  @override
  Future<TodayAction> build() {
    return ref.watch(todayActionRepositoryProvider).loadTodayAction();
  }

  Future<void> refresh() async {
    state = const AsyncLoading<TodayAction>();
    state = await AsyncValue.guard(
      ref.read(todayActionRepositoryProvider).loadTodayAction,
    );
  }
}
