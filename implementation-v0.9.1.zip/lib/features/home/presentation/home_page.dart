import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/core/widgets/primary_action_button.dart';
import 'package:workout_menu_app/features/home/domain/today_action.dart';
import 'package:workout_menu_app/features/home/presentation/today_action_notifier.dart';

final class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final action = ref.watch(todayActionProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('ホーム')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: action.when(
            data: (TodayAction value) => _TodayActionCard(action: value),
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (Object error, StackTrace stackTrace) {
              return Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    const Text('データを読み込めませんでした。'),
                    const SizedBox(height: 12),
                    PrimaryActionButton(
                      label: 'もう一度試す',
                      onPressed: () async {
                        await ref.read(todayActionProvider.notifier).refresh();
                      },
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

final class _TodayActionCard extends StatelessWidget {
  const _TodayActionCard({required this.action});

  final TodayAction action;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(
              '今日やること',
              style: Theme.of(context).textTheme.labelLarge,
            ),
            const SizedBox(height: 12),
            Text(
              action.title,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(action.description),
            const Spacer(),
            PrimaryActionButton(
              label: action.primaryActionLabel,
              onPressed: () => context.go(action.routeLocation),
            ),
          ],
        ),
      ),
    );
  }
}
