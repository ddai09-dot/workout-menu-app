import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/account/presentation/account_notifier.dart';
import 'package:workout_menu_app/features/ai_coach/presentation/ai_coach_notifier.dart';
import 'package:workout_menu_app/features/exercise_form/presentation/exercise_form_notifier.dart';
import 'package:workout_menu_app/features/home/presentation/today_action_notifier.dart';
import 'package:workout_menu_app/features/notifications/presentation/notification_settings_notifier.dart';
import 'package:workout_menu_app/features/onboarding/presentation/onboarding_notifier.dart';
import 'package:workout_menu_app/features/progression/presentation/progression_notifier.dart';
import 'package:workout_menu_app/features/records/presentation/records_notifier.dart';
import 'package:workout_menu_app/features/settings/presentation/training_settings_providers.dart';
import 'package:workout_menu_app/features/weekly_planner/presentation/weekly_planner_notifier.dart';
import 'package:workout_menu_app/features/workout/presentation/workout_notifier.dart';

final class LocalDataResetPage extends ConsumerStatefulWidget {
  const LocalDataResetPage({super.key});

  @override
  ConsumerState<LocalDataResetPage> createState() =>
      _LocalDataResetPageState();
}

final class _LocalDataResetPageState extends ConsumerState<LocalDataResetPage> {
  bool _acknowledged = false;
  bool _isDeleting = false;
  String? _errorMessage;

  @override
  Widget build(BuildContext context) {
    final errorColor = Theme.of(context).colorScheme.error;
    return Scaffold(
      appBar: AppBar(title: const Text('端末内データ')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
          children: <Widget>[
            Text(
              '端末内データを初期化',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w700,
                  ),
            ),
            const SizedBox(height: 12),
            const Text(
              '初期登録、設定、週間メニュー、トレーニング記録、進行履歴をこの端末から削除します。',
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '削除されるもの',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 10),
                    const _ResetItem(label: 'プロフィールとトレーニング設定'),
                    const _ResetItem(label: '作成済みの週間メニュー'),
                    const _ResetItem(label: 'トレーニング記録と身体記録'),
                    const _ResetItem(label: '進行判定と提案履歴'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '削除されないもの',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 10),
                    const _ResetItem(label: '種目データとフォーム説明'),
                    const _ResetItem(label: '用語・FAQなどの同梱コンテンツ'),
                    const _ResetItem(label: 'アプリ本体とデータベース構造'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            CheckboxListTile(
              value: _acknowledged,
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              title: const Text('削除したデータは元に戻せないことを確認しました'),
              onChanged: _isDeleting
                  ? null
                  : (bool? value) {
                      setState(() {
                        _acknowledged = value ?? false;
                        _errorMessage = null;
                      });
                    },
            ),
            if (_errorMessage != null) ...<Widget>[
              const SizedBox(height: 8),
              Text(
                _errorMessage!,
                style: TextStyle(color: errorColor),
              ),
            ],
            const SizedBox(height: 20),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: errorColor,
                foregroundColor: Theme.of(context).colorScheme.onError,
                minimumSize: const Size.fromHeight(52),
              ),
              onPressed: !_acknowledged || _isDeleting
                  ? null
                  : () => unawaited(_confirmAndDelete()),
              icon: _isDeleting
                  ? const SizedBox.square(
                      dimension: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.delete_forever_outlined),
              label: Text(_isDeleting ? '削除しています' : '端末内データを削除'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmAndDelete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('すべて削除しますか？'),
          content: const Text(
            '端末内の登録内容と記録を削除し、新しい初期登録へ戻ります。元には戻せません。',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('キャンセル'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('削除する'),
            ),
          ],
        );
      },
    );
    if (!(confirmed ?? false) || !mounted) {
      return;
    }

    setState(() {
      _isDeleting = true;
      _errorMessage = null;
    });
    final succeeded =
        await ref.read(accountNotifierProvider.notifier).resetLocalData();
    if (!mounted) {
      return;
    }
    if (!succeeded) {
      setState(() {
        _isDeleting = false;
        _errorMessage = '削除処理を完了できませんでした。アプリを再起動して状態を確認してください。';
      });
      return;
    }

    _invalidateUserState(ref);
    context.go('/launch');
  }

  void _invalidateUserState(WidgetRef ref) {
    ref.invalidate(aiCoachProvider);
    ref.invalidate(onboardingStatusProvider);
    ref.invalidate(onboardingFlowProvider);
    ref.invalidate(trainingSettingsSnapshotProvider);
    ref.invalidate(weeklyPlannerProvider);
    ref.invalidate(todayActionProvider);
    ref.invalidate(workoutLaunchProvider);
    ref.invalidate(workoutSessionProvider);
    ref.invalidate(workoutHistoryProvider);
    ref.invalidate(workoutDetailProvider);
    ref.invalidate(workoutBodyPartsProvider);
    ref.invalidate(recordsDashboardProvider);
    ref.invalidate(exerciseRecordSummariesProvider);
    ref.invalidate(exerciseHistoryProvider);
    ref.invalidate(bodyMeasurementsProvider);
    ref.invalidate(progressionProposalsProvider);
    ref.invalidate(pendingProposalCountProvider);
    ref.invalidate(exerciseFormProvider);
    ref.invalidate(notificationSettingsProvider);
  }
}

final class _ResetItem extends StatelessWidget {
  const _ResetItem({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const Padding(
            padding: EdgeInsets.only(top: 2),
            child: Icon(Icons.check, size: 18),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(label)),
        ],
      ),
    );
  }
}
