import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/records/domain/records_models.dart';
import 'package:workout_menu_app/features/records/domain/records_repository.dart';

final class LocalRecordsRepository implements RecordsRepository {
  const LocalRecordsRepository(
    this._database, {
    IdGenerator idGenerator = const UuidV7Generator(),
  }) : _idGenerator = idGenerator;

  final AppDatabase _database;
  final IdGenerator _idGenerator;

  @override
  Future<RecordsDashboard> loadDashboard() async {
    final userId = await _requiredUserId();
    final metrics = await _database.customSelect(
      '''
      SELECT
        COUNT(*) AS session_count,
        COALESCE(SUM(session_work_sets), 0) AS work_set_count,
        COALESCE(SUM(actual_duration_sec), 0) AS duration_sec
      FROM (
        SELECT
          ws.id,
          COALESCE(pa.actual_duration_sec, 0) AS actual_duration_sec,
          (
            SELECT COUNT(*)
            FROM session_exercise se
            JOIN work_set_record wr ON wr.session_exercise_id = se.id
            WHERE se.workout_session_id = ws.id
              AND se.deleted_at IS NULL
              AND wr.voided_at IS NULL
              AND wr.is_warmup = 0
          ) AS session_work_sets
        FROM workout_session ws
        LEFT JOIN post_workout_assessment pa
          ON pa.workout_session_id = ws.id
         AND pa.deleted_at IS NULL
        WHERE ws.user_id = ?
          AND ws.deleted_at IS NULL
          AND ws.status_code IN ('COMPLETED', 'PARTIAL')
          AND ws.record_date >= date('now', 'localtime', '-29 day')
      ) recent_sessions
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).getSingle();
    final week = await _database.customSelect(
      '''
      SELECT
        SUM(CASE WHEN wdp.status_code IN ('COMPLETED', 'PARTIAL') THEN 1 ELSE 0 END) AS completed_count,
        SUM(CASE WHEN wdp.status_code IN ('PLANNED', 'COMPLETED', 'PARTIAL') THEN 1 ELSE 0 END) AS planned_count
      FROM workout_day_plan wdp
      JOIN weekly_menu wm ON wm.id = wdp.weekly_menu_id
      JOIN training_week tw ON tw.id = wm.training_week_id
      WHERE tw.user_id = ?
        AND tw.deleted_at IS NULL
        AND wm.deleted_at IS NULL
        AND wm.is_active = 1
        AND date('now', 'localtime') BETWEEN tw.week_start_date AND tw.week_end_date
        AND wdp.deleted_at IS NULL
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).getSingle();
    final latestMeasurement = await _database.customSelect(
      '''
      SELECT weight_kg, body_fat_percent
      FROM body_measurement
      WHERE user_id = ? AND voided_at IS NULL
      ORDER BY measured_at DESC, created_at DESC
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    final proposal = await _database.customSelect(
      '''
      SELECT COUNT(*) AS count
      FROM progression_proposal
      WHERE user_id = ? AND deleted_at IS NULL
        AND status_code IN ('PENDING', 'DEFERRED')
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).getSingle();
    final recent = await _loadWorkoutHistory(userId: userId, limit: 5);
    return RecordsDashboard(
      sessionsLast30Days: metrics.read<int>('session_count'),
      workSetsLast30Days: metrics.read<int>('work_set_count'),
      minutesLast30Days: metrics.read<int>('duration_sec') ~/ 60,
      completedThisWeek: week.readNullable<int>('completed_count') ?? 0,
      plannedThisWeek: week.readNullable<int>('planned_count') ?? 0,
      pendingProposalCount: proposal.read<int>('count'),
      latestWeightKg: latestMeasurement.isEmpty
          ? null
          : latestMeasurement.first.readNullable<double>('weight_kg'),
      latestBodyFatPercent: latestMeasurement.isEmpty
          ? null
          : latestMeasurement.first.readNullable<double>('body_fat_percent'),
      recentSessions: recent,
    );
  }

  @override
  Future<List<WorkoutHistorySummary>> loadWorkoutHistory({int limit = 100}) async {
    return _loadWorkoutHistory(
      userId: await _requiredUserId(),
      limit: limit,
    );
  }

  Future<List<WorkoutHistorySummary>> _loadWorkoutHistory({
    required String userId,
    required int limit,
  }) async {
    final rows = await _database.customSelect(
      '''
      SELECT
        ws.id,
        ws.record_date,
        ws.started_at,
        ws.status_code,
        COALESCE(wdp.session_focus_snapshot, 'トレーニング') AS focus_text,
        COALESCE(pa.actual_duration_sec, 0) AS duration_sec,
        COALESCE(pa.completed_exercise_count, 0) AS exercise_count,
        COALESCE(pa.completed_work_set_count, 0) AS work_set_count,
        COALESCE(pa.had_pain, 0) AS had_pain
      FROM workout_session ws
      LEFT JOIN workout_day_plan wdp ON wdp.id = ws.workout_day_plan_id
      LEFT JOIN post_workout_assessment pa
        ON pa.workout_session_id = ws.id
       AND pa.deleted_at IS NULL
      WHERE ws.user_id = ?
        AND ws.deleted_at IS NULL
        AND ws.status_code IN ('COMPLETED', 'PARTIAL')
      ORDER BY ws.record_date DESC, ws.started_at DESC
      LIMIT ?
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withInt(limit),
      ],
    ).get();
    return rows.map(_historySummary).toList(growable: false);
  }

  WorkoutHistorySummary _historySummary(QueryRow row) {
    return WorkoutHistorySummary(
      sessionId: row.read<String>('id'),
      recordDate: DateTime.parse(row.read<String>('record_date')),
      startedAt: DateTime.parse(row.read<String>('started_at')),
      statusCode: row.read<String>('status_code'),
      focusText: row.read<String>('focus_text'),
      durationSec: row.read<int>('duration_sec'),
      exerciseCount: row.read<int>('exercise_count'),
      workSetCount: row.read<int>('work_set_count'),
      hadPain: row.read<int>('had_pain') == 1,
    );
  }

  @override
  Future<WorkoutHistoryDetail> loadWorkoutDetail(String sessionId) async {
    final headerRows = await _database.customSelect(
      '''
      SELECT
        ws.id,
        ws.record_date,
        ws.started_at,
        ws.status_code,
        COALESCE(wdp.session_focus_snapshot, 'トレーニング') AS focus_text,
        COALESCE(pa.actual_duration_sec, 0) AS duration_sec,
        COALESCE(pa.completed_exercise_count, 0) AS exercise_count,
        COALESCE(pa.completed_work_set_count, 0) AS work_set_count,
        COALESCE(pa.had_pain, 0) AS had_pain,
        COALESCE(pa.overall_difficulty_score, 3) AS difficulty_score,
        pa.incomplete_reason_code
      FROM workout_session ws
      LEFT JOIN workout_day_plan wdp ON wdp.id = ws.workout_day_plan_id
      LEFT JOIN post_workout_assessment pa
        ON pa.workout_session_id = ws.id
       AND pa.deleted_at IS NULL
      WHERE ws.id = ? AND ws.deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(sessionId)],
    ).get();
    if (headerRows.isEmpty) throw StateError('Workout session not found.');
    final header = headerRows.first;
    final exerciseRows = await _database.customSelect(
      '''
      SELECT
        se.id,
        se.exercise_id,
        se.exercise_name_snapshot,
        se.status_code,
        ev.result_class_code,
        ev.reason_text_snapshot,
        COALESCE(ev.progress_detected, 0) AS progress_detected,
        COALESCE(ev.stall_count_after, 0) AS stall_count_after
      FROM session_exercise se
      LEFT JOIN session_exercise_evaluation ev
        ON ev.session_exercise_id = se.id
       AND ev.deleted_at IS NULL
      WHERE se.workout_session_id = ? AND se.deleted_at IS NULL
      ORDER BY se.order_index ASC
      ''',
      variables: <Variable<Object>>[Variable.withString(sessionId)],
    ).get();
    final exercises = <WorkoutHistoryExercise>[];
    for (final row in exerciseRows) {
      final setRows = await _database.customSelect(
        '''
        SELECT set_number, side_code, is_warmup, actual_weight_kg,
               actual_reps, actual_duration_sec, assistance_value
        FROM work_set_record
        WHERE session_exercise_id = ? AND voided_at IS NULL
        ORDER BY set_number ASC, completed_at ASC
        ''',
        variables: <Variable<Object>>[
          Variable.withString(row.read<String>('id')),
        ],
      ).get();
      exercises.add(
        WorkoutHistoryExercise(
          sessionExerciseId: row.read<String>('id'),
          exerciseId: row.read<String>('exercise_id'),
          name: row.read<String>('exercise_name_snapshot'),
          statusCode: row.read<String>('status_code'),
          resultCode: row.readNullable<String>('result_class_code'),
          resultReason: row.readNullable<String>('reason_text_snapshot'),
          progressDetected: row.read<int>('progress_detected') == 1,
          stallCount: row.read<int>('stall_count_after'),
          sets: setRows
              .map(
                (setRow) => WorkoutHistorySet(
                  setNumber: setRow.read<int>('set_number'),
                  sideCode: setRow.read<String>('side_code'),
                  isWarmup: setRow.read<int>('is_warmup') == 1,
                  weightKg: setRow.readNullable<double>('actual_weight_kg'),
                  reps: setRow.readNullable<int>('actual_reps'),
                  durationSec:
                      setRow.readNullable<int>('actual_duration_sec'),
                  assistanceValue:
                      setRow.readNullable<double>('assistance_value'),
                ),
              )
              .toList(growable: false),
        ),
      );
    }
    return WorkoutHistoryDetail(
      summary: _historySummary(header),
      difficultyScore: header.read<int>('difficulty_score'),
      incompleteReasonCode:
          header.readNullable<String>('incomplete_reason_code'),
      exercises: exercises,
    );
  }

  @override
  Future<List<ExerciseRecordSummary>> loadExerciseSummaries() async {
    final userId = await _requiredUserId();
    final rows = await _database.customSelect(
      '''
      SELECT
        eps.exercise_id,
        MAX(eps.display_name_snapshot) AS exercise_name,
        SUM(eps.valid_session_count) AS session_count,
        MAX(eps.last_recorded_at) AS last_recorded_at,
        MAX(eps.progression_group_code) AS progression_group_code,
        MAX(eps.stall_count) AS stall_count,
        (
          SELECT ev.progression_metric_value
          FROM session_exercise_evaluation ev
          JOIN exercise_performance_series nested
            ON nested.id = ev.performance_series_id
          WHERE nested.user_id = eps.user_id
            AND nested.exercise_id = eps.exercise_id
            AND nested.deleted_at IS NULL
            AND ev.deleted_at IS NULL
          ORDER BY ev.evaluated_at DESC LIMIT 1
        ) AS latest_metric,
        (
          SELECT ev.result_class_code
          FROM session_exercise_evaluation ev
          JOIN exercise_performance_series nested
            ON nested.id = ev.performance_series_id
          WHERE nested.user_id = eps.user_id
            AND nested.exercise_id = eps.exercise_id
            AND nested.deleted_at IS NULL
            AND ev.deleted_at IS NULL
          ORDER BY ev.evaluated_at DESC LIMIT 1
        ) AS latest_result_code
      FROM exercise_performance_series eps
      WHERE eps.user_id = ? AND eps.deleted_at IS NULL
      GROUP BY eps.exercise_id
      ORDER BY last_recorded_at DESC, exercise_name ASC
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    return rows
        .map(
          (row) => ExerciseRecordSummary(
            exerciseId: row.read<String>('exercise_id'),
            name: row.read<String>('exercise_name'),
            sessionCount: row.read<int>('session_count'),
            lastPerformedAt: DateTime.parse(row.read<String>('last_recorded_at')),
            progressionGroupCode:
                row.read<String>('progression_group_code'),
            latestMetric: row.readNullable<double>('latest_metric'),
            latestResultCode:
                row.readNullable<String>('latest_result_code'),
            stallCount: row.read<int>('stall_count'),
          ),
        )
        .toList(growable: false);
  }

  @override
  Future<ExerciseHistoryDetail> loadExerciseHistory(String exerciseId) async {
    final userId = await _requiredUserId();
    final seriesRows = await _database.customSelect(
      '''
      SELECT id, series_key, display_name_snapshot, progression_group_code,
             target_mode_code, stall_count
      FROM exercise_performance_series
      WHERE user_id = ? AND exercise_id = ? AND deleted_at IS NULL
      ORDER BY last_recorded_at DESC
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(exerciseId),
      ],
    ).get();
    if (seriesRows.isEmpty) throw StateError('Exercise history not found.');
    final series = <ExerciseSeriesHistory>[];
    for (final seriesRow in seriesRows) {
      final points = await _database.customSelect(
        '''
        SELECT evaluated_at, progression_metric_value, result_class_code,
               progress_detected, work_set_count, total_reps,
               total_duration_sec, representative_weight_kg,
               representative_assistance_value
        FROM session_exercise_evaluation
        WHERE performance_series_id = ? AND deleted_at IS NULL
        ORDER BY evaluated_at ASC
        ''',
        variables: <Variable<Object>>[
          Variable.withString(seriesRow.read<String>('id')),
        ],
      ).get();
      series.add(
        ExerciseSeriesHistory(
          seriesId: seriesRow.read<String>('id'),
          seriesKey: seriesRow.read<String>('series_key'),
          progressionGroupCode:
              seriesRow.read<String>('progression_group_code'),
          targetModeCode: seriesRow.read<String>('target_mode_code'),
          stallCount: seriesRow.read<int>('stall_count'),
          points: points
              .map(
                (row) => ExerciseSeriesPoint(
                  date: DateTime.parse(row.read<String>('evaluated_at')),
                  metricValue:
                      row.readNullable<double>('progression_metric_value') ?? 0,
                  resultCode: row.read<String>('result_class_code'),
                  progressDetected: row.read<int>('progress_detected') == 1,
                  workSetCount: row.read<int>('work_set_count'),
                  totalReps: row.read<int>('total_reps'),
                  totalDurationSec: row.read<int>('total_duration_sec'),
                  weightKg:
                      row.readNullable<double>('representative_weight_kg'),
                  assistanceValue: row
                      .readNullable<double>('representative_assistance_value'),
                ),
              )
              .toList(growable: false),
        ),
      );
    }
    return ExerciseHistoryDetail(
      exerciseId: exerciseId,
      name: seriesRows.first.read<String>('display_name_snapshot'),
      series: series,
    );
  }

  @override
  Future<List<BodyMeasurementView>> loadBodyMeasurements({int limit = 120}) async {
    final userId = await _requiredUserId();
    final rows = await _database.customSelect(
      '''
      SELECT id, measured_at, weight_kg, body_fat_percent
      FROM body_measurement
      WHERE user_id = ? AND voided_at IS NULL
      ORDER BY measured_at DESC, created_at DESC
      LIMIT ?
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withInt(limit),
      ],
    ).get();
    return rows
        .map(
          (row) => BodyMeasurementView(
            id: row.read<String>('id'),
            measuredAt: DateTime.parse(row.read<String>('measured_at')),
            weightKg: row.readNullable<double>('weight_kg'),
            bodyFatPercent: row.readNullable<double>('body_fat_percent'),
          ),
        )
        .toList(growable: false);
  }

  @override
  Future<void> saveBodyMeasurement({
    required DateTime measuredAt,
    double? weightKg,
    double? bodyFatPercent,
    String? correctsMeasurementId,
  }) async {
    if (weightKg == null && bodyFatPercent == null) {
      throw ArgumentError('weightKg or bodyFatPercent is required.');
    }
    if (weightKg != null && (weightKg < 20 || weightKg > 400)) {
      throw ArgumentError.value(weightKg, 'weightKg');
    }
    if (bodyFatPercent != null &&
        (bodyFatPercent < 2 || bodyFatPercent > 70)) {
      throw ArgumentError.value(bodyFatPercent, 'bodyFatPercent');
    }
    final userId = await _requiredUserId();
    final now = DateTime.now().toUtc().toIso8601String();
    final id = _idGenerator.next();
    await _database.transaction(() async {
      if (correctsMeasurementId != null) {
        final original = await _database.customSelect(
          '''
          SELECT 1 AS found
          FROM body_measurement
          WHERE id = ? AND user_id = ? AND voided_at IS NULL
          LIMIT 1
          ''',
          variables: <Variable<Object>>[
            Variable.withString(correctsMeasurementId),
            Variable.withString(userId),
          ],
        ).get();
        if (original.isEmpty) {
          throw StateError('The measurement to correct no longer exists.');
        }
        await _database.customStatement(
          '''
          UPDATE body_measurement
          SET voided_at = ?, updated_at = ?, sync_status = 'LOCAL_ONLY'
          WHERE id = ? AND user_id = ? AND voided_at IS NULL
          ''',
          <Object?>[now, now, correctsMeasurementId, userId],
        );
      }
      await _database.customStatement(
        '''
        INSERT INTO body_measurement (
          id, user_id, created_at, updated_at, supersedes_id,
          sync_status, measured_at, weight_kg, body_fat_percent, source_code
        ) VALUES (?, ?, ?, ?, ?, 'LOCAL_ONLY', ?, ?, ?, 'MANUAL')
        ''',
        <Object?>[
          id,
          userId,
          now,
          now,
          correctsMeasurementId,
          measuredAt.toUtc().toIso8601String(),
          weightKg,
          bodyFatPercent,
        ],
      );
    });
  }

  Future<String> _requiredUserId() async {
    final rows = await _database.customSelect(
      '''
      SELECT id FROM user_account
      WHERE deleted_at IS NULL AND account_status = 'ACTIVE'
      ORDER BY created_at ASC LIMIT 1
      ''',
    ).get();
    if (rows.isEmpty) throw StateError('Active user not found.');
    return rows.first.read<String>('id');
  }
}
