import 'package:workout_menu_app/features/records/domain/records_models.dart';

abstract interface class RecordsRepository {
  Future<RecordsDashboard> loadDashboard();
  Future<List<WorkoutHistorySummary>> loadWorkoutHistory({int limit = 100});
  Future<WorkoutHistoryDetail> loadWorkoutDetail(String sessionId);
  Future<List<ExerciseRecordSummary>> loadExerciseSummaries();
  Future<ExerciseHistoryDetail> loadExerciseHistory(String exerciseId);
  Future<List<BodyMeasurementView>> loadBodyMeasurements({int limit = 120});
  Future<void> saveBodyMeasurement({
    required DateTime measuredAt,
    double? weightKg,
    double? bodyFatPercent,
    String? correctsMeasurementId,
  });
}
