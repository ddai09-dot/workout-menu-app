final class RecordsDashboard {
  const RecordsDashboard({
    required this.sessionsLast30Days,
    required this.workSetsLast30Days,
    required this.minutesLast30Days,
    required this.completedThisWeek,
    required this.plannedThisWeek,
    required this.pendingProposalCount,
    required this.recentSessions,
    this.latestWeightKg,
    this.latestBodyFatPercent,
  });

  final int sessionsLast30Days;
  final int workSetsLast30Days;
  final int minutesLast30Days;
  final int completedThisWeek;
  final int plannedThisWeek;
  final int pendingProposalCount;
  final double? latestWeightKg;
  final double? latestBodyFatPercent;
  final List<WorkoutHistorySummary> recentSessions;
}

final class WorkoutHistorySummary {
  const WorkoutHistorySummary({
    required this.sessionId,
    required this.recordDate,
    required this.startedAt,
    required this.statusCode,
    required this.focusText,
    required this.durationSec,
    required this.exerciseCount,
    required this.workSetCount,
    required this.hadPain,
  });

  final String sessionId;
  final DateTime recordDate;
  final DateTime startedAt;
  final String statusCode;
  final String focusText;
  final int durationSec;
  final int exerciseCount;
  final int workSetCount;
  final bool hadPain;

  String get statusLabel => switch (statusCode) {
        'COMPLETED' => '完了',
        'PARTIAL' => '一部実施',
        _ => '終了',
      };
}

final class WorkoutHistoryDetail {
  const WorkoutHistoryDetail({
    required this.summary,
    required this.difficultyScore,
    required this.exercises,
    this.incompleteReasonCode,
  });

  final WorkoutHistorySummary summary;
  final int difficultyScore;
  final String? incompleteReasonCode;
  final List<WorkoutHistoryExercise> exercises;
}

final class WorkoutHistoryExercise {
  const WorkoutHistoryExercise({
    required this.sessionExerciseId,
    required this.exerciseId,
    required this.name,
    required this.statusCode,
    required this.sets,
    this.resultCode,
    this.resultReason,
    this.progressDetected = false,
    this.stallCount = 0,
  });

  final String sessionExerciseId;
  final String exerciseId;
  final String name;
  final String statusCode;
  final List<WorkoutHistorySet> sets;
  final String? resultCode;
  final String? resultReason;
  final bool progressDetected;
  final int stallCount;
}

final class WorkoutHistorySet {
  const WorkoutHistorySet({
    required this.setNumber,
    required this.sideCode,
    required this.isWarmup,
    this.weightKg,
    this.reps,
    this.durationSec,
    this.assistanceValue,
  });

  final int setNumber;
  final String sideCode;
  final bool isWarmup;
  final double? weightKg;
  final int? reps;
  final int? durationSec;
  final double? assistanceValue;

  String get valueLabel {
    final values = <String>[];
    if (weightKg != null) values.add('${_number(weightKg!)}kg');
    if (assistanceValue != null) values.add('補助${_number(assistanceValue!)}kg');
    if (reps != null) values.add('$reps回');
    if (durationSec != null) values.add('$durationSec秒');
    if (values.isEmpty) return '記録なし';
    return values.join(' × ');
  }
}

final class ExerciseRecordSummary {
  const ExerciseRecordSummary({
    required this.exerciseId,
    required this.name,
    required this.sessionCount,
    required this.lastPerformedAt,
    required this.progressionGroupCode,
    this.latestMetric,
    this.latestResultCode,
    this.stallCount = 0,
  });

  final String exerciseId;
  final String name;
  final int sessionCount;
  final DateTime lastPerformedAt;
  final String progressionGroupCode;
  final double? latestMetric;
  final String? latestResultCode;
  final int stallCount;
}

final class ExerciseHistoryDetail {
  const ExerciseHistoryDetail({
    required this.exerciseId,
    required this.name,
    required this.series,
  });

  final String exerciseId;
  final String name;
  final List<ExerciseSeriesHistory> series;
}

final class ExerciseSeriesHistory {
  const ExerciseSeriesHistory({
    required this.seriesId,
    required this.seriesKey,
    required this.progressionGroupCode,
    required this.targetModeCode,
    required this.stallCount,
    required this.points,
  });

  final String seriesId;
  final String seriesKey;
  final String progressionGroupCode;
  final String targetModeCode;
  final int stallCount;
  final List<ExerciseSeriesPoint> points;
}

final class ExerciseSeriesPoint {
  const ExerciseSeriesPoint({
    required this.date,
    required this.metricValue,
    required this.resultCode,
    required this.progressDetected,
    required this.workSetCount,
    required this.totalReps,
    required this.totalDurationSec,
    this.weightKg,
    this.assistanceValue,
  });

  final DateTime date;
  final double metricValue;
  final String resultCode;
  final bool progressDetected;
  final int workSetCount;
  final int totalReps;
  final int totalDurationSec;
  final double? weightKg;
  final double? assistanceValue;

  String get summary {
    final values = <String>[];
    if (weightKg != null) values.add('${_number(weightKg!)}kg');
    if (assistanceValue != null) values.add('補助${_number(assistanceValue!)}kg');
    if (totalReps > 0) values.add('合計$totalReps回');
    if (totalDurationSec > 0) values.add('合計$totalDurationSec秒');
    return values.isEmpty ? '$workSetCountセット' : values.join('・');
  }
}

final class BodyMeasurementView {
  const BodyMeasurementView({
    required this.id,
    required this.measuredAt,
    this.weightKg,
    this.bodyFatPercent,
  });

  final String id;
  final DateTime measuredAt;
  final double? weightKg;
  final double? bodyFatPercent;
}

String _number(double value) {
  if (value == value.roundToDouble()) return value.toInt().toString();
  return value.toStringAsFixed(1);
}
