import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/records/domain/records_models.dart';
import 'package:workout_menu_app/features/records/presentation/records_notifier.dart';
import 'package:workout_menu_app/features/records/presentation/widgets/simple_line_chart.dart';

final class ExerciseDetailPage extends ConsumerWidget {
  const ExerciseDetailPage({required this.exerciseId, super.key});
  final String exerciseId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final detail = ref.watch(exerciseHistoryProvider(exerciseId));
    return Scaffold(
      appBar: AppBar(title: const Text('種目の推移')),
      body: SafeArea(
        child: detail.when(
          data: (value) => ListView(
            padding: const EdgeInsets.all(20),
            children: <Widget>[
              Text(value.name, style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 6),
              const Text('器具・マシン・バリエーション・左右が同じ系列だけを比較しています。'),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => context.push('/exercise-form/$exerciseId'),
                icon: const Icon(Icons.accessibility_new_outlined),
                label: const Text('フォームを確認'),
              ),
              const SizedBox(height: 20),
              for (final series in value.series) ...<Widget>[
                _SeriesCard(series: series),
                const SizedBox(height: 12),
              ],
            ],
          ),
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => Center(
            child: FilledButton(
              onPressed: () => ref.invalidate(exerciseHistoryProvider(exerciseId)),
              child: const Text('もう一度試す'),
            ),
          ),
        ),
      ),
    );
  }
}

final class _SeriesCard extends StatelessWidget {
  const _SeriesCard({required this.series});
  final ExerciseSeriesHistory series;

  @override
  Widget build(BuildContext context) {
    final visible = series.points.length > 12
        ? series.points.sublist(series.points.length - 12)
        : series.points;
    final best = series.points.isEmpty
        ? null
        : series.points.reduce(
            (a, b) => a.metricValue >= b.metricValue ? a : b,
          );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(
              _seriesLabel(series.seriesKey),
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 4),
            Text('${series.points.length}回の有効記録・停滞カウント ${series.stallCount}'),
            if (best != null) ...<Widget>[
              const SizedBox(height: 8),
              Row(
                children: <Widget>[
                  const Icon(Icons.emoji_events_outlined, size: 20),
                  const SizedBox(width: 6),
                  Expanded(child: Text('自己ベスト：${best.summary}（${best.date.month}/${best.date.day}）')),
                ],
              ),
            ],
            const SizedBox(height: 12),
            SimpleLineChart(values: visible.map((e) => e.metricValue).toList()),
            const SizedBox(height: 8),
            for (final point in visible.reversed.take(5))
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: <Widget>[
                    SizedBox(width: 54, child: Text('${point.date.month}/${point.date.day}')),
                    Expanded(child: Text(point.summary)),
                    if (point.progressDetected)
                      Icon(Icons.arrow_upward, size: 18, color: Theme.of(context).colorScheme.primary),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

String _seriesLabel(String key) {
  final parts = key.split('|').skip(1).map((e) => e.split(':').last).toList();
  return parts.join('・');
}
