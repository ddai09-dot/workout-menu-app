import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/records/domain/records_models.dart';
import 'package:workout_menu_app/features/records/presentation/records_notifier.dart';

final class SessionDetailPage extends ConsumerWidget {
  const SessionDetailPage({required this.sessionId, super.key});
  final String sessionId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final detail = ref.watch(workoutDetailProvider(sessionId));
    return Scaffold(
      appBar: AppBar(title: const Text('トレーニング詳細')),
      body: SafeArea(
        child: detail.when(
          data: (value) => ListView(
            padding: const EdgeInsets.all(20),
            children: <Widget>[
              _Header(detail: value),
              const SizedBox(height: 20),
              for (final exercise in value.exercises) ...<Widget>[
                _ExerciseCard(exercise: exercise),
                const SizedBox(height: 12),
              ],
            ],
          ),
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => Center(
            child: FilledButton(
              onPressed: () => ref.invalidate(workoutDetailProvider(sessionId)),
              child: const Text('もう一度試す'),
            ),
          ),
        ),
      ),
    );
  }
}

final class _Header extends StatelessWidget {
  const _Header({required this.detail});
  final WorkoutHistoryDetail detail;

  @override
  Widget build(BuildContext context) {
    final s = detail.summary;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(s.focusText, style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Text('${s.recordDate.year}/${s.recordDate.month}/${s.recordDate.day}・${s.statusLabel}'),
            const SizedBox(height: 4),
            Text('${s.exerciseCount}種目・${s.workSetCount}セット・${s.durationSec ~/ 60}分'),
            const SizedBox(height: 4),
            Text('全体のきつさ ${detail.difficultyScore}/5'),
            if (s.hadPain) ...<Widget>[
              const SizedBox(height: 8),
              Text(
                '痛みの記録があります。増量判定には使用していません。',
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

final class _ExerciseCard extends StatelessWidget {
  const _ExerciseCard({required this.exercise});
  final WorkoutHistoryExercise exercise;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: () => context.push('/records/exercise/${exercise.exerciseId}'),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      exercise.name,
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ),
                  if (exercise.progressDetected)
                    const Chip(
                      avatar: Icon(Icons.arrow_upward, size: 16),
                      label: Text('進歩'),
                    ),
                  const Icon(Icons.chevron_right),
                ],
              ),
              const SizedBox(height: 10),
              for (final set in exercise.sets)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(
                    children: <Widget>[
                      SizedBox(
                        width: 70,
                        child: Text(set.isWarmup ? '準備 ${set.setNumber}' : 'セット ${set.setNumber}'),
                      ),
                      Expanded(child: Text(set.valueLabel)),
                      if (set.sideCode != 'BOTH') Text(set.sideCode),
                    ],
                  ),
                ),
              if (exercise.resultReason != null) ...<Widget>[
                const Divider(height: 24),
                Text(exercise.resultReason!),
                if (exercise.stallCount >= 1)
                  Text('同条件で進歩なし：${exercise.stallCount}回'),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
