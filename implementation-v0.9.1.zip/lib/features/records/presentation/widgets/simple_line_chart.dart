import 'dart:math' as math;

import 'package:flutter/material.dart';

final class SimpleLineChart extends StatelessWidget {
  const SimpleLineChart({
    required this.values,
    this.height = 180,
    super.key,
  });

  final List<double> values;
  final double height;

  @override
  Widget build(BuildContext context) {
    if (values.length < 2) {
      return SizedBox(
        height: height,
        child: const Center(child: Text('2回以上記録すると推移を表示します。')),
      );
    }
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(
        painter: _LineChartPainter(
          values: values,
          lineColor: Theme.of(context).colorScheme.primary,
          gridColor: Theme.of(context).colorScheme.outlineVariant,
        ),
      ),
    );
  }
}

final class _LineChartPainter extends CustomPainter {
  const _LineChartPainter({
    required this.values,
    required this.lineColor,
    required this.gridColor,
  });

  final List<double> values;
  final Color lineColor;
  final Color gridColor;

  @override
  void paint(Canvas canvas, Size size) {
    const padding = EdgeInsets.fromLTRB(12, 12, 12, 18);
    final width = size.width - padding.horizontal;
    final height = size.height - padding.vertical;
    if (width <= 0 || height <= 0) return;
    var minValue = values.reduce(math.min);
    var maxValue = values.reduce(math.max);
    if ((maxValue - minValue).abs() < 0.0001) {
      minValue -= 1;
      maxValue += 1;
    }
    final gridPaint = Paint()
      ..color = gridColor
      ..strokeWidth = 1;
    for (var i = 0; i <= 3; i++) {
      final y = padding.top + height * i / 3;
      canvas.drawLine(
        Offset(padding.left, y),
        Offset(padding.left + width, y),
        gridPaint,
      );
    }
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = padding.left + width * i / (values.length - 1);
      final normalized = (values[i] - minValue) / (maxValue - minValue);
      final y = padding.top + height * (1 - normalized);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    final linePaint = Paint()
      ..color = lineColor
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(path, linePaint);
    final pointPaint = Paint()..color = lineColor;
    for (var i = 0; i < values.length; i++) {
      final x = padding.left + width * i / (values.length - 1);
      final normalized = (values[i] - minValue) / (maxValue - minValue);
      final y = padding.top + height * (1 - normalized);
      canvas.drawCircle(Offset(x, y), 3.5, pointPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _LineChartPainter oldDelegate) {
    return oldDelegate.values != values ||
        oldDelegate.lineColor != lineColor ||
        oldDelegate.gridColor != gridColor;
  }
}
