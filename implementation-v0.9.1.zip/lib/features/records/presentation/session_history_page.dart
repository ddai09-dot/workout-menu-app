import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/records/domain/records_models.dart';
import 'package:workout_menu_app/features/records/presentation/records_notifier.dart';

final class SessionHistoryPage extends ConsumerWidget {
  const SessionHistoryPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(workoutHistoryProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('トレーニング履歴')),
      body: SafeArea(
        child: history.when(
          data: (items) => items.isEmpty
              ? const Center(child: Text('完了したトレーニングはまだありません。'))
              : RefreshIndicator(
                  onRefresh: () async {
                    await ref.refresh(workoutHistoryProvider.future);
                  },
                  child: ListView.separated(
                    padding: const EdgeInsets.all(20),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (context, index) => _HistoryTile(item: items[index]),
                  ),
                ),
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => Center(
            child: FilledButton(
              onPressed: () => ref.invalidate(workoutHistoryProvider),
              child: const Text('もう一度試す'),
            ),
          ),
        ),
      ),
    );
  }
}

final class _HistoryTile extends StatelessWidget {
  const _HistoryTile({required this.item});
  final WorkoutHistorySummary item;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(child: Text('${item.recordDate.day}')),
        title: Text(item.focusText),
        subtitle: Text(
          '${item.recordDate.year}/${item.recordDate.month}/${item.recordDate.day}・${item.statusLabel}\n'
          '${item.exerciseCount}種目・${item.workSetCount}セット・${item.durationSec ~/ 60}分'
          '${item.hadPain ? '・痛み記録あり' : ''}',
        ),
        isThreeLine: true,
        trailing: const Icon(Icons.chevron_right),
        onTap: () => context.push('/records/session/${item.sessionId}'),
      ),
    );
  }
}
