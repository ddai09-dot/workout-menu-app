import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/records/domain/records_models.dart';
import 'package:workout_menu_app/features/records/presentation/records_notifier.dart';

final class ExerciseListPage extends ConsumerWidget {
  const ExerciseListPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(exerciseRecordSummariesProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('種目別の推移')),
      body: SafeArea(
        child: items.when(
          data: (values) => values.isEmpty
              ? const Center(child: Text('比較できる種目記録はまだありません。'))
              : ListView.separated(
                  padding: const EdgeInsets.all(20),
                  itemCount: values.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) => _ExerciseTile(item: values[index]),
                ),
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => Center(
            child: FilledButton(
              onPressed: () => ref.invalidate(exerciseRecordSummariesProvider),
              child: const Text('もう一度試す'),
            ),
          ),
        ),
      ),
    );
  }
}

final class _ExerciseTile extends StatelessWidget {
  const _ExerciseTile({required this.item});
  final ExerciseRecordSummary item;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(item.name),
        subtitle: Text(
          '${item.sessionCount}回・最終 ${item.lastPerformedAt.month}/${item.lastPerformedAt.day}'
          '${item.stallCount >= 3 ? '・停滞候補' : ''}',
        ),
        leading: Icon(item.stallCount >= 3 ? Icons.pause_circle_outline : Icons.show_chart),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => context.push('/records/exercise/${item.exerciseId}'),
      ),
    );
  }
}
