import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/database/providers/database_providers.dart';
import 'package:workout_menu_app/features/progression/presentation/progression_notifier.dart';
import 'package:workout_menu_app/features/records/data/local_records_repository.dart';
import 'package:workout_menu_app/features/records/domain/records_models.dart';
import 'package:workout_menu_app/features/records/domain/records_repository.dart';

final recordsRepositoryProvider = Provider<RecordsRepository>((ref) {
  return LocalRecordsRepository(ref.watch(appDatabaseProvider));
});

final recordsDashboardProvider = FutureProvider<RecordsDashboard>((ref) async {
  try {
    await ref.watch(progressionRepositoryProvider).processUnevaluatedSessions();
  } catch (_) {
    // Records remain readable even when a deferred evaluation retry fails.
  }
  return ref.watch(recordsRepositoryProvider).loadDashboard();
});

final workoutHistoryProvider = FutureProvider<List<WorkoutHistorySummary>>((ref) {
  return ref.watch(recordsRepositoryProvider).loadWorkoutHistory();
});

final workoutDetailProvider =
    FutureProvider.family<WorkoutHistoryDetail, String>((ref, sessionId) {
  return ref.watch(recordsRepositoryProvider).loadWorkoutDetail(sessionId);
});

final exerciseRecordSummariesProvider =
    FutureProvider<List<ExerciseRecordSummary>>((ref) {
  return ref.watch(recordsRepositoryProvider).loadExerciseSummaries();
});

final exerciseHistoryProvider =
    FutureProvider.family<ExerciseHistoryDetail, String>((ref, exerciseId) {
  return ref.watch(recordsRepositoryProvider).loadExerciseHistory(exerciseId);
});

final bodyMeasurementsProvider =
    AsyncNotifierProvider<BodyMeasurementsNotifier, List<BodyMeasurementView>>(
  BodyMeasurementsNotifier.new,
);

final class BodyMeasurementsNotifier
    extends AsyncNotifier<List<BodyMeasurementView>> {
  @override
  Future<List<BodyMeasurementView>> build() {
    return ref.watch(recordsRepositoryProvider).loadBodyMeasurements();
  }

  Future<bool> save({
    required DateTime measuredAt,
    double? weightKg,
    double? bodyFatPercent,
    String? correctsMeasurementId,
  }) async {
    try {
      final repository = ref.read(recordsRepositoryProvider);
      await repository.saveBodyMeasurement(
        measuredAt: measuredAt,
        weightKg: weightKg,
        bodyFatPercent: bodyFatPercent,
        correctsMeasurementId: correctsMeasurementId,
      );
      state = AsyncData<List<BodyMeasurementView>>(
        await repository.loadBodyMeasurements(),
      );
      ref.invalidate(recordsDashboardProvider);
      return true;
    } catch (error, stackTrace) {
      state = AsyncError<List<BodyMeasurementView>>(error, stackTrace);
      return false;
    }
  }
}
