import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/features/progression/domain/progression_models.dart';
import 'package:workout_menu_app/features/progression/presentation/progression_notifier.dart';
import 'package:workout_menu_app/features/records/presentation/records_notifier.dart';

final class ProgressionProposalsPage extends ConsumerWidget {
  const ProgressionProposalsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final proposals = ref.watch(progressionProposalsProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('次回の調整提案')),
      body: SafeArea(
        child: proposals.when(
          data: (items) => items.isEmpty
              ? const _EmptyView()
              : ListView.separated(
                  padding: const EdgeInsets.all(20),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) => _ProposalCard(
                    proposal: items[index],
                    onDecision: (decision) async {
                      await ref.read(progressionProposalsProvider.notifier).decide(
                            proposalId: items[index].id,
                            decisionCode: decision,
                          );
                      ref.invalidate(recordsDashboardProvider);
                    },
                  ),
                ),
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => Center(
            child: FilledButton(
              onPressed: () => ref.invalidate(progressionProposalsProvider),
              child: const Text('もう一度試す'),
            ),
          ),
        ),
      ),
    );
  }
}

final class _EmptyView extends StatelessWidget {
  const _EmptyView();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(Icons.check_circle_outline, size: 56),
            SizedBox(height: 16),
            Text('確認が必要な提案はありません。'),
            SizedBox(height: 8),
            Text(
              '痛み・睡眠不足・目標未達の状態では、安易な増量を提案しません。',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

final class _ProposalCard extends StatelessWidget {
  const _ProposalCard({required this.proposal, required this.onDecision});
  final ProgressionProposalView proposal;
  final Future<void> Function(String decision) onDecision;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(proposal.exerciseName, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 4),
            Text(proposal.title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            Text(proposal.reasonText),
            const SizedBox(height: 12),
            _ValueChange(proposal: proposal),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: () => onDecision(ProposalDecisionCodes.accept),
              child: Text(proposal.primaryActionLabel),
            ),
            const SizedBox(height: 8),
            Row(
              children: <Widget>[
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => onDecision(ProposalDecisionCodes.maintain),
                    child: const Text('今回は維持'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => onDecision(ProposalDecisionCodes.defer),
                    child: const Text('後で決める'),
                  ),
                ),
              ],
            ),
            TextButton(
              onPressed: () => _confirmReject(context),
              child: const Text('この提案を断る'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmReject(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('提案を断りますか？'),
        content: const Text('同じ提案は、少なくとも2回の完了セッションが終わるまで再表示しません。'),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('戻る')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('断る')),
        ],
      ),
    );
    if (confirmed == true) {
      await onDecision(ProposalDecisionCodes.reject);
    }
  }
}

final class _ValueChange extends StatelessWidget {
  const _ValueChange({required this.proposal});
  final ProgressionProposalView proposal;

  @override
  Widget build(BuildContext context) {
    final current = _displayValue(proposal.currentValue);
    final next = _displayValue(proposal.proposedValue);
    if (current.isEmpty && next.isEmpty) return const SizedBox.shrink();
    return DecoratedBox(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Text(current.isEmpty ? next : '$current → $next'),
      ),
    );
  }
}

String _displayValue(Map<String, Object?> value) {
  final parts = <String>[];
  final weight = value['weightKg'];
  if (weight is num) parts.add('${_number(weight.toDouble())}kg');
  final reps = value['targetRepsUpper'];
  if (reps is num) parts.add('上限${reps.toInt()}回');
  final duration = value['targetDurationSec'];
  if (duration is num) parts.add('${duration.toInt()}秒');
  final totalDuration = value['totalDurationSec'];
  if (totalDuration is num && duration == null) {
    parts.add('合計${totalDuration.toInt()}秒');
  }
  final totalReps = value['totalReps'];
  if (totalReps is num && reps == null) parts.add('合計${totalReps.toInt()}回');
  final assistance = value['assistanceValue'];
  if (assistance is num) parts.add('補助${_number(assistance.toDouble())}kg');
  final sets = value['setCount'];
  if (sets is num) parts.add('${sets.toInt()}セット');
  return parts.join('・');
}

String _number(double value) => value == value.roundToDouble()
    ? value.toInt().toString()
    : value.toStringAsFixed(1);
