import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:workout_menu_app/features/records/domain/records_models.dart';
import 'package:workout_menu_app/features/records/presentation/records_notifier.dart';

final class RecordsPage extends ConsumerWidget {
  const RecordsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dashboard = ref.watch(recordsDashboardProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('記録')),
      body: SafeArea(
        child: dashboard.when(
          data: (value) => RefreshIndicator(
            onRefresh: () async {
              await ref.refresh(recordsDashboardProvider.future);
            },
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
              children: <Widget>[
                _ThisWeekCard(value: value),
                const SizedBox(height: 12),
                _ThirtyDayCard(value: value),
                const SizedBox(height: 12),
                _MeasurementCard(value: value),
                const SizedBox(height: 20),
                Text('見る', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 8),
                Card(
                  child: Column(
                    children: <Widget>[
                      ListTile(
                        leading: const Icon(Icons.history),
                        title: const Text('トレーニング履歴'),
                        subtitle: const Text('実施日ごとの種目・セット・評価'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => context.push('/records/history'),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.trending_up),
                        title: const Text('種目別の推移'),
                        subtitle: const Text('同じ器具・バリエーション系列で比較'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => context.push('/records/exercises'),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.monitor_weight_outlined),
                        title: const Text('体重・体脂肪率'),
                        subtitle: const Text('測定履歴を追記して推移を確認'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => context.push('/records/measurements'),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.tune),
                        title: const Text('次回の調整提案'),
                        subtitle: Text(
                          value.pendingProposalCount == 0
                              ? '現在、確認が必要な提案はありません'
                              : '${value.pendingProposalCount}件の提案があります',
                        ),
                        trailing: value.pendingProposalCount > 0
                            ? Badge(label: Text('${value.pendingProposalCount}'))
                            : const Icon(Icons.chevron_right),
                        onTap: () => context.push('/records/proposals'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Text(
                        '最近のトレーニング',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                    ),
                    TextButton(
                      onPressed: () => context.push('/records/history'),
                      child: const Text('すべて見る'),
                    ),
                  ],
                ),
                if (value.recentSessions.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Text('完了したトレーニングはまだありません。'),
                    ),
                  )
                else
                  for (final session in value.recentSessions) ...<Widget>[
                    _RecentSessionTile(session: session),
                    const SizedBox(height: 8),
                  ],
              ],
            ),
          ),
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => _ErrorView(
            onRetry: () => ref.invalidate(recordsDashboardProvider),
          ),
        ),
      ),
    );
  }
}

final class _ThisWeekCard extends StatelessWidget {
  const _ThisWeekCard({required this.value});
  final RecordsDashboard value;

  @override
  Widget build(BuildContext context) {
    final progress = value.plannedThisWeek == 0
        ? 0.0
        : value.completedThisWeek / value.plannedThisWeek;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('今週', style: Theme.of(context).textTheme.labelLarge),
            const SizedBox(height: 8),
            Text(
              '${value.completedThisWeek} / ${value.plannedThisWeek}日 完了',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 12),
            LinearProgressIndicator(value: progress.clamp(0.0, 1.0).toDouble()),
          ],
        ),
      ),
    );
  }
}

final class _ThirtyDayCard extends StatelessWidget {
  const _ThirtyDayCard({required this.value});
  final RecordsDashboard value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('直近30日', style: Theme.of(context).textTheme.labelLarge),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                Expanded(child: _Metric(value: '${value.sessionsLast30Days}', label: '回')),
                Expanded(child: _Metric(value: '${value.workSetsLast30Days}', label: 'セット')),
                Expanded(child: _Metric(value: '${value.minutesLast30Days}', label: '分')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

final class _MeasurementCard extends StatelessWidget {
  const _MeasurementCard({required this.value});
  final RecordsDashboard value;

  @override
  Widget build(BuildContext context) {
    String label(double? value, String suffix) =>
        value == null ? '未記録' : '${_number(value)}$suffix';
    return Card(
      child: InkWell(
        onTap: () => context.push('/records/measurements'),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: <Widget>[
              const Icon(Icons.monitor_weight_outlined, size: 32),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text('最新の身体測定'),
                    const SizedBox(height: 4),
                    Text(
                      '${label(value.latestWeightKg, 'kg')}・${label(value.latestBodyFatPercent, '%')}',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}

final class _Metric extends StatelessWidget {
  const _Metric({required this.value, required this.label});
  final String value;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(value, style: Theme.of(context).textTheme.headlineMedium),
        Text(label),
      ],
    );
  }
}

final class _RecentSessionTile extends StatelessWidget {
  const _RecentSessionTile({required this.session});
  final WorkoutHistorySummary session;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(session.focusText),
        subtitle: Text(
          '${_date(session.recordDate)}・${session.exerciseCount}種目・${session.workSetCount}セット・${session.durationSec ~/ 60}分',
        ),
        leading: CircleAvatar(child: Text('${session.recordDate.day}')),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => context.push('/records/session/${session.sessionId}'),
      ),
    );
  }
}

final class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Text('記録を読み込めませんでした。'),
            const SizedBox(height: 16),
            FilledButton(onPressed: onRetry, child: const Text('もう一度試す')),
          ],
        ),
      ),
    );
  }
}

String _date(DateTime value) => '${value.month}/${value.day}';
String _number(double? value) {
  if (value == null) return '';
  return value == value.roundToDouble()
      ? value.toInt().toString()
      : value.toStringAsFixed(1);
}
