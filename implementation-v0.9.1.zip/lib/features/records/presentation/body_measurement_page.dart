import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/features/records/domain/records_models.dart';
import 'package:workout_menu_app/features/records/presentation/records_notifier.dart';
import 'package:workout_menu_app/features/records/presentation/widgets/simple_line_chart.dart';

final class BodyMeasurementPage extends ConsumerWidget {
  const BodyMeasurementPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final measurements = ref.watch(bodyMeasurementsProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('体重・体脂肪率')),
      body: SafeArea(
        child: measurements.when(
          data: (items) => ListView(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 100),
            children: <Widget>[
              _ChartCard(
                title: '体重の推移',
                unit: 'kg',
                values: items.reversed
                    .map((e) => e.weightKg)
                    .whereType<double>()
                    .toList(),
              ),
              const SizedBox(height: 12),
              _ChartCard(
                title: '体脂肪率の推移',
                unit: '%',
                values: items.reversed
                    .map((e) => e.bodyFatPercent)
                    .whereType<double>()
                    .toList(),
              ),
              const SizedBox(height: 20),
              Text('測定履歴', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              if (items.isEmpty)
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Text('測定記録はまだありません。'),
                  ),
                )
              else
                for (final item in items) ...<Widget>[
                  _MeasurementTile(
                    item: item,
                    onCorrect: () => _openEditor(context, ref, item),
                  ),
                  const SizedBox(height: 8),
                ],
            ],
          ),
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => Center(
            child: FilledButton(
              onPressed: () => ref.invalidate(bodyMeasurementsProvider),
              child: const Text('もう一度試す'),
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(context, ref, null),
        icon: const Icon(Icons.add),
        label: const Text('測定を追加'),
      ),
    );
  }

  Future<void> _openEditor(
    BuildContext context,
    WidgetRef ref,
    BodyMeasurementView? current,
  ) async {
    final result = await showModalBottomSheet<_MeasurementDraft>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (context) => _MeasurementEditor(current: current),
    );
    if (result == null || !context.mounted) return;
    final saved = await ref.read(bodyMeasurementsProvider.notifier).save(
          measuredAt: result.measuredAt,
          weightKg: result.weightKg,
          bodyFatPercent: result.bodyFatPercent,
          correctsMeasurementId: current?.id,
        );
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(saved ? '測定を保存しました。' : '測定を保存できませんでした。')),
    );
  }
}

final class _ChartCard extends StatelessWidget {
  const _ChartCard({
    required this.title,
    required this.unit,
    required this.values,
  });

  final String title;
  final String unit;
  final List<double> values;

  @override
  Widget build(BuildContext context) {
    final latest = values.isEmpty ? null : values.last;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            if (latest != null) ...<Widget>[
              const SizedBox(height: 4),
              Text('${_number(latest)}$unit', style: Theme.of(context).textTheme.headlineSmall),
            ],
            const SizedBox(height: 8),
            SimpleLineChart(values: values, height: 150),
          ],
        ),
      ),
    );
  }
}

final class _MeasurementTile extends StatelessWidget {
  const _MeasurementTile({required this.item, required this.onCorrect});
  final BodyMeasurementView item;
  final VoidCallback onCorrect;

  @override
  Widget build(BuildContext context) {
    final values = <String>[];
    if (item.weightKg != null) values.add('${_number(item.weightKg!)}kg');
    if (item.bodyFatPercent != null) values.add('${_number(item.bodyFatPercent!)}%');
    return Card(
      child: ListTile(
        title: Text(values.join('・')),
        subtitle: Text(
          '${item.measuredAt.year}/${item.measuredAt.month}/${item.measuredAt.day} '
          '${item.measuredAt.hour.toString().padLeft(2, '0')}:${item.measuredAt.minute.toString().padLeft(2, '0')}',
        ),
        trailing: TextButton(onPressed: onCorrect, child: const Text('訂正')),
      ),
    );
  }
}

final class _MeasurementEditor extends StatefulWidget {
  const _MeasurementEditor({this.current});
  final BodyMeasurementView? current;

  @override
  State<_MeasurementEditor> createState() => _MeasurementEditorState();
}

final class _MeasurementEditorState extends State<_MeasurementEditor> {
  late final TextEditingController _weight;
  late final TextEditingController _bodyFat;
  late DateTime _measuredAt;
  String? _error;

  @override
  void initState() {
    super.initState();
    _weight = TextEditingController(
      text: widget.current?.weightKg == null ? '' : _number(widget.current!.weightKg!),
    );
    _bodyFat = TextEditingController(
      text: widget.current?.bodyFatPercent == null
          ? ''
          : _number(widget.current!.bodyFatPercent!),
    );
    _measuredAt = widget.current?.measuredAt ?? DateTime.now();
  }

  @override
  void dispose() {
    _weight.dispose();
    _bodyFat.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.viewInsetsOf(context).bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            widget.current == null ? '測定を追加' : '測定を訂正',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _weight,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: '体重（kg）', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _bodyFat,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: '体脂肪率（%）', border: OutlineInputBorder()),
          ),
          if (_error != null) ...<Widget>[
            const SizedBox(height: 8),
            Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
          const SizedBox(height: 20),
          FilledButton(onPressed: _submit, child: const Text('保存する')),
        ],
      ),
    );
  }

  void _submit() {
    final weight = double.tryParse(_weight.text.trim());
    final bodyFat = double.tryParse(_bodyFat.text.trim());
    if (weight == null && bodyFat == null) {
      setState(() => _error = '体重または体脂肪率を入力してください。');
      return;
    }
    if (weight != null && (weight < 20 || weight > 400)) {
      setState(() => _error = '体重は20〜400kgで入力してください。');
      return;
    }
    if (bodyFat != null && (bodyFat < 2 || bodyFat > 70)) {
      setState(() => _error = '体脂肪率は2〜70%で入力してください。');
      return;
    }
    Navigator.of(context).pop(
      _MeasurementDraft(
        measuredAt: _measuredAt,
        weightKg: weight,
        bodyFatPercent: bodyFat,
      ),
    );
  }
}

final class _MeasurementDraft {
  const _MeasurementDraft({
    required this.measuredAt,
    this.weightKg,
    this.bodyFatPercent,
  });
  final DateTime measuredAt;
  final double? weightKg;
  final double? bodyFatPercent;
}

String _number(double value) => value == value.roundToDouble()
    ? value.toInt().toString()
    : value.toStringAsFixed(1);
