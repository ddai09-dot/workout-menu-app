abstract interface class EntitlementRepository {
  Future<EntitlementState> load();
  Stream<EntitlementState> watch();
}

final class EntitlementState {
  const EntitlementState({
    required this.isPremium,
    required this.activeProductId,
  });

  const EntitlementState.free()
      : isPremium = false,
        activeProductId = null;

  final bool isPremium;
  final String? activeProductId;
}
