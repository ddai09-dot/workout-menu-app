import 'dart:convert';

abstract final class ProgressionResultCodes {
  static const pain = 'RS_PAIN';
  static const noData = 'RS_NO_DATA';
  static const contextIncomplete = 'RS_CONTEXT_INCOMPLETE';
  static const fatigueIncomplete = 'RS_FATIGUE_INCOMPLETE';
  static const allUpper = 'RS_ALL_UPPER';
  static const inRange = 'RS_IN_RANGE';
  static const oneSlightBelow = 'RS_ONE_SLIGHT_BELOW';
  static const severeMiss = 'RS_SEVERE_MISS';
  static const multipleBelow = 'RS_MULTIPLE_BELOW';
  static const mixedLoad = 'RS_MIXED_LOAD';
}

abstract final class ProgressionProposalTypes {
  static const increaseWeight = 'INCREASE_WEIGHT';
  static const reduceWeight = 'REDUCE_WEIGHT';
  static const extendReps = 'EXTEND_REPS';
  static const increaseDuration = 'INCREASE_DURATION';
  static const reduceAssistance = 'REDUCE_ASSISTANCE';
  static const advanceVariation = 'ADVANCE_VARIATION';
  static const addSet = 'ADD_SET';
  static const reduceSet = 'REDUCE_SET';
  static const changeRepRange = 'CHANGE_REP_RANGE';
  static const adjustTime = 'ADJUST_TIME';
  static const alternativeExercise = 'ALTERNATIVE_EXERCISE';
}

abstract final class ProposalDecisionCodes {
  static const accept = 'ACCEPT';
  static const maintain = 'MAINTAIN';
  static const defer = 'DEFER';
  static const reject = 'REJECT';
}

final class ProgressionSetSample {
  const ProgressionSetSample({
    required this.setNumber,
    required this.sideCode,
    required this.isWarmup,
    this.actualWeightKg,
    this.actualReps,
    this.actualDurationSec,
    this.assistanceValue,
    this.variationCode,
    this.equipmentModeCode,
    this.machineInstanceKey,
    this.targetRepsLower,
    this.targetRepsUpper,
    this.targetDurationSec,
  });

  final int setNumber;
  final String sideCode;
  final bool isWarmup;
  final double? actualWeightKg;
  final int? actualReps;
  final int? actualDurationSec;
  final double? assistanceValue;
  final String? variationCode;
  final String? equipmentModeCode;
  final String? machineInstanceKey;
  final int? targetRepsLower;
  final int? targetRepsUpper;
  final int? targetDurationSec;

  Map<String, Object?> toJson() => <String, Object?>{
        'setNumber': setNumber,
        'sideCode': sideCode,
        'isWarmup': isWarmup,
        'actualWeightKg': actualWeightKg,
        'actualReps': actualReps,
        'actualDurationSec': actualDurationSec,
        'assistanceValue': assistanceValue,
        'variationCode': variationCode,
        'equipmentModeCode': equipmentModeCode,
        'machineInstanceKey': machineInstanceKey,
        'targetRepsLower': targetRepsLower,
        'targetRepsUpper': targetRepsUpper,
        'targetDurationSec': targetDurationSec,
      };
}

final class ProgressionExerciseInput {
  const ProgressionExerciseInput({
    required this.userId,
    required this.workoutSessionId,
    required this.sessionExerciseId,
    required this.exerciseId,
    required this.exerciseName,
    required this.roleCode,
    required this.recordingMethodCode,
    required this.progressionGroupCode,
    required this.targetModeCode,
    required this.goalCode,
    required this.difficultyScore,
    required this.sleepScore,
    required this.statusCode,
    required this.hadPain,
    required this.incompleteReasonCode,
    required this.sets,
  });

  final String userId;
  final String workoutSessionId;
  final String sessionExerciseId;
  final String exerciseId;
  final String exerciseName;
  final String roleCode;
  final String recordingMethodCode;
  final String progressionGroupCode;
  final String targetModeCode;
  final String goalCode;
  final int difficultyScore;
  final int sleepScore;
  final String statusCode;
  final bool hadPain;
  final String? incompleteReasonCode;
  final List<ProgressionSetSample> sets;

  List<ProgressionSetSample> get workSets => sets
      .where((ProgressionSetSample value) => !value.isWarmup)
      .toList(growable: false);
}

final class ProgressionClassification {
  const ProgressionClassification({
    required this.code,
    required this.validForPerformance,
    required this.reasonText,
    required this.workSetCount,
    required this.totalReps,
    required this.totalDurationSec,
    required this.mixedLoad,
    this.minimumReps,
    this.maximumReps,
    this.representativeWeightKg,
    this.representativeAssistanceValue,
    this.metricValue,
  });

  final String code;
  final bool validForPerformance;
  final String reasonText;
  final int workSetCount;
  final int totalReps;
  final int totalDurationSec;
  final int? minimumReps;
  final int? maximumReps;
  final double? representativeWeightKg;
  final double? representativeAssistanceValue;
  final double? metricValue;
  final bool mixedLoad;

  Map<String, Object?> toJson() => <String, Object?>{
        'code': code,
        'validForPerformance': validForPerformance,
        'reasonText': reasonText,
        'workSetCount': workSetCount,
        'totalReps': totalReps,
        'totalDurationSec': totalDurationSec,
        'minimumReps': minimumReps,
        'maximumReps': maximumReps,
        'representativeWeightKg': representativeWeightKg,
        'representativeAssistanceValue': representativeAssistanceValue,
        'metricValue': metricValue,
        'mixedLoad': mixedLoad,
      };
}

final class PreviousEvaluationSnapshot {
  const PreviousEvaluationSnapshot({
    required this.resultCode,
    required this.workSetCount,
    required this.totalReps,
    required this.totalDurationSec,
    required this.stallCount,
    this.minimumReps,
    this.representativeWeightKg,
    this.representativeAssistanceValue,
    this.metricValue,
  });

  final String resultCode;
  final int workSetCount;
  final int totalReps;
  final int totalDurationSec;
  final int? minimumReps;
  final double? representativeWeightKg;
  final double? representativeAssistanceValue;
  final double? metricValue;
  final int stallCount;
}

final class ProgressionDecisionContext {
  const ProgressionDecisionContext({
    required this.input,
    required this.classification,
    required this.stallCount,
    required this.consecutiveAllUpper,
    required this.consecutiveLow,
    required this.currentSetCount,
    required this.profileSetUpper,
    this.previous,
    this.nextRegisteredWeightKg,
    this.previousRegisteredWeightKg,
    this.nextRegisteredAssistanceValue,
  });

  final ProgressionExerciseInput input;
  final ProgressionClassification classification;
  final PreviousEvaluationSnapshot? previous;
  final int stallCount;
  final int consecutiveAllUpper;
  final int consecutiveLow;
  final int currentSetCount;
  final int profileSetUpper;
  final double? nextRegisteredWeightKg;
  final double? previousRegisteredWeightKg;
  final double? nextRegisteredAssistanceValue;
}

final class ProgressionProposalDraft {
  const ProgressionProposalDraft({
    required this.typeCode,
    required this.priority,
    required this.reasonText,
    required this.currentValue,
    required this.proposedValue,
  });

  final String typeCode;
  final int priority;
  final String reasonText;
  final Map<String, Object?> currentValue;
  final Map<String, Object?> proposedValue;

  String get currentValueJson => jsonEncode(currentValue);
  String get proposedValueJson => jsonEncode(proposedValue);
}

final class ProgressionProposalView {
  const ProgressionProposalView({
    required this.id,
    required this.exerciseId,
    required this.exerciseName,
    required this.typeCode,
    required this.statusCode,
    required this.reasonText,
    required this.createdAt,
    required this.priority,
    required this.currentValue,
    required this.proposedValue,
  });

  final String id;
  final String exerciseId;
  final String exerciseName;
  final String typeCode;
  final String statusCode;
  final String reasonText;
  final DateTime createdAt;
  final int priority;
  final Map<String, Object?> currentValue;
  final Map<String, Object?> proposedValue;

  bool get requiresManualChoice => <String>{
        ProgressionProposalTypes.advanceVariation,
        ProgressionProposalTypes.changeRepRange,
        ProgressionProposalTypes.adjustTime,
        ProgressionProposalTypes.alternativeExercise,
      }.contains(typeCode);

  String get primaryActionLabel =>
      requiresManualChoice ? '次回作成時に確認する' : '次回へ反映する';

  String get title => switch (typeCode) {
        ProgressionProposalTypes.increaseWeight => '重量を上げる',
        ProgressionProposalTypes.reduceWeight => '重量を下げる',
        ProgressionProposalTypes.extendReps => '回数目標を延長する',
        ProgressionProposalTypes.increaseDuration => '保持時間を延ばす',
        ProgressionProposalTypes.reduceAssistance => '補助量を減らす',
        ProgressionProposalTypes.advanceVariation => '難度を一段階上げる',
        ProgressionProposalTypes.addSet => 'セットを1つ追加する',
        ProgressionProposalTypes.reduceSet => 'セットを1つ減らす',
        ProgressionProposalTypes.changeRepRange => '回数帯を変更する',
        ProgressionProposalTypes.adjustTime => '時間内に収まるよう調整する',
        ProgressionProposalTypes.alternativeExercise => '代替種目を検討する',
        _ => '次回条件を調整する',
      };
}

Map<String, Object?> decodeObjectJson(String? source) {
  if (source == null || source.isEmpty) return const <String, Object?>{};
  final value = jsonDecode(source);
  if (value is! Map<String, dynamic>) return const <String, Object?>{};
  return value.cast<String, Object?>();
}
