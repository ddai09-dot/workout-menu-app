import 'package:workout_menu_app/features/progression/domain/progression_models.dart';

abstract interface class ProgressionRepository {
  Future<void> processCompletedSession(String workoutSessionId);
  Future<void> processUnevaluatedSessions();
  Future<List<ProgressionProposalView>> loadProposals({
    Set<String> statusCodes = const <String>{'PENDING', 'DEFERRED'},
  });
  Future<void> decideProposal({
    required String proposalId,
    required String decisionCode,
  });
  Future<int> pendingProposalCount();
}
