import 'package:workout_menu_app/features/progression/domain/progression_models.dart';

final class ProgressionEngine {
  const ProgressionEngine();

  ProgressionProposalDraft? propose(ProgressionDecisionContext context) {
    final input = context.input;
    final result = context.classification;

    if (result.code == ProgressionResultCodes.pain) {
      return ProgressionProposalDraft(
        typeCode: ProgressionProposalTypes.alternativeExercise,
        priority: 1,
        reasonText: '痛みが記録されたため、増量せず、次回は負荷低減または代替種目を確認します。',
        currentValue: _current(context),
        proposedValue: const <String, Object?>{
          'action': 'REVIEW_PAIN_ALTERNATIVE',
          'automaticLoadIncrease': false,
        },
      );
    }
    if (result.code == ProgressionResultCodes.contextIncomplete) {
      if (input.incompleteReasonCode == 'TIME' ||
          input.incompleteReasonCode == 'MOVED_DAY') {
        return ProgressionProposalDraft(
          typeCode: ProgressionProposalTypes.adjustTime,
          priority: 30,
          reasonText: '時間の事情による未完了のため、負荷を下げず、次回は時間内に収まる構成を提案します。',
          currentValue: _current(context),
          proposedValue: const <String, Object?>{
            'action': 'FIT_WITHIN_AVAILABLE_TIME',
          },
        );
      }
      return null;
    }
    if (result.code == ProgressionResultCodes.noData ||
        result.code == ProgressionResultCodes.mixedLoad) {
      return null;
    }
    if (result.code == ProgressionResultCodes.fatigueIncomplete ||
        input.difficultyScore == 5) {
      if (context.currentSetCount > 1) {
        return ProgressionProposalDraft(
          typeCode: ProgressionProposalTypes.reduceSet,
          priority: 5,
          reasonText: input.difficultyScore == 5
              ? '全体のきつさが5だったため、増量せず次回は1セット減らす候補です。'
              : '疲労で未完了だったため、次回は1セット減らす候補です。',
          currentValue: _current(context),
          proposedValue: <String, Object?>{
            'setCount': context.currentSetCount - 1,
          },
        );
      }
      final lower = context.previousRegisteredWeightKg;
      if (lower != null) {
        return ProgressionProposalDraft(
          typeCode: ProgressionProposalTypes.reduceWeight,
          priority: 5,
          reasonText: '疲労または過負荷のため、登録済みの1段階軽い重量を候補にします。',
          currentValue: _current(context),
          proposedValue: <String, Object?>{'weightKg': lower},
        );
      }
      return null;
    }

    if (result.code == ProgressionResultCodes.allUpper) {
      if (input.sleepScore <= 2 || input.difficultyScore >= 4) {
        return null;
      }
      final requiresRepeatedConfirmation = _requiresRepeatedConfirmation(context);
      if (requiresRepeatedConfirmation && context.consecutiveAllUpper < 2) {
        return _extendReps(context, '次の負荷差が大きい、または慎重な目的設定のため、同条件でもう1回確認します。');
      }
      if (input.progressionGroupCode == 'PG08_TIME_HOLD') {
        final current = result.totalDurationSec ~/ context.currentSetCount;
        return ProgressionProposalDraft(
          typeCode: ProgressionProposalTypes.increaseDuration,
          priority: 20,
          reasonText: '全セットで保持時間の上限を達成したため、次回は各セットを5秒延長する候補です。',
          currentValue: _current(context),
          proposedValue: <String, Object?>{'targetDurationSec': current + 5},
        );
      }
      if (input.progressionGroupCode == 'PG07_ASSISTANCE_REVERSE') {
        final next = context.nextRegisteredAssistanceValue;
        if (next != null) {
          return ProgressionProposalDraft(
            typeCode: ProgressionProposalTypes.reduceAssistance,
            priority: 15,
            reasonText: '全セットで上限を達成したため、登録済みの1段階少ない補助量を候補にします。',
            currentValue: _current(context),
            proposedValue: <String, Object?>{'assistanceValue': next},
          );
        }
        return _extendReps(context, '補助量の次候補が登録されていないため、回数を延長して確認します。');
      }
      if (<String>{
        'PG05_BODYWEIGHT_REPS',
        'PG06_BODYWEIGHT_LOADABLE',
        'PG09_BAND_STEPS',
        'PG11_VARIATION_FIRST',
      }.contains(input.progressionGroupCode) &&
          context.nextRegisteredWeightKg == null) {
        return ProgressionProposalDraft(
          typeCode: ProgressionProposalTypes.advanceVariation,
          priority: 25,
          reasonText: '同じバリエーションで全セットの上限を達成したため、次回は難度を一段階上げる候補です。',
          currentValue: _current(context),
          proposedValue: const <String, Object?>{
            'requiresUserSelection': true,
            'step': 1,
          },
        );
      }
      final nextWeight = context.nextRegisteredWeightKg;
      final currentWeight = result.representativeWeightKg;
      if (nextWeight != null && currentWeight != null) {
        final stepRate = currentWeight == 0 ? 0 : (nextWeight - currentWeight) / currentWeight;
        if (stepRate > 0.075 && context.consecutiveAllUpper < 2) {
          return _extendReps(context, '次の登録重量との差が7.5%を超えるため、回数上限を延長して2回確認します。');
        }
        return ProgressionProposalDraft(
          typeCode: ProgressionProposalTypes.increaseWeight,
          priority: 20,
          reasonText: '全ワークセットで目標上限を達成したため、登録済みの次重量を候補にします。',
          currentValue: _current(context),
          proposedValue: <String, Object?>{
            'weightKg': nextWeight,
            'stepRate': stepRate,
          },
        );
      }
      return _extendReps(context, '次に使用できる重量が登録されていないため、回数を延長します。');
    }

    if (<String>{
      ProgressionResultCodes.severeMiss,
      ProgressionResultCodes.multipleBelow,
    }.contains(result.code) &&
        context.consecutiveLow >= 2) {
      final lower = context.previousRegisteredWeightKg;
      if (lower != null) {
        return ProgressionProposalDraft(
          typeCode: ProgressionProposalTypes.reduceWeight,
          priority: 10,
          reasonText: '目標下限未達が2回連続したため、登録済みの1段階軽い重量を候補にします。',
          currentValue: _current(context),
          proposedValue: <String, Object?>{'weightKg': lower},
        );
      }
      if (context.currentSetCount > 1) {
        return ProgressionProposalDraft(
          typeCode: ProgressionProposalTypes.reduceSet,
          priority: 10,
          reasonText: '目標下限未達が続き、軽い登録重量がないため、次回は1セット減らす候補です。',
          currentValue: _current(context),
          proposedValue: <String, Object?>{
            'setCount': context.currentSetCount - 1,
          },
        );
      }
    }

    if (context.stallCount >= 3) {
      if (input.sleepScore >= 3 && input.difficultyScore <= 3 &&
          context.currentSetCount < context.profileSetUpper) {
        return ProgressionProposalDraft(
          typeCode: ProgressionProposalTypes.addSet,
          priority: 40,
          reasonText: '同じ系列で3回進歩がなく、きつさは1〜3のため、次回は1セット追加する候補です。',
          currentValue: _current(context),
          proposedValue: <String, Object?>{
            'setCount': context.currentSetCount + 1,
          },
        );
      }
      return ProgressionProposalDraft(
        typeCode: ProgressionProposalTypes.changeRepRange,
        priority: 45,
        reasonText: '同じ系列で3回進歩がなく、セット上限付近のため、回数帯または種目順を見直す候補です。',
        currentValue: _current(context),
        proposedValue: const <String, Object?>{
          'requiresUserSelection': true,
          'action': 'REVIEW_REP_RANGE_OR_ORDER',
        },
      );
    }
    return null;
  }

  bool _requiresRepeatedConfirmation(ProgressionDecisionContext context) {
    final input = context.input;
    if (input.goalCode == 'STRENGTH' && input.roleCode.contains('MAJOR')) {
      return true;
    }
    if (input.goalCode == 'HEALTH') return true;
    return false;
  }

  ProgressionProposalDraft _extendReps(
    ProgressionDecisionContext context,
    String reason,
  ) {
    final currentUpper = context.input.workSets
        .map((ProgressionSetSample value) => value.targetRepsUpper)
        .whereType<int>()
        .fold<int>(0, (int value, int next) => next > value ? next : value);
    final extension = context.input.progressionGroupCode == 'PG02_WEIGHTED_ACCESSORY'
        ? 2
        : 1;
    return ProgressionProposalDraft(
      typeCode: ProgressionProposalTypes.extendReps,
      priority: 25,
      reasonText: reason,
      currentValue: _current(context),
      proposedValue: <String, Object?>{
        'targetRepsUpper': currentUpper + extension,
      },
    );
  }

  Map<String, Object?> _current(ProgressionDecisionContext context) {
    final result = context.classification;
    return <String, Object?>{
      'weightKg': result.representativeWeightKg,
      'assistanceValue': result.representativeAssistanceValue,
      'totalReps': result.totalReps,
      'totalDurationSec': result.totalDurationSec,
      'setCount': context.currentSetCount,
      'resultClassCode': result.code,
      'stallCount': context.stallCount,
    };
  }
}
