import 'package:workout_menu_app/features/progression/domain/progression_models.dart';

final class ResultClassifier {
  const ResultClassifier();

  static const Set<String> _contextReasons = <String>{
    'TIME',
    'EQUIPMENT',
    'URGENT',
    'APP_ERROR',
    'MOVED_DAY',
  };

  ProgressionClassification classify(ProgressionExerciseInput input) {
    final sets = input.workSets;
    final totalReps = sets.fold<int>(
      0,
      (int sum, ProgressionSetSample value) => sum + (value.actualReps ?? 0),
    );
    final totalDuration = sets.fold<int>(
      0,
      (int sum, ProgressionSetSample value) =>
          sum + (value.actualDurationSec ?? 0),
    );
    final reps = sets
        .map((ProgressionSetSample value) => value.actualReps)
        .whereType<int>()
        .toList(growable: false);
    final weights = sets
        .map((ProgressionSetSample value) => value.actualWeightKg)
        .whereType<double>()
        .map((double value) => (value * 1000).round() / 1000)
        .toSet();
    final assists = sets
        .map((ProgressionSetSample value) => value.assistanceValue)
        .whereType<double>()
        .map((double value) => (value * 1000).round() / 1000)
        .toSet();
    final mixedLoad = weights.length > 1 || assists.length > 1;
    final representativeWeight = weights.length == 1 ? weights.first : null;
    final representativeAssistance = assists.length == 1 ? assists.first : null;
    final metric = _metric(
      input: input,
      totalReps: totalReps,
      totalDuration: totalDuration,
      weight: representativeWeight,
      assistance: representativeAssistance,
    );

    ProgressionClassification result({
      required String code,
      required bool valid,
      required String reason,
    }) {
      return ProgressionClassification(
        code: code,
        validForPerformance: valid,
        reasonText: reason,
        workSetCount: sets.length,
        totalReps: totalReps,
        totalDurationSec: totalDuration,
        minimumReps: reps.isEmpty ? null : reps.reduce((int a, int b) => a < b ? a : b),
        maximumReps: reps.isEmpty ? null : reps.reduce((int a, int b) => a > b ? a : b),
        representativeWeightKg: representativeWeight,
        representativeAssistanceValue: representativeAssistance,
        metricValue: metric,
        mixedLoad: mixedLoad,
      );
    }

    if (input.hadPain || input.incompleteReasonCode == 'PAIN_STOP') {
      return result(
        code: ProgressionResultCodes.pain,
        valid: false,
        reason: '痛みが記録されたため、性能評価より安全対応を優先します。',
      );
    }
    if (sets.isEmpty) {
      return result(
        code: ProgressionResultCodes.noData,
        valid: false,
        reason: '有効なワークセットがないため、次回負荷を自動判定しません。',
      );
    }
    if (input.statusCode != 'COMPLETED' &&
        _contextReasons.contains(input.incompleteReasonCode)) {
      return result(
        code: ProgressionResultCodes.contextIncomplete,
        valid: false,
        reason: '時間・器具などの事情による未完了のため、成績低下には数えません。',
      );
    }
    if (input.statusCode != 'COMPLETED' &&
        input.incompleteReasonCode == 'FATIGUE') {
      return result(
        code: ProgressionResultCodes.fatigueIncomplete,
        valid: true,
        reason: '疲労による未完了として、次回の負荷またはセット数を見直します。',
      );
    }
    if (mixedLoad) {
      return result(
        code: ProgressionResultCodes.mixedLoad,
        valid: false,
        reason: '評価対象セットの負荷が混在しているため、自動増量は行いません。',
      );
    }

    final durationMode = input.targetModeCode == 'DURATION' ||
        input.recordingMethodCode == 'DURATION';
    if (durationMode) {
      final values = sets
          .map((ProgressionSetSample value) => value.actualDurationSec)
          .whereType<int>()
          .toList(growable: false);
      if (values.length != sets.length) {
        return result(
          code: ProgressionResultCodes.noData,
          valid: false,
          reason: '保持時間が不足しているため評価できません。',
        );
      }
      final uppers = sets
          .map((ProgressionSetSample value) => value.targetDurationSec)
          .whereType<int>()
          .toList(growable: false);
      final allUpper = uppers.length == sets.length &&
          List<int>.generate(sets.length, (int i) => i)
              .every((int i) => values[i] >= uppers[i]);
      if (allUpper) {
        return result(
          code: ProgressionResultCodes.allUpper,
          valid: true,
          reason: '全ワークセットで保持時間の目標を達成しました。',
        );
      }
      return result(
        code: ProgressionResultCodes.inRange,
        valid: true,
        reason: '同じ条件で保持時間を伸ばす段階です。',
      );
    }

    if (reps.length != sets.length) {
      return result(
        code: ProgressionResultCodes.noData,
        valid: false,
        reason: '回数記録が不足しているため評価できません。',
      );
    }
    final lowers = sets
        .map((ProgressionSetSample value) => value.targetRepsLower)
        .whereType<int>()
        .toList(growable: false);
    final uppers = sets
        .map((ProgressionSetSample value) => value.targetRepsUpper)
        .whereType<int>()
        .toList(growable: false);
    if (lowers.length != sets.length || uppers.length != sets.length) {
      return result(
        code: ProgressionResultCodes.inRange,
        valid: true,
        reason: '有効な記録として保存しました。回数帯が未設定のため増量は提案しません。',
      );
    }
    final indexes = List<int>.generate(sets.length, (int i) => i);
    if (indexes.every((int i) => reps[i] >= uppers[i])) {
      return result(
        code: ProgressionResultCodes.allUpper,
        valid: true,
        reason: '全ワークセットで目標回数の上限を達成しました。',
      );
    }
    if (indexes.every((int i) => reps[i] >= lowers[i])) {
      return result(
        code: ProgressionResultCodes.inRange,
        valid: true,
        reason: '全セットが目標範囲内です。同じ条件で回数を伸ばします。',
      );
    }
    final below = indexes.where((int i) => reps[i] < lowers[i]).toList();
    if (below.any((int i) => reps[i] <= lowers[i] - 2)) {
      return result(
        code: ProgressionResultCodes.severeMiss,
        valid: true,
        reason: '目標下限を2回以上下回るセットがありました。原因を確認します。',
      );
    }
    if (below.length == 1 && reps[below.single] == lowers[below.single] - 1) {
      return result(
        code: ProgressionResultCodes.oneSlightBelow,
        valid: true,
        reason: '1セットだけ目標下限を1回下回りました。原則として同条件を維持します。',
      );
    }
    return result(
      code: ProgressionResultCodes.multipleBelow,
      valid: true,
      reason: '複数セットが目標下限を下回りました。連続した場合は負荷を見直します。',
    );
  }

  double? _metric({
    required ProgressionExerciseInput input,
    required int totalReps,
    required int totalDuration,
    required double? weight,
    required double? assistance,
  }) {
    if (input.targetModeCode == 'DURATION' ||
        input.recordingMethodCode == 'DURATION') {
      return totalDuration.toDouble();
    }
    if (input.progressionGroupCode == 'PG07_ASSISTANCE_REVERSE') {
      if (assistance == null) return totalReps.toDouble();
      return (100000 - assistance * 100) + totalReps;
    }
    if (weight != null) return weight * 10000 + totalReps;
    return totalReps.toDouble();
  }
}
