import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/database/providers/database_providers.dart';
import 'package:workout_menu_app/features/progression/data/local_progression_repository.dart';
import 'package:workout_menu_app/features/progression/domain/progression_models.dart';
import 'package:workout_menu_app/features/progression/domain/progression_repository.dart';

final progressionRepositoryProvider = Provider<ProgressionRepository>((ref) {
  return LocalProgressionRepository(ref.watch(appDatabaseProvider));
});

final progressionProposalsProvider = AsyncNotifierProvider<
    ProgressionProposalsNotifier, List<ProgressionProposalView>>(
  ProgressionProposalsNotifier.new,
);

final pendingProposalCountProvider = FutureProvider<int>((ref) async {
  return ref.watch(progressionRepositoryProvider).pendingProposalCount();
});

final class ProgressionProposalsNotifier
    extends AsyncNotifier<List<ProgressionProposalView>> {
  @override
  Future<List<ProgressionProposalView>> build() async {
    final repository = ref.watch(progressionRepositoryProvider);
    await repository.processUnevaluatedSessions();
    return repository.loadProposals();
  }

  Future<void> decide({
    required String proposalId,
    required String decisionCode,
  }) async {
    state = const AsyncLoading<List<ProgressionProposalView>>();
    try {
      final repository = ref.read(progressionRepositoryProvider);
      await repository.decideProposal(
        proposalId: proposalId,
        decisionCode: decisionCode,
      );
      state = AsyncData<List<ProgressionProposalView>>(
        await repository.loadProposals(),
      );
      ref.invalidate(pendingProposalCountProvider);
    } catch (error, stackTrace) {
      state = AsyncError<List<ProgressionProposalView>>(error, stackTrace);
    }
  }
}
