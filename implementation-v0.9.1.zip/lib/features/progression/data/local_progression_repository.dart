import 'dart:convert';

import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/features/progression/domain/progression_engine.dart';
import 'package:workout_menu_app/features/progression/domain/progression_models.dart';
import 'package:workout_menu_app/features/progression/domain/progression_repository.dart';
import 'package:workout_menu_app/features/progression/domain/result_classifier.dart';

final class LocalProgressionRepository implements ProgressionRepository {
  const LocalProgressionRepository(
    this._database, {
    IdGenerator idGenerator = const UuidV7Generator(),
    ResultClassifier classifier = const ResultClassifier(),
    ProgressionEngine engine = const ProgressionEngine(),
  })  : _idGenerator = idGenerator,
        _classifier = classifier,
        _engine = engine;

  final AppDatabase _database;
  final IdGenerator _idGenerator;
  final ResultClassifier _classifier;
  final ProgressionEngine _engine;

  @override
  Future<void> processUnevaluatedSessions() async {
    final userId = await _requiredUserId();
    final rows = await _database.customSelect(
      '''
      SELECT ws.id
      FROM workout_session ws
      JOIN post_workout_assessment pa
        ON pa.workout_session_id = ws.id
       AND pa.deleted_at IS NULL
      WHERE ws.user_id = ?
        AND ws.deleted_at IS NULL
        AND ws.status_code IN ('COMPLETED', 'PARTIAL')
        AND EXISTS (
          SELECT 1
          FROM session_exercise se
          WHERE se.workout_session_id = ws.id
            AND se.deleted_at IS NULL
            AND se.status_code IN ('COMPLETED', 'PARTIAL')
            AND NOT EXISTS (
              SELECT 1
              FROM session_exercise_evaluation ev
              WHERE ev.session_exercise_id = se.id
                AND ev.deleted_at IS NULL
            )
        )
      ORDER BY ws.started_at ASC
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    for (final row in rows) {
      await processCompletedSession(row.read<String>('id'));
    }
  }

  @override
  Future<void> processCompletedSession(String workoutSessionId) async {
    final headerRows = await _database.customSelect(
      '''
      SELECT
        ws.id,
        ws.user_id,
        ws.rule_version_id,
        ws.status_code,
        ws.training_location_id,
        ws.record_date,
        pa.overall_difficulty_score,
        pa.had_pain,
        pa.incomplete_reason_code,
        COALESCE(wi.sleep_score, 3) AS sleep_score,
        COALESCE(
          (SELECT ug.goal_code
           FROM user_goal ug
           WHERE ug.user_id = ws.user_id
             AND ug.deleted_at IS NULL
             AND ug.goal_type = 'PRIMARY'
           ORDER BY ug.display_order ASC
           LIMIT 1),
          'HEALTH'
        ) AS goal_code,
        COALESCE(
          (SELECT uep.calculated_level_code
           FROM user_experience_profile uep
           WHERE uep.user_id = ws.user_id
             AND uep.deleted_at IS NULL
           ORDER BY uep.updated_at DESC
           LIMIT 1),
          'BEGINNER'
        ) AS experience_level_code
      FROM workout_session ws
      JOIN post_workout_assessment pa
        ON pa.workout_session_id = ws.id
       AND pa.deleted_at IS NULL
      LEFT JOIN workout_day_plan wdp ON wdp.id = ws.workout_day_plan_id
      LEFT JOIN weekly_menu wm ON wm.id = wdp.weekly_menu_id
      LEFT JOIN weekly_input wi
        ON wi.training_week_id = wm.training_week_id
       AND wi.deleted_at IS NULL
      WHERE ws.id = ?
        AND ws.deleted_at IS NULL
        AND ws.status_code IN ('COMPLETED', 'PARTIAL')
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(workoutSessionId)],
    ).get();
    if (headerRows.isEmpty) return;
    final header = headerRows.first;
    final userId = header.read<String>('user_id');
    final ruleVersionId = header.read<String>('rule_version_id');
    final locationId = header.readNullable<String>('training_location_id');
    final difficulty = header.read<int>('overall_difficulty_score');
    final hadSessionPain = header.read<int>('had_pain') == 1;
    final incompleteReason = header.readNullable<String>('incomplete_reason_code');
    final sleepScore = header.read<int>('sleep_score');
    final rawGoalCode = header.read<String>('goal_code');
    final goalCode = <String>{'HYPERTROPHY', 'STRENGTH', 'HEALTH'}
            .contains(rawGoalCode)
        ? rawGoalCode
        : 'HEALTH';
    final experienceLevel = header.read<String>('experience_level_code');

    final exerciseRows = await _database.customSelect(
      '''
      SELECT
        se.id,
        se.exercise_id,
        se.exercise_name_snapshot,
        se.recording_method_snapshot,
        se.status_code,
        em.role_code,
        COALESCE(epp.progression_group_code, 'PG02_WEIGHTED_ACCESSORY') AS progression_group_code,
        COALESCE(epp.target_mode_code, 'REPS') AS target_mode_code,
        COALESCE(epp.set_upper, se.target_set_count, 3) AS profile_set_upper
      FROM session_exercise se
      JOIN exercise_master em ON em.id = se.exercise_id
      LEFT JOIN exercise_progression_profile epp
        ON epp.exercise_id = se.exercise_id
       AND epp.goal_code = ?
       AND epp.experience_level_code = ?
       AND epp.is_active = 1
      WHERE se.workout_session_id = ?
        AND se.deleted_at IS NULL
        AND se.status_code IN ('COMPLETED', 'PARTIAL')
        AND NOT EXISTS (
          SELECT 1
          FROM session_exercise_evaluation ev
          WHERE ev.session_exercise_id = se.id
            AND ev.deleted_at IS NULL
        )
      ORDER BY se.order_index ASC
      ''',
      variables: <Variable<Object>>[
        Variable.withString(goalCode),
        Variable.withString(experienceLevel),
        Variable.withString(workoutSessionId),
      ],
    ).get();

    for (final exerciseRow in exerciseRows) {
      final sessionExerciseId = exerciseRow.read<String>('id');
      final exerciseId = exerciseRow.read<String>('exercise_id');
      final exerciseName = exerciseRow.read<String>('exercise_name_snapshot');
      final progressionGroup = exerciseRow.read<String>('progression_group_code');
      final targetMode = exerciseRow.read<String>('target_mode_code');
      final setRows = await _loadSetRows(sessionExerciseId);
      final samples = setRows.map(_sampleFromRow).toList(growable: false);
      final exercisePain = await _hasExercisePain(
        workoutSessionId: workoutSessionId,
        sessionExerciseId: sessionExerciseId,
      );
      final input = ProgressionExerciseInput(
        userId: userId,
        workoutSessionId: workoutSessionId,
        sessionExerciseId: sessionExerciseId,
        exerciseId: exerciseId,
        exerciseName: exerciseName,
        roleCode: exerciseRow.read<String>('role_code'),
        recordingMethodCode:
            exerciseRow.read<String>('recording_method_snapshot'),
        progressionGroupCode: progressionGroup,
        targetModeCode: targetMode,
        goalCode: goalCode,
        difficultyScore: difficulty,
        sleepScore: sleepScore,
        statusCode: exerciseRow.read<String>('status_code'),
        hadPain: hadSessionPain || exercisePain,
        incompleteReasonCode: incompleteReason,
        sets: samples,
      );
      final classification = _classifier.classify(input);
      final seriesKey = _seriesKey(exerciseId, samples);
      final now = DateTime.now().toUtc().toIso8601String();
      final seriesId = await _ensureSeries(
        userId: userId,
        exerciseId: exerciseId,
        seriesKey: seriesKey,
        exerciseName: exerciseName,
        progressionGroup: progressionGroup,
        targetMode: targetMode,
        recordedAt: now,
      );
      final previous = await _loadPreviousEvaluation(seriesId);
      final progress = _detectProgress(classification, previous);
      final comparisonDelta = previous?.metricValue == null ||
              classification.metricValue == null
          ? null
          : classification.metricValue! - previous!.metricValue!;
      final stallCount = _nextStallCount(
        classification: classification,
        previous: previous,
        progressDetected: progress,
      );
      final evaluationId = _idGenerator.next();

      await _database.transaction(() async {
        await _database.customStatement(
          '''
          INSERT INTO session_exercise_evaluation (
            id, user_id, rule_version_id, session_exercise_id,
            workout_session_id, performance_series_id, evaluated_at,
            result_class_code, valid_for_performance, work_set_count,
            representative_weight_kg, representative_assistance_value,
            total_reps, minimum_reps, maximum_reps, total_duration_sec,
            progression_metric_value, comparison_delta, progress_detected,
            stall_count_after, pain_detected, incomplete_reason_code,
            reason_text_snapshot, input_snapshot_json,
            created_at, updated_at, row_version, sync_status
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'LOCAL_ONLY')
          ''',
          <Object?>[
            evaluationId,
            userId,
            ruleVersionId,
            sessionExerciseId,
            workoutSessionId,
            seriesId,
            now,
            classification.code,
            classification.validForPerformance ? 1 : 0,
            classification.workSetCount,
            classification.representativeWeightKg,
            classification.representativeAssistanceValue,
            classification.totalReps,
            classification.minimumReps,
            classification.maximumReps,
            classification.totalDurationSec,
            classification.metricValue,
            comparisonDelta,
            progress ? 1 : 0,
            stallCount,
            input.hadPain ? 1 : 0,
            incompleteReason,
            classification.reasonText,
            jsonEncode(<String, Object?>{
              'input': <String, Object?>{
                'goalCode': goalCode,
                'experienceLevelCode': experienceLevel,
                'difficultyScore': difficulty,
                'sleepScore': sleepScore,
                'statusCode': input.statusCode,
                'progressionGroupCode': progressionGroup,
                'targetModeCode': targetMode,
              },
              'sets': samples.map((e) => e.toJson()).toList(),
              'classification': classification.toJson(),
            }),
            now,
            now,
          ],
        );
        await _database.customStatement(
          '''
          UPDATE exercise_performance_series
          SET last_recorded_at = ?,
              latest_session_exercise_id = ?,
              valid_session_count = valid_session_count + ?,
              stall_count = ?,
              pain_count = pain_count + ?,
              last_result_class_code = ?,
              baseline_set_count = COALESCE(baseline_set_count, ?),
              baseline_metric_value = COALESCE(baseline_metric_value, ?),
              updated_at = ?,
              row_version = row_version + 1,
              sync_status = 'LOCAL_ONLY'
          WHERE id = ?
          ''',
          <Object?>[
            now,
            sessionExerciseId,
            classification.validForPerformance ? 1 : 0,
            stallCount,
            input.hadPain ? 1 : 0,
            classification.code,
            classification.workSetCount,
            classification.metricValue,
            now,
            seriesId,
          ],
        );
        await _database.customStatement(
          '''
          UPDATE session_exercise
          SET performance_series_key = ?, updated_at = ?, row_version = row_version + 1
          WHERE id = ?
          ''',
          <Object?>[seriesKey, now, sessionExerciseId],
        );
        await _database.customStatement(
          '''
          UPDATE progression_proposal
          SET cooldown_remaining_sessions = cooldown_remaining_sessions - 1,
              updated_at = ?,
              row_version = row_version + 1
          WHERE user_id = ?
            AND exercise_id = ?
            AND status_code IN ('MAINTAINED', 'REJECTED')
            AND cooldown_remaining_sessions > 0
            AND deleted_at IS NULL
          ''',
          <Object?>[now, userId, exerciseId],
        );

        final consecutiveUpper = await _countConsecutiveResult(
          seriesId,
          ProgressionResultCodes.allUpper,
        );
        final consecutiveLow = await _countConsecutiveLow(seriesId);
        final weightOptions = await _registeredWeights(
          userId: userId,
          exerciseId: exerciseId,
          locationId: locationId,
        );
        final currentWeight = classification.representativeWeightKg;
        final draft = _engine.propose(
          ProgressionDecisionContext(
            input: input,
            classification: classification,
            previous: previous,
            stallCount: stallCount,
            consecutiveAllUpper: consecutiveUpper,
            consecutiveLow: consecutiveLow,
            currentSetCount: classification.workSetCount,
            profileSetUpper: exerciseRow.read<int>('profile_set_upper'),
            nextRegisteredWeightKg:
                _nextHigher(weightOptions, currentWeight),
            previousRegisteredWeightKg:
                _nextLower(weightOptions, currentWeight),
            nextRegisteredAssistanceValue: _nextLower(
              weightOptions,
              classification.representativeAssistanceValue,
            ),
          ),
        );
        if (draft != null) {
          await _insertProposal(
            userId: userId,
            ruleVersionId: ruleVersionId,
            exerciseId: exerciseId,
            sessionId: workoutSessionId,
            evaluationId: evaluationId,
            seriesKey: seriesKey,
            draft: draft,
          );
        }
      });
    }
  }

  Future<List<QueryRow>> _loadSetRows(String sessionExerciseId) {
    return _database.customSelect(
      '''
      SELECT
        wr.set_number,
        wr.side_code,
        wr.is_warmup,
        wr.actual_weight_kg,
        wr.actual_reps,
        wr.actual_duration_sec,
        wr.assistance_value,
        wr.variation_code,
        wr.equipment_mode_code,
        wr.machine_instance_key,
        st.target_reps_lower,
        st.target_reps_upper,
        st.target_duration_sec
      FROM work_set_record wr
      LEFT JOIN session_set_target st
        ON st.session_exercise_id = wr.session_exercise_id
       AND st.set_number = wr.set_number
       AND st.deleted_at IS NULL
      WHERE wr.session_exercise_id = ?
        AND wr.voided_at IS NULL
      ORDER BY wr.set_number ASC, wr.completed_at ASC
      ''',
      variables: <Variable<Object>>[Variable.withString(sessionExerciseId)],
    ).get();
  }

  ProgressionSetSample _sampleFromRow(QueryRow row) {
    return ProgressionSetSample(
      setNumber: row.read<int>('set_number'),
      sideCode: row.read<String>('side_code'),
      isWarmup: row.read<int>('is_warmup') == 1,
      actualWeightKg: row.readNullable<double>('actual_weight_kg'),
      actualReps: row.readNullable<int>('actual_reps'),
      actualDurationSec: row.readNullable<int>('actual_duration_sec'),
      assistanceValue: row.readNullable<double>('assistance_value'),
      variationCode: row.readNullable<String>('variation_code'),
      equipmentModeCode: row.readNullable<String>('equipment_mode_code'),
      machineInstanceKey: row.readNullable<String>('machine_instance_key'),
      targetRepsLower: row.readNullable<int>('target_reps_lower'),
      targetRepsUpper: row.readNullable<int>('target_reps_upper'),
      targetDurationSec: row.readNullable<int>('target_duration_sec'),
    );
  }

  Future<bool> _hasExercisePain({
    required String workoutSessionId,
    required String sessionExerciseId,
  }) async {
    final row = await _database.customSelect(
      '''
      SELECT 1 AS found
      FROM session_pain_entry
      WHERE workout_session_id = ?
        AND (session_exercise_id = ? OR session_exercise_id IS NULL)
        AND voided_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(workoutSessionId),
        Variable.withString(sessionExerciseId),
      ],
    ).get();
    return row.isNotEmpty;
  }

  String _seriesKey(String exerciseId, List<ProgressionSetSample> samples) {
    String dimension(String? Function(ProgressionSetSample value) read, String fallback) {
      final values = samples
          .where((e) => !e.isWarmup)
          .map(read)
          .whereType<String>()
          .where((e) => e.isNotEmpty)
          .toSet();
      if (values.isEmpty) return fallback;
      if (values.length > 1) return 'MIXED';
      return values.single;
    }
    final sides = samples
        .where((e) => !e.isWarmup)
        .map((e) => e.sideCode)
        .toSet();
    return <String>[
      exerciseId,
      'mode:${dimension((e) => e.equipmentModeCode, 'DEFAULT')}',
      'machine:${dimension((e) => e.machineInstanceKey, 'NONE')}',
      'variation:${dimension((e) => e.variationCode, 'STANDARD')}',
      'side:${sides.length == 1 ? sides.single : 'MIXED'}',
    ].join('|');
  }

  Future<String> _ensureSeries({
    required String userId,
    required String exerciseId,
    required String seriesKey,
    required String exerciseName,
    required String progressionGroup,
    required String targetMode,
    required String recordedAt,
  }) async {
    final rows = await _database.customSelect(
      '''
      SELECT id
      FROM exercise_performance_series
      WHERE user_id = ? AND series_key = ? AND deleted_at IS NULL
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(seriesKey),
      ],
    ).get();
    if (rows.isNotEmpty) return rows.first.read<String>('id');
    final id = _idGenerator.next();
    await _database.customStatement(
      '''
      INSERT INTO exercise_performance_series (
        id, user_id, exercise_id, series_key, display_name_snapshot,
        progression_group_code, target_mode_code, first_recorded_at,
        last_recorded_at, valid_session_count, stall_count, pain_count,
        created_at, updated_at, row_version, sync_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?, 1, 'LOCAL_ONLY')
      ''',
      <Object?>[
        id,
        userId,
        exerciseId,
        seriesKey,
        exerciseName,
        progressionGroup,
        targetMode,
        recordedAt,
        recordedAt,
        recordedAt,
        recordedAt,
      ],
    );
    return id;
  }

  Future<PreviousEvaluationSnapshot?> _loadPreviousEvaluation(String seriesId) async {
    final rows = await _database.customSelect(
      '''
      SELECT
        result_class_code, work_set_count, total_reps,
        total_duration_sec, minimum_reps,
        representative_weight_kg, representative_assistance_value,
        progression_metric_value, stall_count_after
      FROM session_exercise_evaluation
      WHERE performance_series_id = ? AND deleted_at IS NULL
      ORDER BY evaluated_at DESC
      LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(seriesId)],
    ).get();
    if (rows.isEmpty) return null;
    final row = rows.first;
    return PreviousEvaluationSnapshot(
      resultCode: row.read<String>('result_class_code'),
      workSetCount: row.read<int>('work_set_count'),
      totalReps: row.read<int>('total_reps'),
      totalDurationSec: row.read<int>('total_duration_sec'),
      minimumReps: row.readNullable<int>('minimum_reps'),
      representativeWeightKg:
          row.readNullable<double>('representative_weight_kg'),
      representativeAssistanceValue:
          row.readNullable<double>('representative_assistance_value'),
      metricValue: row.readNullable<double>('progression_metric_value'),
      stallCount: row.read<int>('stall_count_after'),
    );
  }

  bool _detectProgress(
    ProgressionClassification current,
    PreviousEvaluationSnapshot? previous,
  ) {
    if (!current.validForPerformance || previous == null) return false;
    if (current.workSetCount != previous.workSetCount) return false;
    final currentMetric = current.metricValue;
    final previousMetric = previous.metricValue;
    if (currentMetric != null && previousMetric != null && currentMetric > previousMetric) {
      return true;
    }
    if (current.totalReps > previous.totalReps) return true;
    if (current.totalReps == previous.totalReps &&
        current.minimumReps != null &&
        previous.minimumReps != null &&
        current.minimumReps! > previous.minimumReps!) {
      return true;
    }
    return false;
  }

  int _nextStallCount({
    required ProgressionClassification classification,
    required PreviousEvaluationSnapshot? previous,
    required bool progressDetected,
  }) {
    if (!classification.validForPerformance) return previous?.stallCount ?? 0;
    if (previous == null || progressDetected ||
        previous.workSetCount != classification.workSetCount) {
      return 0;
    }
    return previous.stallCount + 1;
  }

  Future<int> _countConsecutiveResult(String seriesId, String code) async {
    final rows = await _database.customSelect(
      '''
      SELECT result_class_code
      FROM session_exercise_evaluation
      WHERE performance_series_id = ?
        AND deleted_at IS NULL
        AND valid_for_performance = 1
      ORDER BY evaluated_at DESC
      LIMIT 3
      ''',
      variables: <Variable<Object>>[Variable.withString(seriesId)],
    ).get();
    var count = 0;
    for (final row in rows) {
      if (row.read<String>('result_class_code') != code) break;
      count++;
    }
    return count;
  }

  Future<int> _countConsecutiveLow(String seriesId) async {
    const lows = <String>{
      ProgressionResultCodes.severeMiss,
      ProgressionResultCodes.multipleBelow,
      ProgressionResultCodes.fatigueIncomplete,
    };
    final rows = await _database.customSelect(
      '''
      SELECT result_class_code
      FROM session_exercise_evaluation
      WHERE performance_series_id = ?
        AND deleted_at IS NULL
        AND valid_for_performance = 1
      ORDER BY evaluated_at DESC
      LIMIT 3
      ''',
      variables: <Variable<Object>>[Variable.withString(seriesId)],
    ).get();
    var count = 0;
    for (final row in rows) {
      if (!lows.contains(row.read<String>('result_class_code'))) break;
      count++;
    }
    return count;
  }

  Future<List<double>> _registeredWeights({
    required String userId,
    required String exerciseId,
    required String? locationId,
  }) async {
    if (locationId == null) return const <double>[];
    final rows = await _database.customSelect(
      '''
      SELECT DISTINCT
        le.id AS location_equipment_id,
        ewo.weight_value,
        COALESCE(lbd.shaft_weight_kg, le.min_weight) AS min_weight,
        COALESCE(lbd.max_total_weight_kg, le.max_weight) AS max_weight,
        COALESCE(lbd.min_increment_kg, le.increment_weight) AS increment_weight
      FROM exercise_equipment ee
      JOIN location_equipment le
        ON le.equipment_id = ee.equipment_id
       AND le.user_id = ?
       AND le.training_location_id = ?
       AND le.deleted_at IS NULL
       AND le.is_available = 1
      LEFT JOIN equipment_weight_option ewo
        ON ewo.location_equipment_id = le.id
       AND ewo.deleted_at IS NULL
      LEFT JOIN location_barbell_detail lbd
        ON lbd.location_equipment_id = le.id
       AND lbd.deleted_at IS NULL
      WHERE ee.exercise_id = ?
      ORDER BY ewo.weight_value ASC
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(locationId),
        Variable.withString(exerciseId),
      ],
    ).get();
    final values = <double>{};
    final generatedEquipment = <String>{};
    for (final row in rows) {
      final explicit = row.readNullable<double>('weight_value');
      if (explicit != null) values.add(explicit);
      final equipmentId = row.read<String>('location_equipment_id');
      if (!generatedEquipment.add(equipmentId)) continue;
      final minimum = row.readNullable<double>('min_weight');
      final maximum = row.readNullable<double>('max_weight');
      final increment = row.readNullable<double>('increment_weight');
      if (minimum == null || maximum == null || increment == null ||
          increment <= 0 || maximum < minimum) {
        continue;
      }
      var value = minimum;
      var guard = 0;
      while (value <= maximum + 0.0001 && guard < 500) {
        values.add((value * 1000).round() / 1000);
        value += increment;
        guard++;
      }
    }
    final sorted = values.toList()..sort();
    return sorted;
  }

  double? _nextHigher(List<double> values, double? current) {
    if (current == null) return null;
    for (final value in values) {
      if (value > current + 0.0001) return value;
    }
    return null;
  }

  double? _nextLower(List<double> values, double? current) {
    if (current == null) return null;
    for (final value in values.reversed) {
      if (value < current - 0.0001) return value;
    }
    return null;
  }

  Future<void> _insertProposal({
    required String userId,
    required String ruleVersionId,
    required String exerciseId,
    required String sessionId,
    required String evaluationId,
    required String seriesKey,
    required ProgressionProposalDraft draft,
  }) async {
    final suppressed = await _database.customSelect(
      '''
      SELECT 1 AS found
      FROM progression_proposal
      WHERE user_id = ?
        AND exercise_id = ?
        AND proposal_type_code = ?
        AND deleted_at IS NULL
        AND (
          status_code IN ('PENDING', 'DEFERRED')
          OR cooldown_remaining_sessions > 0
          OR EXISTS (
            SELECT 1 FROM accepted_progression_adjustment apa
            WHERE apa.progression_proposal_id = progression_proposal.id
              AND apa.status_code IN ('QUEUED', 'REVIEW_REQUIRED')
              AND apa.deleted_at IS NULL
          )
        )
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(exerciseId),
        Variable.withString(draft.typeCode),
      ],
    ).get();
    if (suppressed.isNotEmpty) return;
    final now = DateTime.now().toUtc().toIso8601String();
    final proposalKey = '$exerciseId|$seriesKey|${draft.typeCode}';
    await _database.customStatement(
      '''
      INSERT INTO progression_proposal (
        id, user_id, rule_version_id, exercise_id,
        performance_series_key, source_workout_session_id,
        source_evaluation_id, proposal_key, proposal_type_code,
        priority, current_value_json, proposed_value_json,
        reason_text_snapshot, status_code, cooldown_remaining_sessions,
        created_at, updated_at, row_version, sync_status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', 0, ?, ?, 1, 'LOCAL_ONLY')
      ''',
      <Object?>[
        _idGenerator.next(),
        userId,
        ruleVersionId,
        exerciseId,
        seriesKey,
        sessionId,
        evaluationId,
        proposalKey,
        draft.typeCode,
        draft.priority,
        draft.currentValueJson,
        draft.proposedValueJson,
        draft.reasonText,
        now,
        now,
      ],
    );
  }

  @override
  Future<List<ProgressionProposalView>> loadProposals({
    Set<String> statusCodes = const <String>{'PENDING', 'DEFERRED'},
  }) async {
    final userId = await _requiredUserId();
    final rows = await _database.customSelect(
      '''
      SELECT pp.*, em.name_ja AS exercise_name
      FROM progression_proposal pp
      LEFT JOIN exercise_master em ON em.id = pp.exercise_id
      WHERE pp.user_id = ? AND pp.deleted_at IS NULL
      ORDER BY
        CASE pp.status_code WHEN 'PENDING' THEN 0 WHEN 'DEFERRED' THEN 1 ELSE 2 END,
        pp.priority ASC,
        pp.created_at DESC
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).get();
    return rows
        .where((row) => statusCodes.contains(row.read<String>('status_code')))
        .map((row) => ProgressionProposalView(
              id: row.read<String>('id'),
              exerciseId: row.readNullable<String>('exercise_id') ?? '',
              exerciseName:
                  row.readNullable<String>('exercise_name') ?? '種目',
              typeCode: row.read<String>('proposal_type_code'),
              statusCode: row.read<String>('status_code'),
              reasonText: row.read<String>('reason_text_snapshot'),
              createdAt: DateTime.parse(row.read<String>('created_at')),
              priority: row.read<int>('priority'),
              currentValue:
                  decodeObjectJson(row.readNullable<String>('current_value_json')),
              proposedValue:
                  decodeObjectJson(row.read<String>('proposed_value_json')),
            ))
        .toList(growable: false);
  }

  @override
  Future<int> pendingProposalCount() async {
    final userId = await _requiredUserId();
    final row = await _database.customSelect(
      '''
      SELECT COUNT(*) AS count
      FROM progression_proposal
      WHERE user_id = ?
        AND deleted_at IS NULL
        AND status_code IN ('PENDING', 'DEFERRED')
      ''',
      variables: <Variable<Object>>[Variable.withString(userId)],
    ).getSingle();
    return row.read<int>('count');
  }

  @override
  Future<void> decideProposal({
    required String proposalId,
    required String decisionCode,
  }) async {
    final rows = await _database.customSelect(
      '''
      SELECT * FROM progression_proposal
      WHERE id = ? AND deleted_at IS NULL LIMIT 1
      ''',
      variables: <Variable<Object>>[Variable.withString(proposalId)],
    ).get();
    if (rows.isEmpty) throw StateError('Proposal not found.');
    final row = rows.first;
    final userId = row.read<String>('user_id');
    final now = DateTime.now().toUtc().toIso8601String();
    final status = switch (decisionCode) {
      ProposalDecisionCodes.accept => 'ACCEPTED',
      ProposalDecisionCodes.maintain => 'MAINTAINED',
      ProposalDecisionCodes.defer => 'DEFERRED',
      ProposalDecisionCodes.reject => 'REJECTED',
      _ => throw ArgumentError.value(decisionCode, 'decisionCode'),
    };
    final cooldown = switch (decisionCode) {
      ProposalDecisionCodes.maintain => 1,
      ProposalDecisionCodes.reject => 2,
      _ => 0,
    };
    String? targetPlannedExerciseId;
    String applicationResult = 'NOT_APPLICABLE';
    await _database.transaction(() async {
      if (decisionCode == ProposalDecisionCodes.accept) {
        final adjustmentId = _idGenerator.next();
        final typeCode = row.read<String>('proposal_type_code');
        final directlyApplicable = _isDirectlyApplicable(typeCode);
        final adjustmentStatus =
            directlyApplicable ? 'QUEUED' : 'REVIEW_REQUIRED';
        await _database.customStatement(
          '''
          INSERT INTO accepted_progression_adjustment (
            id, user_id, progression_proposal_id, exercise_id,
            performance_series_key, adjustment_type_code, payload_json,
            status_code, queued_at, created_at, updated_at,
            row_version, sync_status
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'LOCAL_ONLY')
          ''',
          <Object?>[
            adjustmentId,
            userId,
            proposalId,
            row.read<String>('exercise_id'),
            row.readNullable<String>('performance_series_key'),
            typeCode,
            row.read<String>('proposed_value_json'),
            adjustmentStatus,
            now,
            now,
            now,
          ],
        );
        if (directlyApplicable) {
          targetPlannedExerciseId = await _applyAdjustmentNow(
            adjustmentId: adjustmentId,
            userId: userId,
            exerciseId: row.read<String>('exercise_id'),
            typeCode: typeCode,
            payload: decodeObjectJson(row.read<String>('proposed_value_json')),
            now: now,
          );
          applicationResult = targetPlannedExerciseId == null
              ? 'QUEUED_FOR_NEXT_MENU'
              : 'APPLIED_TO_FUTURE_PLAN';
        } else {
          applicationResult = 'MANUAL_REVIEW_REQUIRED';
        }
      }
      await _database.customStatement(
        '''
        UPDATE progression_proposal
        SET status_code = ?, cooldown_remaining_sessions = ?,
            applied_at = ?, updated_at = ?, row_version = row_version + 1,
            sync_status = 'LOCAL_ONLY'
        WHERE id = ?
        ''',
        <Object?>[
          status,
          cooldown,
          decisionCode == ProposalDecisionCodes.accept ? now : null,
          now,
          proposalId,
        ],
      );
      await _database.customStatement(
        '''
        INSERT INTO progression_proposal_decision (
          id, user_id, progression_proposal_id, decision_code,
          applies_to_code, decided_at, application_result_code,
          target_planned_exercise_id, created_at, sync_status
        ) VALUES (?, ?, ?, ?, 'NEXT_MATCHING_SESSION', ?, ?, ?, ?, 'LOCAL_ONLY')
        ''',
        <Object?>[
          _idGenerator.next(),
          userId,
          proposalId,
          decisionCode,
          now,
          applicationResult,
          targetPlannedExerciseId,
          now,
        ],
      );
    });
  }

  Future<String?> _applyAdjustmentNow({
    required String adjustmentId,
    required String userId,
    required String exerciseId,
    required String typeCode,
    required Map<String, Object?> payload,
    required String now,
  }) async {
    if (!_isDirectlyApplicable(typeCode)) return null;
    final rows = await _database.customSelect(
      '''
      SELECT pe.id
      FROM planned_exercise pe
      JOIN workout_day_plan wdp ON wdp.id = pe.workout_day_plan_id
      JOIN weekly_menu wm ON wm.id = wdp.weekly_menu_id
      WHERE pe.user_id = ?
        AND pe.exercise_id = ?
        AND pe.deleted_at IS NULL
        AND pe.status_code = 'PLANNED'
        AND wdp.deleted_at IS NULL
        AND wdp.status_code = 'PLANNED'
        AND wdp.plan_date >= date('now', 'localtime')
        AND wm.deleted_at IS NULL
        AND wm.is_active = 1
      ORDER BY wdp.plan_date ASC, pe.order_index ASC
      LIMIT 1
      ''',
      variables: <Variable<Object>>[
        Variable.withString(userId),
        Variable.withString(exerciseId),
      ],
    ).get();
    if (rows.isEmpty) return null;
    final plannedExerciseId = rows.first.read<String>('id');
    await applyAdjustmentToPlannedExercise(
      database: _database,
      plannedExerciseId: plannedExerciseId,
      typeCode: typeCode,
      payload: payload,
      now: now,
    );
    await _database.customStatement(
      '''
      UPDATE accepted_progression_adjustment
      SET status_code = 'APPLIED', target_planned_exercise_id = ?,
          applied_at = ?, consumed_at = ?, updated_at = ?,
          row_version = row_version + 1
      WHERE id = ?
      ''',
      <Object?>[plannedExerciseId, now, now, now, adjustmentId],
    );
    return plannedExerciseId;
  }

  bool _isDirectlyApplicable(String typeCode) => <String>{
        ProgressionProposalTypes.increaseWeight,
        ProgressionProposalTypes.reduceWeight,
        ProgressionProposalTypes.extendReps,
        ProgressionProposalTypes.increaseDuration,
        ProgressionProposalTypes.reduceAssistance,
        ProgressionProposalTypes.addSet,
        ProgressionProposalTypes.reduceSet,
      }.contains(typeCode);

  static Future<void> applyAdjustmentToPlannedExercise({
    required AppDatabase database,
    required String plannedExerciseId,
    required String typeCode,
    required Map<String, Object?> payload,
    required String now,
  }) async {
    if (typeCode == ProgressionProposalTypes.increaseWeight ||
        typeCode == ProgressionProposalTypes.reduceWeight) {
      final value = (payload['weightKg'] as num?)?.toDouble();
      if (value != null) {
        await database.customStatement(
          '''
          UPDATE planned_set
          SET target_weight_kg = ?, input_weight_value = ?,
              input_weight_unit_code = 'KG', updated_at = ?,
              row_version = row_version + 1
          WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
          ''',
          <Object?>[value, value, now, plannedExerciseId],
        );
      }
    } else if (typeCode == ProgressionProposalTypes.extendReps) {
      final value = (payload['targetRepsUpper'] as num?)?.toInt();
      if (value != null) {
        await database.customStatement(
          '''
          UPDATE planned_set
          SET target_reps_upper = ?, updated_at = ?, row_version = row_version + 1
          WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
          ''',
          <Object?>[value, now, plannedExerciseId],
        );
      }
    } else if (typeCode == ProgressionProposalTypes.increaseDuration) {
      final value = (payload['targetDurationSec'] as num?)?.toInt();
      if (value != null) {
        await database.customStatement(
          '''
          UPDATE planned_set
          SET target_duration_sec = ?, updated_at = ?, row_version = row_version + 1
          WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
          ''',
          <Object?>[value, now, plannedExerciseId],
        );
      }
    } else if (typeCode == ProgressionProposalTypes.reduceAssistance) {
      final value = (payload['assistanceValue'] as num?)?.toDouble();
      if (value != null) {
        await database.customStatement(
          '''
          UPDATE planned_set
          SET target_assistance_value = ?, updated_at = ?, row_version = row_version + 1
          WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
          ''',
          <Object?>[value, now, plannedExerciseId],
        );
      }
    } else if (typeCode == ProgressionProposalTypes.addSet) {
      final maxRow = await database.customSelect(
        '''
        SELECT MAX(set_number) AS max_set, MAX(rest_sec) AS rest_sec,
               MAX(target_weight_kg) AS target_weight_kg,
               MAX(input_weight_value) AS input_weight_value,
               MAX(input_weight_unit_code) AS input_weight_unit_code,
               MAX(target_reps_lower) AS target_reps_lower,
               MAX(target_reps_upper) AS target_reps_upper,
               MAX(target_duration_sec) AS target_duration_sec,
               MAX(target_assistance_value) AS target_assistance_value,
               MAX(user_id) AS user_id, MAX(rule_version_id) AS rule_version_id
        FROM planned_set
        WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
        ''',
        variables: <Variable<Object>>[Variable.withString(plannedExerciseId)],
      ).getSingle();
      final maxSet = maxRow.readNullable<int>('max_set');
      if (maxSet != null) {
        final id = const UuidV7Generator().next();
        await database.customStatement(
          '''
          INSERT INTO planned_set (
            id, user_id, rule_version_id, created_at, updated_at,
            row_version, sync_status, planned_exercise_id, set_number,
            is_warmup, target_weight_kg, input_weight_value,
            input_weight_unit_code, target_reps_lower, target_reps_upper,
            target_duration_sec, target_assistance_value, rest_sec
          ) VALUES (?, ?, ?, ?, ?, 1, 'LOCAL_ONLY', ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?)
          ''',
          <Object?>[
            id,
            maxRow.read<String>('user_id'),
            maxRow.read<String>('rule_version_id'),
            now,
            now,
            plannedExerciseId,
            maxSet + 1,
            maxRow.readNullable<double>('target_weight_kg'),
            maxRow.readNullable<double>('input_weight_value'),
            maxRow.readNullable<String>('input_weight_unit_code'),
            maxRow.readNullable<int>('target_reps_lower'),
            maxRow.readNullable<int>('target_reps_upper'),
            maxRow.readNullable<int>('target_duration_sec'),
            maxRow.readNullable<double>('target_assistance_value'),
            maxRow.read<int>('rest_sec'),
          ],
        );
      }
    } else if (typeCode == ProgressionProposalTypes.reduceSet) {
      await database.customStatement(
        '''
        UPDATE planned_set
        SET deleted_at = ?, updated_at = ?, row_version = row_version + 1
        WHERE id = (
          SELECT id FROM planned_set
          WHERE planned_exercise_id = ? AND deleted_at IS NULL AND is_warmup = 0
          ORDER BY set_number DESC LIMIT 1
        )
        ''',
        <Object?>[now, now, plannedExerciseId],
      );
    }
  }

  Future<String> _requiredUserId() async {
    final rows = await _database.customSelect(
      '''
      SELECT id FROM user_account
      WHERE deleted_at IS NULL AND account_status = 'ACTIVE'
      ORDER BY created_at ASC LIMIT 1
      ''',
    ).get();
    if (rows.isEmpty) throw StateError('Active user not found.');
    return rows.first.read<String>('id');
  }
}
