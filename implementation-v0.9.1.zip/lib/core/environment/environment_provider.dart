import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/environment/app_environment.dart';

final appEnvironmentProvider = Provider<AppEnvironment>((ref) {
  throw StateError('AppEnvironment must be overridden during bootstrap.');
});
