enum AppFlavor {
  dev,
  stg,
  prod;

  static AppFlavor fromValue(String value) {
    return AppFlavor.values.firstWhere(
      (AppFlavor flavor) => flavor.name == value,
      orElse: () => AppFlavor.dev,
    );
  }
}

final class AppEnvironment {
  const AppEnvironment({
    required this.flavor,
    required this.supabaseUrl,
    required this.supabasePublishableKey,
    required this.syncEnabled,
  });

  factory AppEnvironment.fromDartDefines() {
    return AppEnvironment(
      flavor: AppFlavor.fromValue(
        const String.fromEnvironment('APP_FLAVOR', defaultValue: 'dev'),
      ),
      supabaseUrl: const String.fromEnvironment('SUPABASE_URL'),
      supabasePublishableKey:
          const String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY'),
      syncEnabled: const bool.fromEnvironment(
        'SYNC_ENABLED',
        defaultValue: false,
      ),
    );
  }

  final AppFlavor flavor;
  final String supabaseUrl;
  final String supabasePublishableKey;
  final bool syncEnabled;

  bool get hasSupabaseConfiguration =>
      supabaseUrl.isNotEmpty && supabasePublishableKey.isNotEmpty;
}
