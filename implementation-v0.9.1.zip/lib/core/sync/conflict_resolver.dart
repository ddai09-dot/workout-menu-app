import 'package:workout_menu_app/core/sync/sync_models.dart';

final class ConflictResolver {
  const ConflictResolver();

  ConflictResolution resolve({
    required VersionedEntity local,
    required VersionedEntity remote,
  }) {
    if (local.entityType == 'work_set_record' || local.entityType == 'workout_session_event') {
      return ConflictResolution.appendMerge;
    }
    if (local.entityType == 'workout_session' && local.payload['status_code'] == 'IN_PROGRESS') {
      return ConflictResolution.localWins;
    }
    if (remote.rowVersion > local.rowVersion) return ConflictResolution.remoteWins;
    if (local.rowVersion > remote.rowVersion) return ConflictResolution.localWins;
    return remote.updatedAt.isAfter(local.updatedAt)
        ? ConflictResolution.remoteWins
        : ConflictResolution.localWins;
  }
}
