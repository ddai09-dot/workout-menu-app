import 'package:workout_menu_app/core/environment/app_environment.dart';
import 'package:workout_menu_app/core/sync/sync_gateway.dart';

final class OutboxSyncService {
  const OutboxSyncService({
    required AppEnvironment environment,
    required SyncGateway gateway,
  })  : _environment = environment,
        _gateway = gateway;

  final AppEnvironment _environment;
  final SyncGateway _gateway;

  Future<SyncRunResult> runOnce() async {
    if (!_environment.syncEnabled) {
      return const SyncRunResult(
        pushedCount: 0,
        pulledCount: 0,
        hasConflict: false,
      );
    }

    return _gateway.pushAndPull();
  }
}
