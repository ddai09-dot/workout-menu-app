enum SyncStateCode { disabled, idle, running, offline, pending, failed }

enum ConflictResolution { localWins, remoteWins, appendMerge, manualHold }

final class SyncStatusSnapshot {
  const SyncStatusSnapshot({
    required this.state,
    required this.pendingCount,
    required this.lastSuccessAt,
    this.safeErrorCode,
  });
  final SyncStateCode state;
  final int pendingCount;
  final DateTime? lastSuccessAt;
  final String? safeErrorCode;
}

final class VersionedEntity {
  const VersionedEntity({
    required this.entityType,
    required this.entityId,
    required this.rowVersion,
    required this.updatedAt,
    required this.payload,
  });
  final String entityType;
  final String entityId;
  final int rowVersion;
  final DateTime updatedAt;
  final Map<String, Object?> payload;
}
