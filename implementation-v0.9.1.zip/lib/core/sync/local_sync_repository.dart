import 'dart:convert';
import 'package:drift/drift.dart';
import 'package:workout_menu_app/core/database/app_database.dart';
import 'package:workout_menu_app/core/ids/id_generator.dart';
import 'package:workout_menu_app/core/sync/sync_gateway.dart';
import 'package:workout_menu_app/core/sync/sync_models.dart';
import 'package:workout_menu_app/core/sync/sync_repository.dart';

final class LocalSyncRepository implements SyncRepository {
  LocalSyncRepository({
    required AppDatabase database,
    required IdGenerator idGenerator,
    required SyncGateway gateway,
  })  : _db = database,
        _ids = idGenerator,
        _gateway = gateway;

  final AppDatabase _db;
  final IdGenerator _ids;
  final SyncGateway _gateway;

  @override
  Future<void> enqueue({
    required String userId,
    required String entityType,
    required String entityId,
    required String operationCode,
    required Map<String, Object?> payload,
  }) async {
    final key = '$userId:$entityType:$entityId:$operationCode:${DateTime.now().microsecondsSinceEpoch}';
    await _db.customStatement(
      'INSERT INTO sync_outbox(id,user_id,entity_type,entity_id,operation_code,payload_json,idempotency_key,status_code) VALUES (?,?,?,?,?,?,?,?)',
      <Object?>[_ids.next(), userId, entityType, entityId, operationCode, jsonEncode(payload), key, 'PENDING'],
    );
  }

  @override
  Stream<SyncStatusSnapshot> watchStatus(String userId) async* {
    yield await _status(userId);
    await for (final _ in _db.select(_db.syncOutbox).watch()) {
      yield await _status(userId);
    }
  }

  Future<SyncStatusSnapshot> _status(String userId) async {
    final row = (await _db.customSelect(
      "SELECT COUNT(*) AS pending_count FROM sync_outbox WHERE user_id=? AND status_code IN ('PENDING','RETRY')",
      variables: <Variable<Object>>[Variable<String>(userId)],
    ).get()).single;
    final pending = row.read<int>('pending_count');
    return SyncStatusSnapshot(
      state: pending > 0 ? SyncStateCode.pending : SyncStateCode.idle,
      pendingCount: pending,
      lastSuccessAt: null,
    );
  }

  @override
  Future<SyncStatusSnapshot> synchronize({
    required String userId,
    required String deviceId,
    required String triggerCode,
  }) async {
    final runId = _ids.next();
    final startedAt = DateTime.now().toUtc().toIso8601String();
    await _db.customStatement(
      "INSERT INTO sync_run_history(id,user_id,device_id,started_at,trigger_code,result_code) VALUES (?,?,?,?,?,'RUNNING')",
      <Object?>[runId, userId, deviceId, startedAt, triggerCode],
    );
    try {
      final result = await _gateway.pushAndPull();
      final now = DateTime.now().toUtc().toIso8601String();
      await _db.transaction(() async {
        await _db.customStatement(
          "UPDATE sync_run_history SET finished_at=?,result_code='SUCCESS',pushed_count=?,pulled_count=?,conflict_count=? WHERE id=?",
          <Object?>[now, result.pushedCount, result.pulledCount, result.hasConflict ? 1 : 0, runId],
        );
        await _db.customStatement(
          "INSERT INTO sync_checkpoint(id,user_id,device_id,scope_code,last_push_at,last_pull_at,last_success_at,updated_at) VALUES (?,?,?,'USER_DATA',?,?,?,?) ON CONFLICT(user_id,device_id,scope_code) DO UPDATE SET last_push_at=excluded.last_push_at,last_pull_at=excluded.last_pull_at,last_success_at=excluded.last_success_at,updated_at=excluded.updated_at",
          <Object?>[_ids.next(), userId, deviceId, now, now, now, now],
        );
      });
      return SyncStatusSnapshot(state: SyncStateCode.idle, pendingCount: 0, lastSuccessAt: DateTime.parse(now));
    } catch (_) {
      await _db.customStatement(
        "UPDATE sync_run_history SET finished_at=CURRENT_TIMESTAMP,result_code='FAILED',error_code='SYNC_FAILED',error_message_safe='同期に失敗しました' WHERE id=?",
        <Object?>[runId],
      );
      return const SyncStatusSnapshot(
        state: SyncStateCode.failed,
        pendingCount: 0,
        lastSuccessAt: null,
        safeErrorCode: 'SYNC_FAILED',
      );
    }
  }
}
