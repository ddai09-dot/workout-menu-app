import 'package:workout_menu_app/core/sync/sync_models.dart';

abstract interface class SyncRepository {
  Stream<SyncStatusSnapshot> watchStatus(String userId);
  Future<void> enqueue({
    required String userId,
    required String entityType,
    required String entityId,
    required String operationCode,
    required Map<String, Object?> payload,
  });
  Future<SyncStatusSnapshot> synchronize({
    required String userId,
    required String deviceId,
    required String triggerCode,
  });
}
