abstract interface class SyncGateway {
  Future<SyncRunResult> pushAndPull();
}

final class SyncRunResult {
  const SyncRunResult({
    required this.pushedCount,
    required this.pulledCount,
    required this.hasConflict,
  });

  final int pushedCount;
  final int pulledCount;
  final bool hasConflict;
}
