import 'package:uuid/uuid.dart';

abstract interface class IdGenerator {
  String next();
}

final class UuidV7Generator implements IdGenerator {
  const UuidV7Generator({
    Uuid uuid = const Uuid(),
  }) : _uuid = uuid;

  final Uuid _uuid;

  @override
  String next() => _uuid.v7();
}
