import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';

part 'app_database.g.dart';

@DriftDatabase(include: <String>{'schema/schema_v9.drift'})
final class AppDatabase extends _$AppDatabase {
  AppDatabase([QueryExecutor? executor])
      : super(executor ?? driftDatabase(name: 'workout_menu_app'));

  @override
  int get schemaVersion => 9;

  @override
  MigrationStrategy get migration {
    return MigrationStrategy(
      onCreate: (Migrator migrator) async {
        await migrator.createAll();
      },
      onUpgrade: (Migrator migrator, int from, int to) async {
        var current = from;
        if (current < 2 && to >= 2) {
          await _migrateToV2();
          current = 2;
        }
        if (current < 3 && to >= 3) {
          await _migrateToV3();
          current = 3;
        }
        if (current < 4 && to >= 4) {
          await _migrateToV4();
          current = 4;
        }
        if (current < 5 && to >= 5) {
          await _migrateToV5();
          current = 5;
        }
        if (current < 6 && to >= 6) {
          await _migrateToV6();
          current = 6;
        }
        if (current < 7 && to >= 7) {
          await _migrateToV7();
          current = 7;
        }
        if (current < 8 && to >= 8) {
          await _migrateToV8();
          current = 8;
        }
        if (current < 9 && to >= 9) {
          await _migrateToV9();
          current = 9;
        }
        if (current != to) {
          throw StateError(
            'Missing migration path: schema $from to $to. '
            'Add and test the migration before increasing schemaVersion.',
          );
        }
      },
      beforeOpen: (OpeningDetails details) async {
        await customStatement('PRAGMA foreign_keys = ON');
      },
    );
  }

  Future<void> _migrateToV2() async {
    await customStatement(
      "ALTER TABLE user_experience_profile ADD COLUMN "
      "adjustment_habit_code TEXT NOT NULL DEFAULT 'NONE'",
    );
    await customStatement(
      "ALTER TABLE user_experience_profile ADD COLUMN "
      "logging_habit_code TEXT NOT NULL DEFAULT 'NONE'",
    );
    await customStatement(
      'ALTER TABLE user_restriction ADD COLUMN '
      'joint_id TEXT REFERENCES joint_master(id) ON DELETE RESTRICT',
    );
    await customStatement('DROP INDEX IF EXISTS uq_location_equipment');
    await customStatement(
      'CREATE INDEX IF NOT EXISTS ix_location_equipment '
      'ON location_equipment(training_location_id, equipment_id)',
    );
    await customStatement('''
      CREATE TABLE IF NOT EXISTS location_dumbbell_detail (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        deleted_at TEXT,
        row_version INTEGER NOT NULL DEFAULT 1,
        sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
        source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
        location_equipment_id TEXT NOT NULL REFERENCES location_equipment(id) ON DELETE RESTRICT,
        setup_type_code TEXT NOT NULL,
        unit_count INTEGER NOT NULL DEFAULT 1
      )
    ''');
    await customStatement('''
      CREATE TABLE IF NOT EXISTS location_barbell_detail (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        deleted_at TEXT,
        row_version INTEGER NOT NULL DEFAULT 1,
        sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
        source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
        location_equipment_id TEXT NOT NULL REFERENCES location_equipment(id) ON DELETE RESTRICT,
        shaft_weight_kg REAL NOT NULL,
        max_total_weight_kg REAL NOT NULL,
        min_increment_kg REAL NOT NULL,
        has_rack INTEGER NOT NULL DEFAULT 0,
        has_safety INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await customStatement('''
      CREATE TABLE IF NOT EXISTS onboarding_draft (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        current_step_code TEXT NOT NULL DEFAULT 'INTRO',
        draft_json TEXT NOT NULL,
        status_code TEXT NOT NULL DEFAULT 'IN_PROGRESS',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        deleted_at TEXT,
        row_version INTEGER NOT NULL DEFAULT 1
      )
    ''');
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_active_onboarding_draft '
      "ON onboarding_draft(user_id) WHERE status_code = 'IN_PROGRESS' "
      'AND deleted_at IS NULL',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_dumbbell_detail '
      'ON location_dumbbell_detail(location_equipment_id) '
      'WHERE deleted_at IS NULL',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_barbell_detail '
      'ON location_barbell_detail(location_equipment_id) '
      'WHERE deleted_at IS NULL',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_active_user_profile '
      'ON user_profile(user_id) WHERE deleted_at IS NULL',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_active_training_setting '
      'ON user_training_setting(user_id) WHERE deleted_at IS NULL',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_active_experience_profile '
      'ON user_experience_profile(user_id) WHERE deleted_at IS NULL',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_active_app_preference '
      'ON app_preference(user_id) WHERE deleted_at IS NULL',
    );
  }

  Future<void> _migrateToV3() async {
    await customStatement('''
      CREATE TABLE IF NOT EXISTS weekly_planner_draft (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
        week_start_date TEXT NOT NULL,
        current_step_code TEXT NOT NULL DEFAULT 'START',
        draft_json TEXT NOT NULL,
        status_code TEXT NOT NULL DEFAULT 'IN_PROGRESS',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        deleted_at TEXT,
        row_version INTEGER NOT NULL DEFAULT 1,
        sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
      )
    ''');
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_active_weekly_planner_draft '
      'ON weekly_planner_draft(user_id, week_start_date) '
      "WHERE status_code = 'IN_PROGRESS' AND deleted_at IS NULL",
    );
    await customStatement(
      "ALTER TABLE weekly_input ADD COLUMN priority_mode_code "
      "TEXT NOT NULL DEFAULT 'DEFAULT'",
    );
    await customStatement(
      "ALTER TABLE weekly_menu ADD COLUMN generation_trace_json "
      "TEXT NOT NULL DEFAULT '{}'",
    );
    await customStatement(
      'ALTER TABLE weekly_menu ADD COLUMN estimated_total_min '
      'INTEGER NOT NULL DEFAULT 0',
    );
    await customStatement(
      'ALTER TABLE workout_day_plan ADD COLUMN estimated_duration_min '
      'INTEGER NOT NULL DEFAULT 0',
    );
    await customStatement(
      'ALTER TABLE planned_exercise ADD COLUMN selection_score '
      'INTEGER NOT NULL DEFAULT 0',
    );
    await customStatement(
      "ALTER TABLE planned_exercise ADD COLUMN selection_reason_ids_json "
      "TEXT NOT NULL DEFAULT '[]'",
    );
    await customStatement('DROP INDEX IF EXISTS uq_weekly_priority');
    await customStatement('DROP INDEX IF EXISTS uq_weekly_priority_part');
    await customStatement('DROP INDEX IF EXISTS uq_weekly_main_priority');
    await customStatement(
      'CREATE UNIQUE INDEX uq_weekly_priority_part '
      'ON weekly_priority_part(training_week_id, priority_type, body_part_id) '
      'WHERE deleted_at IS NULL',
    );
    await customStatement(
      'CREATE UNIQUE INDEX uq_weekly_main_priority '
      'ON weekly_priority_part(training_week_id) '
      "WHERE priority_type = 'MAIN' AND deleted_at IS NULL",
    );
    await customStatement('DROP INDEX IF EXISTS uq_weekly_day');
    await customStatement(
      'CREATE UNIQUE INDEX uq_weekly_day '
      'ON weekly_available_day(training_week_id, weekday_code) '
      'WHERE deleted_at IS NULL',
    );
  }
  Future<void> _migrateToV4() async {
    await customStatement(
      "ALTER TABLE workout_session ADD COLUMN current_input_draft_json "
      "TEXT NOT NULL DEFAULT '{}'",
    );
    await customStatement(
      "ALTER TABLE workout_session ADD COLUMN last_interaction_at "
      "TEXT NOT NULL DEFAULT ''",
    );
    await customStatement(
      "UPDATE workout_session SET last_interaction_at = "
      "COALESCE(last_local_saved_at, updated_at, created_at, "
      "'1970-01-01T00:00:00Z') WHERE last_interaction_at = ''",
    );
    await customStatement(
      'ALTER TABLE workout_session ADD COLUMN completion_reason_code TEXT',
    );
    await customStatement(
      'ALTER TABLE session_exercise ADD COLUMN skip_reason_code TEXT',
    );
    await customStatement(
      'ALTER TABLE session_exercise ADD COLUMN started_at TEXT',
    );
    await customStatement(
      'ALTER TABLE session_exercise ADD COLUMN ended_at TEXT',
    );
    await customStatement(
      'ALTER TABLE session_exercise ADD COLUMN original_order_index '
      'INTEGER NOT NULL DEFAULT 1',
    );
    await customStatement(
      'ALTER TABLE session_exercise ADD COLUMN original_set_count '
      'INTEGER NOT NULL DEFAULT 0',
    );
    await customStatement(
      'ALTER TABLE session_exercise ADD COLUMN target_set_count '
      'INTEGER NOT NULL DEFAULT 0',
    );
    await customStatement(
      'ALTER TABLE work_set_record ADD COLUMN rest_duration_sec INTEGER',
    );
    await customStatement(
      'ALTER TABLE work_set_record ADD COLUMN correction_reason_code TEXT',
    );
    await customStatement('''
      CREATE TABLE IF NOT EXISTS session_set_target (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        deleted_at TEXT,
        row_version INTEGER NOT NULL DEFAULT 1,
        sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
        session_exercise_id TEXT NOT NULL REFERENCES session_exercise(id) ON DELETE RESTRICT,
        planned_set_id TEXT REFERENCES planned_set(id) ON DELETE RESTRICT,
        set_number INTEGER NOT NULL,
        is_warmup INTEGER NOT NULL DEFAULT 0,
        target_weight_kg REAL,
        input_weight_value REAL,
        input_weight_unit_code TEXT,
        target_reps_lower INTEGER,
        target_reps_upper INTEGER,
        target_duration_sec INTEGER,
        target_assistance_value REAL,
        rest_sec INTEGER NOT NULL,
        source_code TEXT NOT NULL DEFAULT 'PLANNED',
        CONSTRAINT ck_session_target_range CHECK (
          target_reps_lower IS NULL OR target_reps_upper IS NULL OR
          target_reps_lower <= target_reps_upper
        )
      )
    ''');
    await customStatement('''
      CREATE TABLE IF NOT EXISTS workout_session_event (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
        session_exercise_id TEXT REFERENCES session_exercise(id) ON DELETE RESTRICT,
        event_type_code TEXT NOT NULL,
        payload_json TEXT NOT NULL DEFAULT '{}',
        occurred_at TEXT NOT NULL,
        sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
        source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT
      )
    ''');
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_session_set_target '
      'ON session_set_target(session_exercise_id, set_number) '
      'WHERE deleted_at IS NULL',
    );
    await customStatement(
      'CREATE INDEX IF NOT EXISTS ix_session_events '
      'ON workout_session_event(workout_session_id, occurred_at)',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_post_workout_assessment '
      'ON post_workout_assessment(workout_session_id) '
      'WHERE deleted_at IS NULL',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_open_workout_session '
      'ON workout_session(user_id) '
      "WHERE status_code IN ('IN_PROGRESS', 'AWAITING_ASSESSMENT') "
      'AND deleted_at IS NULL',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_active_work_set '
      'ON work_set_record(session_exercise_id, set_number, side_code) '
      'WHERE voided_at IS NULL',
    );
  }


  Future<void> _migrateToV5() async {
    await customStatement(
      'ALTER TABLE progression_proposal ADD COLUMN '
      'source_evaluation_id TEXT',
    );
    await customStatement(
      "ALTER TABLE progression_proposal ADD COLUMN "
      "proposal_key TEXT NOT NULL DEFAULT ''",
    );
    await customStatement(
      'ALTER TABLE progression_proposal ADD COLUMN '
      'priority INTEGER NOT NULL DEFAULT 100',
    );
    await customStatement(
      'ALTER TABLE progression_proposal ADD COLUMN expires_at TEXT',
    );
    await customStatement(
      'ALTER TABLE progression_proposal ADD COLUMN applied_at TEXT',
    );
    await customStatement('''
      CREATE TABLE IF NOT EXISTS exercise_performance_series (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
        series_key TEXT NOT NULL,
        display_name_snapshot TEXT NOT NULL,
        progression_group_code TEXT NOT NULL,
        target_mode_code TEXT NOT NULL,
        first_recorded_at TEXT NOT NULL,
        last_recorded_at TEXT NOT NULL,
        latest_session_exercise_id TEXT REFERENCES session_exercise(id) ON DELETE RESTRICT,
        valid_session_count INTEGER NOT NULL DEFAULT 0,
        stall_count INTEGER NOT NULL DEFAULT 0,
        pain_count INTEGER NOT NULL DEFAULT 0,
        last_result_class_code TEXT,
        baseline_set_count INTEGER,
        baseline_metric_value REAL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        deleted_at TEXT,
        row_version INTEGER NOT NULL DEFAULT 1,
        sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
      )
    ''');
    await customStatement('''
      CREATE TABLE IF NOT EXISTS session_exercise_evaluation (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        rule_version_id TEXT NOT NULL REFERENCES rule_version(id) ON DELETE RESTRICT,
        session_exercise_id TEXT NOT NULL REFERENCES session_exercise(id) ON DELETE RESTRICT,
        workout_session_id TEXT NOT NULL REFERENCES workout_session(id) ON DELETE RESTRICT,
        performance_series_id TEXT NOT NULL REFERENCES exercise_performance_series(id) ON DELETE RESTRICT,
        evaluated_at TEXT NOT NULL,
        result_class_code TEXT NOT NULL,
        valid_for_performance INTEGER NOT NULL DEFAULT 0,
        work_set_count INTEGER NOT NULL DEFAULT 0,
        representative_weight_kg REAL,
        representative_assistance_value REAL,
        total_reps INTEGER NOT NULL DEFAULT 0,
        minimum_reps INTEGER,
        maximum_reps INTEGER,
        total_duration_sec INTEGER NOT NULL DEFAULT 0,
        progression_metric_value REAL,
        comparison_delta REAL,
        progress_detected INTEGER NOT NULL DEFAULT 0,
        stall_count_after INTEGER NOT NULL DEFAULT 0,
        pain_detected INTEGER NOT NULL DEFAULT 0,
        incomplete_reason_code TEXT,
        reason_text_snapshot TEXT NOT NULL,
        input_snapshot_json TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        deleted_at TEXT,
        row_version INTEGER NOT NULL DEFAULT 1,
        sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
      )
    ''');
    await customStatement('''
      CREATE TABLE IF NOT EXISTS progression_proposal_decision (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        progression_proposal_id TEXT NOT NULL REFERENCES progression_proposal(id) ON DELETE RESTRICT,
        decision_code TEXT NOT NULL,
        applies_to_code TEXT NOT NULL DEFAULT 'NEXT_MATCHING_SESSION',
        decision_reason_code TEXT,
        decided_at TEXT NOT NULL,
        application_result_code TEXT,
        target_planned_exercise_id TEXT REFERENCES planned_exercise(id) ON DELETE RESTRICT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
      )
    ''');
    await customStatement('''
      CREATE TABLE IF NOT EXISTS accepted_progression_adjustment (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        progression_proposal_id TEXT NOT NULL REFERENCES progression_proposal(id) ON DELETE RESTRICT,
        exercise_id TEXT NOT NULL REFERENCES exercise_master(id) ON DELETE RESTRICT,
        performance_series_key TEXT,
        adjustment_type_code TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        status_code TEXT NOT NULL DEFAULT 'QUEUED',
        target_planned_exercise_id TEXT REFERENCES planned_exercise(id) ON DELETE RESTRICT,
        queued_at TEXT NOT NULL,
        applied_at TEXT,
        consumed_at TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        deleted_at TEXT,
        row_version INTEGER NOT NULL DEFAULT 1,
        sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY'
      )
    ''');
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_active_performance_series '
      'ON exercise_performance_series(user_id, series_key) '
      'WHERE deleted_at IS NULL',
    );
    await customStatement(
      'CREATE INDEX IF NOT EXISTS ix_performance_series_exercise '
      'ON exercise_performance_series(user_id, exercise_id, last_recorded_at)',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_session_exercise_evaluation '
      'ON session_exercise_evaluation(session_exercise_id) '
      'WHERE deleted_at IS NULL',
    );
    await customStatement(
      'CREATE INDEX IF NOT EXISTS ix_evaluation_series '
      'ON session_exercise_evaluation(performance_series_id, evaluated_at)',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_active_proposal_key '
      'ON progression_proposal(user_id, proposal_key) '
      "WHERE proposal_key <> '' AND status_code IN ('PENDING', 'DEFERRED') "
      'AND deleted_at IS NULL',
    );
    await customStatement(
      'CREATE INDEX IF NOT EXISTS ix_proposal_source_evaluation '
      'ON progression_proposal(source_evaluation_id)',
    );
    await customStatement(
      'CREATE INDEX IF NOT EXISTS ix_proposal_decision '
      'ON progression_proposal_decision(progression_proposal_id, decided_at)',
    );
    await customStatement(
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_active_progression_adjustment '
      'ON accepted_progression_adjustment(progression_proposal_id) '
      "WHERE status_code IN ('QUEUED', 'APPLIED') AND deleted_at IS NULL",
    );
    await customStatement(
      'CREATE INDEX IF NOT EXISTS ix_queued_adjustment_exercise '
      'ON accepted_progression_adjustment(user_id, exercise_id, status_code, queued_at)',
    );
    await customStatement('''
      CREATE TRIGGER IF NOT EXISTS ck_progression_proposal_source_insert
      BEFORE INSERT ON progression_proposal
      WHEN NEW.source_evaluation_id IS NOT NULL
       AND NOT EXISTS (
         SELECT 1 FROM session_exercise_evaluation
         WHERE id = NEW.source_evaluation_id AND deleted_at IS NULL
       )
      BEGIN
        SELECT RAISE(ABORT, 'invalid progression proposal source evaluation');
      END
    ''');
    await customStatement('''
      CREATE TRIGGER IF NOT EXISTS ck_progression_proposal_source_update
      BEFORE UPDATE OF source_evaluation_id ON progression_proposal
      WHEN NEW.source_evaluation_id IS NOT NULL
       AND NOT EXISTS (
         SELECT 1 FROM session_exercise_evaluation
         WHERE id = NEW.source_evaluation_id AND deleted_at IS NULL
       )
      BEGIN
        SELECT RAISE(ABORT, 'invalid progression proposal source evaluation');
      END
    ''');
  }

  Future<void> _migrateToV6() async {
    await customStatement(r"""
      CREATE TABLE IF NOT EXISTS account_link_history (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        event_code TEXT NOT NULL,
        provider_code TEXT NOT NULL,
        provider_subject_hash TEXT,
        occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
        metadata_json TEXT NOT NULL DEFAULT '{}'
      )
    """);
    await customStatement(r"""
      CREATE TABLE IF NOT EXISTS sync_checkpoint (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        device_id TEXT NOT NULL REFERENCES device_registration(id) ON DELETE RESTRICT,
        scope_code TEXT NOT NULL DEFAULT 'USER_DATA',
        server_cursor TEXT,
        last_push_at TEXT,
        last_pull_at TEXT,
        last_success_at TEXT,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    """);
    await customStatement(r"""
      CREATE TABLE IF NOT EXISTS sync_run_history (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        device_id TEXT NOT NULL REFERENCES device_registration(id) ON DELETE RESTRICT,
        started_at TEXT NOT NULL,
        finished_at TEXT,
        trigger_code TEXT NOT NULL,
        result_code TEXT NOT NULL DEFAULT 'RUNNING',
        pushed_count INTEGER NOT NULL DEFAULT 0,
        pulled_count INTEGER NOT NULL DEFAULT 0,
        conflict_count INTEGER NOT NULL DEFAULT 0,
        error_code TEXT,
        error_message_safe TEXT
      )
    """);
    await customStatement(r"""
      CREATE TABLE IF NOT EXISTS sync_conflict_log (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        sync_run_id TEXT REFERENCES sync_run_history(id) ON DELETE RESTRICT,
        entity_type TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        local_row_version INTEGER,
        remote_row_version INTEGER,
        resolution_code TEXT NOT NULL,
        local_payload_hash TEXT,
        remote_payload_hash TEXT,
        resolved_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    """);
    await customStatement(r"""
      CREATE TABLE IF NOT EXISTS account_deletion_request (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        requested_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        status_code TEXT NOT NULL DEFAULT 'PENDING',
        remote_request_id TEXT,
        completed_at TEXT,
        last_error_code TEXT,
        retry_count INTEGER NOT NULL DEFAULT 0
      )
    """);
    await customStatement('CREATE UNIQUE INDEX IF NOT EXISTS uq_sync_checkpoint ON sync_checkpoint(user_id, device_id, scope_code)');
    await customStatement('CREATE INDEX IF NOT EXISTS ix_sync_run_user_time ON sync_run_history(user_id, started_at)');
    await customStatement('CREATE INDEX IF NOT EXISTS ix_sync_conflict_entity ON sync_conflict_log(user_id, entity_type, entity_id)');
    await customStatement("CREATE UNIQUE INDEX IF NOT EXISTS uq_pending_account_deletion ON account_deletion_request(user_id) WHERE status_code IN ('PENDING','PROCESSING')");
    await customStatement('CREATE INDEX IF NOT EXISTS ix_account_link_history ON account_link_history(user_id, occurred_at)');
    await customStatement('CREATE INDEX IF NOT EXISTS ix_outbox_pending_v6 ON sync_outbox(user_id, status_code, next_retry_at)');
  }


  Future<void> _migrateToV7() async {
    const statements = <String>[
      '''CREATE TABLE IF NOT EXISTS ai_chat_session (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        title TEXT NOT NULL DEFAULT '', context_type_code TEXT NOT NULL DEFAULT 'GENERAL',
        context_entity_id TEXT, status_code TEXT NOT NULL DEFAULT 'ACTIVE',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT,
        row_version INTEGER NOT NULL DEFAULT 1, sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY')''',
      '''CREATE TABLE IF NOT EXISTS ai_chat_message (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        chat_session_id TEXT NOT NULL REFERENCES ai_chat_session(id) ON DELETE RESTRICT,
        role_code TEXT NOT NULL, content_text TEXT NOT NULL,
        safety_code TEXT NOT NULL DEFAULT 'OK', source_code TEXT NOT NULL DEFAULT 'MODEL',
        model_code TEXT, prompt_version TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT,
        row_version INTEGER NOT NULL DEFAULT 1, sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY')''',
      '''CREATE TABLE IF NOT EXISTS ai_prompt_template (
        id TEXT PRIMARY KEY NOT NULL, template_code TEXT NOT NULL,
        version_code TEXT NOT NULL, locale_code TEXT NOT NULL DEFAULT 'ja-JP',
        system_text TEXT NOT NULL, is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, retired_at TEXT)''',
      '''CREATE TABLE IF NOT EXISTS ai_response_cache (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        request_hash TEXT NOT NULL, context_hash TEXT NOT NULL,
        response_text TEXT NOT NULL, safety_code TEXT NOT NULL DEFAULT 'OK',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, expires_at TEXT NOT NULL)''',
      '''CREATE TABLE IF NOT EXISTS ai_feedback (
        id TEXT PRIMARY KEY NOT NULL,
        user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
        message_id TEXT NOT NULL REFERENCES ai_chat_message(id) ON DELETE RESTRICT,
        rating_code TEXT NOT NULL, reason_code TEXT, comment_text TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''',
      '''CREATE TABLE IF NOT EXISTS ai_faq (
        id TEXT PRIMARY KEY NOT NULL, category_code TEXT NOT NULL,
        question_text TEXT NOT NULL, answer_text TEXT NOT NULL,
        locale_code TEXT NOT NULL DEFAULT 'ja-JP', sort_order INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1, content_version TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''',
      '''CREATE TABLE IF NOT EXISTS ai_dictionary (
        id TEXT PRIMARY KEY NOT NULL, term_code TEXT NOT NULL,
        display_term TEXT NOT NULL, reading_text TEXT, definition_text TEXT NOT NULL,
        locale_code TEXT NOT NULL DEFAULT 'ja-JP', sort_order INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1, content_version TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''',
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_ai_prompt_version ON ai_prompt_template(template_code, version_code, locale_code)',
      "CREATE UNIQUE INDEX IF NOT EXISTS uq_ai_active_prompt ON ai_prompt_template(template_code, locale_code) WHERE is_active = 1",
      'CREATE INDEX IF NOT EXISTS ix_ai_chat_session_user_time ON ai_chat_session(user_id, updated_at)',
      'CREATE INDEX IF NOT EXISTS ix_ai_chat_message_session_time ON ai_chat_message(chat_session_id, created_at)',
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_ai_cache_request ON ai_response_cache(user_id, request_hash, context_hash)',
      'CREATE INDEX IF NOT EXISTS ix_ai_cache_expiry ON ai_response_cache(expires_at)',
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_ai_feedback_message ON ai_feedback(user_id, message_id)',
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_ai_faq_content ON ai_faq(locale_code, question_text, content_version)',
      'CREATE UNIQUE INDEX IF NOT EXISTS uq_ai_dictionary_term ON ai_dictionary(locale_code, term_code, content_version)',
    ];
    for (final statement in statements) {
      await customStatement(statement);
    }
  }


  Future<void> _migrateToV8() async {
    const statements = <String>[
      "CREATE TABLE IF NOT EXISTS notification_preference (id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT, notification_type_code TEXT NOT NULL, is_enabled INTEGER NOT NULL DEFAULT 1, local_time TEXT, weekday_mask INTEGER, advance_minutes INTEGER NOT NULL DEFAULT 0, sound_enabled INTEGER NOT NULL DEFAULT 1, vibration_enabled INTEGER NOT NULL DEFAULT 1, timezone TEXT NOT NULL DEFAULT 'Asia/Tokyo', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, deleted_at TEXT, row_version INTEGER NOT NULL DEFAULT 1, sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY')",
      "CREATE TABLE IF NOT EXISTS notification_schedule (id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT, notification_type_code TEXT NOT NULL, source_entity_type TEXT, source_entity_id TEXT, scheduled_at TEXT NOT NULL, timezone TEXT NOT NULL DEFAULT 'Asia/Tokyo', title_text TEXT NOT NULL, body_text TEXT NOT NULL, route_path TEXT, status_code TEXT NOT NULL DEFAULT 'SCHEDULED', platform_notification_id INTEGER NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, delivered_at TEXT, cancelled_at TEXT, deleted_at TEXT, row_version INTEGER NOT NULL DEFAULT 1, sync_status TEXT NOT NULL DEFAULT 'LOCAL_ONLY')",
      "CREATE TABLE IF NOT EXISTS notification_delivery_log (id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT, notification_schedule_id TEXT REFERENCES notification_schedule(id) ON DELETE RESTRICT, event_code TEXT NOT NULL, occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, platform_code TEXT NOT NULL DEFAULT 'IOS', app_state_code TEXT, error_code TEXT, error_message_safe TEXT)",
      "CREATE UNIQUE INDEX IF NOT EXISTS uq_notification_preference_active ON notification_preference(user_id, notification_type_code) WHERE deleted_at IS NULL",
      "CREATE UNIQUE INDEX IF NOT EXISTS uq_notification_platform_id ON notification_schedule(platform_notification_id) WHERE deleted_at IS NULL AND status_code = 'SCHEDULED'",
      "CREATE UNIQUE INDEX IF NOT EXISTS uq_notification_source_schedule ON notification_schedule(user_id, notification_type_code, source_entity_type, source_entity_id, scheduled_at) WHERE deleted_at IS NULL AND status_code = 'SCHEDULED'",
      'CREATE INDEX IF NOT EXISTS ix_notification_due ON notification_schedule(user_id, status_code, scheduled_at)',
      'CREATE INDEX IF NOT EXISTS ix_notification_delivery_time ON notification_delivery_log(user_id, occurred_at)',
    ];
    for (final statement in statements) {
      await customStatement(statement);
    }
  }


  Future<void> _migrateToV9() async {
    const statements = <String>[
      r"""ALTER TABLE notification_preference
ADD COLUMN source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT""",
      r"""CREATE TEMP TABLE _notification_existing_preference AS
SELECT user_id, notification_type_code, id AS preference_id
FROM notification_preference
WHERE deleted_at IS NULL""",
      r"""CREATE TEMP TABLE _notification_source_group AS
SELECT
  ns.user_id,
  ns.notification_type_code,
  'np_migrated_' || lower(hex(randomblob(16))) AS generated_preference_id,
  (
    SELECT n2.is_enabled
    FROM notification_setting n2
    WHERE n2.user_id = ns.user_id
      AND n2.notification_type_code = ns.notification_type_code
      AND n2.deleted_at IS NULL
    ORDER BY n2.updated_at DESC, n2.row_version DESC, n2.id DESC
    LIMIT 1
  ) AS is_enabled,
  (
    SELECT n2.time_local
    FROM notification_setting n2
    WHERE n2.user_id = ns.user_id
      AND n2.notification_type_code = ns.notification_type_code
      AND n2.deleted_at IS NULL
      AND n2.time_local IS NOT NULL
      AND trim(n2.time_local) <> ''
    ORDER BY n2.updated_at DESC, n2.row_version DESC, n2.id DESC
    LIMIT 1
  ) AS local_time,
  CASE
    WHEN MAX(
      CASE
        WHEN ns.weekday_code IS NULL
          OR trim(ns.weekday_code) = ''
          OR upper(trim(ns.weekday_code)) IN ('ALL', 'DAILY', 'EVERYDAY', 'ANY')
        THEN 1 ELSE 0
      END
    ) = 1 THEN NULL
    WHEN MAX(
      CASE
        WHEN upper(trim(ns.weekday_code)) IN (
          'MON', 'MONDAY', '1', '月', '月曜', '月曜日',
          'TUE', 'TUESDAY', '2', '火', '火曜', '火曜日',
          'WED', 'WEDNESDAY', '3', '水', '水曜', '水曜日',
          'THU', 'THURSDAY', '4', '木', '木曜', '木曜日',
          'FRI', 'FRIDAY', '5', '金', '金曜', '金曜日',
          'SAT', 'SATURDAY', '6', '土', '土曜', '土曜日',
          'SUN', 'SUNDAY', '7', '0', '日', '日曜', '日曜日'
        ) THEN 0 ELSE 1
      END
    ) = 1 THEN NULL
    ELSE SUM(DISTINCT CASE upper(trim(ns.weekday_code))
      WHEN 'MON' THEN 1 WHEN 'MONDAY' THEN 1 WHEN '1' THEN 1
      WHEN '月' THEN 1 WHEN '月曜' THEN 1 WHEN '月曜日' THEN 1
      WHEN 'TUE' THEN 2 WHEN 'TUESDAY' THEN 2 WHEN '2' THEN 2
      WHEN '火' THEN 2 WHEN '火曜' THEN 2 WHEN '火曜日' THEN 2
      WHEN 'WED' THEN 4 WHEN 'WEDNESDAY' THEN 4 WHEN '3' THEN 4
      WHEN '水' THEN 4 WHEN '水曜' THEN 4 WHEN '水曜日' THEN 4
      WHEN 'THU' THEN 8 WHEN 'THURSDAY' THEN 8 WHEN '4' THEN 8
      WHEN '木' THEN 8 WHEN '木曜' THEN 8 WHEN '木曜日' THEN 8
      WHEN 'FRI' THEN 16 WHEN 'FRIDAY' THEN 16 WHEN '5' THEN 16
      WHEN '金' THEN 16 WHEN '金曜' THEN 16 WHEN '金曜日' THEN 16
      WHEN 'SAT' THEN 32 WHEN 'SATURDAY' THEN 32 WHEN '6' THEN 32
      WHEN '土' THEN 32 WHEN '土曜' THEN 32 WHEN '土曜日' THEN 32
      WHEN 'SUN' THEN 64 WHEN 'SUNDAY' THEN 64 WHEN '7' THEN 64 WHEN '0' THEN 64
      WHEN '日' THEN 64 WHEN '日曜' THEN 64 WHEN '日曜日' THEN 64
    END)
  END AS weekday_mask,
  COALESCE((
    SELECT ap.sound_enabled
    FROM app_preference ap
    WHERE ap.user_id = ns.user_id AND ap.deleted_at IS NULL
    ORDER BY ap.updated_at DESC, ap.row_version DESC, ap.id DESC
    LIMIT 1
  ), 1) AS sound_enabled,
  COALESCE((SELECT ua.timezone FROM user_account ua WHERE ua.id = ns.user_id), 'Asia/Tokyo') AS timezone,
  MIN(ns.created_at) AS created_at,
  MAX(ns.updated_at) AS updated_at,
  MAX(ns.row_version) + 1 AS row_version,
  (
    SELECT n2.source_device_id
    FROM notification_setting n2
    WHERE n2.user_id = ns.user_id
      AND n2.notification_type_code = ns.notification_type_code
      AND n2.deleted_at IS NULL
    ORDER BY n2.updated_at DESC, n2.row_version DESC, n2.id DESC
    LIMIT 1
  ) AS source_device_id,
  COUNT(*) AS source_count,
  MAX(
    CASE
      WHEN ns.weekday_code IS NULL
        OR trim(ns.weekday_code) = ''
        OR upper(trim(ns.weekday_code)) IN (
          'ALL', 'DAILY', 'EVERYDAY', 'ANY',
          'MON', 'MONDAY', '1', '月', '月曜', '月曜日',
          'TUE', 'TUESDAY', '2', '火', '火曜', '火曜日',
          'WED', 'WEDNESDAY', '3', '水', '水曜', '水曜日',
          'THU', 'THURSDAY', '4', '木', '木曜', '木曜日',
          'FRI', 'FRIDAY', '5', '金', '金曜', '金曜日',
          'SAT', 'SATURDAY', '6', '土', '土曜', '土曜日',
          'SUN', 'SUNDAY', '7', '0', '日', '日曜', '日曜日'
        )
      THEN 0 ELSE 1
    END
  ) AS has_unknown_weekday
FROM notification_setting ns
WHERE ns.deleted_at IS NULL
GROUP BY ns.user_id, ns.notification_type_code""",
      r"""INSERT INTO notification_preference (
  id, user_id, notification_type_code, is_enabled, local_time,
  weekday_mask, advance_minutes, sound_enabled, vibration_enabled,
  timezone, created_at, updated_at, deleted_at, row_version,
  sync_status, source_device_id
)
SELECT
  g.generated_preference_id,
  g.user_id,
  g.notification_type_code,
  g.is_enabled,
  g.local_time,
  g.weekday_mask,
  0,
  g.sound_enabled,
  1,
  g.timezone,
  g.created_at,
  g.updated_at,
  NULL,
  g.row_version,
  'LOCAL_ONLY',
  g.source_device_id
FROM _notification_source_group g
LEFT JOIN _notification_existing_preference e
  ON e.user_id = g.user_id
 AND e.notification_type_code = g.notification_type_code
WHERE e.preference_id IS NULL""",
      r"""UPDATE notification_preference
SET source_device_id = (
  SELECT g.source_device_id
  FROM _notification_source_group g
  WHERE g.user_id = notification_preference.user_id
    AND g.notification_type_code = notification_preference.notification_type_code
)
WHERE source_device_id IS NULL
  AND deleted_at IS NULL
  AND EXISTS (
    SELECT 1
    FROM _notification_source_group g
    WHERE g.user_id = notification_preference.user_id
      AND g.notification_type_code = notification_preference.notification_type_code
      AND g.source_device_id IS NOT NULL
  )""",
      r"""CREATE TEMP TABLE _notification_preference_map AS
SELECT
  g.user_id,
  g.notification_type_code,
  COALESCE(e.preference_id, g.generated_preference_id) AS preference_id,
  CASE WHEN e.preference_id IS NULL THEN 0 ELSE 1 END AS used_existing
FROM _notification_source_group g
LEFT JOIN _notification_existing_preference e
  ON e.user_id = g.user_id
 AND e.notification_type_code = g.notification_type_code""",
      r"""CREATE TABLE notification_setting_legacy_archive (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES user_account(id) ON DELETE RESTRICT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  row_version INTEGER NOT NULL,
  sync_status TEXT NOT NULL,
  source_device_id TEXT REFERENCES device_registration(id) ON DELETE RESTRICT,
  notification_type_code TEXT NOT NULL,
  is_enabled INTEGER NOT NULL,
  time_local TEXT,
  weekday_code TEXT,
  migrated_preference_id TEXT REFERENCES notification_preference(id) ON DELETE RESTRICT,
  archived_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  migration_status_code TEXT NOT NULL,
  CONSTRAINT ck_notification_legacy_migration_status CHECK (
    migration_status_code IN (
      'MIGRATED', 'CONSOLIDATED', 'MAPPED_TO_EXISTING',
      'REVIEW_REQUIRED_WEEKDAY', 'DELETED_SOURCE'
    )
  )
)""",
      r"""INSERT INTO notification_setting_legacy_archive (
  id, user_id, created_at, updated_at, deleted_at, row_version,
  sync_status, source_device_id, notification_type_code, is_enabled,
  time_local, weekday_code, migrated_preference_id, archived_at,
  migration_status_code
)
SELECT
  ns.id,
  ns.user_id,
  ns.created_at,
  ns.updated_at,
  ns.deleted_at,
  ns.row_version,
  ns.sync_status,
  ns.source_device_id,
  ns.notification_type_code,
  ns.is_enabled,
  ns.time_local,
  ns.weekday_code,
  pm.preference_id,
  CURRENT_TIMESTAMP,
  CASE
    WHEN ns.deleted_at IS NOT NULL THEN 'DELETED_SOURCE'
    WHEN g.has_unknown_weekday = 1 THEN 'REVIEW_REQUIRED_WEEKDAY'
    WHEN pm.used_existing = 1 THEN 'MAPPED_TO_EXISTING'
    WHEN g.source_count > 1 THEN 'CONSOLIDATED'
    ELSE 'MIGRATED'
  END
FROM notification_setting ns
LEFT JOIN _notification_source_group g
  ON g.user_id = ns.user_id
 AND g.notification_type_code = ns.notification_type_code
LEFT JOIN _notification_preference_map pm
  ON pm.user_id = ns.user_id
 AND pm.notification_type_code = ns.notification_type_code""",
      r"""DROP TABLE notification_setting""",
      r"""CREATE INDEX ix_notification_setting_legacy_user_type
ON notification_setting_legacy_archive(user_id, notification_type_code, archived_at)""",
      r"""DROP TABLE _notification_preference_map""",
      r"""DROP TABLE _notification_source_group""",
      r"""DROP TABLE _notification_existing_preference""",
    ];
    for (final statement in statements) {
      await customStatement(statement);
    }
  }

}
