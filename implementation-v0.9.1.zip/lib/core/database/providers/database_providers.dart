import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:workout_menu_app/core/database/app_database.dart';

final appDatabaseProvider = Provider<AppDatabase>((ref) {
  throw StateError('AppDatabase must be overridden during bootstrap.');
});
