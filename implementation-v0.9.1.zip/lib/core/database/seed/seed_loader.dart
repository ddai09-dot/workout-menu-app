import 'package:drift/drift.dart';
import 'package:flutter/services.dart';
import 'package:workout_menu_app/core/database/app_database.dart';

final class SeedLoader {
  const SeedLoader(this._database);

  static const String _statementSeparator = '\n-- statement\n';

  final AppDatabase _database;

  Future<void> ensureSeeded() async {
    await _applySeedIfMissing(
      markerCode: 'SEED_V1',
      assetPath: 'assets/seed/seed_v1.sql',
    );
    await _applySeedIfMissing(
      markerCode: 'SEED_PATCH_V2',
      assetPath: 'assets/seed/seed_patch_v2.sql',
    );
    await _applySeedIfMissing(
      markerCode: 'SEED_PATCH_V3',
      assetPath: 'assets/seed/seed_patch_v3.sql',
    );
  }

  Future<void> _applySeedIfMissing({
    required String markerCode,
    required String assetPath,
  }) async {
    final existing = await _database.customSelect(
      'SELECT 1 AS found FROM rule_version WHERE code = ? LIMIT 1',
      variables: <Variable<Object>>[Variable.withString(markerCode)],
    ).get();

    if (existing.isNotEmpty) {
      return;
    }

    final sql = await rootBundle.loadString(assetPath);
    final statements = sql
        .split(_statementSeparator)
        .map((String value) => value.trim())
        .where((String value) => value.isNotEmpty);

    await _database.transaction(() async {
      for (final statement in statements) {
        await _database.customStatement(statement);
      }
    });
  }
}
