import 'package:workout_menu_app/app/bootstrap.dart';
import 'package:workout_menu_app/core/environment/app_environment.dart';

Future<void> main() async {
  await bootstrap(AppEnvironment.fromDartDefines());
}
